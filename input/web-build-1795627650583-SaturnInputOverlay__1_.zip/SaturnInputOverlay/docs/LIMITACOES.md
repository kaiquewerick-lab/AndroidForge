# Limitações de captura — Saturn Input Overlay

Este documento descreve, com honestidade, o que o Android permite capturar de fato.
O app **não usa root**, **não simula** eventos e **não exibe dados falsos**.

## Teclado (teclas de hardware USB / Bluetooth)

| Situação | Status |
|---|---|
| Teclas de letras, números, Shift, Ctrl, Alt, Tab, Esc, Enter, Espaço, setas, F1–F12 | Captura real via `AccessibilityService` com `canRequestFilterKeyEvents` |
| Teclas pressionadas simultaneamente | Suportado (cada tecla é rastreada individualmente) |
| Repetição automática ao segurar uma tecla | Ignorada; a tecla continua destacada até soltar |
| Tecla não prevista no layout | Aparece em uma faixa "extra" enquanto estiver pressionada |
| O jogo continua recebendo a tecla | Sim — o serviço nunca consome o evento (`onKeyEvent` retorna `false`) |
| Teclado da tela (virtual) do Android | Não gera eventos de hardware; não aparece no painel |
| Teclas de algumas marcas/modelos (ex.: teclas de função proprietárias, teclas de multimídia no firmware) | Depende do fabricante; podem não chegar ao serviço |

Requisito: ativar **Saturn Input Overlay** em *Configurações → Acessibilidade*.
O app declara `canRetrieveWindowContent=false`: não lê o conteúdo de telas nem o texto digitado.

## Mouse (USB / Bluetooth)

| Recurso pedido | Situação no Android |
|---|---|
| Clique esquerdo / direito | **Não capturável globalmente** por apps de terceiros sem root. Eventos de toque/mouse só chegam à activity que está em foco ou à view que o próprio app desenha. |
| Roda do mouse | Mesma limitação. |
| Movimento do mouse | Não entregue globalmente a apps comuns. |
| Detectar se há mouse conectado | **Sim** — `InputDevice` lista os dispositivos com `SOURCE_MOUSE`. O status "Mouse conectado" na tela principal é real. |

Consequência: o componente de mouse existe e está pronto para receber eventos (`{"type":"mouse","button":"left|right|wheel","down":true|false}`), mas
**nenhum evento de mouse global é gerado** nesta versão. Quando não há captura, o painel exibe
"Mouse: sem captura" em vez de simular cliques. Para capturar cliques globais seria necessário root
ou um dispositivo/ferramenta com privilégios de sistema — o que está fora do escopo deste projeto.

## Painel sobre outros apps

- Usa `TYPE_APPLICATION_OVERLAY` (Android 8+) com `SYSTEM_ALERT_WINDOW`.
- Por padrão **não** recebe toques (`FLAG_NOT_FOCUSABLE`), então não bloqueia os controles do jogo.
- A barra superior pode arrastar o painel. Em modo **BLOQ**, o painel fica totalmente "transparente a toques"; para desbloquear use a notificação.
- Alguns jogos com anti-cheat ou modo de tela cheia exclusiva podem ocultar sobreposições de outros apps.

## Ciclo de vida / Android 12–15

- Serviço em primeiro plano (`specialUse`) com notificação fixa e ações Ocultar / Bloquear / Parar.
- Android 14+ exige o tipo de serviço declarado no manifesto — já configurado.
- Android 13+ pede permissão de notificação ao iniciar.
- Se o Android encerrar o processo, o usuário precisa iniciar novamente pelo app (START_NOT_STICKY, para não reiniciar sem o usuário).
- Fabricantes com otimização agressiva de bateria (Xiaomi, Samsung etc.) podem encerrar o serviço; desative a otimização para o app.

## Desempenho

- O painel usa uma única WebView leve, sem animações pesadas. A opção "Animações" pode ser desligada.
- Eventos são entregues pelo barramento em memória (`InputBus`), sem gravação em disco.
- Nada é gravado nem enviado pela rede.
