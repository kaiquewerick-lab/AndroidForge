# Saturn Input Overlay

Painel flutuante para Android que mostra, em tempo real, as **teclas de hardware** pressionadas
(teclado USB ou Bluetooth) por cima de outros apps, como o Roblox.

> Leia **docs/LIMITACOES.md** antes de usar. O Android não permite capturar cliques globais
> de mouse sem root. O app informa isso no painel e não exibe dados falsos.

## Estrutura

```
SaturnInputOverlay/
├─ settings.gradle.kts / build.gradle.kts / gradle.properties
├─ gradle/wrapper/gradle-wrapper.properties
├─ app/
│  ├─ build.gradle.kts  proguard-rules.pro
│  └─ src/main/
│     ├─ AndroidManifest.xml
│     ├─ java/com/saturn/inputoverlay/
│     │  ├─ MainActivity.kt              tela principal (WebView + ponte "Android")
│     │  ├─ OverlayService.kt            painel flutuante (TYPE_APPLICATION_OVERLAY)
│     │  ├─ InputAccessibilityService.kt captura real de teclas de hardware
│     │  ├─ InputBus.kt                  barramento de eventos (memória)
│     │  └─ Prefs.kt                     configurações persistentes
│     ├─ assets/ui/
│     │  ├─ index.html                   tela inicial (INICIAR / CONFIGURAÇÕES / PERSONALIZAR)
│     │  ├─ overlay.html                 conteúdo do painel
│     │  ├─ css/app.css, css/overlay.css
│     │  └─ js/layout.js, app.js, overlay.js
│     └─ res/                            ícones, cores, temas, strings, XML de acessibilidade
└─ docs/
   ├─ LIMITACOES.md
   └─ capa/capa_saturn_input_overlay.svg  arte de capa (1200×1200)
```

## Como compilar

Requisitos: Android Studio Ladybug (2024.2) ou mais novo, JDK 17, Android SDK 35.

1. Abra a pasta `SaturnInputOverlay` no Android Studio.
2. Se o `gradle-wrapper.jar` não existir, rode no terminal da pasta:
   `gradle wrapper --gradle-version 8.9` (requer Gradle instalado) — ou deixe o Android Studio sincronizar.
3. Menu **Build → Build APK(s)** para gerar o APK de depuração, ou:
   `./gradlew assembleDebug` (Linux/macOS) / `gradlew.bat assembleDebug` (Windows).
4. APK gerado em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale no celular (ative "Instalar apps desconhecidos" se necessário).

## Como usar

1. Abra o app → **CONFIGURAÇÕES** → **Permitir sobreposição** e ative "Permitir exibição sobre outros apps".
2. **CONFIGURAÇÕES** → **Serviço de acessibilidade** → ative **Saturn Input Overlay**.
   (Serve só para ler teclas de hardware. Não lê telas nem texto.)
3. Conecte o teclado USB ou Bluetooth ao celular (e o mouse, se quiser ver se ele é detectado).
4. Toque em **INICIAR**. Uma notificação fixa aparece com as ações Ocultar, Bloquear e Parar.
5. Abra o Roblox e jogue normalmente. As teclas pressionadas acendem no painel.

No painel: **COMPACTO** alterna o tamanho, **OCULTAR** esconde o painel sem parar a captura,
**BLOQ** deixa os toques passarem para o jogo (desbloqueie pela notificação). Arraste pela barra superior.

## Personalização

**PERSONALIZAR** permite escolher a exibição (teclado + mouse, somente WASD, somente teclado,
somente mouse), cores das teclas e do mouse, transparência, tamanho do teclado e do mouse,
e ligar/desligar animações. As configurações são salvas automaticamente.

## Compatibilidade

- Android 12 (API 31) até Android 15 (API 35), `targetSdk` 35.
- Android 14+: serviço em primeiro plano com tipo `specialUse` declarado.
- Android 13+: pede permissão de notificação.

## Teste rápido da comunicação HTML ↔ nativo

- Tela principal: o status "Painel sobre outros apps", "Captura de teclado" e "Mouse conectado"
  vem de `Android.status()` e atualiza a cada 1,5 s.
- Painel: as teclas recebem eventos reais do `InputAccessibilityService` via
  `InputBus` → `OverlayService.pushToWeb` → `SaturnBridge.dispatch`.
- Abrir `index.html` em um navegador comum mostra a interface, sem captura (modo pré-visualização).

## Privacidade

Nenhum dado de teclado é gravado, armazenado ou enviado pela rede. Os eventos existem apenas em memória
para exibição no painel. O app não usa internet.
