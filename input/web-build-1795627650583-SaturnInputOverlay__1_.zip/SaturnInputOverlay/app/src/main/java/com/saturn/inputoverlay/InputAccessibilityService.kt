package com.saturn.inputoverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/**
 * Captura GLOBAL de teclas de hardware (USB / Bluetooth) enquanto outros apps estão em uso.
 *
 * - Usa FLAG_REQUEST_FILTER_KEY_EVENTS: o Android entrega cada tecla ao serviço.
 * - onKeyEvent retorna false, portanto NUNCA consome a tecla: o jogo recebe tudo normalmente.
 * - Não lê conteúdo de tela (canRetrieveWindowContent=false) nem texto digitado.
 */
class InputAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = serviceInfo ?: AccessibilityServiceInfo()
        info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        serviceInfo = info
        InputBus.setServiceConnected(true)
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        val down = when (event.action) {
            KeyEvent.ACTION_DOWN -> true
            KeyEvent.ACTION_UP -> false
            else -> return false
        }
        // Ignora as repetições automáticas enquanto a tecla está segurada.
        if (down && event.repeatCount > 0) return false

        val name = KeyEvent.keyCodeToString(event.keyCode).removePrefix("KEYCODE_")
        InputBus.dispatchKey(name, down)
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não utilizado: o serviço só observa teclas.
    }

    override fun onInterrupt() {
        // Não utilizado.
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        InputBus.setServiceConnected(false)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        InputBus.setServiceConnected(false)
        super.onDestroy()
    }
}
