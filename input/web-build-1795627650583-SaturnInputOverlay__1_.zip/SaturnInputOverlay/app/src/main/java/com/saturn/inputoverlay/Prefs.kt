package com.saturn.inputoverlay

import android.content.Context
import org.json.JSONObject

/** Configurações persistentes (JSON único, compartilhado entre a tela principal e o painel). */
object Prefs {

    private const val FILE = "saturn_prefs"
    private const val KEY_CONFIG = "config"
    private const val KEY_X = "overlay_x"
    private const val KEY_Y = "overlay_y"

    const val DEFAULT_CONFIG =
        """{"keyboard":"full","mouse":true,"keyColorPressed":"#22C55E","keyColorNormal":"#1F2937","mouseColorLeft":"#22C55E","mouseColorRight":"#3B82F6","mouseColorWheel":"#A3E635","opacity":0.92,"keySize":1,"mouseSize":1,"animations":true,"compact":false}"""

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun config(ctx: Context): String =
        prefs(ctx).getString(KEY_CONFIG, DEFAULT_CONFIG) ?: DEFAULT_CONFIG

    fun saveConfig(ctx: Context, json: String): Boolean {
        return try {
            JSONObject(json) // valida antes de gravar
            prefs(ctx).edit().putString(KEY_CONFIG, json).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun updateKey(ctx: Context, key: String, value: Any) {
        val obj = JSONObject(config(ctx))
        obj.put(key, value)
        prefs(ctx).edit().putString(KEY_CONFIG, obj.toString()).apply()
    }

    fun isCompact(ctx: Context): Boolean =
        JSONObject(config(ctx)).optBoolean("compact", false)

    fun position(ctx: Context): Pair<Int, Int> {
        val p = prefs(ctx)
        return p.getInt(KEY_X, 40) to p.getInt(KEY_Y, 160)
    }

    fun savePosition(ctx: Context, x: Int, y: Int) {
        prefs(ctx).edit().putInt(KEY_X, x).putInt(KEY_Y, y).apply()
    }
}
