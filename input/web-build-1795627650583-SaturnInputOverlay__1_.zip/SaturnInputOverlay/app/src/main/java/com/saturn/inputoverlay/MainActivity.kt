package com.saturn.inputoverlay

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.InputDevice
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** Tela principal: hospeda a interface HTML (assets/ui/index.html). */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* a captura funciona mesmo sem notificação */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(AndroidBridge(), "Android")
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/ui/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val callback = this
                web.evaluateJavascript("(window.SaturnUI && SaturnUI.handleBack()) ? 'yes' : 'no'") { result ->
                    if (result == "\"yes\"") return@evaluateJavascript
                    callback.isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    callback.isEnabled = true
                }
            }
        })
    }

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val target = ComponentName(this, InputAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(target, ignoreCase = true) }
    }

    /** Detecta de verdade se há um mouse (USB ou Bluetooth) conectado ao aparelho. */
    private fun isMouseConnected(): Boolean =
        InputDevice.getDeviceIds().any { id ->
            val device = InputDevice.getDevice(id)
            device != null && !device.isVirtual && device.supportsSource(InputDevice.SOURCE_MOUSE)
        }

    /** Métodos expostos ao JavaScript como window.Android. */
    inner class AndroidBridge {

        @JavascriptInterface
        fun status(): String = JSONObject()
            .put("overlay", Settings.canDrawOverlays(this@MainActivity))
            .put("accessibility", isAccessibilityEnabled())
            .put("capturing", OverlayService.running)
            .put("mouse", isMouseConnected())
            .toString()

        @JavascriptInterface
        fun requestOverlayPermission() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        @JavascriptInterface
        fun openAccessibilitySettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun startCapture(): String {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                return JSONObject().put("ok", false).put("reason", "overlay").toString()
            }
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    ContextCompat.checkSelfPermission(
                        this@MainActivity, Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, OverlayService::class.java)
                )
            }
            return JSONObject()
                .put("ok", true)
                .put("accessibility", isAccessibilityEnabled())
                .toString()
        }

        @JavascriptInterface
        fun stopCapture() {
            runOnUiThread {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }

        @JavascriptInterface
        fun getConfig(): String = Prefs.config(this@MainActivity)

        @JavascriptInterface
        fun saveConfig(json: String): Boolean {
            val ok = Prefs.saveConfig(this@MainActivity, json)
            if (ok) InputBus.notifyConfigChanged()
            return ok
        }
    }
}
