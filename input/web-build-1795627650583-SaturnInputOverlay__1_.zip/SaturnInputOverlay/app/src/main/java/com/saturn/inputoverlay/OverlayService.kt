package com.saturn.inputoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import org.json.JSONObject

/**
 * Serviço em primeiro plano que mantém o painel flutuante (TYPE_APPLICATION_OVERLAY).
 * O conteúdo do painel é HTML (assets/ui/overlay.html) e recebe eventos reais via JavaScript.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.saturn.inputoverlay.action.STOP"
        const val ACTION_TOGGLE_VISIBLE = "com.saturn.inputoverlay.action.TOGGLE_VISIBLE"
        const val ACTION_TOGGLE_LOCK = "com.saturn.inputoverlay.action.TOGGLE_LOCK"

        private const val CHANNEL_ID = "saturn_capture"
        private const val NOTIFICATION_ID = 1001
        private const val HEADER_DP = 30f

        @Volatile
        var running = false
    }

    private lateinit var windowManager: WindowManager
    private var rootLayout: LinearLayout? = null
    private var webView: WebView? = null
    private var windowParams: WindowManager.LayoutParams? = null
    private var locked = false
    private var visible = true

    private val inputListener: (String) -> Unit = { json -> pushToWeb(json) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        startInForeground()

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        InputBus.addListener(inputListener)
        buildWindow()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_TOGGLE_VISIBLE -> setPanelVisible(!visible)
            ACTION_TOGGLE_LOCK -> setLocked(!locked)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        InputBus.removeListener(inputListener)
        rootLayout?.let { root ->
            try {
                windowManager.removeView(root)
            } catch (e: Exception) {
                // já removida
            }
        }
        webView?.destroy()
        rootLayout = null
        webView = null
        super.onDestroy()
    }

    // ---------- Notificação / foreground ----------

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.app_name),
            NotificationManager.IMPORTANCE_LOW
        )
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun startInForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        fun svc(action: String, req: Int): PendingIntent = PendingIntent.getService(
            this, req,
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_saturn)
            .setContentTitle("Saturn Input Overlay ativo")
            .setContentText(if (visible) "Captura de teclas em execução" else "Painel oculto - captura ativa")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, if (visible) "Ocultar" else "Mostrar", svc(ACTION_TOGGLE_VISIBLE, 1))
            .addAction(0, if (locked) "Desbloquear" else "Bloquear clique", svc(ACTION_TOGGLE_LOCK, 2))
            .addAction(0, "Parar", svc(ACTION_STOP, 3))
            .build()
    }

    private fun refreshNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification())
    }

    // ---------- Janela flutuante ----------

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildWindow() {
        val ctx = ContextThemeWrapper(this, R.style.Theme_SaturnInputOverlay)

        val header = buildHeader(ctx)

        val content = WebView(ctx).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient()
            addJavascriptInterface(OverlayBridge(), "Android")
            loadUrl("file:///android_asset/ui/overlay.html")
        }
        webView = content

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(14f).toFloat()
                setColor(Color.argb(235, 11, 11, 12))
                setStroke(dp(1f), Color.argb(70, 34, 197, 94))
            }
            addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(HEADER_DP)))
            addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        rootLayout = root

        val (px, py) = Prefs.position(this)
        windowParams = WindowManager.LayoutParams(
            dp(260f),
            dp(200f),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px
            y = py
        }
        windowManager.addView(root, windowParams)
    }

    private fun buildHeader(ctx: Context): View =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(4f), 0)
            setOnTouchListener(dragListener())

            addView(
                TextView(ctx).apply {
                    text = "SATURN"
                    setTextColor(Color.parseColor("#22C55E"))
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            addView(headerButton(ctx, "COMPACTO") { toggleCompact() })
            addView(headerButton(ctx, "BLOQ") { setLocked(true) })
            addView(headerButton(ctx, "OCULTAR") { setPanelVisible(false) })
        }

    private fun headerButton(ctx: Context, label: String, onClick: () -> Unit): TextView =
        TextView(ctx).apply {
            text = label
            textSize = 9f
            setTextColor(Color.parseColor("#E5E7EB"))
            background = GradientDrawable().apply {
                cornerRadius = dp(6f).toFloat()
                setColor(Color.parseColor("#26262A"))
            }
            setPadding(dp(6f), dp(4f), dp(6f), dp(4f))
            isClickable = true
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = dp(4f) }
        }

    /** Arrastar o painel pela barra superior. */
    private fun dragListener(): View.OnTouchListener {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        return View.OnTouchListener { _, event ->
            val lp = windowParams ?: return@OnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = event.rawX
                    touchY = event.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (event.rawX - touchX).toInt()
                    lp.y = startY + (event.rawY - touchY).toInt()
                    rootLayout?.let { windowManager.updateViewLayout(it, lp) }
                }
                MotionEvent.ACTION_UP -> Prefs.savePosition(this@OverlayService, lp.x, lp.y)
            }
            true
        }
    }

    private fun toggleCompact() {
        Prefs.updateKey(this, "compact", !Prefs.isCompact(this))
        InputBus.notifyConfigChanged()
    }

    private fun setPanelVisible(value: Boolean) {
        visible = value
        rootLayout?.visibility = if (value) View.VISIBLE else View.GONE
        refreshNotification()
    }

    /** Bloqueado = toques passam através do painel para o jogo (FLAG_NOT_TOUCHABLE). */
    private fun setLocked(value: Boolean) {
        locked = value
        val lp = windowParams ?: return
        lp.flags = if (value) {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        }
        rootLayout?.let { windowManager.updateViewLayout(it, lp) }
        refreshNotification()
    }

    private fun applySize(widthDp: Float, heightDp: Float) {
        val lp = windowParams ?: return
        lp.width = dp(widthDp.coerceIn(120f, 600f))
        lp.height = dp((heightDp + HEADER_DP).coerceIn(80f, 900f))
        rootLayout?.let { windowManager.updateViewLayout(it, lp) }
    }

    private fun pushToWeb(json: String) {
        Handler(Looper.getMainLooper()).post {
            webView?.evaluateJavascript("if(window.SaturnBridge){SaturnBridge.dispatch($json);}", null)
        }
    }

    /** Ponte JavaScript do painel (objeto "Android" dentro do overlay.html). */
    inner class OverlayBridge {
        @JavascriptInterface
        fun getConfig(): String = Prefs.config(this@OverlayService)

        @JavascriptInterface
        fun getStatus(): String =
            JSONObject().put("accessibility", InputBus.serviceConnected).toString()

        /** O HTML informa o tamanho do conteúdo (em dp) para ajustar a janela. */
        @JavascriptInterface
        fun resize(width: String, height: String) {
            val w = width.toFloatOrNull() ?: return
            val h = height.toFloatOrNull() ?: return
            Handler(Looper.getMainLooper()).post { applySize(w, h) }
        }
    }
}
