package com.saturn.inputoverlay

import java.util.concurrent.CopyOnWriteArraySet

/**
 * Barramento de eventos reais.
 * - InputAccessibilityService publica teclas de hardware aqui.
 * - OverlayService assina e repassa ao painel HTML (SaturnBridge.dispatch).
 * Todos os eventos são JSON válido para JavaScript.
 */
object InputBus {

    @Volatile
    var serviceConnected: Boolean = false
        private set

    private val listeners = CopyOnWriteArraySet<(String) -> Unit>()

    fun addListener(listener: (String) -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: (String) -> Unit) {
        listeners.remove(listener)
    }

    fun setServiceConnected(connected: Boolean) {
        serviceConnected = connected
        emit("""{"type":"service","connected":$connected}""")
    }

    fun dispatchKey(name: String, down: Boolean) {
        emit("""{"type":"key","name":"$name","down":$down}""")
    }

    fun notifyConfigChanged() {
        emit("""{"type":"config"}""")
    }

    private fun emit(json: String) {
        listeners.forEach { it(json) }
    }
}
