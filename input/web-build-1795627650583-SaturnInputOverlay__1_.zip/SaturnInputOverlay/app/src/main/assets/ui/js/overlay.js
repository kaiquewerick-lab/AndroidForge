/* Painel flutuante. Recebe eventos REAIS via SaturnBridge.dispatch(evento),
   chamado pelo OverlayService a partir do InputAccessibilityService. */
(function () {
  'use strict';

  var bridge = window.Android || null;
  var hasBridge = !!bridge && typeof bridge.getConfig === 'function';
  var L = window.SaturnLayout;

  var DEFAULTS = {
    keyboard: 'full', mouse: true,
    keyColorPressed: '#22C55E', keyColorNormal: '#1F2937',
    mouseColorLeft: '#22C55E', mouseColorRight: '#3B82F6', mouseColorWheel: '#A3E635',
    opacity: 0.92, keySize: 1, mouseSize: 1, animations: true, compact: false
  };

  var cfg = DEFAULTS;
  var pressed = Object.create(null);     // teclas físicas atualmente pressionadas
  var keyEls = Object.create(null);      // id -> elemento
  var extraEls = Object.create(null);    // teclas fora do layout (todas as demais)
  var accessibilityOn = true;
  var lastHeight = 0, lastWidth = 0;

  var $ = function (id) { return document.getElementById(id); };

  function readConfig() {
    var parsed = null;
    try { parsed = hasBridge ? JSON.parse(bridge.getConfig()) : null; } catch (e) { parsed = null; }
    cfg = Object.assign({}, DEFAULTS, parsed || {});
  }

  function makeKey(id) {
    var el = document.createElement('div');
    el.className = 'key';
    el.textContent = displayLabel(id);
    if (id.length >= 4) el.classList.add('w2');
    if (id === 'SPACE') el.classList.add('space');
    if (['BACKSPACE', 'ENTER', 'SHIFT', 'CTRL', 'TAB', 'CAPS'].indexOf(id) >= 0) el.classList.add('w2');
    return el;
  }

  function displayLabel(id) {
    var map = { SPACE: 'ESPAÇO', BACKSPACE: 'BACK', CAPS: 'CAPS', WIN: 'WIN', SHIFT: 'SHIFT', CTRL: 'CTRL', ALT: 'ALT' };
    return map[id] || id;
  }

  function buildKeyboard() {
    var kb = $('keyboard');
    kb.innerHTML = '';
    keyEls = Object.create(null);
    if (cfg.keyboard === 'off') { kb.style.display = 'none'; return; }
    kb.style.display = '';
    var rows = cfg.keyboard === 'wasd' ? L.WASD_ROWS : L.FULL_ROWS;
    rows.forEach(function (row) {
      var r = document.createElement('div');
      r.className = 'krow';
      row.forEach(function (id) {
        var el = makeKey(id);
        keyEls[id] = el;
        r.appendChild(el);
      });
      kb.appendChild(r);
    });
    if (cfg.keyboard === 'wasd') kb.classList.add('wasd');
    // Reaplica o estado das teclas que já estavam pressionadas.
    Object.keys(pressed).forEach(function (id) { setKeyState(id, true); });
  }

  function setKeyState(id, down) {
    var el = keyEls[id];
    if (!el) {
      if (!down) { removeExtra(id); return; }
      el = extraEls[id] || createExtra(id);
    }
    el.classList.toggle('on', down);
  }

  function createExtra(id) {
    var el = makeKey(id);
    extraEls[id] = el;
    $('extra').appendChild(el);
    return el;
  }

  function removeExtra(id) {
    var el = extraEls[id];
    if (el) { el.remove(); delete extraEls[id]; }
  }

  function applyVisual() {
    var root = document.documentElement.style;
    root.setProperty('--kp', cfg.keyColorPressed);
    root.setProperty('--kn', cfg.keyColorNormal);
    root.setProperty('--ml', cfg.mouseColorLeft);
    root.setProperty('--mr', cfg.mouseColorRight);
    root.setProperty('--mw', cfg.mouseColorWheel);
    root.setProperty('--ms', (60 * cfg.mouseSize).toFixed(0) + 'px');
    document.body.style.opacity = String(cfg.opacity);
    document.body.style.zoom = String(cfg.keySize);
    document.body.classList.toggle('anim', !!cfg.animations);
    document.body.classList.toggle('compact', !!cfg.compact);
    document.body.classList.toggle('hide-kb', cfg.keyboard === 'off');
    document.body.classList.toggle('hide-mouse', !cfg.mouse);
  }

  function reportSize() {
    if (!hasBridge || typeof bridge.resize !== 'function') return;
    var panel = $('panel');
    var w = Math.ceil(panel.offsetWidth), h = Math.ceil(panel.offsetHeight);
    if (w === lastWidth && h === lastHeight) return;
    lastWidth = w; lastHeight = h;
    bridge.resize(String(w + 4), String(h + 4));
  }

  function fullRebuild() {
    readConfig();
    applyVisual();
    buildKeyboard();
    paintMouse();
    reportSize();
  }

  /* ---------- Mouse ----------
     Eventos de mouse só chegam aqui se o Android os entregar ao serviço.
     Ver docs/LIMITACOES.md: o Android não expõe cliques globais de mouse
     a apps de terceiros, então o painel fica sem dados de mouse nessa situação. */
  var mouseState = { left: false, right: false, wheel: false };
  var wheelTimer = null;

  function paintMouse() {
    $('mLeft').classList.toggle('on', mouseState.left);
    $('mRight').classList.toggle('on', mouseState.right);
    $('mWheel').classList.toggle('on', mouseState.wheel);
  }

  function handleMouse(ev) {
    if (ev.button === 'left') mouseState.left = !!ev.down;
    if (ev.button === 'right') mouseState.right = !!ev.down;
    if (ev.button === 'wheel') {
      mouseState.wheel = true;
      clearTimeout(wheelTimer);
      wheelTimer = setTimeout(function () { mouseState.wheel = false; paintMouse(); }, 180);
    }
    paintMouse();
  }

  /* ---------- Teclado ---------- */
  function handleKey(ev) {
    var id = L.normalize(ev.name);
    if (!id) return;
    if (ev.down) pressed[id] = true; else delete pressed[id];
    if (keyEls[id]) {
      keyEls[id].classList.toggle('on', !!ev.down);
    } else if (ev.down) {
      createExtra(id).classList.add('on');
    } else {
      removeExtra(id);
    }
    if (ev.down && !keyEls[id]) reportSize();
  }

  /* Ponto de entrada chamado pelo Android (evaluateJavascript). */
  window.SaturnBridge = {
    dispatch: function (ev) {
      if (!ev || typeof ev !== 'object') return;
      switch (ev.type) {
        case 'key': handleKey(ev); break;
        case 'mouse': handleMouse(ev); break;
        case 'service':
          accessibilityOn = !!ev.connected;
          $('mouseStatus').textContent = accessibilityOn ? 'Teclado: capturando' : 'Teclado: serviço desligado';
          if (!accessibilityOn) { pressed = Object.create(null); buildKeyboard(); }
          break;
        case 'config': fullRebuild(); break;
      }
    }
  };

  document.addEventListener('DOMContentLoaded', function () {
    fullRebuild();
    if (window.ResizeObserver) new ResizeObserver(reportSize).observe($('panel'));
    $('mouseStatus').textContent = 'Mouse: sem captura (ver limitações)';
    // Ao soltar uma tecla ao trocar de app, nada fica "preso" na tela.
    window.addEventListener('blur', function () { pressed = Object.create(null); buildKeyboard(); });
  });
})();
