/* Layout do teclado virtual + normalização dos nomes vindos do Android.
   Compartilhado entre a tela principal e o painel flutuante. */
(function (global) {
  'use strict';

  var FULL_ROWS = [
    ['ESC', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'],
    ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 'BACKSPACE'],
    ['TAB', 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '[', ']', '\\'],
    ['CAPS', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ';', "'", 'ENTER'],
    ['SHIFT', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', 'SHIFT'],
    ['CTRL', 'WIN', 'ALT', 'SPACE', 'ALT', 'CTRL'],
    ['UP'],
    ['LEFT', 'DOWN', 'RIGHT']
  ];

  var WASD_ROWS = [
    ['Q', 'W', 'E', 'R', 'F'],
    ['A', 'S', 'D'],
    ['SHIFT', 'CTRL', 'SPACE']
  ];

  var ALIASES = {
    'SHIFT_LEFT': 'SHIFT', 'SHIFT_RIGHT': 'SHIFT',
    'CTRL_LEFT': 'CTRL', 'CTRL_RIGHT': 'CTRL',
    'ALT_LEFT': 'ALT', 'ALT_RIGHT': 'ALT',
    'META_LEFT': 'WIN', 'META_RIGHT': 'WIN',
    'ESCAPE': 'ESC', 'ENTER': 'ENTER', 'NUMPAD_ENTER': 'ENTER',
    'DEL': 'BACKSPACE', 'FORWARD_DEL': 'DEL',
    'CAPS_LOCK': 'CAPS', 'SPACE': 'SPACE',
    'DPAD_UP': 'UP', 'DPAD_DOWN': 'DOWN', 'DPAD_LEFT': 'LEFT', 'DPAD_RIGHT': 'RIGHT',
    'PAGE_UP': 'PGUP', 'PAGE_DOWN': 'PGDN', 'GRAVE': '`', 'MINUS': '-',
    'EQUALS': '=', 'LEFT_BRACKET': '[', 'RIGHT_BRACKET': ']', 'BACKSLASH': '\\',
    'SEMICOLON': ';', 'APOSTROPHE': "'", 'COMMA': ',', 'PERIOD': '.', 'SLASH': '/'
  };

  /* Converte "W", "SHIFT_LEFT", "0", "NUMPAD_5" etc. para o id usado no teclado. */
  function normalize(raw) {
    var name = String(raw || '').toUpperCase();
    if (ALIASES[name]) return ALIASES[name];
    if (name.indexOf('NUMPAD_') === 0) {
      var rest = name.substring(7);
      if (/^[0-9]$/.test(rest)) return rest;
    }
    return name;
  }

  global.SaturnLayout = {
    FULL_ROWS: FULL_ROWS,
    WASD_ROWS: WASD_ROWS,
    normalize: normalize
  };
})(window);
