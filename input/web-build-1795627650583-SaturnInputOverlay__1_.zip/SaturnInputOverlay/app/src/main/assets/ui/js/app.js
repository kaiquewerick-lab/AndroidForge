/* Tela principal do Saturn Input Overlay.
   Conversa com o Android pela ponte window.Android (MainActivity.AndroidBridge). */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var bridge = window.Android || null;
  var hasBridge = !!bridge && typeof bridge.status === 'function';

  var DEFAULTS = {
    keyboard: 'full', mouse: true,
    keyColorPressed: '#22C55E', keyColorNormal: '#1F2937',
    mouseColorLeft: '#22C55E', mouseColorRight: '#3B82F6', mouseColorWheel: '#A3E635',
    opacity: 0.92, keySize: 1, mouseSize: 1, animations: true, compact: false
  };

  var cfg = null;
  var capturing = false;

  function call(fn, fallback) {
    try { return fn(); } catch (e) { return fallback; }
  }

  function readStatus() {
    if (!hasBridge) return { overlay: false, accessibility: false, capturing: false, mouse: false };
    var raw = call(function () { return bridge.status(); }, '{}');
    try { return JSON.parse(raw); } catch (e) { return {}; }
  }

  function loadConfig() {
    var raw = hasBridge ? call(function () { return bridge.getConfig(); }, null) : null;
    var parsed = null;
    try { parsed = raw ? JSON.parse(raw) : null; } catch (e) { parsed = null; }
    cfg = Object.assign({}, DEFAULTS, parsed || {});
  }

  function saveConfig() {
    var json = JSON.stringify(cfg);
    if (!hasBridge) return;
    var ok = call(function () { return bridge.saveConfig(json); }, false);
    if (!ok) toast('Não foi possível salvar a configuração.');
  }

  function toast(text) {
    var t = $('toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { t.classList.remove('show'); }, 2200);
  }

  /* ---------- Status ---------- */
  function setTag(el, ok, yes, no) {
    el.textContent = ok ? yes : no;
    el.className = 'tag ' + (ok ? 'ok' : 'no');
  }

  function refreshStatus() {
    var s = readStatus();
    capturing = !!s.capturing;
    setTag($('tOverlay'), !!s.overlay, 'Permitido', 'Não permitido');
    setTag($('tAccess'), !!s.accessibility, 'Ativo', 'Desativado');
    setTag($('tMouse'), !!s.mouse, 'Detectado', 'Não detectado');

    var dot = $('mainDot'), text = $('mainText'), btn = $('btnStart');
    if (capturing) {
      dot.className = 'dot on';
      text.textContent = s.accessibility ? 'Captura ativa' : 'Painel ativo — teclado não liberado';
      btn.textContent = 'PARAR';
      btn.className = 'btn primary stop';
    } else {
      dot.className = 'dot';
      text.textContent = 'Captura parada';
      btn.textContent = 'INICIAR';
      btn.className = 'btn primary';
    }
  }

  /* ---------- Ações ---------- */
  function onStart() {
    if (!hasBridge) { toast('Abra o app Android para iniciar a captura.'); return; }
    if (capturing) {
      call(function () { bridge.stopCapture(); });
      setTimeout(refreshStatus, 400);
      return;
    }
    var raw = call(function () { return bridge.startCapture(); }, '{"ok":false}');
    var res = {};
    try { res = JSON.parse(raw); } catch (e) {}
    if (!res.ok) {
      toast('Ative primeiro "Permitir sobreposição" em CONFIGURAÇÕES.');
      showSection('secSettings');
      return;
    }
    if (!res.accessibility) {
      toast('Ative o serviço de acessibilidade para ver o teclado.');
    }
    setTimeout(refreshStatus, 500);
  }

  function showSection(id) {
    $('secSettings').classList.toggle('hidden', id !== 'secSettings');
    $('secCustom').classList.toggle('hidden', id !== 'secCustom');
  }

  function toggleSection(id) {
    var target = $(id);
    var willShow = target.classList.contains('hidden');
    $('secSettings').classList.add('hidden');
    $('secCustom').classList.add('hidden');
    if (willShow) target.classList.remove('hidden');
  }

  function bindSeg(segId, key, transform) {
    var buttons = $(segId).querySelectorAll('button');
    buttons.forEach(function (b) {
      b.addEventListener('click', function () {
        cfg[key] = transform ? transform(b.getAttribute('data-v')) : b.getAttribute('data-v');
        paintSeg(segId, cfg[key], transform);
        saveConfig();
        if (key === 'keyboard') applyViewFromCfg();
      });
    });
  }

  function paintSeg(segId, value, transform) {
    $(segId).querySelectorAll('button').forEach(function (b) {
      var v = transform ? transform(b.getAttribute('data-v')) : b.getAttribute('data-v');
      b.classList.toggle('on', String(v) === String(value));
    });
  }

  /* Exibição = combinação de "keyboard" (full | wasd | off) e "mouse" (bool). */
  function applyViewFromCfg() {
    paintSeg('segView', viewValue(), null);
  }
  function viewValue() {
    if (cfg.keyboard === 'wasd') return 'wasd';
    if (cfg.keyboard === 'off' && cfg.mouse) return 'mouse';
    if (cfg.keyboard !== 'off' && !cfg.mouse) return 'keys';
    return 'full';
  }
  function setView(v) {
    if (v === 'full') { cfg.keyboard = 'full'; cfg.mouse = true; }
    if (v === 'wasd') { cfg.keyboard = 'wasd'; cfg.mouse = false; }
    if (v === 'keys') { cfg.keyboard = 'full'; cfg.mouse = false; }
    if (v === 'mouse') { cfg.keyboard = 'off'; cfg.mouse = true; }
    applyViewFromCfg();
    saveConfig();
  }

  function paintCustom() {
    $('cPressed').value = cfg.keyColorPressed;
    $('cNormal').value = cfg.keyColorNormal;
    $('cLeft').value = cfg.mouseColorLeft;
    $('cRight').value = cfg.mouseColorRight;
    $('cWheel').value = cfg.mouseColorWheel;
    $('rOpacity').value = Math.round(cfg.opacity * 100);
    $('lOpacity').textContent = Math.round(cfg.opacity * 100) + '%';
    $('rKeySize').value = Math.round(cfg.keySize * 100);
    $('lKeySize').textContent = Math.round(cfg.keySize * 100) + '%';
    $('rMouseSize').value = Math.round(cfg.mouseSize * 100);
    $('lMouseSize').textContent = Math.round(cfg.mouseSize * 100) + '%';
    $('swAnim').classList.toggle('on', !!cfg.animations);
    paintSeg('segMode', String(!!cfg.compact), null);
    applyViewFromCfg();
  }

  function bindColor(id, key) {
    $(id).addEventListener('input', function (e) { cfg[key] = e.target.value; saveConfig(); });
  }

  function bindRange(id, labelId, key) {
    $(id).addEventListener('input', function (e) {
      var v = Number(e.target.value);
      cfg[key] = v / 100;
      $(labelId).textContent = v + '%';
    });
    $(id).addEventListener('change', saveConfig);
  }

  /* ---------- Inicialização ---------- */
  function init() {
    loadConfig();
    if (!hasBridge) $('msgNoBridge').classList.remove('hidden');

    $('btnStart').addEventListener('click', onStart);
    $('btnSettings').addEventListener('click', function () { toggleSection('secSettings'); });
    $('btnCustom').addEventListener('click', function () { toggleSection('secCustom'); });

    $('btnOverlayPerm').addEventListener('click', function () {
      if (hasBridge) call(function () { bridge.requestOverlayPermission(); });
    });
    $('btnAccessPerm').addEventListener('click', function () {
      if (hasBridge) call(function () { bridge.openAccessibilitySettings(); });
    });

    bindSeg('segMode', 'compact', function (v) { return v === 'true'; });
    $('segView').querySelectorAll('button').forEach(function (b) {
      b.addEventListener('click', function () { setView(b.getAttribute('data-v')); });
    });

    bindColor('cPressed', 'keyColorPressed');
    bindColor('cNormal', 'keyColorNormal');
    bindColor('cLeft', 'mouseColorLeft');
    bindColor('cRight', 'mouseColorRight');
    bindColor('cWheel', 'mouseColorWheel');
    bindRange('rOpacity', 'lOpacity', 'opacity');
    bindRange('rKeySize', 'lKeySize', 'keySize');
    bindRange('rMouseSize', 'lMouseSize', 'mouseSize');

    $('swAnim').addEventListener('click', function () {
      cfg.animations = !cfg.animations;
      $('swAnim').classList.toggle('on', cfg.animations);
      saveConfig();
    });

    $('btnReset').addEventListener('click', function () {
      cfg = Object.assign({}, DEFAULTS);
      paintCustom();
      saveConfig();
      toast('Padrão restaurado.');
    });

    paintCustom();
    refreshStatus();
    setInterval(refreshStatus, 1500);

    // Botão voltar do Android: fecha seções abertas antes de sair.
    window.SaturnUI = {
      handleBack: function () {
        var open = !$('secSettings').classList.contains('hidden') || !$('secCustom').classList.contains('hidden');
        $('secSettings').classList.add('hidden');
        $('secCustom').classList.add('hidden');
        return open;
      }
    };
  }

  document.addEventListener('DOMContentLoaded', init);
})();
