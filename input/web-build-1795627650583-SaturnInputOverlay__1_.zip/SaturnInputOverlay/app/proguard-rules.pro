# Saturn Input Overlay - regras extras (nenhuma necessária no momento).
-keepclassmembers class com.saturn.inputoverlay.OverlayService$OverlayBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class com.saturn.inputoverlay.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
