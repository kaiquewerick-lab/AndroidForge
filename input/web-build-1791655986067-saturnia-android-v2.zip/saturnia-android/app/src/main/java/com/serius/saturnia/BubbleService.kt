package com.serius.saturnia

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.util.Base64
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * SaturnIA Bubble: balão flutuante e janela de conversa sobre outros apps.
 *
 * Modos:
 *  - FLOATING: balão arrastável. Tocar nele abre o painel compacto; "Minimizar" fecha o painel.
 *  - FULLSCREEN: painel ocupa a tela. "Janela" volta ao modo flutuante.
 *  - HIDDEN: nada visível. A notificação tem "Mostrar balão" para reabrir.
 *
 * A conversa fica em BubbleChat e não é perdida ao trocar de modo.
 * Não lê a tela, não captura nada e não acessa outros apps.
 */
class BubbleService : Service() {

    companion object {
        private const val ACTION_START = "com.serius.saturnia.action.START_BUBBLE"
        private const val ACTION_STOP = "com.serius.saturnia.action.STOP_BUBBLE"
        private const val ACTION_SHOW = "com.serius.saturnia.action.SHOW_BUBBLE"
        private const val ACTION_HIDE = "com.serius.saturnia.action.HIDE_BUBBLE"
        private const val CHANNEL_ID = "saturnia_bubble"
        private const val NOTIFICATION_ID = 4202

        /** Posição do balão, lembrada enquanto o serviço estiver vivo. */
        private var bubbleX = -1
        private var bubbleY = -1

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, BubbleService::class.java).setAction(ACTION_START)
            )
        }

        fun stop(context: Context) {
            try {
                context.startService(Intent(context, BubbleService::class.java).setAction(ACTION_STOP))
            } catch (e: IllegalStateException) {
                BubbleState.set(BubbleState.STOPPED, BubbleState.MODE_HIDDEN)
            }
        }
    }

    /** Referências da janela de conversa, criadas uma vez e reaproveitadas. */
    private class PanelUi(
        val root: View,
        val title: TextView,
        val status: TextView,
        val modeButton: TextView,
        val scroll: ScrollView,
        val list: LinearLayout,
        val typing: TextView,
        val attach: TextView,
        val input: EditText,
        val sendButton: TextView
    )

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    private var running = false
    private var mode = BubbleState.MODE_FLOATING
    private var panelOpen = false

    private var bubbleView: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var panel: PanelUi? = null

    private var dotCount = 0
    private val dotsTicker = object : Runnable {
        override fun run() {
            if (!running) return
            dotCount = (dotCount + 1) % 4
            panel?.typing?.text = "Pensando" + ".".repeat(dotCount)
            main.postDelayed(this, 400)
        }
    }

    private val chatListener: () -> Unit = { main.post { renderPanel() } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        BubbleChat.addListener(chatListener)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown(BubbleState.STOPPED, BubbleState.MODE_HIDDEN)
                return START_NOT_STICKY
            }
            ACTION_HIDE -> if (running) {
                setMode(BubbleState.MODE_HIDDEN)
                return START_NOT_STICKY
            }
            ACTION_SHOW -> if (running) {
                setMode(BubbleState.MODE_FLOATING)
                return START_NOT_STICKY
            }
        }

        if (running) return START_NOT_STICKY

        // Sem as permissões, não entra em primeiro plano: informa e encerra.
        if (!Settings.canDrawOverlays(this)) {
            BubbleState.set(BubbleState.NO_OVERLAY, BubbleState.MODE_HIDDEN,
                "Permissão “Exibir sobre outros apps” não concedida.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (!notificationsAllowed()) {
            BubbleState.set(BubbleState.NO_NOTIFICATION, BubbleState.MODE_HIDDEN,
                "Sem permissão de notificações: o balão precisa dela para ser reaberto.")
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()
        running = true
        mode = BubbleState.MODE_FLOATING
        panelOpen = false
        BubbleState.set(BubbleState.RUNNING, mode, "")
        renderAll()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        BubbleChat.removeListener(chatListener)
        main.removeCallbacksAndMessages(null)
        removeViews()
        if (running) {
            running = false
            BubbleState.set(BubbleState.STOPPED, mode)
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------ modos e janelas

    private fun setMode(newMode: String) {
        mode = newMode
        panelOpen = false
        BubbleState.set(BubbleState.RUNNING, mode, "")
        renderAll()
    }

    private fun renderAll() {
        if (!running) return
        if (!Settings.canDrawOverlays(this)) {
            shutdown(BubbleState.NO_OVERLAY, BubbleState.MODE_HIDDEN,
                "Permissão “Exibir sobre outros apps” foi removida.")
            return
        }
        when (mode) {
            BubbleState.MODE_HIDDEN -> {
                removeBubble()
                removePanel()
            }
            BubbleState.MODE_FULLSCREEN -> {
                removeBubble()
                showPanel(fullscreen = true)
            }
            else -> {
                showBubble()
                if (panelOpen) showPanel(fullscreen = false) else removePanel()
            }
        }
        updateNotification()
        renderPanel()
    }

    private fun showBubble() {
        val view = bubbleView ?: buildBubble().also { bubbleView = it }
        val params = bubbleParams ?: createBubbleParams().also { bubbleParams = it }
        if (!attach(view, params)) {
            BubbleState.set(BubbleState.BLOCKED, mode,
                "O Android não permitiu mostrar o balão sobre este app agora.")
        } else if (BubbleState.state == BubbleState.BLOCKED) {
            BubbleState.set(BubbleState.RUNNING, mode, "")
        }
    }

    private fun showPanel(fullscreen: Boolean) {
        val ui = panel ?: buildPanel().also { panel = it }
        val view = ui.root
        val params = if (fullscreen) fullscreenParams() else compactParams()
        panelView = view
        panelParams = params
        if (!attach(view, params)) {
            BubbleState.set(BubbleState.BLOCKED, mode,
                "O Android não permitiu mostrar a janela de conversa sobre este app agora.")
        }
        view.animate().cancel()
        if (view.alpha < 1f) view.animate().alpha(1f).setDuration(180).start()
    }

    private fun removeBubble() {
        bubbleView?.let { detach(it) }
    }

    private fun removePanel() {
        panelView?.let { detach(it) }
    }

    private fun removeViews() {
        removeBubble()
        removePanel()
        bubbleView = null
        panelView = null
        panel = null
    }

    private fun attach(view: View, params: WindowManager.LayoutParams): Boolean = try {
        if (view.isAttachedToWindow) wm.updateViewLayout(view, params) else wm.addView(view, params)
        true
    } catch (e: Exception) {
        false
    }

    private fun detach(view: View) {
        if (view.isAttachedToWindow) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // A janela já tinha sido removida pelo sistema.
            }
        }
    }

    private fun overlayType(): Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private fun createBubbleParams(): WindowManager.LayoutParams {
        val size = dp(60)
        val params = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        if (bubbleX < 0 || bubbleY < 0) {
            bubbleX = screenWidth() - size - dp(12)
            bubbleY = screenHeight() / 3
        }
        params.x = bubbleX
        params.y = bubbleY
        return params
    }

    private fun compactParams(): WindowManager.LayoutParams {
        val params = WindowManager.LayoutParams(
            screenWidth() - dp(24),
            (screenHeight() * 0.62f).toInt(),
            overlayType(),
            // Toques fora do painel passam para o app que está por baixo.
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        params.y = dp(12)
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        return params
    }

    private fun fullscreenParams(): WindowManager.LayoutParams {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        return params
    }

    // ------------------------------------------------------------ balão

    private fun buildBubble(): View {
        val size = dp(60)
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#8FA0FF"), Color.parseColor("#3B2F8F"))
            ).apply { shape = GradientDrawable.OVAL }
            elevation = dp(10).toFloat()
            contentDescription = "Balão SaturnIA. Toque para abrir a conversa."
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.saturnia_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            val pad = dp(8)
            setPadding(pad, pad, pad, pad)
        }
        frame.addView(icon, FrameLayout.LayoutParams(size, size))

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var startX = 0
        var startY = 0
        var dragged = false
        frame.setOnTouchListener { _, event ->
            val params = bubbleParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startX = params.x
                    startY = params.y
                    dragged = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!dragged && (abs(dx) > slop || abs(dy) > slop)) dragged = true
                    if (dragged) {
                        params.x = (startX + dx).toInt().coerceIn(0, screenWidth() - size)
                        params.y = (startY + dy).toInt().coerceIn(0, screenHeight() - size)
                        bubbleX = params.x
                        bubbleY = params.y
                        try {
                            wm.updateViewLayout(frame, params)
                        } catch (e: Exception) {
                            // Balão removido pelo sistema durante o arraste.
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) {
                        panelOpen = !panelOpen
                        renderAll()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> true
                else -> false
            }
        }
        return frame
    }

    // ------------------------------------------------------------ painel de conversa

    private fun buildPanel(): PanelUi {
        val surface = GradientDrawable().apply {
            setColor(Color.parseColor("#F2101423"))
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = surface
            setPadding(dp(14), dp(12), dp(14), dp(12))
            elevation = dp(14).toFloat()
        }

        // Cabeçalho: título, status e controles.
        val title = TextView(this).apply {
            text = "SaturnIA"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val status = TextView(this).apply {
            setTextColor(Color.parseColor("#AAB2D6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.saturnia_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Logo da SaturnIA"
        }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(8) })
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(status)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(6))
        }
        val modeButton = controlButton("Tela cheia") { toggleFullscreen() }
        val minimize = controlButton("Minimizar") { minimizeToBubble() }
        val hide = controlButton("Ocultar") { setMode(BubbleState.MODE_HIDDEN) }
        val close = controlButton("Fechar") { closePanel() }
        listOf(modeButton, minimize, hide, close).forEach { controls.addView(it, weightedParams()) }
        root.addView(controls)

        // Conversa.
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val typing = TextView(this).apply {
            setTextColor(Color.parseColor("#AAB2D6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            visibility = View.GONE
            setPadding(dp(4), dp(4), 0, dp(4))
        }
        root.addView(typing)

        // Entrada e envio.
        val input = EditText(this).apply {
            hint = "Mensagem para a SaturnIA"
            setHintTextColor(Color.parseColor("#7F88B0"))
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 4
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1B2032"))
                cornerRadius = dp(18).toFloat()
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val sendButton = TextView(this).apply {
            text = "Enviar"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#7C8CF8"))
                cornerRadius = dp(18).toFloat()
            }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            setOnClickListener { sendFromInput() }
        }
        val clear = controlButton("Nova") { BubbleChat.clear() }
        val photo = controlButton("Foto") { openImagePicker() }
        val attach = TextView(this).apply {
            setTextColor(Color.parseColor("#C9D0F5"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2A3260"))
                cornerRadius = dp(12).toFloat()
            }
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
            setOnClickListener {
                BubbleChat.setPendingImage(null)
                Toast.makeText(this@BubbleService, "Imagem removida.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(attach, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        inputRow.addView(clear)
        inputRow.addView(photo, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(6)
        })
        inputRow.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(6)
        })
        inputRow.addView(sendButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(8)
        })
        root.addView(inputRow)

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendFromInput()
                true
            } else {
                false
            }
        }

        return PanelUi(root, title, status, modeButton, scroll, list, typing, attach, input, sendButton)
    }

    private fun controlButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#22FFFFFF"))
            cornerRadius = dp(12).toFloat()
        }
        setPadding(dp(6), dp(8), dp(6), dp(8))
        setOnClickListener { onClick() }
    }

    private fun weightedParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(6)
        }

    private fun sendFromInput() {
        val ui = panel ?: return
        val text = ui.input.text.toString()
        if (text.isBlank() && BubbleChat.pendingImage == null) return
        ui.input.setText("")
        BubbleChat.send(text)
    }

    /**
     * Abre a galeria pelo app principal (o balão não tem tela própria para isso).
     * A imagem só é lida depois que o usuário escolhe o arquivo.
     */
    private fun openImagePicker() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .setAction(MainActivity.ACTION_PICK_BUBBLE_IMAGE)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Não consegui abrir a galeria.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyText(text: String) {
        val clipboard = getSystemService(ClipboardManager::class.java)
        clipboard.setPrimaryClip(ClipData.newPlainText("SaturnIA", text))
        Toast.makeText(this, "Copiado.", Toast.LENGTH_SHORT).show()
    }

    private fun toggleFullscreen() {
        mode = if (mode == BubbleState.MODE_FULLSCREEN) BubbleState.MODE_FLOATING else BubbleState.MODE_FULLSCREEN
        // Voltar do modo tela cheia abre a janela compacta com a mesma conversa.
        panelOpen = mode == BubbleState.MODE_FLOATING
        BubbleState.set(BubbleState.RUNNING, mode, "")
        renderAll()
    }

    private fun minimizeToBubble() {
        mode = BubbleState.MODE_FLOATING
        panelOpen = false
        BubbleState.set(BubbleState.RUNNING, mode, "")
        renderAll()
    }

    private fun closePanel() {
        if (mode == BubbleState.MODE_FULLSCREEN) mode = BubbleState.MODE_FLOATING
        panelOpen = false
        BubbleState.set(BubbleState.RUNNING, mode, "")
        renderAll()
    }

    private fun renderPanel() {
        val ui = panel ?: return
        val messages = BubbleChat.snapshot()
        ui.list.removeAllViews()
        if (messages.isEmpty()) {
            ui.list.addView(TextView(this).apply {
                text = "Pergunte algo à SaturnIA. A conversa continua quando você minimiza o balão."
                setTextColor(Color.parseColor("#7F88B0"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(24), dp(8), dp(24))
            })
        }
        messages.forEach { ui.list.addView(messageRow(it)) }

        val busy = BubbleChat.busy
        ui.typing.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) {
            main.removeCallbacks(dotsTicker)
            dotCount = 0
            ui.typing.text = "Pensando"
            if (running) main.postDelayed(dotsTicker, 400)
        } else {
            main.removeCallbacks(dotsTicker)
        }
        val pending = BubbleChat.pendingImage
        ui.attach.visibility = if (pending != null) View.VISIBLE else View.GONE
        ui.attach.text = "Imagem pronta para enviar. Toque para remover."
        ui.sendButton.alpha = if (busy) 0.5f else 1f
        ui.sendButton.isEnabled = !busy
        ui.status.text = when {
            BubbleChat.token.isBlank() -> "Entre na sua conta no app para usar o balão"
            busy -> "Respondendo…"
            else -> "Modelo ${BubbleChat.model}"
        }
        ui.modeButton.text = if (mode == BubbleState.MODE_FULLSCREEN) "Janela" else "Tela cheia"
        ui.scroll.post { ui.scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun messageRow(message: ChatMessage): View {
        val isUser = message.role == "user"
        val shownText = listOfNotNull(
            if (message.image != null) "Imagem enviada" else null,
            message.text.takeIf { it.isNotBlank() }
        ).joinToString("\n")

        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            maxWidth = (resources.displayMetrics.widthPixels * 0.78f).toInt()
            background = GradientDrawable().apply {
                setColor(
                    when {
                        isUser -> Color.parseColor("#4A55B8")
                        message.failed -> Color.parseColor("#3A1F26")
                        else -> Color.parseColor("#1B2032")
                    }
                )
                cornerRadius = dp(16).toFloat()
            }
            setPadding(dp(10), dp(9), dp(10), dp(9))
        }
        message.image?.let { image ->
            decodeThumb(image.base64)?.let { bitmap ->
                bubble.addView(ImageView(this).apply {
                    setImageBitmap(bitmap)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    adjustViewBounds = true
                    contentDescription = "Imagem enviada"
                }, LinearLayout.LayoutParams(dp(200), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = if (shownText.isNotEmpty()) dp(6) else 0
                })
            }
        }
        if (shownText.isNotEmpty()) {
            bubble.addView(TextView(this).apply {
                text = shownText
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(if (message.failed) Color.parseColor("#FFB4B4") else Color.WHITE)
                setTextIsSelectable(true)
                setPadding(dp(2), 0, dp(2), 0)
            })
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (isUser) Gravity.END else Gravity.START
            setPadding(dp(4), dp(2), dp(4), 0)
        }
        actions.addView(TextView(this).apply {
            text = "Copiar"
            setTextColor(Color.parseColor("#AAB2D6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { copyText(shownText) }
        })

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (isUser) Gravity.END else Gravity.START
            setPadding(0, dp(4), 0, dp(4))
        }
        column.addView(bubble, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        column.addView(actions, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return column
    }

    /** Miniatura da imagem para mostrar na conversa. Decodifica pouco, com amostragem. */
    private fun decodeThumb(base64: String): android.graphics.Bitmap? = try {
        val bytes = Base64.decode(base64, Base64.DEFAULT)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------ notificação e permissões

    private fun startAsForeground() {
        createChannel()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), type)
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = if (mode == BubbleState.MODE_HIDDEN) {
            serviceAction(ACTION_SHOW, 2)
        } else {
            serviceAction(ACTION_HIDE, 3)
        }
        val toggleLabel = if (mode == BubbleState.MODE_HIDDEN) "Mostrar balão" else "Ocultar balão"
        val text = when {
            BubbleState.state == BubbleState.BLOCKED -> "O Android impediu o balão neste app. Toque para tentar de novo."
            mode == BubbleState.MODE_HIDDEN -> "Balão oculto. Toque em Mostrar para voltar."
            else -> "Balão ativo sobre outros apps. A conversa fica guardada enquanto o serviço estiver ativo."
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("SaturnIA Bubble")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(0, toggleLabel, toggleIntent)
            .addAction(0, "Parar", serviceAction(ACTION_STOP, 4))
            .build()
    }

    private fun serviceAction(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this, requestCode,
        Intent(this, BubbleService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "SaturnIA Bubble", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Mostra o balão da SaturnIA sobre outros apps."
                    setShowBadge(false)
                }
            )
        }
    }

    private fun notificationsAllowed(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") ==
            android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun shutdown(finalState: String, finalMode: String, detail: String = "") {
        running = false
        main.removeCallbacksAndMessages(null)
        removeViews()
        stopForeground(STOP_FOREGROUND_REMOVE)
        BubbleState.set(finalState, finalMode, detail)
        stopSelf()
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics).toInt()

    private fun screenWidth(): Int = resources.displayMetrics.widthPixels
    private fun screenHeight(): Int = resources.displayMetrics.heightPixels
}
