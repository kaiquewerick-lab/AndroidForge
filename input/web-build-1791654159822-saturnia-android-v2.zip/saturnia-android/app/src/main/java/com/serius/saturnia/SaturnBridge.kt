package com.serius.saturnia

import android.content.Intent
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import java.util.Locale

/**
 * Ponte entre o HTML (window.SaturnIANative) e o código nativo.
 *
 * Segurança:
 *  - Só expõe as funções listadas abaixo. Nenhuma delas recebe código, URL ou caminho de arquivo.
 *  - launch() só abre apps que já têm ícone na tela inicial (validado pelo PackageManager).
 *  - Nenhuma chave de API existe aqui: as chamadas de IA continuam no Worker.
 *  - A ponte é exposta à página. Veja README: a WebView só carrega a própria página
 *    (ou a URL configurada) e bloqueia navegação para outros sites.
 */
class SaturnBridge(private val activity: MainActivity) {

    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false

    init {
        tts = TextToSpeech(activity) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("pt", "BR"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    fun shutdown() {
        ttsReady = false
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    // ----------------------------------------------------- serviço de voz

    /** Chamado pelo switch "Assistente de voz em segundo plano" quando o usuário liga. */
    @JavascriptInterface
    fun startVoiceService() {
        activity.runOnUiThread { activity.requestVoiceStart() }
    }

    /** Chamado quando o usuário desliga o switch. */
    @JavascriptInterface
    fun stopVoiceService() {
        VoiceService.stop(activity)
        VoiceState.set(VoiceState.STOPPED)
    }

    /** Estado atual: stopped, starting, running, interrupted, error, permission ou unavailable. */
    @JavascriptInterface
    fun getVoiceServiceState(): String = VoiceState.state

    @JavascriptInterface
    fun setWakePhrase(phrase: String) {
        VoicePrefs.setWake(activity, phrase)
    }

    // ----------------------------------------------------- respostas faladas

    /** Lê a resposta em voz alta (pt-BR). Sem efeito se o TTS não estiver pronto. */
    @JavascriptInterface
    fun speak(text: String) {
        val clean = text.trim().take(4000)
        if (clean.isEmpty()) return
        activity.runOnUiThread {
            if (ttsReady) {
                tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "saturnia-${System.nanoTime()}")
            }
        }
    }

    // ----------------------------------------------------- SaturnIA Bubble

    /** Chamado pelo switch "Balão flutuante" no HTML. Pede as permissões que faltarem. */
    @JavascriptInterface
    fun startBubble() {
        activity.runOnUiThread { activity.requestBubbleStart() }
    }

    @JavascriptInterface
    fun stopBubble() {
        BubbleService.stop(activity)
    }

    /** Estado do balão: stopped, running, no_overlay_permission, no_notification_permission, blocked ou error. */
    @JavascriptInterface
    fun getBubbleState(): String = BubbleState.state

    /** Token de sessão do Firebase (ou "" ao sair). Fica só na memória do processo. */
    @JavascriptInterface
    fun setAuthToken(token: String) {
        BubbleChat.setToken(token)
    }

    /** Modelo Gemini escolhido pelo usuário no HTML (validado pelo padrão de nomes). */
    @JavascriptInterface
    fun setChatModel(model: String) {
        BubbleChat.setModel(model)
    }

    // ----------------------------------------------------- apps do aparelho

    /**
     * Lista os apps que podem ser abertos, como JSON:
     * [{"pkg":"...","name":"...","icon":null,"cat":"SOCIAL"}]
     */
    @JavascriptInterface
    fun listApps(): String = AppCatalog.installedJson(activity)

    /** Ícone do app como data URL PNG, ou "" se não houver. Carregado sob demanda. */
    @JavascriptInterface
    fun appIcon(pkg: String): String {
        if (pkg.isBlank() || pkg.length > 200) return ""
        return AppCatalog.iconDataUrl(activity, pkg) ?: ""
    }

    /** Abre um app pelo nome do pacote. Retorna false se não for possível. */
    @JavascriptInterface
    fun launch(pkg: String): Boolean {
        if (pkg.isBlank() || pkg.length > 200) return false
        val intent = activity.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
