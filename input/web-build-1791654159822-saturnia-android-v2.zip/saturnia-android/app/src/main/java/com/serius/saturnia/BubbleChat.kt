package com.serius.saturnia

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Conversa do SaturnIA Bubble, guardada só na memória do processo.
 *
 * Minimizar, ocultar ou reabrir o balão não apaga a conversa. Ela some quando o app
 * é encerrado pelo sistema ou pelo usuário, e não é gravada em disco.
 */
object BubbleChat {

    const val DEFAULT_MODEL = "gemini-3.8-flash"
    private val MODEL_RE = Regex("^gemini-\\d+(\\.\\d+)?-(flash-lite|flash|pro)(-preview)?$")
    private const val MAX_STORED = 60
    private const val MAX_INPUT = 4000

    private val messages = CopyOnWriteArrayList<ChatMessage>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** Token de sessão Firebase, enviado pelo HTML. Só na memória. */
    @Volatile
    var token: String = ""
        private set

    @Volatile
    var model: String = DEFAULT_MODEL
        private set

    @Volatile
    var busy: Boolean = false
        private set

    fun setToken(value: String) {
        token = value.trim()
    }

    fun setModel(value: String) {
        if (MODEL_RE.matches(value)) model = value
    }

    fun snapshot(): List<ChatMessage> = messages.toList()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun clear() {
        if (busy) return
        messages.clear()
        notifyListeners()
    }

    /** Envia uma mensagem. Respostas e erros chegam pela thread principal e avisam os ouvintes. */
    fun send(text: String) {
        val clean = text.trim().take(MAX_INPUT)
        if (clean.isEmpty() || busy) return

        add(ChatMessage("user", clean))
        val history = ChatHistory.forRequest(messages.toList())
        val currentToken = token
        val currentModel = model
        busy = true
        notifyListeners()

        worker.execute {
            val result = GeminiClient.call(currentToken, currentModel, history)
            main.post {
                when (result) {
                    is GeminiResult.Ok -> add(ChatMessage("model", result.text))
                    is GeminiResult.Failed -> add(ChatMessage("model", result.message, failed = true))
                }
                busy = false
                notifyListeners()
            }
        }
    }

    private fun add(message: ChatMessage) {
        messages.add(message)
        while (messages.size > MAX_STORED) messages.removeAt(0)
    }

    private fun notifyListeners() {
        listeners.forEach { it() }
    }
}
