package com.serius.saturnia

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente do endpoint /api/gemini do Worker, o mesmo usado pela versão web.
 * O app não tem chave de API: envia só o token de sessão Firebase do usuário.
 */
object GeminiClient {

    /** Endereço público do Worker (não é segredo). As chaves ficam no servidor. */
    const val WORKER_URL = "https://saturnia-api-proxy.kiiikaioxdogulox.workers.dev"

    private const val SYSTEM =
        "Você é a SaturnIA, uma assistente que responde em português do Brasil. " +
            "Você aparece em um balão flutuante sobre outros aplicativos, então seja clara e objetiva."

    /** Mensagem amigável para o erro HTTP recebido do Worker (regras em ChatRules). */
    fun errorFor(status: Int, code: String?): String = ChatRules.errorFor(status, code)

    fun buildBody(model: String, history: List<ChatMessage>): JSONObject {
        val contents = JSONArray()
        for (m in history) {
            contents.put(
                JSONObject()
                    .put("role", m.role)
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        return JSONObject()
            .put("model", model)
            .put("contents", contents)
            .put("system", SYSTEM)
            .put("temperature", 0.7)
            .put("search", false)
    }

    /** Chamada bloqueante: rodar sempre fora da thread principal. */
    fun call(token: String, model: String, history: List<ChatMessage>): GeminiResult {
        if (token.isBlank()) {
            return GeminiResult.Failed("Entre na sua conta da SaturnIA no app para usar o balão.")
        }
        if (history.isEmpty()) {
            return GeminiResult.Failed("Escreva uma mensagem para começar.")
        }
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("$WORKER_URL/api/gemini").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.outputStream.use { it.write(buildBody(model, history).toString().toByteArray(Charsets.UTF_8)) }

            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (status !in 200..299) {
                val code = try {
                    JSONObject(raw).optJSONObject("error")?.optString("code")
                } catch (e: Exception) {
                    null
                }
                GeminiResult.Failed(ChatRules.errorFor(status, code))
            } else {
                val text = JSONObject(raw).optString("text").trim()
                if (text.isEmpty()) {
                    GeminiResult.Failed("O modelo não enviou resposta. Tente reformular a pergunta.")
                } else {
                    GeminiResult.Ok(text)
                }
            }
        } catch (e: IOException) {
            GeminiResult.Failed("Não foi possível falar com o servidor. Verifique a conexão.")
        } catch (e: Exception) {
            GeminiResult.Failed("Resposta inesperada do servidor.")
        } finally {
            conn?.disconnect()
        }
    }
}
