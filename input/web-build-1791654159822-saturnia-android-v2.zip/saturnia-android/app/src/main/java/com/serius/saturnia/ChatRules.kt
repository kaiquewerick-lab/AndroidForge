package com.serius.saturnia

/**
 * Regras puras do balão: histórico enviado, tipos de resposta e mensagens de erro.
 * Não usam Android nem org.json, então são testadas na JVM (BubbleLogicTest).
 */

/** Mensagem da conversa do balão. */
data class ChatMessage(val role: String, val text: String, val failed: Boolean = false)

/** Resultado de uma chamada à IA. */
sealed class GeminiResult {
    data class Ok(val text: String) : GeminiResult()
    data class Failed(val message: String) : GeminiResult()
}

object ChatHistory {
    const val MAX_TURNS = 20

    /**
     * Mensagens válidas para a próxima chamada: sem falhas, sem vazios, com papéis
     * "user"/"model", limitadas às últimas [maxTurns], começando sempre pelo usuário.
     */
    fun forRequest(messages: List<ChatMessage>, maxTurns: Int = MAX_TURNS): List<ChatMessage> {
        val usable = messages.filter {
            !it.failed && it.text.isNotBlank() && (it.role == "user" || it.role == "model")
        }
        val recent = usable.takeLast(maxTurns)
        val firstUser = recent.indexOfFirst { it.role == "user" }
        return if (firstUser < 0) emptyList() else recent.drop(firstUser)
    }
}

object ChatRules {
    /** Mensagem amigável para o erro HTTP recebido do Worker. */
    fun errorFor(status: Int, code: String?): String = when {
        code == "limite_local" || status == 429 -> "Muitas mensagens em pouco tempo. Aguarde um minuto."
        status == 401 -> "Sua sessão expirou. Abra a SaturnIA e entre de novo."
        status == 400 || status == 413 -> "Não consegui enviar esta conversa. Tente uma mensagem mais curta."
        status == 500 && code == "config" -> "O servidor ainda não está configurado. Tente mais tarde."
        else -> "Servidor indisponível agora. Tente de novo em instantes."
    }
}
