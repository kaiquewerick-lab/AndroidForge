package com.serius.saturnia

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BubbleLogicTest {

    private fun u(t: String) = ChatMessage("user", t)
    private fun m(t: String) = ChatMessage("model", t)

    @Test
    fun falhasESemTextoNaoVaoParaAIA() {
        val list = listOf(u("oi"), m("Erro de rede", failed = true), u("   "), m("olá"), u("tudo bem?"))
        val out = ChatHistory.forRequest(list)
        assertEquals(listOf("oi", "olá", "tudo bem?"), out.map { it.text })
    }

    @Test
    fun conversaSempreComecaPeloUsuario() {
        val out = ChatHistory.forRequest(listOf(m("resposta antiga"), u("pergunta"), m("ok")))
        assertEquals("user", out.first().role)
        assertEquals(listOf("pergunta", "ok"), out.map { it.text })
    }

    @Test
    fun limitaAsUltimasMensagens() {
        val list = (1..30).map { if (it % 2 == 1) u("p$it") else m("r$it") }
        val out = ChatHistory.forRequest(list, maxTurns = 4)
        assertEquals(listOf("p27", "r28", "p29", "r30"), out.map { it.text })
    }

    @Test
    fun semMensagensValidasNaoEnviaNada() {
        assertTrue(ChatHistory.forRequest(listOf(m("só resposta"))).isEmpty())
        assertTrue(ChatHistory.forRequest(emptyList()).isEmpty())
    }

    @Test
    fun erroDeLimiteEhMensagemDeEspera() {
        assertTrue(ChatRules.errorFor(429, null).startsWith("Muitas mensagens"))
        assertTrue(ChatRules.errorFor(400, "limite_local").startsWith("Muitas mensagens"))
    }

    @Test
    fun erroDeSessaoPedeNovoLogin() {
        assertTrue(ChatRules.errorFor(401, "unauthenticated").contains("entre de novo"))
    }

    @Test
    fun erroGenericoTemMensagemPadrao() {
        assertEquals("Servidor indisponível agora. Tente de novo em instantes.", ChatRules.errorFor(503, null))
    }
}
