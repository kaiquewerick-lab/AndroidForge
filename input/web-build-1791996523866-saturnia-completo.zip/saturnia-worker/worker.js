// SaturnIA · API proxy (Cloudflare Worker)
// Chaves da empresa (GEMINI_API_KEY, OPENAI_API_KEY, ANTHROPIC_API_KEY) ficam APENAS em env (Secrets).
// Nunca são devolvidas, registradas em log ou enviadas ao navegador.
//
// Rotas:
//   GET  /api/health     -> { ok: true }
//   POST /api/gemini     -> body { model, contents, system?, temperature?, search? }  -> { text, sources }
//   POST /api/multi      -> body { provider: "openai"|"claude", model, system?, messages } -> { text }
//
// Autenticação: Authorization: Bearer <Firebase ID token>. O token é verificado aqui
// (assinatura RS256 com os certificados públicos do Google Securetoken, iss/aud/exp/sub).
// CORS é só política do navegador; não substitui a verificação do token.

// Limites alinhados ao cliente (index-50.html): ctx() corta cada mensagem em 30.000 caracteres e
// a instrução de sistema (BASE + memória + projeto) pode passar de 8.000. Imagens vão em base64.
const LIMITS = {
  bodyBytes: 12_000_000,     // corpo máximo (inclui anexos em base64)
  contents: 60,              // mensagens por requisição
  textChars: 60_000,         // caracteres por mensagem de texto
  systemChars: 40_000,       // instrução de sistema
  timeoutMs: 90_000,         // tempo máximo para o provedor responder
  temperatureMax: 2,
  ratePerMinute: 20,         // padrão, sobrescrito por RATE_PER_MINUTE
};

// Modelos permitidos. O cliente não escolhe livremente qualquer identificador.
const GEMINI_MODEL_RE = /^gemini-\d+(\.\d+)?-(flash-lite|flash|pro)(-preview)?$/;
const OPENAI_MODELS = new Set(["gpt-6-astra","gpt-6.1-sol","gpt-6-luna","gpt-5.5","gpt-5.5-pro","gpt-5.4","gpt-5.4-pro","gpt-5.4-mini","gpt-5.4-nano","gpt-5","gpt-5-mini","gpt-5-nano","gpt-4.1","gpt-4.1-mini","gpt-4.1-nano","gpt-4o","gpt-4o-mini","o3","o3-pro","o4-mini"]);
const CLAUDE_MODELS = new Set(["claude-fable-5-1","claude-opus-5-5","claude-sonnet-5-5","claude-haiku-5-5"]);
const INLINE_MIME = new Set(["image/png","image/jpeg","image/webp","image/gif","application/pdf",
  "audio/wav","audio/mpeg","audio/mp3","audio/mp4","audio/aac","audio/ogg","audio/webm","audio/flac",
  "text/plain","text/markdown","text/csv","application/json"]);

const enc = new TextEncoder();
let certCache = { at: 0, maxAge: 0, certs: null };

// ---------- utilidades de resposta ----------
function corsHeaders(origin, env) {
  const allowed = (env.ALLOWED_ORIGINS || "").split(",").map(s => s.trim()).filter(Boolean);
  if (origin && allowed.includes(origin)) {
    return { "Access-Control-Allow-Origin": origin, "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization", "Access-Control-Max-Age": "600", "Vary": "Origin" };
  }
  return { "Vary": "Origin" };
}
function json(status, body, cors) {
  return new Response(JSON.stringify(body), { status, headers: {
    "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff", ...cors } });
}
const err = (status, code, message, cors) => json(status, { error: { code, message } }, cors);

// Remove qualquer trecho com cara de chave antes de devolver mensagem de erro de provedor.
function scrub(s) {
  return String(s || "").slice(0, 200).replace(/AIza[0-9A-Za-z_-]{10,}/g, "[oculto]").replace(/sk-[A-Za-z0-9_-]{8,}/g, "[oculto]");
}

// ---------- verificação de token Firebase ----------
const b64uToBytes = s => {
  s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "=";
  return Uint8Array.from(atob(s), c => c.charCodeAt(0));
};
const jsonB64u = s => JSON.parse(new TextDecoder().decode(b64uToBytes(s)));

async function getCerts() {
  const now = Date.now();
  if (certCache.certs && now - certCache.at < certCache.maxAge * 1000) return certCache.certs;
  let r;
  try { r = await fetch("https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com"); }
  catch (e) { throw Object.assign(new Error("certs"), { upstream: true }); }
  if (!r.ok) throw Object.assign(new Error("certs"), { upstream: true });
  const maxAge = /max-age=(\d+)/.exec(r.headers.get("Cache-Control") || "");
  certCache = { at: now, maxAge: maxAge ? +maxAge[1] : 3600, certs: await r.json() };
  return certCache.certs;
}

// Lê um TLV ASN.1 em buf[off]. Retorna { tag, start, end } (start = início do conteúdo, end = fim).
function tlv(buf, off) {
  const tag = buf[off]; let len = buf[off + 1]; let p = off + 2;
  if (len & 0x80) { const n = len & 0x7f; len = 0; for (let i = 0; i < n; i++) len = len * 256 + buf[p + i]; p += n; }
  return { tag, start: p, end: p + len };
}
// Extrai o SubjectPublicKeyInfo (DER) de um certificado X.509 (DER).
function spkiFromCert(der) {
  const cert = tlv(der, 0);
  const tbs = tlv(der, cert.start);
  let off = tbs.start, child = null;
  const RSA_OID = [0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x01, 0x01];
  while (off < tbs.end) {
    const t = tlv(der, off);
    if (t.tag === 0x30) {
      const inner = tlv(der, t.start);
      if (inner.tag === 0x30) {
        const oid = tlv(der, inner.start);
        if (oid.tag === 0x06 && oid.end - oid.start === RSA_OID.length && RSA_OID.every((b, i) => der[oid.start + i] === b)) { child = der.slice(off, t.end); break; }
      }
    }
    off = t.end;
  }
  if (!child) throw new Error("spki");
  return child;
}
function pemToDer(pem) {
  const b64 = pem.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "");
  return Uint8Array.from(atob(b64), c => c.charCodeAt(0));
}

export async function verifyIdToken(token, projectId) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) throw new Error("formato");
  const header = jsonB64u(parts[0]), payload = jsonB64u(parts[1]);
  if (header.alg !== "RS256" || !header.kid) throw new Error("alg");
  const now = Math.floor(Date.now() / 1000);
  if (payload.iss !== `https://securetoken.google.com/${projectId}`) throw new Error("iss");
  if (payload.aud !== projectId) throw new Error("aud");
  if (!(payload.exp > now)) throw new Error("exp");
  if (!(payload.iat <= now + 60)) throw new Error("iat");
  if (typeof payload.sub !== "string" || !payload.sub || payload.sub.length > 128) throw new Error("sub");
  let certs = await getCerts();
  let pem = certs[header.kid];
  if (!pem) { certCache.at = 0; certs = await getCerts(); pem = certs[header.kid]; }
  if (!pem) throw new Error("kid");
  const key = await crypto.subtle.importKey("spki", spkiFromCert(pemToDer(pem)),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64uToBytes(parts[2]), enc.encode(parts[0] + "." + parts[1]));
  if (!ok) throw new Error("assinatura");
  return payload.sub;
}

// ---------- validação ----------
function validGeminiBody(b) {
  if (!b || typeof b !== "object") return "corpo inválido";
  if (typeof b.model !== "string" || !GEMINI_MODEL_RE.test(b.model)) return "modelo não permitido";
  if (!Array.isArray(b.contents) || b.contents.length < 1 || b.contents.length > LIMITS.contents) return "mensagens inválidas";
  if (b.system !== undefined && (typeof b.system !== "string" || b.system.length > LIMITS.systemChars)) return "instrução inválida";
  if (b.temperature !== undefined && (typeof b.temperature !== "number" || b.temperature < 0 || b.temperature > LIMITS.temperatureMax)) return "temperatura inválida";
  if (b.search !== undefined && typeof b.search !== "boolean") return "busca inválida";
  for (const c of b.contents) {
    if (!c || (c.role !== "user" && c.role !== "model") || !Array.isArray(c.parts)) return "mensagem inválida";
    for (const p of c.parts) {
      if (p && typeof p.text === "string") { if (p.text.length > LIMITS.textChars) return "texto grande demais"; continue; }
      if (p && p.inline_data && INLINE_MIME.has(p.inline_data.mime_type) && typeof p.inline_data.data === "string") continue;
      return "parte inválida";
    }
  }
  return null;
}
function validMultiBody(b) {
  if (!b || typeof b !== "object") return "corpo inválido";
  if (b.provider === "openai") { if (!OPENAI_MODELS.has(b.model)) return "modelo não permitido"; }
  else if (b.provider === "claude") { if (!CLAUDE_MODELS.has(b.model)) return "modelo não permitido"; }
  else return "provedor não suportado";
  if (b.system !== undefined && (typeof b.system !== "string" || b.system.length > LIMITS.systemChars)) return "instrução inválida";
  if (!Array.isArray(b.messages) || b.messages.length < 1 || b.messages.length > LIMITS.contents) return "mensagens inválidas";
  for (const m of b.messages) {
    if (!m || (m.role !== "user" && m.role !== "assistant") || typeof m.text !== "string" || m.text.length > LIMITS.textChars) return "mensagem inválida";
  }
  return null;
}

// ---------- chamadas aos provedores ----------
async function upstream(url, init) {
  try {
    return await fetch(url, { ...init, signal: AbortSignal.timeout(LIMITS.timeoutMs) });
  } catch (e) {
    if (e && (e.name === "TimeoutError" || e.name === "AbortError")) return { timeout: true };
    return { network: true };
  }
}
const netFail = { fail: [502, "rede", "Não foi possível falar com o provedor agora. Tente de novo."] };
function mapUpstreamStatus(status) {
  if (status === 400) return [502, "provedor_recusou", "O provedor recusou o pedido."];
  if (status === 401 || status === 403) return [502, "chave_servidor", "A chave do servidor não tem permissão para este modelo. Avise o administrador."];
  if (status === 404) return [404, "modelo_indisponivel", "Este modelo não está disponível no momento. Escolha outro."];
  if (status === 429) return [429, "limite", "Limite de uso do provedor atingido. Tente de novo em instantes."];
  return [503, "indisponivel", "O provedor está instável agora. Tente de novo em instantes."];
}

// Instabilidade do provedor: tenta de novo e, se persistir, usa um modelo mais leve.
const GEMINI_FALLBACK = "gemini-3.5-flash-lite";
const TRANSIENT_STATUS = new Set([429, 500, 502, 503, 504]);
const isTransient = r => !r.timeout && !r.network && TRANSIENT_STATUS.has(r.status);

async function callGemini(env, b) {
  const body = { contents: b.contents, generationConfig: { temperature: b.temperature ?? 1 } };
  if (b.system) body.systemInstruction = { parts: [{ text: b.system }] };
  if (b.search) body.tools = [{ google_search: {} }];
  const callModel = model => upstream(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
    body: JSON.stringify(body) });
  let r = await callModel(b.model);
  if (isTransient(r)) { await new Promise(res => setTimeout(res, 800)); r = await callModel(b.model); }
  if (isTransient(r) && b.model !== GEMINI_FALLBACK) r = await callModel(GEMINI_FALLBACK);
  if (r.timeout) return { fail: [504, "tempo_esgotado", "O Gemini demorou demais. Tente de novo."] };
  if (r.network) return netFail;
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) return { fail: mapUpstreamStatus(r.status) };
  const cd = (j && j.candidates && j.candidates[0]) || null;
  if (!j || !cd) return { fail: [502, "resposta_invalida", "Resposta do Gemini em formato inesperado."] };
  const text = ((cd.content && cd.content.parts) || []).map(p => p.text || "").join("");
  if (!text) return { fail: [422, "sem_texto", "O Gemini não devolveu texto (" + scrub(cd.finishReason || j.promptFeedback?.blockReason || "sem motivo") + ")."] };
  const seen = {};
  const sources = ((cd.groundingMetadata || {}).groundingChunks || [])
    .map(c => c.web && c.web.uri ? { u: c.web.uri, t: String(c.web.title || "").slice(0, 80) } : null)
    .filter(x => x && /^https:\/\//.test(x.u) && !seen[x.t || x.u] && (seen[x.t || x.u] = 1)).slice(0, 6);
  return { ok: { text, sources } };
}

async function callOpenAI(env, b) {
  const msgs = [];
  if (b.system) msgs.push({ role: "system", content: b.system });
  for (const m of b.messages) msgs.push({ role: m.role, content: m.text });
  const r = await upstream("https://api.openai.com/v1/chat/completions", {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: "Bearer " + env.OPENAI_API_KEY },
    body: JSON.stringify({ model: b.model, messages: msgs }) });
  if (r.timeout) return { fail: [504, "tempo_esgotado", "A OpenAI demorou demais. Tente de novo."] };
  if (r.network) return netFail;
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) return { fail: mapUpstreamStatus(r.status) };
  const text = j && j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
  if (typeof text !== "string") return { fail: [502, "resposta_invalida", "Resposta da OpenAI em formato inesperado."] };
  return { ok: { text } };
}

// A API da Anthropic exige alternância user/assistant e começar por user.
function claudeMessages(list) {
  const out = [];
  for (const m of list) {
    const last = out[out.length - 1];
    if (last && last.role === m.role) last.content += "\n\n" + m.text; else out.push({ role: m.role, content: m.text });
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}
async function callClaude(env, b) {
  const msgs = claudeMessages(b.messages);
  if (!msgs.length) return { fail: [400, "vazio", "Mensagem vazia."] };
  const body = { model: b.model, max_tokens: 2048, messages: msgs };
  if (b.system) body.system = b.system;
  const r = await upstream("https://api.anthropic.com/v1/messages", {
    method: "POST", headers: { "Content-Type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify(body) });
  if (r.timeout) return { fail: [504, "tempo_esgotado", "A Claude demorou demais. Tente de novo."] };
  if (r.network) return netFail;
  let j = null; try { j = await r.json(); } catch (e) {}
  if (!r.ok) return { fail: mapUpstreamStatus(r.status) };
  if (!j || !Array.isArray(j.content)) return { fail: [502, "resposta_invalida", "Resposta da Claude em formato inesperado."] };
  return { ok: { text: j.content.map(x => x.text || "").join("") } };
}

// ---------- roteamento ----------
async function readBody(request) {
  const declared = +(request.headers.get("Content-Length") || 0);
  if (declared > LIMITS.bodyBytes) return { tooLarge: true };
  const raw = await request.text();
  if (enc.encode(raw).length > LIMITS.bodyBytes) return { tooLarge: true };
  try { return { body: JSON.parse(raw) }; } catch (e) { return { bad: true }; }
}

// Controle de requisições por usuário: janela fixa de 1 minuto guardada num Durable Object.
// Cada usuário tem seu próprio contador; o estado é persistido pelo Cloudflare.
export class RateLimiter {
  constructor(state) { this.state = state; }
  async fetch(request) {
    const { limit, windowMs } = await request.json();
    const now = Date.now();
    let w = (await this.state.storage.get("w")) || { start: now, count: 0 };
    if (now - w.start >= windowMs) w = { start: now, count: 0 };
    w.count += 1;
    await this.state.storage.put("w", w);
    const ok = w.count <= limit;
    return Response.json({ ok, retryAfter: Math.max(1, Math.ceil((w.start + windowMs - now) / 1000)) });
  }
}

async function checkRate(env, uid) {
  if (!env.RATE_LIMITER) return { error: "config" };
  const limit = Math.max(1, +(env.RATE_PER_MINUTE || LIMITS.ratePerMinute));
  const stub = env.RATE_LIMITER.get(env.RATE_LIMITER.idFromName(uid));
  const r = await stub.fetch("https://ratelimit.internal/check", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ limit, windowMs: 60_000 }) });
  if (!r.ok) return { error: "config" };
  const j = await r.json();
  return { ok: j.ok, retryAfter: j.retryAfter };
}

export default {
  async fetch(request, env) {
    try {
      return await handle(request, env);
    } catch (e) {
      // Última barreira: registra só o tipo do erro, sem detalhes internos nem dados do pedido.
      console.log(JSON.stringify({ route: "interno", error: e && e.name ? e.name : "erro" }));
      return json(500, { error: { code: "interno", message: "Erro interno no servidor. Tente de novo." } }, {});
    }
  },
};

async function handle(request, env) {
  {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin");
    const cors = corsHeaders(origin, env);
    if (origin && !cors["Access-Control-Allow-Origin"]) return err(403, "origem_nao_permitida", "Origem não permitida.", cors);

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
    if (url.pathname === "/api/health") {
      if (request.method !== "GET") return err(405, "metodo", "Use GET.", cors);
      return json(200, { ok: true }, cors);
    }
    if (url.pathname !== "/api/gemini" && url.pathname !== "/api/multi") return err(404, "rota", "Rota não encontrada.", cors);
    if (request.method !== "POST") return err(405, "metodo", "Use POST.", cors);
    if (!(request.headers.get("Content-Type") || "").toLowerCase().startsWith("application/json")) return err(415, "tipo", "Envie JSON.", cors);

    const auth = request.headers.get("Authorization") || "";
    const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
    if (!token) return err(401, "sem_sessao", "Entre na conta para usar a SaturnIA.", cors);
    let uid;
    try { uid = await verifyIdToken(token, env.FIREBASE_PROJECT_ID); }
    catch (e) {
      if (e && e.upstream) return err(503, "auth_indisponivel", "Não foi possível verificar a sessão agora. Tente de novo.", cors);
      return err(401, "sessao_invalida", "Sua sessão expirou. Entre novamente.", cors);
    }

    // Controle de requisições: obrigatório. Sem o binding RATE_LIMITER o Worker recusa as chamadas.
    const rate = await checkRate(env, uid);
    if (rate.error) return err(500, "config", "Controle de requisições não configurado no servidor.", cors);
    if (!rate.ok) return json(429, { error: { code: "limite_local", message: "Muitas mensagens em pouco tempo. Aguarde um minuto." } },
      { ...cors, "Retry-After": String(rate.retryAfter) });

    const read = await readBody(request);
    if (read.tooLarge) return err(413, "grande", "Mensagem grande demais.", cors);
    if (read.bad) return err(400, "json", "Corpo inválido.", cors);

    const started = Date.now();
    let result, provider;
    if (url.pathname === "/api/gemini") {
      provider = "gemini";
      const bad = validGeminiBody(read.body);
      if (bad) return err(400, "validacao", bad, cors);
      if (!env.GEMINI_API_KEY) return err(500, "config", "Servidor sem chave configurada.", cors);
      result = await callGemini(env, read.body);
    } else {
      const bad = validMultiBody(read.body);
      if (bad) return err(400, "validacao", bad, cors);
      provider = read.body.provider;
      const keyName = provider === "openai" ? "OPENAI_API_KEY" : "ANTHROPIC_API_KEY";
      if (!env[keyName]) return err(500, "config", "Servidor sem chave configurada.", cors);
      result = provider === "openai" ? await callOpenAI(env, read.body) : await callClaude(env, read.body);
    }
    // Log sem identificadores pessoais e sem segredos.
    console.log(JSON.stringify({ route: url.pathname, provider, ok: !!result.ok, status: result.fail ? result.fail[0] : 200, ms: Date.now() - started }));
    if (result.fail) return err(result.fail[0], result.fail[1], result.fail[2], cors);
    return json(200, result.ok, cors);
  }
}

// Listas de modelos exportadas para o teste de consistência com o HTML.
export const ALLOWED_MODELS = { gemini: GEMINI_MODEL_RE, openai: OPENAI_MODELS, claude: CLAUDE_MODELS };
