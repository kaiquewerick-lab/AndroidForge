# SaturnIA · Worker das APIs (saturnia-api-proxy)

O Worker recebe as chamadas do site, verifica a sessão Firebase e encaminha o pedido ao Gemini, à OpenAI ou à Claude usando os Secrets da Cloudflare. As chaves nunca vão para o HTML, o JavaScript do navegador, logs ou respostas.

## Arquivos
- `worker.js`: servidor (rotas, verificação do token, validação, limite por usuário, chamadas aos provedores).
- `wrangler.toml`: nome, variáveis, origens permitidas e o Durable Object do limite.
- `test/worker.test.mjs`: 23 testes automatizados (chamadas simuladas).
- `test/e2e_server.mjs`: sobe o `worker.js` real em `http://localhost:8799` para testar junto com o site.

## Rotas (contrato usado pelo site)
| Rota | Corpo | Resposta de sucesso | Erro |
|---|---|---|---|
| `GET /api/health` | — | `{ "ok": true }` | — |
| `POST /api/gemini` | `{ model, contents, system?, temperature?, search? }` | `{ "text", "sources": [{u,t}] }` | `{ "error": { "code", "message" } }` |
| `POST /api/multi` | `{ provider: "openai" \| "claude", model, system?, messages: [{role: "user"\|"assistant", text}] }` | `{ "text" }` | igual |

Todas as rotas `POST` exigem `Authorization: Bearer <token do Firebase>`.

Códigos de erro: `sessao_invalida` (401), `validacao` (400), `grande` (413), `limite_local` (429, com `Retry-After`), `limite` (429 do provedor), `modelo_indisponivel` (404), `indisponivel` (503), `tempo_esgotado` (504), `resposta_invalida` (502), `rede` (502, provedor inacessível por falha de rede), `auth_indisponivel` (503, não foi possível obter as chaves públicas do Google para verificar a sessão; tente de novo), `interno` (500, erro inesperado; detalhes não são devolvidos), `config` (500).

## Modelos aceitos
- Gemini: `gemini-<versão>-(flash|flash-lite|pro)[-preview]`. Confirmado na documentação do Gemini: `gemini-3.8-flash`, `gemini-3.5-flash-lite`, `gemini-3.1-pro-preview`.
- Claude: `claude-fable-5-1`, `claude-opus-5-5`, `claude-sonnet-5-5`, `claude-haiku-5-5`. Confirmado na documentação da Anthropic.
- OpenAI: `gpt-6-astra`, `gpt-6.1-sol`, `gpt-6-luna` foram confirmados como modelos atuais na documentação da OpenAI. Os demais (gpt-5.x, gpt-4.1, gpt-4o, o3, o4-mini) ainda não foram confirmados por essa documentação. Antes de publicar, confira na sua conta quais estão disponíveis e remova os que não estiverem.
- A lista do Worker é a mesma usada no site. O teste `modelos do HTML são exatamente os aceitos pelo Worker` falha se as duas divergirem.

## Limites
- Corpo: até 12 MB (anexos em base64 entram aqui).
- Mensagens: até 60 por requisição; 60 mil caracteres por mensagem; instrução de sistema até 40 mil.
- Tempo: 90 segundos por chamada ao provedor.
- Temperatura: 0 a 2.

## Controle de requisições por usuário
- Cada usuário tem um contador próprio no Durable Object `RateLimiter`, com janela de 1 minuto.
- Limite padrão: `RATE_PER_MINUTE = "20"` em `wrangler.toml`. Ajuste o valor se quiser.
- Ao passar do limite, o Worker responde 429 com `Retry-After` e o site mostra "Muitas mensagens em pouco tempo".
- Falha fechada: se o binding não existir, o Worker recusa as chamadas (500 `config`). O limite não pode ser desligado sem remover o binding de propósito.
- Esse controle é por minuto. Um limite diário, se quiser, precisa de outra regra.

## Publicar (somente quando você decidir)
1. Instale o Node.js 20 ou superior e o Wrangler: `npm i -g wrangler`.
2. Dentro desta pasta, entre na sua conta: `wrangler login`.
3. Confirme os Secrets: `wrangler secret list` (devem aparecer GEMINI_API_KEY, OPENAI_API_KEY e ANTHROPIC_API_KEY).
4. No `wrangler.toml`, troque `ALLOWED_ORIGINS` pelo endereço real do site (exatamente como aparece no navegador, com https).
5. Valide sem publicar: `npx wrangler deploy --dry-run`.
6. Publique: `npx wrangler deploy`. A URL aparece no final, no formato `https://saturnia-api-proxy.<sua-conta>.workers.dev`.
7. Teste: abra `<URL>/api/health`. Deve mostrar `{"ok":true}`.

## Conectar o site (somente depois de testar)
No `index.html`, troque:
`const WORKER_URL="";`
por:
`const WORKER_URL="<URL do passo 6>";`
Com a URL vazia, o site usa o caminho atual (Firebase). Não troque antes de testar o Worker publicado.

## Instabilidade do Gemini

Quando o Google responde com erro temporário (429, 500, 502, 503 ou 504), o Worker:

1. espera 0,8 segundo e tenta o mesmo modelo de novo;
2. se ainda falhar, usa o modelo de reserva `gemini-3.5-flash-lite`.

Erros que não são de instabilidade (ex.: 400, chave inválida) não são repetidos. Se o modelo de reserva também falhar, o cliente recebe o erro normal (503 "instável" ou 429 "limite"). O cliente não é avisado quando a reserva foi usada.

## Testes
- Automatizados: `node --test test/worker.test.mjs` (23 testes). Usam uma chave RSA de teste gerada localmente para simular o Firebase e chamadas simuladas aos provedores. Nada é enviado ao Google, OpenAI ou Anthropic.
- Geração das chaves de teste (necessária uma vez, não são enviadas nesta pasta):
  ```
  cd test
  openssl req -x509 -newkey rsa:2048 -nodes -keyout key1.pem -out cert1.pem -days 2 -subj "/CN=securetoken-test"
  openssl req -x509 -newkey rsa:2048 -nodes -keyout key2.pem -out cert2.pem -days 2 -subj "/CN=other"
  cd ..
  ```
- Ponta a ponta com o site: `node test/e2e_server.mjs` (sobe o Worker em localhost:8799 e grava `test/token.txt`). Depois abra `out_worker_mode.html` (com `WORKER_URL="http://localhost:8799"`) em um servidor local na porta 8765.
- Ainda não executados: chamadas reais ao Gemini, OpenAI e Claude, verificação com os certificados públicos do Google e comportamento na Cloudflare (inclusive o Durable Object). Esses testes precisam ser feitos depois da publicação.
- O `wrangler deploy --dry-run` não pôde ser executado neste ambiente, porque o registro npm bloqueia o pacote wrangler. A sintaxe do `wrangler.toml` foi validada, mas não a configuração pelo próprio Wrangler.

## Pendências do proprietário
- Informar a URL real publicada (o site só usa o Worker depois disso).
- Ajustar `ALLOWED_ORIGINS` para o endereço real do site.
- Confirmar os modelos OpenAI disponíveis na sua conta.
- Confirmar que os Secrets antigos que possam ter ficado expostos foram revogados e substituídos.
- As Firebase Functions `saturniaApi` e `saturniaMulti` continuam existindo e podem conter chaves próprias. Este código não as altera.
