// Sobe o worker.js REAL em http://localhost:8799 (Node), com Google e provedores simulados.
// Uso: node e2e_server.mjs  -> escreve token.txt (JWT assinado com a chave de teste) e upstream.log
import http from "node:http";
import { readFileSync, writeFileSync, appendFileSync, existsSync, rmSync } from "node:fs";
import { createSign } from "node:crypto";
import worker from "../worker.js";

const HERE = new URL(".", import.meta.url);
const CERT1 = readFileSync(new URL("cert1.pem", HERE), "utf8");
const KEY1 = readFileSync(new URL("key1.pem", HERE), "utf8");
const PROJECT = "saturnia-test";
const LOG = new URL("upstream.log", HERE);
if (existsSync(LOG)) rmSync(LOG);

const b64u = b => Buffer.from(b).toString("base64url");
const now = Math.floor(Date.now() / 1000);
const h = b64u(JSON.stringify({ alg: "RS256", kid: "k1", typ: "JWT" }));
const p = b64u(JSON.stringify({ iss: `https://securetoken.google.com/${PROJECT}`, aud: PROJECT, sub: "uid-e2e", iat: now - 5, exp: now + 3600, auth_time: now - 5 }));
const sg = createSign("RSA-SHA256"); sg.update(h + "." + p); sg.end();
writeFileSync(new URL("token.txt", HERE), `${h}.${p}.${sg.sign(KEY1, "base64url")}`);

const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init = {}) => {
  const u = String(url);
  if (u.includes("googleapis.com/robot/v1/metadata/x509")) return new Response(JSON.stringify({ k1: CERT1 }), { headers: { "Cache-Control": "max-age=3600" } });
  if (u.includes("generativelanguage.googleapis.com")) {
    appendFileSync(LOG, JSON.stringify({ to: "gemini", model: u.split("/models/")[1]?.split(":")[0], key: init.headers["x-goog-api-key"] ? "presente" : "ausente" }) + "\n");
    return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: "resposta gemini via worker" }] } }] }), { status: 200 });
  }
  if (u.includes("api.openai.com")) {
    appendFileSync(LOG, JSON.stringify({ to: "openai", model: JSON.parse(init.body).model, key: init.headers.Authorization ? "presente" : "ausente" }) + "\n");
    return new Response(JSON.stringify({ choices: [{ message: { content: "resposta openai via worker" } }] }), { status: 200 });
  }
  if (u.includes("api.anthropic.com")) {
    appendFileSync(LOG, JSON.stringify({ to: "claude", model: JSON.parse(init.body).model, key: init.headers["x-api-key"] ? "presente" : "ausente" }) + "\n");
    return new Response(JSON.stringify({ content: [{ type: "text", text: "resposta claude via worker" }] }), { status: 200 });
  }
  return realFetch(url, init);
};

// Durable Object em memória (mesma lógica do RateLimiter exportado pelo worker.js)
const { RateLimiter } = await import("../worker.js");
const store = new Map();
const RATE_LIMITER = { idFromName: n => n, get: id => ({ fetch: (url, init) => {
  if (!store.has(id)) store.set(id, new Map());
  const m = store.get(id);
  return new RateLimiter({ storage: { get: async k => m.get(k), put: async (k, v) => m.set(k, v) } }).fetch(new Request(url, init));
} }) };

const ENV = { FIREBASE_PROJECT_ID: PROJECT, ALLOWED_ORIGINS: "http://localhost:8765", RATE_PER_MINUTE: "4", RATE_LIMITER,
  GEMINI_API_KEY: "AIzaSECRET_E2E_0123456789", OPENAI_API_KEY: "sk-SECRETOPENAI_E2E_0123456789", ANTHROPIC_API_KEY: "sk-ant-SECRETCLAUDE_E2E_0123456789" };

http.createServer(async (req, res) => {
  const chunks = []; for await (const c of req) chunks.push(c);
  const body = chunks.length ? Buffer.concat(chunks) : undefined;
  const r = await worker.fetch(new Request("http://localhost:8799" + req.url, { method: req.method, headers: req.headers, body: ["GET", "HEAD", "OPTIONS"].includes(req.method) ? undefined : body }), ENV);
  const headers = Object.fromEntries(r.headers.entries());
  res.writeHead(r.status, headers);
  res.end(Buffer.from(await r.arrayBuffer()));
}).listen(8799, () => console.log("worker real em http://localhost:8799"));
