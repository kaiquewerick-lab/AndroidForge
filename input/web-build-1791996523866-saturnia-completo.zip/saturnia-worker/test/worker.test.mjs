// Testes do Worker com fetch simulado. Nenhuma chamada real a Google, OpenAI ou Anthropic.
import { test } from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { createSign } from "node:crypto";
import worker, { verifyIdToken, RateLimiter } from "../worker.js";

const HERE = new URL(".", import.meta.url);
const CERT1 = readFileSync(new URL("cert1.pem", HERE), "utf8");
const KEY1 = readFileSync(new URL("key1.pem", HERE), "utf8");
const KEY2 = readFileSync(new URL("key2.pem", HERE), "utf8");
const PROJECT = "saturnia-test";
// Durable Object simulado: mesma lógica do RateLimiter, com storage em memória por nome.
const DO_STATE = new Map();
const fakeNamespace = (state = DO_STATE) => ({
  idFromName: n => n,
  get: id => ({ fetch: async (url, init) => {
    if (!state.has(id)) state.set(id, new Map());
    const storage = { get: async k => state.get(id).get(k), put: async (k, v) => state.get(id).set(k, v) };
    const inst = new RateLimiter({ storage });
    return inst.fetch(new Request(url, init));
  } }),
});
const ENV = { FIREBASE_PROJECT_ID: PROJECT, ALLOWED_ORIGINS: "https://site.exemplo", RATE_LIMITER: fakeNamespace(), RATE_PER_MINUTE: "1000",
  GEMINI_API_KEY: "AIzaSECRET_TESTE_0123456789", OPENAI_API_KEY: "sk-SECRETOPENAI0123456789", ANTHROPIC_API_KEY: "sk-ant-SECRETCLAUDE0123456789" };

const b64u = b => Buffer.from(b).toString("base64url");
function token({ key = KEY1, kid = "k1", iss = `https://securetoken.google.com/${PROJECT}`, aud = PROJECT, exp, sub = "uid-A" } = {}) {
  const now = Math.floor(Date.now() / 1000);
  const h = b64u(JSON.stringify({ alg: "RS256", kid, typ: "JWT" }));
  const p = b64u(JSON.stringify({ iss, aud, sub, iat: now - 5, exp: exp ?? now + 3600, auth_time: now - 5 }));
  const s = createSign("RSA-SHA256"); s.update(h + "." + p); s.end();
  return `${h}.${p}.${s.sign(key, "base64url")}`;
}

// fetch simulado: cada teste define como o upstream responde.
let upstreamHandler = null; const calls = []; let certsDown = false;
globalThis.fetch = async (url, init = {}) => {
  const u = String(url);
  if (u.includes("googleapis.com/robot/v1/metadata/x509") && certsDown) throw new Error("rede caiu");
  if (u.includes("googleapis.com/robot/v1/metadata/x509")) return new Response(JSON.stringify({ k1: CERT1 }), { headers: { "Cache-Control": "max-age=3600" } });
  calls.push({ url: u, init });
  if (!upstreamHandler) throw new Error("sem handler");
  return upstreamHandler(u, init);
};
const req = (path, { method = "POST", body, auth = token(), origin = "https://site.exemplo", ct = "application/json", raw } = {}) => {
  const h = { "Content-Type": ct }; if (auth) h.Authorization = "Bearer " + auth; if (origin) h.Origin = origin;
  return new Request("https://worker.exemplo" + path, { method, headers: h, body: raw ?? (body === undefined ? undefined : JSON.stringify(body)) });
};
const geminiOk = { contents: [{ role: "user", parts: [{ text: "oi" }] }], model: "gemini-3.8-flash", system: "Seja breve", temperature: 1, search: false };
const multiOk = { provider: "openai", model: "gpt-4o-mini", system: "", messages: [{ role: "user", text: "oi" }] };
const okGemini = () => new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: "resposta gemini" }] }, groundingMetadata: { groundingChunks: [{ web: { uri: "https://fonte.exemplo/a", title: "Fonte" } }] } }] }), { status: 200 });

test("token válido é aceito; adulterado, expirado, de outro projeto ou de outra chave é recusado", async () => {
  assert.equal(await verifyIdToken(token(), PROJECT), "uid-A");
  await assert.rejects(verifyIdToken(token({ exp: 1 }), PROJECT), /exp/);
  await assert.rejects(verifyIdToken(token({ aud: "outro" }), PROJECT), /aud/);
  await assert.rejects(verifyIdToken(token({ iss: "https://securetoken.google.com/outro" }), PROJECT), /iss/);
  await assert.rejects(verifyIdToken(token({ key: KEY2 }), PROJECT), /assinatura/);
  const t = token(); const bad = t.slice(0, -4) + "AAAA";
  await assert.rejects(verifyIdToken(bad, PROJECT));
});

test("sem Authorization retorna 401 e não chama provedor", async () => {
  calls.length = 0; upstreamHandler = () => { throw new Error("não deveria chamar"); };
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk, auth: null }), ENV);
  assert.equal(r.status, 401);
  assert.equal(calls.length, 0);
});

test("Gemini responde com texto e fontes; a chave vai só ao upstream", async () => {
  calls.length = 0; upstreamHandler = okGemini;
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV);
  const j = await r.json();
  assert.equal(r.status, 200);
  assert.equal(j.text, "resposta gemini");
  assert.deepEqual(j.sources, [{ u: "https://fonte.exemplo/a", t: "Fonte" }]);
  assert.equal(calls[0].init.headers["x-goog-api-key"], ENV.GEMINI_API_KEY);
  assert.ok(!JSON.stringify(j).includes(ENV.GEMINI_API_KEY));
});

test("busca do Gemini envia google_search somente quando pedida", async () => {
  calls.length = 0; upstreamHandler = okGemini;
  await worker.fetch(req("/api/gemini", { body: { ...geminiOk, search: true } }), ENV);
  assert.ok(JSON.parse(calls[0].init.body).tools);
  calls.length = 0;
  await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV);
  assert.equal(JSON.parse(calls[0].init.body).tools, undefined);
});

test("modelo fora da lista é recusado antes de qualquer chamada", async () => {
  calls.length = 0; upstreamHandler = okGemini;
  const r1 = await worker.fetch(req("/api/gemini", { body: { ...geminiOk, model: "gemini-x/../../evil" } }), ENV);
  const r2 = await worker.fetch(req("/api/multi", { body: { ...multiOk, model: "gpt-9000" } }), ENV);
  assert.equal(r1.status, 400); assert.equal(r2.status, 400);
  assert.equal(calls.length, 0);
});

test("validação: contents vazio, role inválido, parte inválida e temperatura fora do limite", async () => {
  upstreamHandler = okGemini;
  for (const bodyBad of [
    { ...geminiOk, contents: [] },
    { ...geminiOk, contents: [{ role: "system", parts: [{ text: "x" }] }] },
    { ...geminiOk, contents: [{ role: "user", parts: [{ fileUrl: "http://x" }] }] },
    { ...geminiOk, temperature: 9 },
  ]) {
    const r = await worker.fetch(req("/api/gemini", { body: bodyBad }), ENV);
    assert.equal(r.status, 400);
  }
});

test("corpo grande demais retorna 413 e JSON inválido retorna 400", async () => {
  upstreamHandler = okGemini;
  const big = "x".repeat(12_100_000);
  const r1 = await worker.fetch(req("/api/multi", { body: { ...multiOk, messages: [{ role: "user", text: big }] } }), ENV);
  assert.equal(r1.status, 413);
  const r2 = await worker.fetch(req("/api/multi", { raw: "{isso não é json" }), ENV);
  assert.equal(r2.status, 400);
});

test("OpenAI: requisição e resposta no formato oficial; system vazio não é enviado", async () => {
  calls.length = 0;
  upstreamHandler = () => new Response(JSON.stringify({ choices: [{ message: { content: "oi do openai" } }] }), { status: 200 });
  const r = await worker.fetch(req("/api/multi", { body: multiOk }), ENV);
  assert.deepEqual(await r.json(), { text: "oi do openai" });
  const sent = JSON.parse(calls[0].init.body);
  assert.equal(calls[0].url, "https://api.openai.com/v1/chat/completions");
  assert.equal(calls[0].init.headers.Authorization, "Bearer " + ENV.OPENAI_API_KEY);
  assert.equal(sent.model, "gpt-4o-mini");
  assert.deepEqual(sent.messages, [{ role: "user", content: "oi" }]);
});

test("Claude: cabeçalhos da Anthropic, alternância user/assistant e texto de content[]", async () => {
  calls.length = 0;
  upstreamHandler = () => new Response(JSON.stringify({ content: [{ type: "text", text: "oi " }, { type: "text", text: "claude" }] }), { status: 200 });
  const body = { provider: "claude", model: "claude-haiku-5-5", system: "Breve", messages: [
    { role: "assistant", text: "antes" }, { role: "user", text: "a" }, { role: "user", text: "b" }, { role: "assistant", text: "c" } ] };
  const r = await worker.fetch(req("/api/multi", { body }), ENV);
  assert.deepEqual(await r.json(), { text: "oi claude" });
  assert.equal(calls[0].url, "https://api.anthropic.com/v1/messages");
  assert.equal(calls[0].init.headers["x-api-key"], ENV.ANTHROPIC_API_KEY);
  assert.equal(calls[0].init.headers["anthropic-version"], "2023-06-01");
  const sent = JSON.parse(calls[0].init.body);
  assert.deepEqual(sent.messages, [{ role: "user", content: "a\n\nb" }, { role: "assistant", content: "c" }]);
  assert.equal(sent.system, "Breve");
});

test("erro de autenticação do provedor vira 502 sem vazar a chave", async () => {
  upstreamHandler = () => new Response(JSON.stringify({ error: { message: "Incorrect API key provided: sk-SECRETOPENAI0123456789" } }), { status: 401 });
  const r = await worker.fetch(req("/api/multi", { body: multiOk }), ENV);
  const txt = await r.text();
  assert.equal(r.status, 502);
  assert.ok(!txt.includes("SECRETOPENAI"));
  assert.ok(!txt.includes(ENV.OPENAI_API_KEY));
});

test("limite do provedor vira 429 e instabilidade vira 503", async () => {
  upstreamHandler = () => new Response("{}", { status: 429 });
  assert.equal((await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV)).status, 429);
  upstreamHandler = () => new Response("{}", { status: 500 });
  assert.equal((await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV)).status, 503);
});

test("resposta malformada do provedor vira 502", async () => {
  upstreamHandler = () => new Response("<html>não é JSON</html>", { status: 200 });
  const r = await worker.fetch(req("/api/multi", { body: multiOk }), ENV);
  assert.equal(r.status, 502);
  upstreamHandler = () => new Response(JSON.stringify({ nada: 1 }), { status: 200 });
  assert.equal((await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV)).status, 502);
});

test("timeout do provedor vira 504", async () => {
  upstreamHandler = () => { const e = new Error("timeout"); e.name = "TimeoutError"; throw e; };
  const r = await worker.fetch(req("/api/multi", { body: multiOk }), ENV);
  assert.equal(r.status, 504);
  assert.equal((await r.json()).error.code, "tempo_esgotado");
});

test("origem fora da lista é bloqueada; preflight responde a origem permitida", async () => {
  const r1 = await worker.fetch(req("/api/multi", { body: multiOk, origin: "https://evil.exemplo" }), ENV);
  assert.equal(r1.status, 403);
  const r2 = await worker.fetch(new Request("https://worker.exemplo/api/multi", { method: "OPTIONS", headers: { Origin: "https://site.exemplo" } }), ENV);
  assert.equal(r2.status, 204);
  assert.equal(r2.headers.get("Access-Control-Allow-Origin"), "https://site.exemplo");
});

test("método, rota e tipo de conteúdo são validados; health não expõe segredos", async () => {
  assert.equal((await worker.fetch(req("/api/gemini", { method: "GET" }), ENV)).status, 405);
  assert.equal((await worker.fetch(req("/api/nada", { body: {} }), ENV)).status, 404);
  assert.equal((await worker.fetch(req("/api/multi", { body: multiOk, ct: "text/plain" }), ENV)).status, 415);
  const h = await worker.fetch(new Request("https://worker.exemplo/api/health", { headers: { Origin: "https://site.exemplo" } }), ENV);
  const t = await h.text();
  assert.equal(h.status, 200);
  for (const v of Object.values(ENV)) if (v.length > 12) assert.ok(!t.includes(v));
});

test("Groq não é mais atendido pelo Worker", async () => {
  const r = await worker.fetch(req("/api/multi", { body: { ...multiOk, provider: "groq", model: "openai/gpt-oss-20b" } }), ENV);
  assert.equal(r.status, 400);
});

test("imagem em base64 de 3 MB é aceita (anexos do cliente)", async () => {
  upstreamHandler = okGemini;
  const data = "A".repeat(3_000_000);
  const r = await worker.fetch(req("/api/gemini", { body: { ...geminiOk, contents: [{ role: "user", parts: [{ text: "veja" }, { inline_data: { mime_type: "image/jpeg", data } }] }] } }), ENV);
  assert.equal(r.status, 200);
});

test("tipos de anexo do cliente (áudio webm, markdown, csv) são aceitos; executável é recusado", async () => {
  upstreamHandler = okGemini;
  for (const mime of ["audio/webm", "text/markdown", "text/csv", "image/gif", "application/pdf"]) {
    const r = await worker.fetch(req("/api/gemini", { body: { ...geminiOk, contents: [{ role: "user", parts: [{ inline_data: { mime_type: mime, data: "QUJD" } }] }] } }), ENV);
    assert.equal(r.status, 200, mime);
  }
  const bad = await worker.fetch(req("/api/gemini", { body: { ...geminiOk, contents: [{ role: "user", parts: [{ inline_data: { mime_type: "application/x-msdownload", data: "QUJD" } }] }] } }), ENV);
  assert.equal(bad.status, 400);
});

test("limite por usuário: a partir da chamada 21 no mesmo minuto recebe 429 com Retry-After", async () => {
  const state = new Map();
  const env = { ...ENV, RATE_LIMITER: fakeNamespace(state), RATE_PER_MINUTE: "20" };
  upstreamHandler = okGemini;
  let last;
  for (let i = 0; i < 20; i++) last = await worker.fetch(req("/api/gemini", { body: geminiOk }), env);
  assert.equal(last.status, 200);
  const blocked = await worker.fetch(req("/api/gemini", { body: geminiOk }), env);
  assert.equal(blocked.status, 429);
  assert.ok(Number(blocked.headers.get("Retry-After")) >= 1);
  assert.equal((await blocked.json()).error.code, "limite_local");
  // outro usuário não é afetado
  const other = await worker.fetch(req("/api/gemini", { body: geminiOk, auth: token({ sub: "uid-B" }) }), env);
  assert.equal(other.status, 200);
});

test("sem binding RATE_LIMITER o Worker recusa as chamadas (falha fechada)", async () => {
  upstreamHandler = okGemini;
  const env = { ...ENV, RATE_LIMITER: undefined };
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), env);
  assert.equal(r.status, 500);
  assert.equal((await r.json()).error.code, "config");
});

test("gpt-6-luna (flagship confirmado na documentação da OpenAI) é aceito", async () => {
  upstreamHandler = () => new Response(JSON.stringify({ choices: [{ message: { content: "ok" } }] }), { status: 200 });
  const r = await worker.fetch(req("/api/multi", { body: { ...multiOk, model: "gpt-6-luna" } }), ENV);
  assert.equal(r.status, 200);
});

// Consistência: os modelos oferecidos no HTML precisam ser aceitos pelo Worker, e vice-versa.
import { ALLOWED_MODELS } from "../worker.js";
test("falha de rede com o provedor vira 502 'rede' (não derruba o Worker)", async () => {
  upstreamHandler = () => { throw new TypeError("fetch failed"); };
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV);
  assert.equal(r.status, 502);
  assert.equal((await r.json()).error.code, "rede");
});

test("certificados do Google indisponíveis viram 503 'auth_indisponivel', não 401", async () => {
  certsDown = true;
  try {
    upstreamHandler = okGemini;
    const r = await worker.fetch(req("/api/gemini", { body: geminiOk, auth: token({ kid: "chave-nova" }) }), ENV);
    assert.equal(r.status, 503);
    assert.equal((await r.json()).error.code, "auth_indisponivel");
  } finally { certsDown = false; }
});

test("erro interno inesperado vira 500 'interno' sem detalhes", async () => {
  const env = { ...ENV, RATE_LIMITER: { idFromName: () => { throw new Error("segredo interno 123"); }, get: () => { throw new Error("x"); } } };
  upstreamHandler = okGemini;
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), env);
  const txt = await r.text();
  assert.equal(r.status, 500);
  assert.ok(txt.includes('"interno"'));
  assert.ok(!txt.includes("segredo interno"));
});

test("modelos OpenAI e Claude do HTML são exatamente os aceitos pelo Worker", () => {
  const html = readFileSync(new URL("../../out_v22.html", import.meta.url), "utf8");
  const block = html.slice(html.indexOf("const LISTS={"), html.indexOf(" const PS={}"));
  const ids = name => { const m = new RegExp(name + ":\\[([^\\]]*)\\]").exec(block); assert.ok(m, name); return [...m[1].matchAll(/id:"([^"]+)"/g)].map(x => x[1]).sort(); };
  assert.deepEqual(ids("openai"), [...ALLOWED_MODELS.openai].sort());
  assert.deepEqual(ids("claude"), [...ALLOWED_MODELS.claude].sort());
});
test("modelos Gemini do HTML passam na regra do Worker", () => {
  const html = readFileSync(new URL("../../out_v22.html", import.meta.url), "utf8");
  const m = /const MODELS=\[(.*?)\];/.exec(html);
  const ids = [...m[1].matchAll(/"(gemini-[^"]+)"/g)].map(x => x[1]);
  assert.ok(ids.length >= 3);
  for (const id of ids) assert.ok(ALLOWED_MODELS.gemini.test(id), id);
});

test("instabilidade do Gemini: tenta de novo no mesmo modelo e recupera sem avisar", async () => {
  calls.length = 0;
  let n = 0;
  upstreamHandler = () => (++n === 1 ? new Response("{}", { status: 503 }) : okGemini());
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV);
  assert.equal(r.status, 200);
  assert.equal(calls.length, 2);
  assert.ok(calls.every(c => c.url.includes("/models/gemini-3.8-flash:")));
});

test("instabilidade persistente: usa o modelo de reserva depois de duas tentativas", async () => {
  calls.length = 0;
  upstreamHandler = (u) => (u.includes("gemini-3.5-flash-lite:") ? okGemini() : new Response("{}", { status: 503 }));
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV);
  assert.equal(r.status, 200);
  assert.equal(calls.length, 3);
  assert.ok(calls[2].url.includes("/models/gemini-3.5-flash-lite:"));
});

test("erro que não é de instabilidade (400) não é repetido", async () => {
  calls.length = 0;
  upstreamHandler = () => new Response("{}", { status: 400 });
  const r = await worker.fetch(req("/api/gemini", { body: geminiOk }), ENV);
  assert.equal(r.status, 502);
  assert.equal(calls.length, 1);
});

test("se o próprio modelo de reserva falha, não há terceira chamada", async () => {
  calls.length = 0;
  upstreamHandler = () => new Response("{}", { status: 503 });
  const r = await worker.fetch(req("/api/gemini", { body: { ...geminiOk, model: "gemini-3.5-flash-lite" } }), ENV);
  assert.equal(r.status, 503);
  assert.equal(calls.length, 2);
});
