package com.serius.saturnia

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/**
 * Serviço de acessibilidade do SaturnIA Bubble.
 *
 * Só funciona depois que o usuário liga "SaturnIA Tela" em Acessibilidade.
 * Lê os textos e botões da tela do app aberto (sem captura de imagem) e executa
 * ações que o usuário confirmou no balão. Não lê campos de senha e não grava nada
 * em disco.
 */
class ScreenAccessService : AccessibilityService() {

    /** Elementos da última leitura, na ordem da lista numerada enviada à IA. */
    @Volatile
    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        nodes = emptyList()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não reagimos a eventos: a leitura acontece só quando o usuário pede.
    }

    override fun onInterrupt() {}

    /**
     * Lista numerada da tela atual, uma linha por elemento útil. Devolve null se não há
     * janela disponível e texto vazio se a tela não tem nada legível.
     */
    fun snapshot(maxNodes: Int = MAX_NODES, maxChars: Int = MAX_CHARS): String? {
        val root = rootInActiveWindow ?: return null
        val refs = ArrayList<AccessibilityNodeInfo>()
        val out = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && refs.size < maxNodes && out.length < maxChars) {
            val node = queue.removeFirst()
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
            if (node.packageName == packageName) continue
            if (!node.isVisibleToUser || node.isPassword) continue
            val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .joinToString(" / ")
                .take(200)
            val actionable = node.isClickable || node.isEditable || node.isScrollable
            if (label.isEmpty() && !actionable) continue
            val kind = when {
                node.isEditable -> "campo"
                node.isClickable -> "botão"
                node.isScrollable -> "rolagem"
                else -> "texto"
            }
            val idx = refs.size
            refs.add(node)
            out.append("[").append(idx).append("] ").append(kind).append(": ")
                .append(if (label.isEmpty()) "(sem texto)" else label)
                .append('\n')
        }
        nodes = refs
        return out.toString()
    }

    /** Executa uma ação já confirmada pelo usuário. Devolve uma linha de resultado. */
    fun perform(action: ScreenAction): String {
        when (action.op) {
            "back" -> return if (performGlobalAction(GLOBAL_ACTION_BACK)) "Voltei" else "Não consegui voltar"
            "home" -> return if (performGlobalAction(GLOBAL_ACTION_HOME)) "Fui para a tela inicial" else "Não consegui ir para a tela inicial"
        }
        val node = action.index?.let { nodes.getOrNull(it) }
            ?: return "Elemento ${action.index} não está mais na tela"
        if (node.isPassword) return "Campo protegido, não alterado"
        return when (action.op) {
            "click" -> if (node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "Cliquei em ${action.index}" else "Não consegui clicar em ${action.index}"
            "type" -> {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, action.text.orEmpty())
                }
                if (node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "Digitei em ${action.index}"
                else "Não consegui digitar em ${action.index}"
            }
            "scroll" -> {
                val id = if (action.dir == "up") AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                if (node.performAction(id)) "Rolei ${action.dir ?: "down"} em ${action.index}" else "Não consegui rolar ${action.index}"
            }
            else -> "Ação não suportada: ${action.op}"
        }
    }

    companion object {
        private const val MAX_NODES = 150
        private const val MAX_CHARS = 6000

        /** Instância ativa do serviço. Null quando o usuário não ligou o recurso. */
        @Volatile
        var instance: ScreenAccessService? = null
            private set
    }
}

/** Ação de tela. `index` vem da lista numerada da última leitura. */
data class ScreenAction(
    val op: String,
    val index: Int? = null,
    val text: String? = null,
    val dir: String? = null,
)

/** Lê o bloco ```json {"actions": [...]} ``` da resposta da IA e aceita só ações conhecidas. */
object ScreenActions {
    private const val MAX = 10
    private val ALLOWED = setOf("click", "type", "scroll", "back", "home")
    private val NEEDS_INDEX = setOf("click", "type", "scroll")
    private val BLOCK = Regex("```json\\s*([\\s\\S]*?)```")

    fun parse(reply: String): List<ScreenAction> {
        val raw = BLOCK.find(reply)?.groupValues?.get(1) ?: return emptyList()
        return try {
            val list = JSONObject(raw.trim()).optJSONArray("actions") ?: return emptyList()
            (0 until minOf(list.length(), MAX)).mapNotNull { i ->
                val o = list.optJSONObject(i) ?: return@mapNotNull null
                val op = o.optString("op")
                if (op !in ALLOWED) return@mapNotNull null
                val index = if (o.has("i")) o.optInt("i", -1).takeIf { it >= 0 } else null
                if (op in NEEDS_INDEX && index == null) return@mapNotNull null
                ScreenAction(
                    op = op,
                    index = index,
                    text = o.optString("text").take(500).ifEmpty { null },
                    dir = o.optString("dir").ifEmpty { null },
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
