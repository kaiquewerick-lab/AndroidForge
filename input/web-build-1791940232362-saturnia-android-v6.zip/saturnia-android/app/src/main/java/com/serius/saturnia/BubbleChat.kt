package com.serius.saturnia

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Conversa do SaturnIA Bubble, guardada só na memória do processo.
 *
 * Minimizar, ocultar ou reabrir o balão não apaga a conversa. Ela some quando o app
 * é encerrado pelo sistema ou pelo usuário, e não é gravada em disco.
 */
object BubbleChat {

    const val DEFAULT_MODEL = "gemini-3.8-flash"
    private val MODEL_RE = Regex("^gemini-\\d+(\\.\\d+)?-(flash-lite|flash|pro)(-preview)?$")
    private const val MAX_STORED = 60
    private const val MAX_INPUT = 4000

    private val messages = CopyOnWriteArrayList<ChatMessage>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** Token de sessão Firebase, enviado pelo HTML. Só na memória. */
    @Volatile
    var token: String = ""
        private set

    @Volatile
    var model: String = DEFAULT_MODEL
        private set

    @Volatile
    var busy: Boolean = false
        private set

    fun setToken(value: String) {
        token = value.trim()
    }

    /** Chave própria do usuário (campo "Chave própria do Gemini" do app). Só na memória. */
    @Volatile
    var ownKey: String = ""
        private set

    fun setOwnKey(value: String) {
        ownKey = value.trim().take(200)
    }

    fun setModel(value: String) {
        if (MODEL_RE.matches(value)) model = value
    }

    /** Imagem escolhida pelo usuário, aguardando o envio. Só na memória. */
    @Volatile
    var pendingImage: ImageData? = null
        private set

    fun setPendingImage(image: ImageData?) {
        pendingImage = image
        notifyListeners()
    }

    /** Ações propostas pela IA sobre a tela, aguardando o toque do usuário em "Executar". */
    @Volatile
    var proposedActions: List<ScreenAction> = emptyList()
        private set

    /**
     * Lê a tela do app aberto e pergunta à IA. A lista da tela vai junto na mensagem, para
     * o usuário ver exatamente o que foi lido.
     */
    fun analyzeScreen(userText: String) {
        if (busy) return
        val service = ScreenAccessService.instance
        if (service == null) {
            add(ChatMessage("model", "Ative \"SaturnIA Tela\" em Acessibilidade para eu ver o app aberto.", failed = true))
            notifyListeners()
            return
        }
        val screen = service.snapshot()
        if (screen == null) {
            add(ChatMessage("model", "Não consegui ler a tela agora. Tente de novo.", failed = true))
            notifyListeners()
            return
        }
        val ask = userText.trim().ifEmpty { "Me ajude com esta tela." }
        send(
            ask + "\n\n" +
                "Tela atual do app aberto (elementos numerados). Responda em português.\n" +
                "Se for útil agir na tela, termine com um bloco ```json no formato " +
                "{\"actions\":[{\"op\":\"click\",\"i\":N},{\"op\":\"type\",\"i\":N,\"text\":\"...\"}," +
                "{\"op\":\"scroll\",\"i\":N,\"dir\":\"down\"},{\"op\":\"back\"},{\"op\":\"home\"}]}. " +
                "Use só os números da lista. Não proponha enviar dinheiro, apagar dados ou publicar " +
                "nada que o usuário não tenha pedido.\n" +
                "---\n" + screen.ifEmpty { "(nenhum elemento legível)" }
        )
    }

    /** Executa as ações pendentes, depois que o usuário tocou em "Executar". */
    fun runProposed() {
        val actions = proposedActions
        if (actions.isEmpty() || busy) return
        proposedActions = emptyList()
        val service = ScreenAccessService.instance
        val results = if (service == null) {
            listOf("O serviço de tela está desligado")
        } else {
            actions.map { service.perform(it) }
        }
        add(ChatMessage("model", "Ações executadas:\n" + results.joinToString("\n") { "• $it" }))
        notifyListeners()
    }

    fun snapshot(): List<ChatMessage> = messages.toList()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun clear() {
        if (busy) return
        messages.clear()
        proposedActions = emptyList()
        notifyListeners()
    }

    /**
     * Envia o texto, a imagem pendente ou os dois. Respostas e erros chegam pela thread
     * principal e avisam os ouvintes.
     */
    fun send(text: String) {
        val clean = text.trim().take(MAX_INPUT)
        val image = pendingImage
        if ((clean.isEmpty() && image == null) || busy) return

        add(ChatMessage("user", clean, image = image))
        pendingImage = null
        val history = ChatHistory.forRequest(messages.toList())
        val currentToken = token
        val currentModel = model
        val currentKey = ownKey
        busy = true
        proposedActions = emptyList()
        notifyListeners()

        worker.execute {
            val result = GeminiClient.call(currentToken, currentModel, history, currentKey)
            main.post {
                when (result) {
                    is GeminiResult.Ok -> {
                        add(ChatMessage("model", result.text))
                        proposedActions = ScreenActions.parse(result.text)
                    }
                    is GeminiResult.Failed -> add(ChatMessage("model", result.message, failed = true))
                }
                busy = false
                notifyListeners()
            }
        }
    }

    private fun add(message: ChatMessage) {
        messages.add(message)
        while (messages.size > MAX_STORED) messages.removeAt(0)
    }

    private fun notifyListeners() {
        listeners.forEach { it() }
    }
}
