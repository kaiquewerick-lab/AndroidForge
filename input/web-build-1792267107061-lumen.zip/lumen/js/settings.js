// Configurações: conta, privacidade, notificações, aparência, salvos, bloqueados e sair.
import {
  state, myUid, me, $, on, esc, avatar, toast, confirmar, applyTheme,
  ref, set, remove, db
} from './core.js';
import { logout, trocarSenha } from './auth.js';
import { abrirEditar } from './social.js';
import { abrirPost, midiasDe } from './feed.js';

let painel = 'main';
const TIPOS_NOTIF = [['curtida', 'Curtidas'], ['comentario', 'Comentários'], ['seguir', 'Novos seguidores'], ['mensagem', 'Mensagens']];

export function initSettings() {
  const root = $('#settings-root');
  root.addEventListener('click', onClick);
  root.addEventListener('change', e => {
    if (e.target.dataset.notif) {
      const prefs = prefsNotif();
      prefs[e.target.dataset.notif] = e.target.checked;
      localStorage.setItem('lumen_notif', JSON.stringify(prefs));
      render();
    }
  });
  on('me', () => { if (ativa()) render(); });
  on('blocked', () => { if (ativa()) render(); });
  on('posts', () => { if (ativa() && painel === 'salvos') render(); });
}

const ativa = () => $('#view-settings').classList.contains('active');

export function openSettings(params = {}) {
  painel = params.painel || 'main';
  render();
}

function prefsNotif() {
  try {
    return { curtida: true, comentario: true, seguir: true, mensagem: true,
      ...JSON.parse(localStorage.getItem('lumen_notif') || '{}') };
  } catch { return { curtida: true, comentario: true, seguir: true, mensagem: true }; }
}

const cabecalho = titulo => `<div class="set-head">
  <button class="icon-btn" data-painel="main" aria-label="Voltar"><i class="fa-solid fa-arrow-left"></i></button>
  <h2>${titulo}</h2></div>`;

const toggle = (id, on_) => `<span class="switch ${on_ ? 'on' : ''}" data-toggle="${id}" role="switch" aria-checked="${on_}"></span>`;

function render() {
  const root = $('#settings-root');
  const p = me();
  const tema = localStorage.getItem('lumen_theme') || 'system';

  if (painel === 'main') {
    root.innerHTML = `
      <h2 class="view-title">Configurações</h2>
      <div class="set-group" style="margin:12px 14px">
        <div class="set-item" style="cursor:default;border-top:0">
          ${avatar(p, 'av-md')}
          <div><strong>${esc(p.username || p.nome || '')}</strong><br><small>${esc(p.nome || '')}</small></div>
        </div>
      </div>
      <div class="set-group" style="margin:0 14px 14px">
        <h4>Sua conta</h4>
        <button class="set-item" data-acao="editar"><i class="ico fa-regular fa-user"></i><span>Editar perfil</span><span class="val"><i class="fa-solid fa-chevron-right"></i></span></button>
        <button class="set-item" data-painel="privacidade"><i class="ico fa-solid fa-lock"></i><span>Privacidade da conta</span>
          <span class="val">${p.privado ? 'Privada' : 'Pública'}<i class="fa-solid fa-chevron-right"></i></span></button>
        <button class="set-item" data-acao="senha"><i class="ico fa-solid fa-key"></i><span>Redefinir senha</span><span class="val"><i class="fa-solid fa-chevron-right"></i></span></button>
      </div>
      <div class="set-group" style="margin:0 14px 14px">
        <h4>Como você usa o Lumen</h4>
        <button class="set-item" data-painel="salvos"><i class="ico fa-regular fa-bookmark"></i><span>Salvos</span><span class="val"><i class="fa-solid fa-chevron-right"></i></span></button>
        <button class="set-item" data-painel="bloqueados"><i class="ico fa-solid fa-ban"></i><span>Contas bloqueadas</span>
          <span class="val">${Object.keys(state.blocked).length}<i class="fa-solid fa-chevron-right"></i></span></button>
        <button class="set-item" data-painel="notificacoes"><i class="ico fa-regular fa-bell"></i><span>Notificações</span><span class="val"><i class="fa-solid fa-chevron-right"></i></span></button>
      </div>
      <div class="set-group" style="margin:0 14px 14px">
        <h4>Preferências</h4>
        <button class="set-item" data-painel="aparencia"><i class="ico fa-solid fa-circle-half-stroke"></i><span>Aparência</span>
          <span class="val">${{ light: 'Claro', dark: 'Escuro', system: 'Sistema' }[tema]}<i class="fa-solid fa-chevron-right"></i></span></button>
        <div class="set-item" style="cursor:default"><i class="ico fa-solid fa-language"></i><span>Idioma</span><span class="val">Português (Brasil)</span></div>
      </div>
      <div class="set-group" style="margin:0 14px 14px">
        <h4>Suporte e sobre</h4>
        <button class="set-item" data-painel="ajuda"><i class="ico fa-regular fa-circle-question"></i><span>Central de ajuda</span><span class="val"><i class="fa-solid fa-chevron-right"></i></span></button>
        <button class="set-item" data-painel="sobre"><i class="ico fa-solid fa-circle-info"></i><span>Sobre o Lumen</span><span class="val">v1.0<i class="fa-solid fa-chevron-right"></i></span></button>
      </div>
      <div class="set-group" style="margin:0 14px 24px">
        <button class="set-item" data-acao="sair" style="color:var(--danger);font-weight:700;justify-content:center"><span>Sair da conta</span></button>
      </div>`;
    return;
  }

  if (painel === 'privacidade') {
    root.innerHTML = `${cabecalho('Privacidade da conta')}
      <div class="set-group" style="margin:0 14px">
        <div class="set-item" style="cursor:default;border-top:0"><div style="flex:1"><strong>Conta privada</strong>
          <br><small>Quando ativada, só quem segue você vê suas publicações, reels e stories.</small></div>
          ${toggle('privado', !!p.privado)}</div>
      </div>`;
    return;
  }

  if (painel === 'notificacoes') {
    const prefs = prefsNotif();
    root.innerHTML = `${cabecalho('Notificações')}
      <div class="set-group" style="margin:0 14px">
        <h4>Mostrar no painel de notificações</h4>
        ${TIPOS_NOTIF.map(([k, l]) => `<label class="set-item" style="cursor:pointer">
          <span>${l}</span>
          <input type="checkbox" data-notif="${k}" ${prefs[k] ? 'checked' : ''} class="sr-check" style="margin-left:auto;width:20px;height:20px;accent-color:var(--accent)">
        </label>`).join('')}
      </div>
      <p class="about">As preferências ficam salvas neste dispositivo.</p>`;
    return;
  }

  if (painel === 'aparencia') {
    const op = (v, l) => `<button data-tema="${v}" class="${tema === v ? 'active' : ''}">${l}</button>`;
    root.innerHTML = `${cabecalho('Aparência')}
      <div class="set-group" style="margin:0 14px">
        <h4>Tema</h4>
        <div class="radio-row">${op('light', 'Claro')}${op('dark', 'Escuro')}${op('system', 'Sistema')}</div>
      </div>`;
    return;
  }

  if (painel === 'salvos') {
    const uid = myUid();
    const salvos = state.posts.filter(x => (x.salvos || {})[uid]);
    root.innerHTML = `${cabecalho('Salvos')}
      ${salvos.length ? `<div class="explore">${salvos.map(x => {
        const m = midiasDe(x)[0] || {};
        const thumb = m.tipo === 'video' ? `<video src="${esc(m.url)}" muted preload="metadata"></video>` : `<img src="${esc(m.url || '')}" loading="lazy" alt="">`;
        return `<div class="thumb" data-abrir-post="${x.id}">${thumb}</div>`;
      }).join('')}</div>` : '<div class="empty"><i class="fa-regular fa-bookmark"></i><p>Nenhuma publicação salva. Toque no marcador de uma publicação para salvá-la.</p></div>'}`;
    return;
  }

  if (painel === 'bloqueados') {
    const ids = Object.keys(state.blocked);
    root.innerHTML = `${cabecalho('Contas bloqueadas')}
      <div style="padding:0 14px">${ids.length ? ids.map(uid => {
        const u = state.users[uid] || { nome: 'Conta', username: '' };
        return `<div class="user-row">
          <div class="who">${avatar(u, 'av-md')}<div><strong>${esc(u.username || u.nome)}</strong><small>${esc(u.nome || '')}</small></div></div>
          <button class="btn-soft sm" data-desbloquear="${uid}">Desbloquear</button></div>`;
      }).join('') : '<div class="empty"><i class="fa-solid fa-ban"></i><p>Você não bloqueou nenhuma conta.</p></div>'}</div>`;
    return;
  }

  if (painel === 'ajuda') {
    root.innerHTML = `${cabecalho('Central de ajuda')}
      <div class="about">
        <p><strong>Publicar:</strong> toque em + para criar uma publicação, reel ou story.</p>
        <p><strong>Stories:</strong> desaparecem após 24 horas. Toque nas laterais para avançar ou voltar.</p>
        <p><strong>Duplo toque</strong> em uma foto ou vídeo para curtir.</p>
        <p><strong>Denunciar ou bloquear:</strong> use o menu ⋯ em qualquer publicação.</p>
        <p><strong>Esqueceu a senha?</strong> Use "Redefinir senha" em Configurações.</p>
      </div>`;
    return;
  }

  if (painel === 'sobre') {
    root.innerHTML = `${cabecalho('Sobre o Lumen')}
      <div class="about">
        <p><strong>Lumen</strong> — versão 1.0</p>
        <p>Compartilhe fotos, vídeos, reels e stories com amigos, com mensagens privadas e notificações em tempo real.</p>
        <p>Desenvolvido como projeto próprio. Não possui relação com outras redes sociais.</p>
      </div>`;
    return;
  }

  root.innerHTML = `${cabecalho('Configurações')}`;
}

async function onClick(e) {
  const t = e.target;
  let el;
  if ((el = t.closest('[data-painel]'))) { painel = el.dataset.painel; return render(); }
  if ((el = t.closest('[data-tema]'))) {
    localStorage.setItem('lumen_theme', el.dataset.tema);
    applyTheme();
    return render();
  }
  if ((el = t.closest('[data-toggle]'))) return alternarPrivacidade(el);
  if ((el = t.closest('[data-acao]'))) {
    const a = el.dataset.acao;
    if (a === 'editar') return abrirEditar();
    if (a === 'senha') return trocarSenha().catch(() => toast('Não foi possível enviar o link.'));
    if (a === 'sair') { if (await confirmar('Deseja sair da sua conta?')) logout(); return; }
  }
  if ((el = t.closest('[data-abrir-post]'))) return abrirPost(el.dataset.abrirPost);
  if ((el = t.closest('[data-desbloquear]'))) {
    await remove(ref(db, `bloqueados/${myUid()}/${el.dataset.desbloquear}`));
    return toast('Conta desbloqueada');
  }
}

async function alternarPrivacidade(el) {
  const uid = myUid();
  const novo = !me().privado;
  await set(ref(db, `usuarios/${uid}/privado`), novo);
  toast(novo ? 'Conta agora é privada' : 'Conta agora é pública');
}
