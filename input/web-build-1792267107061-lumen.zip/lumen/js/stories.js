// Stories: barra superior, visualizador em tela cheia, respostas e visualizações.
import {
  state, myUid, me, $, on, esc, timeAgo, avatar, nomeDe, openModal, closeModal, confirmar,
  toast, abrirLista, apagarArquivo, remove, ref, set, db
} from './core.js';
import { openCreate } from './create.js';
import { enviarMensagem } from './direct.js';

const DURACAO_IMAGEM = 5000;
const DURACAO_MAX_VIDEO = 30000;
const VINTE_QUATRO_H = 24 * 60 * 60 * 1000;

let fila = [];        // uids com stories, na ordem de exibição
let qi = 0;           // índice do usuário atual
let itens = [];       // stories do usuário atual
let ii = 0;           // índice do story atual
let timer = null;
let audio = null;

// ---------- Dados ----------
export function storiesDe(uid) {
  return Object.entries(state.stories[uid] || {})
    .map(([id, s]) => ({ id, ...s }))
    .filter(s => s.midia && Date.now() - s.timestamp < VINTE_QUATRO_H)
    .sort((a, b) => a.timestamp - b.timestamp);
}

function uidsComStories() {
  const uid = myUid();
  const comStory = Object.keys(state.stories).filter(u => storiesDe(u).length && (u === uid || state.following[u]));
  return comStory.sort((a, b) => {
    if (a === uid) return -1;
    if (b === uid) return 1;
    return storiesDe(b).at(-1).timestamp - storiesDe(a).at(-1).timestamp;
  });
}

const vistoPorMim = s => !!(s.visualizacoes || {})[myUid()];
const todosVistos = uid => storiesDe(uid).every(vistoPorMim);

// ---------- Barra ----------
export function initStories() {
  on('stories', renderBar);
  on('following', renderBar);
  on('me', renderBar);
  on('users', renderBar);

  $('#stories-bar').addEventListener('click', e => {
    const add = e.target.closest('[data-add-story]');
    if (add) { e.stopPropagation(); return openCreate('story'); }
    const mine = e.target.closest('#story-mine');
    if (mine) return storiesDe(myUid()).length ? abrirVisualizador(myUid()) : openCreate('story');
    const outro = e.target.closest('[data-story-of]');
    if (outro) return abrirVisualizador(outro.dataset.storyOf);
  });

  $('#sv-close').addEventListener('click', fecharStories);
  $('#sv-tap-l').addEventListener('click', anterior);
  $('#sv-tap-r').addEventListener('click', proximo);
  $('#sv-views').addEventListener('click', () => {
    const s = itens[ii];
    if (s) abrirLista('Visualizações', Object.keys(s.visualizacoes || {}));
  });
  $('#sv-del').addEventListener('click', apagarStoryAtual);
  $('#form-sv-reply').addEventListener('submit', responder);
}

function renderBar() {
  const bar = $('#stories-bar');
  const uid = myUid();
  if (!bar || !uid) return;
  const minhas = storiesDe(uid);
  const outros = uidsComStories().filter(u => u !== uid);
  const minhaFoto = state.me;
  bar.innerHTML = `
    <div class="story-item" id="story-mine">
      <div class="wrap">
        ${minhas.length ? `<span class="ring ${todosVistos(uid) ? 'seen' : ''}">${avatar(minhaFoto, 'av-md')}</span>` : avatar(minhaFoto, 'av-md')}
        <span class="plus" data-add-story title="Adicionar story"><i class="fa-solid fa-plus"></i></span>
      </div>
      <span class="name">Seu story</span>
    </div>
    ${outros.map(u => {
      const p = state.users[u] || { nome: '?' };
      return `<div class="story-item" data-story-of="${u}">
        <div class="wrap"><span class="ring ${todosVistos(u) ? 'seen' : ''}">${avatar(p, 'av-md')}</span></div>
        <span class="name">${esc(nomeDe(p))}</span>
      </div>`;
    }).join('')}`;
}

// ---------- Visualizador ----------
export function openStoriesOf(uid) { abrirVisualizador(uid); }

function abrirVisualizador(uid) {
  fila = uidsComStories();
  if (!fila.includes(uid)) fila.unshift(uid);
  qi = fila.indexOf(uid);
  carregarUsuario();
  openModal('modal-story');
}

function carregarUsuario() {
  if (qi < 0 || qi >= fila.length) return fecharStories();
  itens = storiesDe(fila[qi]);
  if (!itens.length) return proximoUsuario();
  ii = 0;
  mostrarItem();
}

function mostrarItem() {
  clearTimeout(timer);
  pararAudio();
  const s = itens[ii];
  const dono = s.uid === myUid() || fila[qi] === myUid();
  const p = state.users[fila[qi]] || { nome: '' };

  if (!dono && !vistoPorMim(s)) {
    set(ref(db, `stories/${fila[qi]}/${s.id}/visualizacoes/${myUid()}`), true).catch(() => {});
  }

  $('#sv-avatar').innerHTML = avatar(p, 'av-sm');
  $('#sv-nome').textContent = nomeDe(p);
  $('#sv-time').textContent = timeAgo(s.timestamp);

  const media = $('#sv-media');
  media.innerHTML = '';
  let dur = DURACAO_IMAGEM;
  if (s.tipo === 'video') {
    const v = document.createElement('video');
    v.src = s.midia;
    v.playsInline = true;
    v.autoplay = true;
    v.onloadedmetadata = () => {
      dur = Math.min(v.duration * 1000 || DURACAO_MAX_VIDEO, DURACAO_MAX_VIDEO);
      progresso(dur);
      clearTimeout(timer);
      timer = setTimeout(proximo, dur);
    };
    v.onended = proximo;
    v.play().catch(() => { v.muted = true; v.play().catch(() => {}); });
    media.appendChild(v);
    dur = DURACAO_MAX_VIDEO;
  } else {
    const img = document.createElement('img');
    img.src = s.midia;
    img.alt = '';
    media.appendChild(img);
  }

  progresso(dur);
  timer = setTimeout(proximo, dur);

  const musica = $('#sv-music');
  if (s.musicaNome || s.audioUrl) {
    musica.classList.remove('hidden');
    musica.querySelector('span').textContent = s.musicaNome || 'Áudio original';
  } else musica.classList.add('hidden');
  if (s.audioUrl) {
    audio = new Audio(s.audioUrl);
    audio.loop = true;
    audio.play().catch(() => {});
  }

  $('#sv-own').classList.toggle('hidden', !dono);
  $('#form-sv-reply').classList.toggle('hidden', dono);
}

function progresso(dur) {
  $('#sv-progress').innerHTML = itens.map((_, i) => {
    if (i < ii) return '<div class="done"><i></i></div>';
    if (i === ii) return `<div class="cur" style="--d:${dur}ms"><i></i></div>`;
    return '<div><i></i></div>';
  }).join('');
}

function proximo() {
  if (ii < itens.length - 1) { ii++; mostrarItem(); }
  else proximoUsuario();
}
function anterior() {
  if (ii > 0) { ii--; mostrarItem(); }
  else if (qi > 0) { qi--; carregarUsuario(); }
  else { ii = 0; mostrarItem(); }
}
function proximoUsuario() {
  qi++;
  if (qi >= fila.length) return fecharStories();
  carregarUsuario();
}

function pararAudio() {
  if (audio) { audio.pause(); audio = null; }
}

export function fecharStories() {
  clearTimeout(timer);
  pararAudio();
  $('#sv-media').innerHTML = '';
  closeModal('modal-story');
}

async function apagarStoryAtual() {
  const s = itens[ii];
  if (!s || !(await confirmar('Excluir este story?'))) return;
  await remove(ref(db, `stories/${myUid()}/${s.id}`));
  apagarArquivo(s.midia);
  itens.splice(ii, 1);
  toast('Story excluído');
  if (!itens.length) return proximoUsuario();
  if (ii >= itens.length) ii = itens.length - 1;
  mostrarItem();
}

async function responder(e) {
  e.preventDefault();
  const input = $('#sv-reply-input');
  const texto = input.value.trim();
  if (!texto) return;
  const s = itens[ii];
  await enviarMensagem(fila[qi], texto, { storyRef: s?.midia || '' });
  input.value = '';
  toast('Resposta enviada');
}
