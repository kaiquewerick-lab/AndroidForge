// Reels: vídeos verticais em tela cheia, com reprodução automática ao rolar.
import { state, myUid, $, on, esc, timeAgo, avatar, verifiedBadge, nomeDe, isBlocked, podeVer, go } from './core.js';
import { toggleCurtir, salvarPost, compartilhar, abrirComentarios } from './feed.js';

let obs = null;

export function initReels() {
  obs = new IntersectionObserver(entries => entries.forEach(en => {
    const v = en.target;
    if (en.isIntersecting && en.intersectionRatio > 0.7) v.play().catch(() => {});
    else v.pause();
  }), { threshold: [0, 0.7] });

  on('posts', () => { if (isOpen()) render(); });
  on('following', () => { if (isOpen()) render(); });

  const root = $('#reels-list');
  root.addEventListener('click', e => {
    const t = e.target;
    let el;
    if ((el = t.closest('[data-rlike]'))) return toggleCurtir(el.dataset.rlike);
    if ((el = t.closest('[data-rsave]'))) return salvarPost(el.dataset.rsave);
    if ((el = t.closest('[data-rcom]'))) return abrirComentarios(el.dataset.rcom);
    if ((el = t.closest('[data-rshare]'))) return compartilhar(el.dataset.rshare);
    if ((el = t.closest('[data-rprofile]'))) return go('profile', { uid: el.dataset.rprofile });
    if ((el = t.closest('video'))) el.muted = !el.muted;
  });
}

const isOpen = () => $('#view-reels').classList.contains('active');

export function openReels() {
  render();
  // Garante que o primeiro reel comece do topo
  $('#reels-list').scrollTop = 0;
}

function reelsList() {
  const uid = myUid();
  return state.posts.filter(p => p.tipo === 'reel' && !isBlocked(p.uid) && (p.uid === uid || podeVer(p.uid)));
}

function render() {
  const box = $('#reels-list');
  const lista = reelsList();
  obs.disconnect();
  if (!lista.length) {
    box.innerHTML = `<div class="empty" style="height:100%;display:flex;flex-direction:column;justify-content:center;background:var(--bg)">
      <i class="fa-solid fa-clapperboard"></i><h3>Nenhum reel ainda</h3>
      <p>Publique um vídeo vertical para aparecer aqui.</p>
      <button class="btn-primary sm" data-create>Criar reel</button></div>`;
    return;
  }
  const uid = myUid();
  box.innerHTML = lista.map(p => {
    const u = state.users[p.uid] || { nome: p.autor, username: p.username, foto: p.autorFoto, verificado: p.verificado };
    const curtidas = p.curtidas || {};
    const n = Object.keys(curtidas).length;
    const m = (p.midias || [])[0] || {};
    const url = typeof m === 'string' ? m : m.url;
    const salvo = !!(p.salvos || {})[uid];
    const nCom = Object.keys(p.comentarios || {}).length;
    return `<article class="reel">
      <video src="${esc(url)}" loop playsinline muted preload="metadata"></video>
      <div class="r-info">
        <div data-rprofile="${p.uid}" style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:700">
          ${avatar(u, 'av-xs')} ${esc(nomeDe(u))} ${verifiedBadge(u.verificado)}
        </div>
        ${p.legenda ? `<p>${esc(p.legenda)}</p>` : ''}
        ${p.musicaNome ? `<p><i class="fa-solid fa-music"></i> ${esc(p.musicaNome)}</p>` : ''}
        <small style="color:#fff;opacity:.8">${timeAgo(p.timestamp)}</small>
      </div>
      <div class="r-side">
        <button data-rlike="${p.id}" class="${curtidas[uid] ? 'liked' : ''}">
          <i class="fa-${curtidas[uid] ? 'solid' : 'regular'} fa-heart"></i><small>${n}</small></button>
        <button data-rcom="${p.id}"><i class="fa-regular fa-comment"></i><small>${nCom}</small></button>
        <button data-rshare="${p.id}"><i class="fa-regular fa-paper-plane"></i><small>Enviar</small></button>
        <button data-rsave="${p.id}"><i class="fa-${salvo ? 'solid' : 'regular'} fa-bookmark"></i><small>Salvar</small></button>
      </div>
    </article>`;
  }).join('');
  box.querySelectorAll('video').forEach(v => obs.observe(v));
}
