// Mensagens diretas: lista de conversas, chat em tempo real, excluir mensagem e nova conversa.
import {
  state, myUid, $, on, esc, timeAgo, avatar, verifiedBadge, nomeDe, isBlocked, toast, confirmar,
  go, ref, set, push, remove, onValue, runTransaction, db, update
} from './core.js';

let uidAtual = null;       // conversa aberta (uid do outro usuário)
let unsubMsgs = null;
let mensagens = [];
let buscaNova = false;     // painel "nova mensagem"

export const chatId = (a, b) => (a < b ? `${a}_${b}` : `${b}_${a}`);

// Envia texto (usado também pelas respostas de story)
export async function enviarMensagem(paraUid, texto, extra = {}) {
  const de = myUid();
  if (!de || !paraUid || !texto) return;
  const cid = chatId(de, paraUid);
  const agora = Date.now();
  await set(push(ref(db, `chats/${cid}/mensagens`)), {
    de, texto: texto.slice(0, 1000), timestamp: agora, ...extra
  });
  const resumo = texto.slice(0, 60);
  await update(ref(db), {
    [`conversas/${de}/${cid}/withUid`]: paraUid,
    [`conversas/${de}/${cid}/ultimo`]: resumo,
    [`conversas/${de}/${cid}/timestamp`]: agora,
    [`conversas/${paraUid}/${cid}/withUid`]: de,
    [`conversas/${paraUid}/${cid}/ultimo`]: resumo,
    [`conversas/${paraUid}/${cid}/timestamp`]: agora,
  });
  await runTransaction(ref(db, `conversas/${paraUid}/${cid}/naoLidas`), n => (n || 0) + 1);
}

export function initDirect() {
  on('conversas', () => { if (ativa()) renderLista(); if (ativa() && uidAtual) marcarLida(uidAtual); });
  on('users', () => { if (ativa()) renderLista(); });
  on('me', () => { if (ativa()) renderLista(); });

  const root = $('#direct-root');
  root.addEventListener('click', onClick);
  root.addEventListener('submit', onSubmit);
  root.addEventListener('input', e => {
    if (e.target.id === 'dm-busca') renderNova(e.target.value);
  });
}

const ativa = () => $('#view-direct').classList.contains('active');

export function openDirect(params = {}) {
  buscaNova = false;
  if (params.uid) return abrirConversa(params.uid);
  if (uidAtual) return abrirConversa(uidAtual);
  renderLista();
}

// ---------- Lista de conversas ----------
function renderLista() {
  const root = $('#direct-root');
  if (buscaNova) return renderNova($('#dm-busca')?.value || '');
  const uid = myUid();
  const conversas = Object.entries(state.conversas)
    .map(([cid, c]) => ({ cid, ...c }))
    .filter(c => c.withUid && !isBlocked(c.withUid))
    .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  root.innerHTML = `
    <div class="dm-head">
      <strong style="font-size:16px" id="dm-titulo">${esc(state.me.username || 'Mensagens')}</strong>
      <button class="icon-btn" data-nova title="Nova mensagem"><i class="fa-regular fa-pen-to-square"></i></button>
    </div>
    <div class="dm-list">
      ${conversas.length ? conversas.map(c => {
        const u = state.users[c.withUid] || { nome: 'Usuário' };
        const naoLidas = c.naoLidas || 0;
        return `<div class="dm-row ${naoLidas ? 'unread' : ''}" data-abrir="${c.withUid}">
          ${avatar(u, 'av-md')}
          <div class="info"><strong>${esc(nomeDe(u))} ${verifiedBadge(u.verificado)}</strong>
            <span>${esc(c.ultimo || '')}${c.timestamp ? ` · ${timeAgo(c.timestamp)}` : ''}</span></div>
          ${naoLidas ? `<b class="badge" style="position:static">${naoLidas}</b>` : ''}
        </div>`;
      }).join('') : `<div class="empty"><i class="fa-regular fa-paper-plane"></i><h3>Suas mensagens</h3>
        <p>Envie mensagens privadas para amigos.</p>
        <button class="btn-primary sm" data-nova>Enviar mensagem</button></div>`}
    </div>`;
}

function renderNova(termo = '') {
  buscaNova = true;
  const root = $('#direct-root');
  const uid = myUid();
  const t = termo.trim().toLowerCase();
  const pessoas = Object.values(state.users)
    .filter(u => u.uid !== uid && !isBlocked(u.uid) &&
      (!t || (u.username || '').toLowerCase().includes(t) || (u.nome || '').toLowerCase().includes(t)))
    .sort((a, b) => Number(!!state.following[b.uid]) - Number(!!state.following[a.uid]))
    .slice(0, 40);
  root.innerHTML = `
    <div class="dm-head">
      <button class="icon-btn" data-voltar-lista aria-label="Voltar"><i class="fa-solid fa-arrow-left"></i></button>
      <strong>Nova mensagem</strong><span class="ph"></span>
    </div>
    <div class="search-box"><i class="fa-solid fa-magnifying-glass"></i>
      <input id="dm-busca" placeholder="Pesquisar" value="${esc(termo)}" autocomplete="off"></div>
    <div class="dm-list">
      ${pessoas.map(u => `<div class="dm-row" data-abrir="${u.uid}">${avatar(u, 'av-md')}
        <div class="info"><strong>${esc(u.username || u.nome)}</strong><span>${esc(u.nome || '')}</span></div></div>`).join('')
        || '<p class="empty-sm">Nenhuma conta encontrada.</p>'}
    </div>`;
  const campo = $('#dm-busca');
  if (campo) { campo.focus(); campo.setSelectionRange(termo.length, termo.length); }
}

// ---------- Conversa ----------
function abrirConversa(outroUid) {
  uidAtual = outroUid;
  buscaNova = false;
  const u = state.users[outroUid] || { nome: 'Usuário' };
  const root = $('#direct-root');
  root.innerHTML = `
    <div class="dm" style="height:100%;border:0;border-radius:0">
      <div class="dm-head">
        <div style="display:flex;align-items:center;gap:10px">
          <button class="icon-btn" data-voltar-lista aria-label="Voltar"><i class="fa-solid fa-arrow-left"></i></button>
          <div class="who" data-profile="${outroUid}">${avatar(u, 'av-sm')}
            <div><strong>${esc(nomeDe(u))}</strong>${verifiedBadge(u.verificado)}<br>
            <small><span class="dot ${u.online ? 'on' : 'off'}"></span> ${u.online ? 'Online' : 'Offline'}</small></div></div>
        </div>
        <button class="icon-btn" data-limpar-conv title="Apagar conversa"><i class="fa-solid fa-trash-can"></i></button>
      </div>
      <div class="dm-msgs" id="dm-msgs"></div>
      <form class="dm-form" id="dm-form">
        <input id="dm-texto" placeholder="Mensagem..." maxlength="1000" autocomplete="off">
        <button class="icon-btn" type="submit" aria-label="Enviar"><i class="fa-solid fa-paper-plane"></i></button>
      </form>
    </div>`;
  const aviso = isBlocked(outroUid);
  if (aviso) {
    $('#dm-form').innerHTML = '<p class="sub center" style="width:100%">Você bloqueou esta conta.</p>';
  }
  if (unsubMsgs) unsubMsgs();
  mensagens = [];
  unsubMsgs = onValue(ref(db, `chats/${chatId(myUid(), outroUid)}/mensagens`), s => {
    const v = s.val() || {};
    mensagens = Object.entries(v).map(([id, m]) => ({ id, ...m })).sort((a, b) => a.timestamp - b.timestamp);
    renderMensagens();
  });
  marcarLida(outroUid);
}

function renderMensagens() {
  const box = $('#dm-msgs');
  if (!box) return;
  const uid = myUid();
  let html = '';
  let ultimoDia = '';
  for (const m of mensagens) {
    const d = new Date(m.timestamp);
    const dia = d.toLocaleDateString('pt-BR');
    if (dia !== ultimoDia) {
      html += `<div class="bubble-time">${dia}</div>`;
      ultimoDia = dia;
    }
    const meu = m.de === uid;
    html += `<div class="bubble ${meu ? 'me' : 'them'}" data-msg="${m.id}" data-meu="${meu ? 1 : 0}" title="${d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}">${esc(m.texto)}${m.storyRef ? '<br><small style="opacity:.8"><i class="fa-regular fa-circle-play"></i> Resposta a um story</small>' : ''}</div>`;
  }
  box.innerHTML = html || '<p class="empty-sm">Envie a primeira mensagem!</p>';
  box.scrollTop = box.scrollHeight;
}

function marcarLida(outroUid) {
  const cid = chatId(myUid(), outroUid);
  if (state.conversas[cid]?.naoLidas) {
    set(ref(db, `conversas/${myUid()}/${cid}/naoLidas`), 0).catch(() => {});
  }
}

async function onClick(e) {
  const t = e.target;
  let el;
  if (t.closest('[data-voltar-lista]')) {
    if (unsubMsgs) unsubMsgs();
    unsubMsgs = null;
    uidAtual = null;
    buscaNova = false;
    return renderLista();
  }
  if ((el = t.closest('[data-nova]'))) return renderNova('');
  if ((el = t.closest('[data-abrir]'))) return abrirConversa(el.dataset.abrir);
  if ((el = t.closest('[data-limpar-conv]'))) return apagarConversa();
  if ((el = t.closest('[data-msg]'))) {
    if (el.dataset.meu !== '1') return;
    if (!(await confirmar('Apagar esta mensagem para você?'))) return;
    await remove(ref(db, `chats/${chatId(myUid(), uidAtual)}/mensagens/${el.dataset.msg}`));
  }
}

async function onSubmit(e) {
  if (e.target.id !== 'dm-form') return;
  e.preventDefault();
  const input = $('#dm-texto');
  const texto = input.value.trim();
  if (!texto || !uidAtual || isBlocked(uidAtual)) return;
  input.value = '';
  try { await enviarMensagem(uidAtual, texto); }
  catch { toast('Não foi possível enviar. Tente novamente.'); input.value = texto; }
}

async function apagarConversa() {
  if (!uidAtual) return;
  if (!(await confirmar('Apagar toda a conversa? Isso não pode ser desfeito.'))) return;
  const cid = chatId(myUid(), uidAtual);
  await remove(ref(db, `chats/${cid}`));
  await remove(ref(db, `conversas/${myUid()}/${cid}`));
  toast('Conversa apagada');
  if (unsubMsgs) unsubMsgs();
  unsubMsgs = null;
  uidAtual = null;
  renderLista();
}
