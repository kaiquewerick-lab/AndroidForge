// Núcleo compartilhado: Firebase, estado global, eventos e utilitários de interface.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, browserLocalPersistence, setPersistence } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getDatabase, ref, set, get, update, push, remove, onValue, onDisconnect, runTransaction
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-database.js";
import {
  getStorage, ref as sref, uploadBytes, getDownloadURL, deleteObject, refFromURL
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-storage.js";
import { firebaseConfig } from "./config.js";

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
export const storage = getStorage(app);
setPersistence(auth, browserLocalPersistence).catch(console.error);

export { ref, set, get, update, push, remove, onValue, onDisconnect, runTransaction };
export { sref, uploadBytes, getDownloadURL, deleteObject, refFromURL };

// ---------- Estado global ----------
export const state = {
  user: null,        // usuário do Firebase Auth
  me: {},            // perfil em usuarios/{uid}
  users: {},         // todos os perfis
  posts: [],         // publicações (inclui reels), mais recentes primeiro
  stories: {},       // stories/{uid}/{id}
  following: {},     // seguindo/{meu uid}
  followers: {},     // seguidores/{meu uid}
  blocked: {},       // bloqueados/{meu uid}
  notifs: [],
  conversas: {},
};
export const myUid = () => state.user?.uid;
export const me = () => state.me || {};

// ---------- Eventos ----------
export const bus = new EventTarget();
export const emit = name => bus.dispatchEvent(new Event('data:' + name));
export const on = (name, fn) => bus.addEventListener('data:' + name, fn);
export const go = (view, params = {}) =>
  bus.dispatchEvent(new CustomEvent('nav', { detail: { view, params } }));

// ---------- Seletores e textos ----------
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function timeAgo(ts) {
  if (!ts) return '';
  const s = Math.floor((Date.now() - ts) / 1000);
  if (s < 60) return 'agora';
  const m = Math.floor(s / 60); if (m < 60) return `há ${m} min`;
  const h = Math.floor(m / 60); if (h < 24) return `há ${h} h`;
  const d = Math.floor(h / 24); if (d < 7) return `há ${d} d`;
  return new Date(ts).toLocaleDateString('pt-BR');
}

export function avatar(u = {}, cls = 'av-md') {
  if (u.foto) return `<span class="av ${cls}"><img src="${esc(u.foto)}" alt=""></span>`;
  const n = (u.username || u.nome || '?').trim();
  return `<span class="av ${cls}">${esc(n.charAt(0).toUpperCase())}</span>`;
}
export const verifiedBadge = v => v ? '<i class="fa-solid fa-circle-check verified" title="Conta verificada"></i>' : '';
export const nomeDe = u => u?.username || u?.nome || 'usuário';
export const isBlocked = uid => !!state.blocked[uid];
export const isVideo = f => f.type.startsWith('video/');

// Conta privada: só quem segue (ou o próprio dono) vê o conteúdo.
export function podeVer(uid) {
  if (uid === myUid()) return true;
  if (isBlocked(uid)) return false;
  return !state.users[uid]?.privado || !!state.following[uid];
}

// ---------- Feedback ----------
let toastTimer;
export function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}

export function openModal(id) {
  $('#' + id).classList.remove('hidden');
  document.body.classList.add('modal-open');
}
export function closeModal(id) {
  const el = $('#' + id);
  if (el) el.classList.add('hidden');
  if (!$$('.modal:not(.hidden)').length) document.body.classList.remove('modal-open');
}
export function closeAllModals() { $$('.modal:not([data-static])').forEach(m => m.classList.add('hidden')); document.body.classList.remove('modal-open'); }

export function confirmar(texto) {
  return new Promise(resolve => {
    $('#confirm-texto').textContent = texto;
    openModal('modal-confirm');
    const ok = $('#confirm-ok'), cancel = $('#confirm-cancel');
    const done = v => { closeModal('modal-confirm'); ok.onclick = cancel.onclick = null; resolve(v); };
    ok.onclick = () => done(true);
    cancel.onclick = () => done(false);
  });
}

// ---------- Arquivos ----------
// Redimensiona e comprime imagens antes do envio (economiza espaço e banda).
export function compressImage(file, max = 1080, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const r = Math.min(1, max / Math.max(img.width, img.height));
      const w = Math.round(img.width * r), h = Math.round(img.height * r);
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      c.getContext('2d').drawImage(img, 0, 0, w, h);
      c.toBlob(b => { URL.revokeObjectURL(url); b ? resolve(b) : reject(new Error('Falha ao comprimir')); }, 'image/jpeg', quality);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Imagem inválida')); };
    img.src = url;
  });
}

export async function uploadArquivo(path, blob) {
  const r = sref(storage, path);
  await uploadBytes(r, blob);
  return getDownloadURL(r);
}

export function apagarArquivo(url) {
  try { return deleteObject(refFromURL(url)).catch(() => {}); } catch { return Promise.resolve(); }
}

// ---------- Notificações e relações ----------
export async function notificar(paraUid, tipo, extra = {}) {
  const uid = myUid();
  if (!paraUid || paraUid === uid) return;
  const p = me();
  await set(push(ref(db, `notificacoes/${paraUid}`)), {
    tipo, deUid: uid, deNome: p.nome || '', deUser: p.username || '', deFoto: p.foto || '',
    timestamp: Date.now(), lida: false, ...extra
  });
}

export async function toggleSeguir(outroUid) {
  const uid = myUid();
  if (!uid || outroUid === uid) return;
  const seguindo = !!state.following[outroUid];
  if (seguindo) {
    await remove(ref(db, `seguindo/${uid}/${outroUid}`));
    await remove(ref(db, `seguidores/${outroUid}/${uid}`));
    toast('Você deixou de seguir');
  } else {
    await set(ref(db, `seguindo/${uid}/${outroUid}`), true);
    await set(ref(db, `seguidores/${outroUid}/${uid}`), true);
    notificar(outroUid, 'seguir');
  }
}

// Linha de usuário com botão seguir (usada em listas e sugestões)
export function userRow(u, { followBtn = true, extra = '' } = {}) {
  const uid = myUid();
  const seguindo = !!state.following[u.uid];
  const btn = followBtn && u.uid !== uid
    ? `<button class="btn-${seguindo ? 'soft' : 'primary'} sm" data-follow="${u.uid}">${seguindo ? 'Seguindo' : 'Seguir'}</button>`
    : '';
  return `<div class="user-row">
    <div class="who" data-profile="${u.uid}">
      ${avatar(u, 'av-md')}
      <div>
        <strong>${esc(u.username || u.nome)} ${verifiedBadge(u.verificado)}</strong>
        <small>${esc(u.nome || '')} ${extra}</small>
      </div>
    </div>
    ${btn}
  </div>`;
}

// Lista modal genérica de usuários
export function abrirLista(titulo, uids, { busca = false, extra = {} } = {}) {
  $('#lista-title').textContent = titulo;
  $('#lista-busca-wrap').classList.toggle('hidden', !busca);
  const body = $('#lista-body');
  const render = (filtro = '') => {
    const f = filtro.trim().toLowerCase();
    const lista = uids.map(uid => state.users[uid] ? { uid, ...state.users[uid] } : null)
      .filter(Boolean)
      .filter(u => !f || (u.username || '').toLowerCase().includes(f) || (u.nome || '').toLowerCase().includes(f));
    body.innerHTML = lista.length
      ? lista.map(u => userRow(u, { followBtn: !extra.semBotao, extra: extra.linha ? extra.linha(u) : '' })).join('')
      : '<p class="empty-sm">Nada por aqui.</p>';
  };
  render();
  $('#lista-busca').value = '';
  $('#lista-busca').oninput = e => render(e.target.value);
  openModal('modal-lista');
}

export function applyTheme() {
  const t = localStorage.getItem('lumen_theme') || 'system';
  const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}
