// Criar publicação, reel e story com pré-visualização e envio para o Storage.
import {
  state, myUid, me, $, $$, toast, openModal, closeModal, compressImage, uploadArquivo,
  db, ref, set, push, go, isVideo
} from './core.js';

const LIMITES = {
  post: { max: 10, legenda: true, local: true, musica: true, audio: true, rotulo: 'Compartilhar', titulo: 'Nova publicação' },
  reel: { max: 1, legenda: true, local: false, musica: true, audio: true, rotulo: 'Publicar reel', titulo: 'Novo reel' },
  story: { max: 10, legenda: false, local: false, musica: true, audio: true, rotulo: 'Publicar story', titulo: 'Novo story' },
};
const MAX_VIDEO_MB = 60;
const MAX_AUDIO_MB = 5;

let modo = 'post';
let arquivos = [];
let audioArq = null;
let enviando = false;

export function initCreate() {
  $$('[data-ctab]').forEach(b => b.addEventListener('click', () => setModo(b.dataset.ctab)));
  $('#create-files').addEventListener('change', e => setArquivos(Array.from(e.target.files)));
  $('#create-audio').addEventListener('change', e => {
    const f = e.target.files[0];
    if (f && f.size > MAX_AUDIO_MB * 1024 * 1024) {
      toast(`Áudio muito grande (máx. ${MAX_AUDIO_MB} MB).`);
      e.target.value = ''; audioArq = null;
    } else audioArq = f || null;
    $('#create-audio-label').textContent = audioArq ? audioArq.name : 'Áudio de fundo (opcional, até 5 MB)';
  });
  $('#form-create').addEventListener('submit', publicar);
}

export function openCreate(tab = 'post') {
  setModo(tab);
  openModal('modal-create');
}

function setModo(m) {
  modo = m;
  const cfg = LIMITES[m];
  $$('[data-ctab]').forEach(b => b.classList.toggle('active', b.dataset.ctab === m));
  $('#create-title').textContent = cfg.titulo;
  $('#create-submit').textContent = cfg.rotulo;
  $('#create-legenda').classList.toggle('hidden', !cfg.legenda);
  $('#create-local').classList.toggle('hidden', !cfg.local);
  $('#create-musica').classList.toggle('hidden', !cfg.musica);
  $('#create-audio').closest('label').classList.toggle('hidden', !cfg.audio);
  $('#create-files').multiple = cfg.max > 1;
  $('#create-files').accept = m === 'reel' ? 'video/*' : 'image/*,video/*';
  $('#create-file-label').textContent = m === 'reel' ? 'Selecionar um vídeo' : 'Selecionar fotos ou vídeos';
  setArquivos([]);
}

function setArquivos(lista) {
  const cfg = LIMITES[modo];
  if (lista.length > cfg.max) {
    toast(`Você pode enviar no máximo ${cfg.max} arquivo${cfg.max > 1 ? 's' : ''}.`);
    lista = lista.slice(0, cfg.max);
  }
  if (modo === 'reel' && lista.some(f => !isVideo(f))) {
    toast('Reels aceitam apenas vídeos.');
    lista = lista.filter(isVideo);
  }
  const grandes = lista.filter(f => isVideo(f) && f.size > MAX_VIDEO_MB * 1024 * 1024);
  if (grandes.length) {
    toast(`Vídeos devem ter até ${MAX_VIDEO_MB} MB.`);
    lista = lista.filter(f => !grandes.includes(f));
  }
  arquivos = lista;
  $('#create-previews').innerHTML = lista.map(f => {
    const url = URL.createObjectURL(f);
    return isVideo(f)
      ? `<div class="pv"><video src="${url}" muted></video></div>`
      : `<div class="pv"><img src="${url}" alt=""></div>`;
  }).join('');
  $('#create-file-label').textContent = lista.length
    ? `${lista.length} arquivo${lista.length > 1 ? 's' : ''} selecionado${lista.length > 1 ? 's' : ''}`
    : LIMITES[modo].max === 1 ? 'Selecionar um vídeo' : 'Selecionar fotos ou vídeos';
}

function progresso(txt) {
  const p = $('#create-progress');
  p.textContent = txt;
  p.classList.toggle('hidden', !txt);
  $('#create-submit').disabled = !!txt;
}

async function enviarMidias(lista) {
  const uid = myUid();
  const saida = [];
  for (let i = 0; i < lista.length; i++) {
    const f = lista[i];
    progresso(`Enviando ${i + 1} de ${lista.length}…`);
    const id = Math.random().toString(36).slice(2, 9) + i;
    if (isVideo(f)) {
      const ext = (f.name.split('.').pop() || 'mp4').toLowerCase();
      const url = await uploadArquivo(`media/${uid}/${Date.now()}_${id}.${ext}`, f);
      saida.push({ url, tipo: 'video' });
    } else {
      const blob = await compressImage(f, 1080, 0.82);
      const url = await uploadArquivo(`media/${uid}/${Date.now()}_${id}.jpg`, blob);
      saida.push({ url, tipo: 'imagem' });
    }
  }
  return saida;
}

async function publicar(e) {
  e.preventDefault();
  if (enviando) return;
  const uid = myUid();
  if (!uid) return;
  if (!arquivos.length) return toast(modo === 'reel' ? 'Selecione um vídeo.' : 'Selecione pelo menos um arquivo.');

  enviando = true;
  try {
    const legenda = $('#create-legenda').value.trim();
    const local = $('#create-local').value.trim();
    const musicaNome = $('#create-musica').value.trim();
    let audioUrl = '';
    if (audioArq) {
      progresso('Enviando áudio…');
      audioUrl = await uploadArquivo(`audio/${uid}/${Date.now()}.${(audioArq.name.split('.').pop() || 'mp3')}`, audioArq);
    }

    const midias = await enviarMidias(arquivos);
    const p = me();
    const base = {
      uid,
      autor: p.nome || p.username || 'usuário',
      username: p.username || '',
      autorFoto: p.foto || '',
      verificado: !!p.verificado,
      timestamp: Date.now(),
    };

    if (modo === 'story') {
      for (const m of midias) {
        await set(push(ref(db, `stories/${uid}`)), {
          ...base, midia: m.url, tipo: m.tipo, musicaNome, audioUrl,
        });
      }
      toast('Story publicado!');
    } else {
      await set(push(ref(db, 'posts')), {
        ...base,
        tipo: modo === 'reel' ? 'reel' : 'post',
        tipoMidia: midias.length > 1 ? 'carrossel' : midias[0].tipo,
        midias,
        legenda: legenda.slice(0, 2200),
        local,
        musicaNome,
        audioUrl,
      });
      toast(modo === 'reel' ? 'Reel publicado!' : 'Publicação compartilhada!');
    }

    resetar();
    closeModal('modal-create');
    go(modo === 'reel' ? 'reels' : 'home');
  } catch (err) {
    console.error(err);
    toast('Não foi possível publicar. Verifique sua conexão.');
  } finally {
    enviando = false;
    progresso('');
  }
}

function resetar() {
  $('#form-create').reset();
  arquivos = [];
  audioArq = null;
  $('#create-previews').innerHTML = '';
  $('#create-audio-label').textContent = 'Áudio de fundo (opcional, até 5 MB)';
}
