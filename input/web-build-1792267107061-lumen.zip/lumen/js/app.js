// Ponto de entrada: roteamento entre telas, sincronização em tempo real e eventos globais.
import {
  bus, state, $, $$, go, emit, avatar, closeModal, applyTheme,
  ref, db, onValue, set, onDisconnect, toggleSeguir
} from './core.js';
import { initAuth } from './auth.js';
import { initFeed, openFeed } from './feed.js';
import { initStories, openStoriesOf } from './stories.js';
import { initCreate, openCreate } from './create.js';
import { initReels, openReels } from './reels.js';
import { initSocial, openSocial } from './social.js';
import { initDirect, openDirect } from './direct.js';
import { initSettings, openSettings } from './settings.js';

const VIEWS = {
  home: () => openFeed(),
  reels: () => openReels(),
  search: p => openSocial('search', p),
  notifs: p => openSocial('notifs', p),
  profile: p => openSocial('profile', p),
  direct: p => openDirect(p),
  settings: p => openSettings(p),
};

// ---------- Navegação ----------
function showView(view, params = {}, push = true) {
  if (!VIEWS[view]) view = 'home';
  closeAllModalsNonStatic();
  $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
  $$('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === view));
  VIEWS[view](params);
  window.scrollTo({ top: 0 });
  const st = { view, params };
  if (push) history.pushState(st, '', '#' + view);
  else history.replaceState(st, '', '#' + view);
}

function closeAllModalsNonStatic() {
  $$('.modal:not([data-static])').forEach(m => m.classList.add('hidden'));
  document.body.classList.remove('modal-open');
}

bus.addEventListener('nav', e => showView(e.detail.view, e.detail.params));
window.addEventListener('popstate', e => showView(e.state?.view || 'home', e.state?.params || {}, false));

// ---------- Sincronização em tempo real ----------
function setBadge(nome, n) {
  $$(`[data-badge="${nome}"]`).forEach(b => {
    b.textContent = n > 99 ? '99+' : n;
    b.classList.toggle('hidden', !n);
  });
}

function startData(uid) {
  onValue(ref(db, 'usuarios/' + uid), s => {
    state.me = s.val() || {};
    $('#nav-avatar').innerHTML = avatar(state.me, 'av-xs');
    $('#side-avatar').innerHTML = avatar(state.me, 'av-xs');
    emit('me');
  });
  onValue(ref(db, 'usuarios'), s => { state.users = s.val() || {}; emit('users'); });
  onValue(ref(db, 'posts'), s => {
    const v = s.val() || {};
    state.posts = Object.entries(v).map(([id, p]) => ({ id, ...p })).sort((a, b) => b.timestamp - a.timestamp);
    emit('posts');
  });
  onValue(ref(db, 'stories'), s => { state.stories = s.val() || {}; emit('stories'); });
  onValue(ref(db, 'seguindo/' + uid), s => { state.following = s.val() || {}; emit('following'); });
  onValue(ref(db, 'seguidores/' + uid), s => { state.followers = s.val() || {}; emit('followers'); });
  onValue(ref(db, 'bloqueados/' + uid), s => { state.blocked = s.val() || {}; emit('blocked'); });
  onValue(ref(db, 'notificacoes/' + uid), s => {
    const v = s.val() || {};
    state.notifs = Object.entries(v).map(([id, n]) => ({ id, ...n })).sort((a, b) => b.timestamp - a.timestamp);
    setBadge('notif', state.notifs.filter(n => !n.lida).length);
    emit('notifs');
  });
  onValue(ref(db, 'conversas/' + uid), s => {
    state.conversas = s.val() || {};
    const n = Object.values(state.conversas).reduce((a, c) => a + (c.naoLidas || 0), 0);
    setBadge('direct', n);
    emit('conversas');
  });
  // Presença: marca offline automaticamente ao fechar a aba
  onValue(ref(db, '.info/connected'), s => {
    if (s.val() !== true) return;
    const st = ref(db, `usuarios/${uid}/online`);
    onDisconnect(st).set(false);
    set(st, true);
  });
}

// ---------- Eventos globais (delegação) ----------
document.addEventListener('click', async e => {
  const t = e.target;

  const nav = t.closest('[data-nav]');
  if (nav) { e.preventDefault(); return go(nav.dataset.nav); }

  if (t.closest('[data-create]')) return openCreate();

  const cl = t.closest('[data-close]');
  if (cl) return closeModal(cl.dataset.close);

  const prof = t.closest('[data-profile]');
  if (prof) return go('profile', { uid: prof.dataset.profile });

  const fol = t.closest('[data-follow]');
  if (fol) {
    const uid = fol.dataset.follow;
    const was = !!state.following[uid];
    fol.textContent = was ? 'Seguir' : 'Seguindo';
    fol.className = was ? 'btn-primary sm' : 'btn-soft sm';
    return toggleSeguir(uid);
  }

  const st = t.closest('[data-story-of]');
  if (st) return openStoriesOf(st.dataset.storyOf);

  // Fecha modais não estáticos ao clicar no fundo escuro
  if (t.classList.contains('modal') && !t.hasAttribute('data-static')) closeModal(t.id);
});

// ---------- Inicialização ----------
applyTheme();
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

initFeed();
initStories();
initCreate();
initReels();
initSocial();
initDirect();
initSettings();

initAuth(user => {
  if (!user) {
    $('#app').classList.add('hidden');
    $('#auth').classList.remove('hidden');
    return;
  }
  state.user = user;
  $('#auth').classList.add('hidden');
  $('#app').classList.remove('hidden');
  startData(user.uid);
  const inicial = location.hash.slice(1);
  showView(VIEWS[inicial] ? inicial : 'home', {}, false);
});
