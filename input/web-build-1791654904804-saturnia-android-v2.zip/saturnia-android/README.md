# SaturnIA para Android (v2: SaturnIA Bubble + SaturnIA Actions)

Aplicativo Android nativo (Kotlin) que hospeda a SaturnIA em uma WebView, com:

- **Assistente de voz em segundo plano** (v1): frase de ativação "Ei, SaturnIA".
- **SaturnIA Bubble** (v2): balão flutuante sobre outros apps, com conversa com a IA.
- **SaturnIA Actions** (v2): detecção automática dos apps instalados, com pesquisa, seleção e abertura.

O HTML, CSS, JavaScript, o design e a integração com a IA (Worker) são os mesmos da versão web.
As alterações no HTML estão listadas no fim deste arquivo.

## Status (leia antes de tudo)

**O APK não foi compilado nem executado em aparelho neste ambiente.** O ambiente não tem acesso
ao Android SDK, ao Google Maven nem ao Gradle, então não foi possível gerar o APK.

**Verificado neste ambiente:**

- XML bem-formados (manifesto, recursos, Gradle).
- Código Kotlin passa na checagem de sintaxe e tipos do Kotlin 2.0. Restam apenas erros de
  referências às classes do Android, que só se resolvem com o SDK instalado.
- Regras puras, na JVM: 8 de 8 casos do histórico do balão e 7 de 7 casos da frase de ativação.
  Os testes JUnit correspondentes estão em `app/src/test/`.
- HTML em Chromium headless, com uma ponte nativa simulada, sem erros de JavaScript:
  - Actions: 4 apps detectados, ícones, pesquisa ("maps" reduz para 1), adicionar e remover do
    desktop, persistência das escolhas (`desk:x` no localStorage), abrir app, reação a instalação
    ou remoção de apps.
  - Bubble: switch liga e desliga pela ponte, e cada estado de permissão aparece em texto.
  - Voz: frase padrão "Ei, SaturnIA", todos os estados, comando nativo chegando à página e
    resposta falada pela ponte.

**Ainda não verificado (precisa de aparelho real):** build com Gradle, instalação, o balão
sobre outros apps, arrastar, minimizar, ocultar, reabrir pela notificação, tela cheia, o
comportamento das permissões, a detecção real de apps e a conversa com a IA a partir do app.

## Estrutura

```
saturnia-android/
├── settings.gradle.kts, build.gradle.kts, gradle.properties, .gitignore
├── gradle/wrapper/gradle-wrapper.properties
├── README.md
└── app/
    ├── build.gradle.kts
    ├── src/main/
    │   ├── AndroidManifest.xml
    │   ├── assets/saturnia/index.html        ← HTML da SaturnIA (com as alterações da seção "Alterações no HTML")
    │   ├── java/com/serius/saturnia/
    │   │   ├── MainActivity.kt        ← WebView, permissões, seletor de arquivos, downloads,
    │   │   │                             permissão do balão, receptor de instalação/remoção de apps
    │   │   ├── SaturnBridge.kt        ← window.SaturnIANative (ponte JavaScript)
    │   │   ├── VoiceService.kt        ← serviço de voz em primeiro plano
    │   │   ├── VoiceState.kt          ← estado do serviço de voz e fila de comandos
    │   │   ├── VoicePrefs.kt          ← frase de ativação salva
    │   │   ├── WakeWord.kt            ← reconhecimento da frase (função pura)
    │   │   ├── BubbleService.kt       ← balão, painel de conversa e notificação (v2)
    │   │   ├── BubbleState.kt         ← estado e modo do balão (v2)
    │   │   ├── BubbleChat.kt          ← conversa do balão, só na memória (v2)
    │   │   ├── ChatRules.kt           ← histórico enviado e mensagens de erro, funções puras (v2)
    │   │   ├── GeminiClient.kt        ← chamada ao /api/gemini do Worker (v2)
    │   │   └── AppCatalog.kt          ← apps instalados e ícones (v2)
    │   └── res/                        ← ícones, cores, tema, textos
    └── src/test/java/com/serius/saturnia/
        ├── WakeWordTest.kt
        └── BubbleLogicTest.kt          (v2)
```

## Como compilar e instalar

Requisitos: **JDK 17**, **Android Studio Iguana (2023.2) ou mais novo** (ou o SDK com command line
tools) e **Gradle 8.9** (só para gerar o wrapper).

1. Abra a pasta `saturnia-android` no Android Studio e aguarde a sincronização. Aceite instalar o SDK 34 se pedido.
2. Gere o wrapper, uma vez, na raiz do projeto: `gradle wrapper --gradle-version 8.9`
   (cria `gradlew`, `gradlew.bat` e `gradle/wrapper/gradle-wrapper.jar`, que não vêm no projeto).
3. `./gradlew assembleDebug`. O APK fica em `app/build/outputs/apk/debug/app-debug.apk`.
4. Testes unitários: `./gradlew testDebugUnitTest`.
5. Instalação: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

Para usar o site publicado em vez do HTML empacotado, defina `SATURNIA_URL` em `app/build.gradle.kts`.

## Antes de publicar: ajuste no Worker

A WebView envia a origem `https://appassets.androidplatform.net` nas chamadas do HTML empacotado.
Adicione essa origem a `ALLOWED_ORIGINS` no Worker, senão as chamadas feitas pela página serão
bloqueadas pelo CORS. **Não alterei o Worker publicado.**

O balão chama o Worker pelo código nativo, sem cabeçalho `Origin`, então não depende dessa lista.

---

## SaturnIA Bubble (v2)

### O que faz

- Um balão com o ícone da SaturnIA, arrastável pela tela. Tocar nele abre o **painel de conversa**
  compacto, sem sair do app em uso.
- Três modos:
  - **Flutuante:** balão visível. O painel compacto abre ao tocar no balão.
  - **Tela cheia:** o painel ocupa a tela. Botão "Janela" volta à janela compacta, com a mesma conversa.
  - **Oculto:** nada visível. A notificação tem "Mostrar balão" para reabrir.
- Controles do painel: **Tela cheia**, **Minimizar** (fecha o painel e deixa o balão), **Ocultar**
  (modo oculto), **Fechar** (fecha o painel) e **Nova** (limpa a conversa).
- A conversa é mantida ao minimizar, ocultar e reabrir. Ela fica só na memória do processo e
  some quando o app é encerrado. Nada é gravado em disco.
- A IA é a mesma da versão web: o balão chama `POST /api/gemini` do Worker, com o modelo escolhido
  no HTML. A chave de API continua no Worker. O app só envia o token de sessão do usuário.

### Como ele recebe a sessão

Na página, `auth.onIdTokenChanged` envia o token Firebase para o código nativo
(`SaturnIANative.setAuthToken`), ao entrar e a cada renovação do token (cerca de uma hora). O token
fica só na memória. Sem token, o painel pede para entrar no app.

### Permissões e segurança

- **"Exibir sobre outros apps"** (`SYSTEM_ALERT_WINDOW`): é pedida só quando o usuário liga o balão.
  Antes da tela do Android, o app mostra um aviso explicando o motivo. Se o usuário recusar, o balão
  fica desligado e o status diz o que falta. O app não contorna essa permissão.
- **Notificações** (Android 13+): necessárias para o atalho de reabrir o balão. Sem elas, o balão
  não inicia e o status diz isso.
- **Serviço em primeiro plano** do tipo `specialUse` (Android 14+), com a propriedade
  `PROPERTY_SPECIAL_USE_FGS_SUBTYPE` explicando o motivo.
- **Não lê a tela, não captura nada, não lê mensagens de outros apps** e não registra conteúdo
  privado. A conversa só contém o que o usuário digita no painel e as respostas da IA.
- Se o Android impedir o balão sobre um app (por exemplo, telas protegidas ou o próprio sistema),
  o app mostra "O Android impediu o balão neste app agora" no status e na notificação.

### Limites reais

1. **Telas protegidas:** apps com proteção de tela (ex.: alguns apps bancários) e a tela de bloqueio
   podem não exibir o balão. O app informa quando isso acontece.
2. **Economia de bateria:** o fabricante pode encerrar o serviço. Use "Sem restrições" em
   Ajustes > Aplicativos > SaturnIA > Bateria.
3. **Login dentro da WebView:** o Google bloqueia login em WebView embutida. Se o login falhar, o
   balão fica sem sessão e pede para entrar. Não testado no aparelho.
4. **Sem sessão após fechar o app:** o token fica só na memória. Ao reabrir a SaturnIA, o token volta.
5. **Não inicia sozinho** após reiniciar o aparelho.
6. **Teclado:** o painel recebe o foco para digitar. Em alguns aparelhos, o teclado pode cobrir parte
   do painel compacto. O modo tela cheia resolve isso.

---

## SaturnIA Actions (v2): apps do celular

### O que faz

- Lista automaticamente os apps que o usuário pode abrir (os que têm ícone no launcher), com nome,
  ícone e nome do pacote. Não exige Client ID.
- Campo de **pesquisa** por nome ou pacote.
- Agrupamento por **categoria** (Ferramentas, Música, Redes sociais etc.).
- **Adicionar ao desktop / Remover do desktop**: controla quais apps aparecem no desktop interno.
- **Abrir**: abre o app pelo Android.
- **Atualizar lista** e atualização automática quando apps são instalados, atualizados ou removidos.
  Apps que saem do aparelho deixam de aparecer.
- As escolhas são salvas no navegador (`desk:x`), por usuário, e continuam após fechar o app.
- Os ícones são carregados sob demanda e guardados em memória, em 72 px. Não vão para o
  armazenamento da página, para não estourar o espaço disponível.

### Client ID

O Client ID do Spotify continua na seção "Integrações externas (opcional)", porque o Spotify usa OAuth
e precisa dele. **Apps comuns do celular não precisam de Client ID.**

### Compatibilidade e privacidade

- A lista usa só a API pública de pacotes (`queryIntentActivities`). O bloco `<queries>` do
  manifesto declara a consulta, exigida a partir do Android 11. Não há permissão ampla para ver
  todos os apps.
- **Abrir um app não é controlá-lo.** O SaturnIA abre o app. Ações dentro dele dependem de
  integrações próprias (como o Spotify, com a própria autenticação).
- Apps sem atividade de inicialização, ocultos ou desinstalados não aparecem na lista.

---

### Chave da API (duas formas de uso)

- **Sem chave própria (padrão):** o balão e o chat chamam o Worker. A chave do Gemini fica como
  secret no Cloudflare; o app envia só o token de login. Limite de uso e login continuam valendo.
- **Com chave própria:** se o usuário preencher "Chave própria do Gemini" em Configurações (a mesma
  regra do chat web), o balão chama a API do Gemini direto com essa chave, sem passar pelo Worker.
  A chave é enviada ao código nativo só para a memória do processo: não é gravada no aparelho e
  some quando o app é fechado. Ao remover a chave no app, o balão volta ao Worker.

Limite: a chave própria fica na memória da WebView e do processo do app. Quem tiver o aparelho
desbloqueado e com depuração USB pode, em tese, lê-la. Por isso ela é opcional e deve ser uma chave
do próprio usuário.

## Permissões do manifesto

| Permissão | Quando é pedida | Por quê |
|---|---|---|
| INTERNET | sempre | IA e site |
| RECORD_AUDIO | ao ligar a escuta de voz | frase de ativação |
| POST_NOTIFICATIONS | ao ligar a escuta ou o balão (Android 13+) | notificação persistente |
| FOREGROUND_SERVICE, FOREGROUND_SERVICE_MICROPHONE | com a escuta | serviço de voz |
| SYSTEM_ALERT_WINDOW | ao ligar o balão, após explicação | balão sobre outros apps |
| FOREGROUND_SERVICE_SPECIAL_USE | com o balão | serviço do balão (Android 14+) |

## Como os dois recursos se relacionam

- O **balão** e a **escuta de voz** são serviços separados e podem ficar ligados ao mesmo tempo.
- Os dois usam o mesmo token e a mesma página. O balão não usa o microfone.
- Comandos de voz continuam indo para a SaturnIA pela página, como na v1.

---

## Alterações no HTML (`index.html`)

Alterações pequenas e aditivas. A versão web continua funcionando sem o app.

1. **Frase padrão:** "Ei, SaturnIA" (antes "OK, SaturnIA"). Também vale para a web.
2. **Estado `unavailable`** no status da escuta de voz.
3. **Frase salva** é enviada ao código nativo (`setWakePhrase`).
4. **`saturniaNativeCommand` e `saturniaNativeStatus`** para o código nativo.
5. **Comandos nativos** não reabrem a escuta do navegador. A resposta é lida pela ponte.
6. **`launch`** devolve booleano.
7. **Token e modelo para o balão:** `auth.onIdTokenChanged` chama `setAuthToken`; `gem()` chama
   `setChatModel` com o modelo escolhido.
8. **Seção "SaturnIA Bubble"** no painel de voz, com o switch e o estado do balão. Também há o item **SaturnIA Bubble** no menu lateral, que abre essa seção direto.
9. **Actions:** seção "Apps do celular" com pesquisa, adicionar/remover do desktop, abrir e
   atualizar. O Client ID do Spotify ficou em "Integrações externas (opcional)".
10. **`saturniaAppsChanged`** também salva e redesenha o desktop.
12. **Modelos do balão editáveis:** lista em "SaturnIA Bubble" (padrão: gemini-3.5-flash-lite, gemini-3.8-flash, gemini-3.1-pro-preview). É possível adicionar e remover modelos; só nomes válidos são aceitos. O balão usa o modelo selecionado, sem depender do modelo do chat web.
11. **Funções do desktop expostas** em `window` (`dkEnsure`, `dkSyncNative`, `dkSave`, `dkRender`,
    `dkState`, `dkCat`), para a seção de apps. Sem alteração de comportamento.

## Arquivos substituídos

O rascunho anterior em `/mnt/attach/outputs/android-nativo/` foi substituído por este projeto e pode
ser apagado.

## Checklist de teste no aparelho (Android 8 a 14)

Voz (v1):
- [ ] Ligar a escuta pede microfone e notificações; negar mostra "sem permissão".
- [ ] "Ei, SaturnIA" + comando executa e fala a resposta.
- [ ] Botão "Parar" na notificação desliga.

Balão (v2). Caminho: menu lateral > SaturnIA Bubble (ou SaturnIA Voice, seção SaturnIA Bubble):
- [ ] Ligar o balão mostra a explicação e depois a tela "Exibir sobre outros apps".
- [ ] Recusar a permissão deixa o balão desligado e o status explica o motivo.
- [ ] O balão aparece sobre outro app, e arrastar muda a posição.
- [ ] Tocar no balão abre o painel compacto; tocar de novo fecha.
- [ ] Enviar mensagem recebe resposta da IA (confirma a sessão e o Worker).
- [ ] "Minimizar" volta ao balão e a conversa continua ao reabrir.
- [ ] "Tela cheia" abre o painel inteiro; "Janela" volta ao compacto.
- [ ] "Ocultar" some com tudo; a notificação "Mostrar balão" reabre.
- [ ] Girar a tela e abrir o teclado não quebram o painel.
- [ ] Em tela protegida, o app informa que o Android impediu o balão.

Actions (v2):
- [ ] A lista mostra os apps do aparelho, com ícones e pacotes.
- [ ] A pesquisa filtra por nome e por pacote.
- [ ] Adicionar e remover do desktop muda o desktop e persiste após fechar o app.
- [ ] "Abrir" abre o app.
- [ ] Instalar ou remover um app atualiza a lista sem reiniciar.
- [ ] Apps sem ícone de launcher não aparecem.

Geral:
- [ ] A conversa com a IA funciona dentro do app (confirma o CORS do Worker).
- [ ] Anexar um arquivo abre o seletor do Android.
