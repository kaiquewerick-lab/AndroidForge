package com.serius.saturnia

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.sin

/**
 * Três pontos que pulsam em sequência, usados como "•••" enquanto a IA responde.
 * A animação só roda enquanto a view está na tela.
 */
class TypingDotsView(context: Context, private val dotColor: Int) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = dotColor }
    private val radius = context.resources.displayMetrics.density * 3.5f
    private val gap = context.resources.displayMetrics.density * 7f
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1100L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (radius * 2 * 3 + gap * 2).toInt() + paddingLeft + paddingRight
        val h = (radius * 2).toInt() + 2 + paddingTop + paddingBottom
        setMeasuredDimension(w, h)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cy = height / 2f
        for (i in 0 until 3) {
            // Cada ponto está defasado em 1/3 do ciclo; a opacidade sobe e desce como uma onda.
            val wave = (sin((phase - i / 3f) * 2 * Math.PI.toFloat()) + 1f) / 2f
            paint.alpha = (60 + 195 * wave).toInt()
            val cx = paddingLeft + radius + i * (radius * 2 + gap)
            canvas.drawCircle(cx, cy, radius * (0.8f + 0.2f * wave), paint)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) {
            if (!animator.isStarted) animator.start()
        } else {
            animator.cancel()
        }
    }
}
