// Plugins compartilhados pelos módulos. As versões ficam aqui para o projeto inteiro.
plugins {
    id("com.android.application") version "8.1.4" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
