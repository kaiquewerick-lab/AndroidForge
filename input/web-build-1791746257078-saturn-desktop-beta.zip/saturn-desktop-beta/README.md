# SaturnDesktopBETA

PC virtual configurável, com disco persistente independente do celular e arquitetura pronta para um computador remoto real.

> **Projeto separado da SaturnIA.** Não compartilha código, identidade visual, configurações ou infraestrutura com ela.

## Estado atual — Etapa 1 (arquitetura, menu e central de configuração)

| Item | Situação |
|---|---|
| Menu principal com botões, indicadores, resumo de hardware e espaço do disco | ✅ Implementado |
| Botão "+" e "+ Configurar hardware" abrem a central de configuração | ✅ Implementado |
| Seletores de SO, RAM, vCPU, GPU, armazenamento, resolução e perfil | ✅ Implementado, **somente com opções confirmadas pelo backend** |
| Validação da seleção contra o catálogo real | ✅ Implementado e testado |
| Resumo antes de iniciar, com etapas da inicialização | ✅ Exibido; botão de confirmação **desabilitado** até a Etapa 2 |
| Painéis Meu armazenamento, Configurações avançadas e Gerenciar máquinas | ✅ Informativos; ações reais dependem do backend |
| Provisionamento de VM, volume persistente, desktop, conexão remota | ⏳ Etapas 2 a 4 |
| Conexão a um provedor de nuvem ou hipervisor | ❌ Depende de infraestrutura externa ainda não escolhida |

**Regra do projeto:** nenhuma RAM, GPU ou disco aparece como disponível sem vir do catálogo do backend. Sem backend, a central mostra "nenhuma capacidade confirmada" e o início fica bloqueado. Não há tela de inicialização simulada.

## Estrutura

```
saturn-desktop-beta/
├── server.mjs              # Servidor HTTP (zero dependências) + API /api/catalog
├── package.json
├── public/                 # Cliente web (HTML, CSS, JS modular, sem frameworks)
│   ├── index.html
│   ├── css/app.css
│   └── js/
│       ├── app.js          # Controlador do menu e dos diálogos
│       ├── views.js        # Renderização da central, resumo e painéis
│       ├── selection.js    # Seleção do usuário, validação e resumo (puro)
│       ├── catalog.js      # Cliente do catálogo (puro, nunca lança exceção)
│       └── util.js         # Formatação e escape HTML (puro)
├── backend/                # Lugar do adaptador de infraestrutura (ver abaixo)
├── data/catalog.demo.json  # Catálogo FICTÍCIO, só para testar a interface
└── test/                   # 24 testes unitários da lógica pura
```

## Como executar

Requisito: **Node.js 20 ou superior**. Não há dependências npm.

```bash
cd saturn-desktop-beta

# Modo real: sem infraestrutura configurada, a API responde 503 e a interface avisa.
npm start                 # http://127.0.0.1:8080

# Modo demonstração: usa data/catalog.demo.json (fictício, marcado como DEMO na tela).
npm run start:demo

# Testes
npm test
```

Variáveis de ambiente: `PORT` (padrão 8080), `HOST` (padrão 127.0.0.1), `SATURN_CATALOG_FILE` (caminho de um catálogo JSON).

## Teste no Android

1. No computador, rode `HOST=0.0.0.0 npm run start:demo` (Windows: defina as variáveis no PowerShell antes de `npm run start:demo`).
2. Conecte o Android à mesma rede Wi-Fi e abra `http://IP_DO_COMPUTADOR:8080` no Chrome.
3. Confira: botão "+" visível, central abre em tela cheia, seletores reagem ao toque, item "[DEMO] Windows 11" aparece indisponível, a RTX 4090 de demonstração não pode ser selecionada, e o perfil "Jogos e gráficos" exige GPU.
4. Teste também em modo retrato e paisagem, e com o teclado virtual aberto.

Observação: este teste foi feito apenas com validação de lógica. A **interface ainda não foi verificada em navegador real** (ver "Limitações").

## Contrato da API de catálogo — `GET /api/catalog`

O cliente só mostra o que este JSON contiver. Entradas malformadas são descartadas.

```jsonc
{
  "demo": false,                       // true apenas para catálogos de teste
  "os":      [{ "id": "ubuntu-24.04", "name": "Ubuntu 24.04 LTS", "available": true }],
  "ram":     [{ "gb": 8, "available": true }],
  "cpu":     [{ "vcpus": 4, "available": true }],
  "gpu":     [{ "id": "gpu-1", "name": "…", "vramGb": 12, "available": true,
                "assignment": "livre", "features": ["…"], "notes": "…" }],
  "storage": [{ "gb": 50, "available": true }],
  "resolutions": ["1920x1080"],
  "machines": [{ "id": "vm-1", "name": "Meu PC", "state": "desligada", "os": "Ubuntu" }],
  "limits":  { "maxRamGb": 32, "maxVcpus": 8, "maxStorageGb": 256 },
  "disk":    { "volumeId": "vol-1", "state": "disponível", "totalGb": 50, "usedGb": 12,
               "files": 143, "persistent": true, "expandable": false }
}
```

Respostas: `200` com o catálogo; `503` com `{ "error": "infra_not_configured", "message": "…" }` quando não há infraestrutura.

## Arquitetura de destino (Etapas 2 a 4)

- **Cliente web:** interface, seleção, visualizador remoto, explorador de arquivos e indicadores. Não guarda credenciais.
- **Backend:** autenticação, catálogo real, provisionamento de VM, volumes persistentes, ciclo de vida (iniciar, desligar, reiniciar), monitoramento, conexão remota e transferência de arquivos. Todas as autorizações são feitas no backend.
- **Infraestrutura:** provedor de nuvem ou servidor com virtualização (KVM/Proxmox ou equivalente). A escolha depende de custo, região e suporte a passthrough de GPU, que ainda não foi definido.
- **Transmissão:** candidatos WebRTC ou RDP por gateway seguro. A decisão depende do tipo de máquina escolhido.

## Dependências externas (ainda não configuradas)

| Dependência | Para quê | Status |
|---|---|---|
| Provedor de nuvem ou servidor com virtualização | Criar VMs reais, com RAM, CPU, GPU e disco | Não escolhido |
| Volumes persistentes do provedor | Disco separado do celular, com backup e exclusão | Não escolhido |
| Imagens de SO | Windows/Linux com licença válida | Não escolhido |
| Gateway de conexão remota (WebRTC ou RDP) | Desktop remoto de baixa latência | Não escolhido |
| Domínio com HTTPS e autenticação | Acesso seguro pelo navegador e pelo Android | Não configurado |

Nenhuma dessas integrações foi inventada. Quando forem escolhidas, entram como adaptadores no backend.

## Segurança já aplicada

- Cabeçalho `Content-Security-Policy` restrito a origem própria, sem scripts inline.
- Escape de todo dado vindo do backend antes de inserir em HTML.
- Servidor aceita só `GET` e `HEAD`; bloqueia path traversal.
- Preferências no `localStorage` guardam apenas a escolha do usuário, nunca capacidades nem segredos.
- Nenhuma credencial no código entregue ao navegador.

## Limitações conhecidas

- **Interface sem teste em navegador real.** A lógica tem 24 testes unitários, mas não foi possível instalar um navegador headless neste ambiente (o registro npm não é alcançável). É preciso abrir o projeto em Chrome ou Edge e revisar os diálogos.
- Sem infraestrutura, o PC virtual **não inicia**, por desenho.
- O volume de armazenamento real, a transferência de arquivos e a exclusão definitiva dependem do backend (Etapa 2).
- O desktop virtual, os aplicativos internos e a conexão remota ainda não existem (Etapas 3 e 4).
- O desempenho depende da conexão e do servidor; não há promessa de latência zero.
- Software instalado na máquina remota depende de SO, licenças, permissões e compatibilidade.
