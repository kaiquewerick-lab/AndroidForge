/**
 * Seleção de hardware do usuário: sanitização, validação contra o catálogo e resumo.
 * Módulo puro (sem DOM).
 */
import { isPositiveNumber, formatGb } from './util.js';

export const PROFILES = Object.freeze([
  { id: 'economico', label: 'Econômico', hint: 'Menor consumo e custo para tarefas leves.', needsGpu: false },
  { id: 'equilibrado', label: 'Equilibrado', hint: 'Equilíbrio entre desempenho e custo.', needsGpu: false },
  { id: 'alto', label: 'Alto desempenho', hint: 'Prioriza CPU e RAM que o servidor puder oferecer.', needsGpu: false },
  { id: 'jogos', label: 'Jogos e gráficos', hint: 'Requer uma GPU dedicada disponível.', needsGpu: true },
  { id: 'desenvolvimento', label: 'Desenvolvimento de software', hint: 'Compilação, terminal e ferramentas de projeto.', needsGpu: false },
  { id: 'renderizacao', label: 'Renderização e aplicações pesadas', hint: 'Combinação de vCPU, RAM e armazenamento para cargas longas.', needsGpu: false },
]);

export const EMPTY_SELECTION = Object.freeze({
  os: null,
  ram: null,
  cpu: null,
  gpu: null,
  storage: null,
  resolution: null,
  profile: 'equilibrado',
});

const REQUIRED = [
  ['os', 'o sistema operacional'],
  ['ram', 'a quantidade de RAM'],
  ['cpu', 'a quantidade de vCPUs'],
  ['storage', 'a capacidade do armazenamento'],
];

const RESOLUTION_RE = /^\d{3,5}x\d{3,5}$/;

/** Converte dados quaisquer (ex.: localStorage) em uma seleção válida. */
export function sanitizeSelection(raw) {
  const s = { ...EMPTY_SELECTION };
  if (!raw || typeof raw !== 'object') return s;
  if (typeof raw.os === 'string' && raw.os) s.os = raw.os;
  if (isPositiveNumber(raw.ram)) s.ram = raw.ram;
  if (isPositiveNumber(raw.cpu)) s.cpu = raw.cpu;
  if (typeof raw.gpu === 'string' && raw.gpu) s.gpu = raw.gpu;
  if (isPositiveNumber(raw.storage)) s.storage = raw.storage;
  if (typeof raw.resolution === 'string' && RESOLUTION_RE.test(raw.resolution)) s.resolution = raw.resolution;
  if (PROFILES.some((p) => p.id === raw.profile)) s.profile = raw.profile;
  return s;
}

const find = (list, key, value) => list.find((item) => item[key] === value);

/**
 * Confere a seleção contra o catálogo real.
 * Retorna { ready, errors, warnings }. Só fica "ready" com catálogo conectado
 * e todos os recursos obrigatórios confirmados pela infraestrutura.
 */
export function validateSelection(sel, catalog) {
  const errors = [];
  const warnings = [];

  if (catalog.status !== 'ok') {
    errors.push('Infraestrutura não conectada. Você pode montar a configuração, mas o PC virtual só inicia com um backend disponível.');
    return { ready: false, errors, warnings };
  }

  if (!sel.os) errors.push('Escolha o sistema operacional.');
  else if (!find(catalog.os, 'id', sel.os)) errors.push('O sistema operacional escolhido não está disponível nesta infraestrutura.');

  if (!sel.ram) errors.push('Escolha a quantidade de RAM.');
  else if (!find(catalog.ram, 'gb', sel.ram)) errors.push(`${formatGb(sel.ram)} de RAM não está disponível nesta infraestrutura.`);

  if (!sel.cpu) errors.push('Escolha a quantidade de vCPUs.');
  else if (!find(catalog.cpu, 'vcpus', sel.cpu)) errors.push(`${sel.cpu} vCPUs não estão disponíveis nesta infraestrutura.`);

  if (!sel.storage) errors.push('Escolha a capacidade do armazenamento.');
  else if (!find(catalog.storage, 'gb', sel.storage)) errors.push(`${formatGb(sel.storage)} de armazenamento não está disponível nesta infraestrutura.`);

  if (sel.gpu) {
    const gpu = find(catalog.gpu, 'id', sel.gpu);
    if (!gpu) errors.push('A GPU escolhida não consta mais no catálogo.');
    else if (!gpu.available) errors.push(`${gpu.name} está indisponível nesta infraestrutura.`);
  }

  if (sel.resolution && catalog.resolutions.length && !catalog.resolutions.includes(sel.resolution)) {
    errors.push(`A resolução ${sel.resolution} não é suportada pelo servidor.`);
  }

  const profile = PROFILES.find((p) => p.id === sel.profile);
  if (profile?.needsGpu && !sel.gpu) {
    errors.push(`O perfil "${profile.label}" exige uma GPU dedicada disponível.`);
  }

  if (catalog.disk && sel.storage && sel.storage !== catalog.disk.totalGb) {
    warnings.push(`O volume existente tem ${formatGb(catalog.disk.totalGb)}. Alterar a capacidade depende de expansão suportada pelo provedor.`);
  }

  return { ready: errors.length === 0, errors, warnings };
}

/** Linhas de resumo com estado: 'ok' | 'empty' | 'bad'. */
export function summarize(sel, catalog) {
  const connected = catalog.status === 'ok';
  const state = (chosen, found) => (!chosen ? 'empty' : found ? 'ok' : 'bad');
  const row = (key, label, value, st) => ({ key, label, value, state: st });

  const os = sel.os ? find(catalog.os, 'id', sel.os) : null;
  const gpu = sel.gpu ? find(catalog.gpu, 'id', sel.gpu) : null;
  const profile = PROFILES.find((p) => p.id === sel.profile);

  return [
    row('os', 'Sistema operacional', os ? os.name : sel.os ? 'Indisponível nesta infraestrutura' : 'Não escolhido', state(sel.os, os)),
    row('ram', 'RAM', sel.ram ? formatGb(sel.ram) : 'Não escolhida', state(sel.ram, find(catalog.ram, 'gb', sel.ram))),
    row('cpu', 'CPU', sel.cpu ? `${sel.cpu} vCPUs` : 'Não escolhida', state(sel.cpu, find(catalog.cpu, 'vcpus', sel.cpu))),
    row(
      'gpu',
      'GPU',
      gpu ? gpu.name : sel.gpu ? 'Indisponível nesta infraestrutura' : 'Sem GPU dedicada',
      sel.gpu ? (gpu && gpu.available ? 'ok' : 'bad') : 'empty',
    ),
    row('storage', 'Armazenamento', sel.storage ? formatGb(sel.storage) : 'Não escolhido', state(sel.storage, find(catalog.storage, 'gb', sel.storage))),
    row('resolution', 'Resolução', sel.resolution ? sel.resolution.replace('x', '×') : 'Padrão do servidor', sel.resolution ? 'ok' : 'empty'),
    row('profile', 'Perfil', profile ? profile.label : 'Equilibrado', 'ok'),
    row(
      'infra',
      'Infraestrutura',
      connected ? (catalog.demo ? 'Demonstração (nenhuma máquina real)' : 'Conectada') : 'Não conectada',
      !connected ? 'bad' : catalog.demo ? 'empty' : 'ok',
    ),
  ];
}
