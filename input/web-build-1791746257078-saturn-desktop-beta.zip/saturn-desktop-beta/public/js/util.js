/** Utilitários puros, sem dependência de DOM (testáveis em Node). */

export const isPositiveNumber = (n) => typeof n === 'number' && Number.isFinite(n) && n > 0;

/** Formata capacidade em GB/TB (1 TB = 1024 GB). */
export function formatGb(gb) {
  if (typeof gb !== 'number' || !Number.isFinite(gb) || gb < 0) return '—';
  if (gb >= 1024) {
    const tb = gb / 1024;
    return `${Number.isInteger(tb) ? tb : tb.toFixed(1)} TB`;
  }
  return `${gb} GB`;
}

const ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

/** Escapa texto antes de inserir em HTML. Todo dado vindo do backend passa por aqui. */
export function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (ch) => ESCAPES[ch]);
}
