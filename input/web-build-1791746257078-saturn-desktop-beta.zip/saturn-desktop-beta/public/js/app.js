/**
 * Controlador do menu principal e da central de configuração.
 * Fluxos de início, sessão e transferência entram na Etapa 2 (backend).
 */
import { fetchCatalog, unavailableCatalog } from './catalog.js';
import { sanitizeSelection, summarize, validateSelection } from './selection.js';
import {
  renderAdvancedInfo,
  renderHardwareCenter,
  renderManageInfo,
  renderStartSummary,
  renderStorageInfo,
} from './views.js';
import { esc, formatGb } from './util.js';

const PREF_KEY = 'saturn-desktop-beta:preferencias:v1';
const $ = (selector) => document.querySelector(selector);

const app = {
  catalog: unavailableCatalog('Verificando…'),
  checking: true,
  saved: loadPreferences(),   // preferências confirmadas pelo usuário
  draft: null,                // alterações não salvas dentro da central
  session: null,              // sessão ativa; preenchida na Etapa 2
};

/* ---------- Preferências (apenas escolhas do usuário; nunca capacidades) ---------- */

function loadPreferences() {
  try {
    return sanitizeSelection(JSON.parse(localStorage.getItem(PREF_KEY)));
  } catch {
    return sanitizeSelection(null);
  }
}

function savePreferences(sel) {
  try {
    localStorage.setItem(PREF_KEY, JSON.stringify(sel));
    return true;
  } catch {
    return false;
  }
}

/* ---------- Menu principal ---------- */

function setText(selector, text, tone) {
  const el = $(selector);
  if (!el) return;
  el.textContent = text;
  if (tone) el.dataset.tone = tone;
  else delete el.dataset.tone;
}

function diskLabel(c) {
  if (c.disk) return `${formatGb(c.disk.freeGb)} livres de ${formatGb(c.disk.totalGb)}`;
  return c.status === 'ok' ? 'Nenhum volume provisionado' : 'Indisponível sem infraestrutura';
}

function renderNotice() {
  const el = $('#menu-notice');
  const c = app.catalog;
  if (app.checking) {
    el.textContent = 'Consultando a infraestrutura…';
    return;
  }
  if (c.status !== 'ok') {
    el.innerHTML = `${esc(c.reason)} Você pode montar a configuração, mas o PC virtual só inicia com uma infraestrutura conectada. `
      + '<button type="button" class="link" data-action="recheck">Verificar novamente</button>';
    return;
  }
  el.textContent = c.demo ? 'Catálogo de demonstração: nenhuma máquina real será iniciada.' : '';
}

function renderMenu() {
  const c = app.catalog;
  const infra = app.checking ? ['Verificando…', 'muted']
    : c.status !== 'ok' ? ['Não conectada', 'err']
      : c.demo ? ['Demonstração', 'warn']
        : ['Conectada', 'ok'];

  setText('#infra-state', infra[0], infra[1]);
  setText('#vm-state', app.session ? app.session.label : 'Desligada', app.session ? 'ok' : 'muted');
  setText('#remote-state', app.session ? app.session.remote : 'Não aplicável', 'muted');
  setText('#disk-free', diskLabel(c), c.disk ? 'ok' : 'muted');

  for (const item of summarize(app.saved, c)) {
    if (item.key === 'infra') continue;
    setText(`#hw-${item.key}`, item.value, item.state === 'bad' ? 'err' : undefined);
  }

  $('#btn-shutdown').hidden = !app.session;
  renderNotice();
}

/* ---------- Diálogos ---------- */

function openDialog(dlg) {
  if (typeof dlg.showModal === 'function') dlg.showModal();
  else dlg.setAttribute('open', '');
}

function openInfo(title, html) {
  $('#info-title').textContent = title;
  $('#info-body').innerHTML = html;
  openDialog($('#info-dialog'));
}

function applyPick(draft, pick, value) {
  const next = { ...draft };
  if (pick === 'ram' || pick === 'cpu' || pick === 'storage') next[pick] = Number(value);
  else next[pick] = value || null; // os, gpu, resolution: vazio = nenhum; profile sempre tem valor
  return sanitizeSelection(next);
}

function renderConfig(focus = null) {
  const validation = validateSelection(app.draft, app.catalog);
  const body = $('#config-body');
  body.innerHTML = renderHardwareCenter({ catalog: app.catalog, selection: app.draft, validation });
  if (focus) {
    const target = [...body.querySelectorAll('[data-pick]')]
      .find((b) => b.dataset.pick === focus.pick && b.dataset.value === focus.value);
    target?.focus();
  }
}

function openConfig() {
  app.draft = { ...app.saved };
  renderConfig();
  openDialog($('#config-dialog'));
}

function openStart() {
  const sel = app.saved;
  const validation = validateSelection(sel, app.catalog);
  $('#start-body').innerHTML = renderStartSummary({
    catalog: app.catalog,
    summary: summarize(sel, app.catalog),
    validation,
  });
  $('#start-note').textContent = validation.ready
    ? 'A inicialização real será ligada na Etapa 2, quando o backend de provisionamento estiver implementado. Nenhuma tela de inicialização é simulada.'
    : 'Corrija os itens acima para preparar o início do PC virtual.';
  $('#btn-confirm-start').disabled = true; // só libera quando o provisionamento existir
  openDialog($('#start-dialog'));
}

/* ---------- Eventos ---------- */

async function refreshCatalog() {
  app.checking = true;
  renderMenu();
  app.catalog = await fetchCatalog();
  app.checking = false;
  renderMenu();
  if ($('#config-dialog').open) renderConfig();
}

document.querySelectorAll('[data-open-config]').forEach((btn) => btn.addEventListener('click', openConfig));
$('#btn-start').addEventListener('click', openStart);
$('#btn-storage').addEventListener('click', () => openInfo('Meu armazenamento', renderStorageInfo(app.catalog)));
$('#btn-advanced').addEventListener('click', () => openInfo('Configurações avançadas', renderAdvancedInfo(app.catalog)));
$('#btn-manage').addEventListener('click', () => openInfo('Computadores virtuais', renderManageInfo(app.catalog)));
$('#btn-adjust').addEventListener('click', () => {
  $('#start-dialog').close();
  openConfig();
});

$('#config-body').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-pick]');
  if (!btn || btn.disabled) return;
  const { pick, value } = btn.dataset;
  app.draft = applyPick(app.draft, pick, value);
  renderConfig({ pick, value });
});

$('#btn-save-config').addEventListener('click', () => {
  app.saved = sanitizeSelection(app.draft);
  const persisted = savePreferences(app.saved);
  $('#config-dialog').close();
  renderMenu();
  if (!persisted) {
    $('#menu-notice').textContent = 'Não foi possível salvar as preferências neste navegador. Elas valem apenas nesta página.';
  }
});

$('#menu-notice').addEventListener('click', (e) => {
  if (e.target.closest('[data-action="recheck"]')) refreshCatalog();
});

// Fechar pelo botão [data-close] ou clicando no fundo escuro.
document.querySelectorAll('dialog').forEach((dlg) => {
  dlg.addEventListener('click', (e) => {
    if (e.target === dlg || e.target.closest('[data-close]')) dlg.close();
  });
});

refreshCatalog();
