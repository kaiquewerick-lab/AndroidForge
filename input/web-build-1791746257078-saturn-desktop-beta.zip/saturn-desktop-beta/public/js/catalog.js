/**
 * Cliente do catálogo de máquinas.
 *
 * Regra central: o cliente NÃO inventa recursos. Só existe no catálogo o que o
 * backend informou. Se o backend não responder, o catálogo fica "unavailable"
 * e a interface não oferece nenhuma capacidade como escolhível.
 */
import { isPositiveNumber } from './util.js';

export const CATALOG_URL = '/api/catalog';

const offered = (item) => item.available !== false;
const byKey = (key) => (a, b) => a[key] - b[key];
const isObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

export function unavailableCatalog(reason) {
  return {
    status: 'unavailable',
    reason,
    demo: false,
    os: [],
    ram: [],
    cpu: [],
    gpu: [],
    storage: [],
    resolutions: [],
    machines: [],
    limits: null,
    disk: null,
  };
}

function normalizeGpu(x) {
  return {
    id: x.id,
    name: x.name,
    vramGb: isPositiveNumber(x.vramGb) ? x.vramGb : null,
    available: offered(x),
    assignment: typeof x.assignment === 'string' ? x.assignment : 'não informada',
    features: Array.isArray(x.features) ? x.features.filter((f) => typeof f === 'string') : [],
    notes: typeof x.notes === 'string' ? x.notes : null,
  };
}

function normalizeLimits(l) {
  if (!isObject(l)) return null;
  const pick = (v) => (isPositiveNumber(v) ? v : null);
  return {
    maxRamGb: pick(l.maxRamGb),
    maxVcpus: pick(l.maxVcpus),
    maxStorageGb: pick(l.maxStorageGb),
  };
}

function normalizeDisk(d) {
  if (!isObject(d) || !isPositiveNumber(d.totalGb)) return null;
  const usedGb = typeof d.usedGb === 'number' && d.usedGb >= 0 ? Math.min(d.usedGb, d.totalGb) : 0;
  return {
    volumeId: String(d.volumeId ?? '—'),
    state: String(d.state ?? 'desconhecido'),
    totalGb: d.totalGb,
    usedGb,
    freeGb: d.totalGb - usedGb,
    files: Number.isInteger(d.files) ? d.files : null,
    persistent: d.persistent === true,
    expandable: d.expandable === true,
  };
}

function normalizeMachine(m) {
  return {
    id: m.id,
    name: m.name,
    state: String(m.state ?? 'desconhecido'),
    os: String(m.os ?? '—'),
  };
}

/** Valida e filtra a resposta do backend. Entradas malformadas são descartadas. */
export function normalizeCatalog(raw) {
  if (!isObject(raw)) {
    return unavailableCatalog('O backend retornou um catálogo em formato inválido.');
  }
  const items = (list, valid) =>
    (Array.isArray(list) ? list.filter((x) => isObject(x) && valid(x)) : []);

  return {
    status: 'ok',
    reason: null,
    demo: raw.demo === true,
    os: items(raw.os, (x) => typeof x.id === 'string' && typeof x.name === 'string' && offered(x)),
    ram: items(raw.ram, (x) => isPositiveNumber(x.gb) && offered(x)).sort(byKey('gb')),
    cpu: items(raw.cpu, (x) => Number.isInteger(x.vcpus) && x.vcpus > 0 && offered(x)).sort(byKey('vcpus')),
    gpu: items(raw.gpu, (x) => typeof x.id === 'string' && typeof x.name === 'string').map(normalizeGpu),
    storage: items(raw.storage, (x) => isPositiveNumber(x.gb) && offered(x)).sort(byKey('gb')),
    resolutions: Array.isArray(raw.resolutions)
      ? raw.resolutions.filter((r) => typeof r === 'string' && /^\d{3,5}x\d{3,5}$/.test(r))
      : [],
    machines: items(raw.machines, (x) => typeof x.id === 'string' && typeof x.name === 'string').map(normalizeMachine),
    limits: normalizeLimits(raw.limits),
    disk: normalizeDisk(raw.disk),
  };
}

/** Busca o catálogo no backend. Nunca lança: qualquer falha vira catálogo indisponível. */
export async function fetchCatalog({ fetchImpl = globalThis.fetch, timeoutMs = 6000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetchImpl(CATALOG_URL, {
      headers: { accept: 'application/json' },
      cache: 'no-store',
      signal: controller.signal,
    });
    const body = await res.json().catch(() => null);
    if (!res.ok) {
      const message = isObject(body) && typeof body.message === 'string'
        ? body.message
        : `O backend respondeu com erro ${res.status}.`;
      return unavailableCatalog(message);
    }
    return normalizeCatalog(body);
  } catch (err) {
    const reason = err?.name === 'AbortError'
      ? 'O backend não respondeu a tempo.'
      : 'Não foi possível contatar o backend.';
    return unavailableCatalog(reason);
  } finally {
    clearTimeout(timer);
  }
}
