/**
 * Renderização HTML das telas. Todo dado externo passa por esc().
 * Nenhuma opção é mostrada como disponível sem vir do catálogo do backend.
 */
import { PROFILES } from './selection.js';
import { esc, formatGb } from './util.js';

const START_STEPS = [
  'Validar a configuração solicitada',
  'Confirmar que os recursos estão disponíveis',
  'Provisionar ou selecionar a máquina virtual',
  'Associar o disco persistente correto',
  'Inicializar o sistema operacional',
  'Aguardar o serviço remoto ficar disponível',
  'Estabelecer a conexão segura',
  'Abrir o desktop virtual',
];

const empty = (text) => `<p class="empty">${esc(text)}</p>`;
const hintP = (text) => (text ? `<p class="hint">${esc(text)}</p>` : '');

function chip({ pick, value, label, active, disabled = false, sub = '' }) {
  return `<button type="button" class="chip" data-pick="${esc(pick)}" data-value="${esc(value)}"`
    + ` aria-pressed="${active ? 'true' : 'false'}"${disabled ? ' disabled' : ''}>`
    + `<span>${esc(label)}</span>${sub ? `<small>${esc(sub)}</small>` : ''}</button>`;
}

function section(id, title, body, hint = '') {
  return `<section class="cat" aria-labelledby="${id}"><h3 id="${id}">${esc(title)}</h3>${hintP(hint)}${body}</section>`;
}

function facts(rows) {
  return `<dl class="facts">${rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('')}</dl>`;
}

function banner(catalog) {
  if (catalog.status !== 'ok') {
    return `<div class="banner err"><strong>Infraestrutura não conectada.</strong> ${esc(catalog.reason)} `
      + 'As escolhas abaixo são apenas preferências: nenhuma capacidade foi confirmada.</div>';
  }
  if (catalog.demo) {
    return '<div class="banner warn"><strong>Catálogo de demonstração.</strong> '
      + 'Os recursos listados não correspondem a uma máquina real; nada será iniciado.</div>';
  }
  return '';
}

function issues(validation) {
  const rows = [
    ...validation.errors.map((t) => ['err', t]),
    ...validation.warnings.map((t) => ['warn', t]),
  ];
  if (!rows.length) return '';
  return `<ul class="issues">${rows.map(([tone, t]) => `<li class="${tone}">${esc(t)}</li>`).join('')}</ul>`;
}

function osSection(c, sel) {
  const body = c.os.length
    ? `<div class="options">${c.os.map((o) => chip({ pick: 'os', value: o.id, label: o.name, active: sel.os === o.id })).join('')}</div>`
    : empty('Nenhum sistema operacional foi confirmado pela infraestrutura.');
  return section('cat-os', 'Sistema operacional', body, 'Lista vinda do catálogo do backend.');
}

function ramSection(c, sel) {
  const body = c.ram.length
    ? `<div class="options">${c.ram.map((r) => chip({ pick: 'ram', value: r.gb, label: formatGb(r.gb), active: sel.ram === r.gb })).join('')}</div>`
    : empty('Nenhuma capacidade de RAM foi confirmada pela infraestrutura.');
  const max = c.ram.at(-1)?.gb;
  return section('cat-ram', 'Memória RAM', body + facts([
    ['Selecionada', sel.ram ? formatGb(sel.ram) : '—'],
    ['Disponível agora', max ? formatGb(max) : '—'],
    ['Limite da infraestrutura', c.limits?.maxRamGb ? formatGb(c.limits.maxRamGb) : 'Não informado'],
    ['Uso atual', 'Medido somente com a máquina em execução'],
  ]), 'A alteração só vale para a máquina real quando o backend e o hipervisor suportarem a operação.');
}

function cpuSection(c, sel) {
  const body = c.cpu.length
    ? `<div class="options">${c.cpu.map((p) => chip({ pick: 'cpu', value: p.vcpus, label: `${p.vcpus} vCPUs`, active: sel.cpu === p.vcpus })).join('')}</div>`
    : empty('Nenhuma configuração de vCPU foi confirmada pela infraestrutura.');
  return section('cat-cpu', 'Processador (vCPU)', body + facts([
    ['Selecionadas', sel.cpu ? `${sel.cpu} vCPUs` : '—'],
    ['Limite da infraestrutura', c.limits?.maxVcpus ? `${c.limits.maxVcpus} vCPUs` : 'Não informado'],
    ['Uso atual', 'Medido somente com a máquina em execução'],
  ]));
}

function gpuSection(c, sel) {
  const cards = c.gpu.map((g) => `
    <article class="gpu${g.available ? '' : ' is-off'}">
      <div class="row">
        <strong>${esc(g.name)}</strong>
        <span class="badge ${g.available ? 'ok' : 'err'}">${g.available ? 'Disponível' : 'Indisponível'}</span>
      </div>
      <p class="meta">Memória de vídeo: ${g.vramGb ? esc(`${g.vramGb} GB`) : 'não informada'} · Atribuição: ${esc(g.assignment)}</p>
      ${g.features.length ? `<p class="meta">Recursos: ${esc(g.features.join(', '))}</p>` : ''}
      ${g.notes ? `<p class="meta">${esc(g.notes)}</p>` : ''}
      ${chip({
        pick: 'gpu',
        value: g.id,
        label: sel.gpu === g.id ? 'Selecionada' : 'Selecionar',
        active: sel.gpu === g.id,
        disabled: !g.available,
      })}
    </article>`).join('');
  const list = c.gpu.length
    ? `<div class="gpu-list">${cards}</div>`
    : empty('GPU indisponível nesta infraestrutura.');
  const none = `<div class="options">${chip({ pick: 'gpu', value: '', label: 'Sem GPU dedicada', active: !sel.gpu })}</div>`;
  return section(
    'cat-gpu',
    'Placa de vídeo (GPU)',
    list + none,
    'Somente GPUs confirmadas pelo provedor podem ser selecionadas. Modelos de referência não garantem disponibilidade.',
  );
}

function storageSection(c, sel) {
  const body = c.storage.length
    ? `<div class="options">${c.storage.map((s) => chip({ pick: 'storage', value: s.gb, label: formatGb(s.gb), active: sel.storage === s.gb })).join('')}</div>`
    : empty('Nenhuma capacidade de armazenamento foi confirmada pela infraestrutura.');
  const rows = [
    ['Selecionada', sel.storage ? formatGb(sel.storage) : '—'],
    ['Limite da infraestrutura', c.limits?.maxStorageGb ? formatGb(c.limits.maxStorageGb) : 'Não informado'],
  ];
  if (c.disk) {
    rows.push(['Volume atual', c.disk.volumeId], ['Estado do volume', c.disk.state]);
  }
  return section(
    'cat-storage',
    'Armazenamento do PC virtual',
    body + facts(rows),
    'Disco persistente do backend, separado do armazenamento interno do celular. Encerrar a sessão não o apaga.',
  );
}

function resolutionSection(c, sel) {
  const body = c.resolutions.length
    ? `<div class="options">${c.resolutions.map((r) => chip({ pick: 'resolution', value: r, label: r.replace('x', '×'), active: sel.resolution === r })).join('')}</div>`
    : empty('A infraestrutura não informou resoluções disponíveis. A sessão usará o padrão do servidor.');
  return section('cat-res', 'Resolução da tela', body, 'Opcional.');
}

function profileSection(sel) {
  const current = PROFILES.find((p) => p.id === sel.profile);
  const body = `<div class="profiles">${PROFILES.map((p) => chip({
    pick: 'profile',
    value: p.id,
    label: p.label,
    active: sel.profile === p.id,
    sub: p.needsGpu ? 'Exige GPU' : '',
  })).join('')}</div>${current ? hintP(current.hint) : ''}`;
  return section('cat-profile', 'Perfil de desempenho', body, 'O perfil escolhe combinações válidas; o desempenho efetivo depende do servidor.');
}

/** Central de configuração completa (botão "+"). */
export function renderHardwareCenter({ catalog, selection, validation }) {
  return [
    banner(catalog),
    issues(validation),
    osSection(catalog, selection),
    ramSection(catalog, selection),
    cpuSection(catalog, selection),
    gpuSection(catalog, selection),
    storageSection(catalog, selection),
    resolutionSection(catalog, selection),
    profileSection(selection),
  ].join('');
}

/** Resumo exibido antes de iniciar. A confirmação só é liberada na Etapa 2. */
export function renderStartSummary({ catalog, summary, validation }) {
  const rows = summary
    .map((r) => `<div><dt>${esc(r.label)}</dt><dd class="${r.state === 'bad' ? 'bad' : r.state === 'empty' ? 'empty-state' : ''}">${esc(r.value)}</dd></div>`)
    .join('');
  const steps = START_STEPS
    .map((s, i) => `<li><span class="step-n">${i + 1}</span>${esc(s)}</li>`)
    .join('');
  return banner(catalog)
    + issues(validation)
    + `<dl class="facts dl-kv">${rows}</dl>`
    + '<h3 class="sub">Etapas da inicialização</h3>'
    + `<ol class="steps">${steps}</ol>`;
}

/** Painel "Meu armazenamento". */
export function renderStorageInfo(c) {
  const rules = '<h3 class="sub">Regras de persistência</h3><ul class="rules">'
    + '<li>Os arquivos devem continuar disponíveis depois que a sessão for encerrada.</li>'
    + '<li>Reiniciar o PC virtual não deve apagar arquivos.</li>'
    + '<li>Encerrar uma sessão não exclui o disco.</li>'
    + '<li>Excluir um disco com dados exige confirmação.</li>'
    + '</ul>';
  const transfer = '<div class="options">'
    + '<button type="button" class="btn-ghost" disabled>Enviar do celular</button>'
    + '<button type="button" class="btn-ghost" disabled>Baixar para o celular</button>'
    + '</div>'
    + hintP('Transferências e expansão ficam disponíveis após a conexão com o backend.');

  if (c.status !== 'ok') {
    return banner(c) + empty('Não é possível consultar o volume sem uma infraestrutura conectada.') + rules;
  }
  if (!c.disk) {
    return empty('Nenhum volume persistente foi provisionado ainda. Ao iniciar a máquina, o backend criará ou associará um disco dedicado.') + rules;
  }
  const pct = Math.round((c.disk.usedGb / c.disk.totalGb) * 100);
  return banner(c)
    + `<progress class="meter" max="100" value="${pct}" aria-label="Espaço usado">${pct}%</progress>`
    + facts([
      ['Identificação do disco', c.disk.volumeId],
      ['Estado do volume', c.disk.state],
      ['Capacidade total', formatGb(c.disk.totalGb)],
      ['Espaço utilizado', formatGb(c.disk.usedGb)],
      ['Espaço livre', formatGb(c.disk.freeGb)],
      ['Arquivos armazenados', c.disk.files === null ? 'Não informado' : String(c.disk.files)],
      ['Persistência', c.disk.persistent ? 'Dados mantidos entre sessões' : 'Não confirmada'],
      ['Expansão', c.disk.expandable ? 'Suportada pelo provedor' : 'Não suportada'],
    ])
    + transfer
    + rules;
}

const ADVANCED = [
  ['Versão do sistema operacional', 'Define a build instalada. Alterá-la pode exigir reinicialização ou uma nova máquina.', ['Exige reinicialização']],
  ['Resolução e taxa de quadros', 'Resolução da tela e limite de FPS enviado pela transmissão, quando o servidor suportar.', ['Depende da infraestrutura']],
  ['Qualidade da imagem remota', 'Equilíbrio entre nitidez e uso de banda. Pode ser ajustado automaticamente.', []],
  ['Configurações de rede', 'Rede da máquina virtual e rota da sessão remota.', ['Exige reinicialização']],
  ['Modo de tela cheia', 'Ocupa a tela inteira com a sessão remota.', []],
  ['Inicialização automática da sessão', 'Abre a sessão automaticamente quando desejado.', []],
  ['Suspensão e retomada', 'Pausa a máquina e a retoma depois. Só aparece se o provedor suportar.', ['Depende da infraestrutura']],
  ['Política de encerramento', 'Define se a máquina continua ligada, suspende ou desliga ao encerrar a sessão. Encerrar a sessão nunca apaga os dados do disco.', []],
  ['Snapshots', 'Pontos de restauração do disco. Depende do provedor.', ['Depende da infraestrutura']],
  ['Backup e restauração', 'Cópias do volume persistente. A exclusão definitiva exige confirmação.', []],
  ['Teclado e idioma', 'Layout de teclado e idioma aplicados à sessão remota.', []],
  ['Dispositivos de entrada', 'Mouse, teclado e toque usados na sessão.', []],
  ['Compartilhamento de arquivos', 'Transferência explícita entre o celular e o PC virtual, com indicação de progresso.', []],
  ['Segurança', 'Sessões autenticadas, comunicação criptografada e isolamento entre usuários.', []],
  ['Consumo e custos', 'Tempo de uso e cobrança do provedor, quando houver.', ['Depende da infraestrutura']],
];

/** Painel "Configurações avançadas". */
export function renderAdvancedInfo(c) {
  const items = ADVANCED.map(([title, text, tags]) => `
    <li>
      <strong>${esc(title)}</strong>
      <p>${esc(text)}</p>
      ${tags.length ? `<div class="tags">${tags.map((t) => `<span class="badge warn">${esc(t)}</span>`).join('')}</div>` : ''}
    </li>`).join('');
  const note = c.status === 'ok'
    ? 'Os ajustes são aplicados ao iniciar a máquina.'
    : 'Estas opções só podem ser alteradas com a infraestrutura conectada.';
  return banner(c) + hintP(note) + `<ul class="adv-list">${items}</ul>`;
}

/** Painel "Gerenciar computadores virtuais". */
export function renderManageInfo(c) {
  const createBtn = '<button type="button" class="btn-primary" disabled>Criar nova máquina</button>'
    + hintP('Criação e duplicação de máquinas ficam disponíveis após a conexão com o backend.');
  if (c.status !== 'ok') {
    return banner(c) + empty('Nenhuma máquina virtual pode ser listada sem infraestrutura conectada.') + createBtn;
  }
  if (!c.machines.length) {
    return empty('Nenhuma máquina virtual cadastrada nesta conta.') + createBtn;
  }
  const list = c.machines.map((m) => `
    <li>
      <div class="row"><strong>${esc(m.name)}</strong><span class="badge">${esc(m.state)}</span></div>
      <p class="meta">${esc(m.os)} · ${esc(m.id)}</p>
    </li>`).join('');
  return `<ul class="machines">${list}</ul>` + createBtn;
}
