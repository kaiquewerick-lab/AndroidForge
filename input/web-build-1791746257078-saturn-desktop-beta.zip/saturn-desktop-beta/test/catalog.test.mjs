import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fetchCatalog, normalizeCatalog, unavailableCatalog } from '../public/js/catalog.js';

const okResponse = (body, status = 200) => ({
  ok: status >= 200 && status < 300,
  status,
  json: async () => body,
});

test('catálogo nulo ou inválido vira indisponível', () => {
  assert.equal(normalizeCatalog(null).status, 'unavailable');
  assert.equal(normalizeCatalog([]).status, 'unavailable');
  assert.equal(normalizeCatalog('texto').status, 'unavailable');
});

test('descarta entradas malformadas e ordena RAM e vCPU', () => {
  const c = normalizeCatalog({
    ram: [{ gb: 16 }, { gb: -4 }, { gb: 'oito' }, { gb: 4 }, null],
    cpu: [{ vcpus: 8 }, { vcpus: 2.5 }, { vcpus: 0 }, { vcpus: 4 }],
  });
  assert.deepEqual(c.ram.map((r) => r.gb), [4, 16]);
  assert.deepEqual(c.cpu.map((p) => p.vcpus), [4, 8]);
});

test('itens marcados como indisponíveis não entram em RAM, vCPU e armazenamento', () => {
  const c = normalizeCatalog({
    ram: [{ gb: 8, available: false }, { gb: 16 }],
    storage: [{ gb: 100, available: false }],
  });
  assert.deepEqual(c.ram.map((r) => r.gb), [16]);
  assert.equal(c.storage.length, 0);
});

test('GPU indisponível continua listada, com disponibilidade falsa', () => {
  const c = normalizeCatalog({
    gpu: [{ id: 'g1', name: 'GPU X', available: false }],
  });
  assert.equal(c.gpu.length, 1);
  assert.equal(c.gpu[0].available, false);
});

test('resoluções inválidas são filtradas', () => {
  const c = normalizeCatalog({ resolutions: ['1920x1080', 'abc', '99999x1', '2560x1440'] });
  assert.deepEqual(c.resolutions, ['1920x1080', '2560x1440']);
});

test('disco sem capacidade válida vira null; uso é limitado ao total', () => {
  assert.equal(normalizeCatalog({ disk: { totalGb: 0 } }).disk, null);
  const c = normalizeCatalog({ disk: { totalGb: 50, usedGb: 80 } });
  assert.equal(c.disk.usedGb, 50);
  assert.equal(c.disk.freeGb, 0);
});

test('fetchCatalog: falha de rede vira indisponível, sem lançar exceção', async () => {
  const c = await fetchCatalog({ fetchImpl: async () => { throw new TypeError('offline'); } });
  assert.equal(c.status, 'unavailable');
  assert.match(c.reason, /Não foi possível contatar/);
});

test('fetchCatalog: resposta 503 usa a mensagem do backend', async () => {
  const c = await fetchCatalog({
    fetchImpl: async () => okResponse({ message: 'Sem infraestrutura.' }, 503),
  });
  assert.equal(c.status, 'unavailable');
  assert.equal(c.reason, 'Sem infraestrutura.');
});

test('fetchCatalog: resposta 200 é normalizada', async () => {
  const c = await fetchCatalog({
    fetchImpl: async () => okResponse({ os: [{ id: 'linux', name: 'Linux' }], ram: [{ gb: 8 }] }),
  });
  assert.equal(c.status, 'ok');
  assert.equal(c.os[0].id, 'linux');
  assert.equal(c.ram[0].gb, 8);
});

test('fetchCatalog: tempo esgotado é reportado', async () => {
  const c = await fetchCatalog({
    timeoutMs: 20,
    fetchImpl: (_url, { signal }) => new Promise((_, reject) => {
      signal.addEventListener('abort', () => {
        const err = new Error('aborted');
        err.name = 'AbortError';
        reject(err);
      });
    }),
  });
  assert.equal(c.status, 'unavailable');
  assert.match(c.reason, /não respondeu a tempo/);
});

test('unavailableCatalog tem listas vazias (nenhuma capacidade inventada)', () => {
  const c = unavailableCatalog('x');
  for (const key of ['os', 'ram', 'cpu', 'gpu', 'storage', 'resolutions', 'machines']) {
    assert.deepEqual(c[key], [], key);
  }
  assert.equal(c.disk, null);
});
