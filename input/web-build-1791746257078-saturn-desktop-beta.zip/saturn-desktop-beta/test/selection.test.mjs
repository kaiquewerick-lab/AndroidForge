import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { PROFILES, sanitizeSelection, summarize, validateSelection } from '../public/js/selection.js';
import { normalizeCatalog, unavailableCatalog } from '../public/js/catalog.js';
import { formatGb, esc } from '../public/js/util.js';

const demo = normalizeCatalog(JSON.parse(
  await readFile(new URL('../data/catalog.demo.json', import.meta.url), 'utf8'),
));

const complete = {
  os: 'ubuntu-24.04',
  ram: 8,
  cpu: 4,
  gpu: null,
  storage: 50,
  resolution: null,
  profile: 'equilibrado',
};

test('sem infraestrutura, nada fica pronto', () => {
  const v = validateSelection(complete, unavailableCatalog('x'));
  assert.equal(v.ready, false);
  assert.equal(v.errors.length, 1);
});

test('seleção vazia lista todos os recursos obrigatórios', () => {
  const v = validateSelection(sanitizeSelection(null), demo);
  assert.equal(v.ready, false);
  assert.equal(v.errors.length, 4);
});

test('seleção completa com catálogo demo fica pronta', () => {
  const v = validateSelection(complete, demo);
  assert.equal(v.ready, true, v.errors.join(' | '));
});

test('RAM fora do catálogo é rejeitada', () => {
  const v = validateSelection({ ...complete, ram: 64 }, demo);
  assert.equal(v.ready, false);
  assert.match(v.errors.join(' '), /64 GB de RAM/);
});

test('sistema operacional marcado como indisponível é rejeitado', () => {
  const v = validateSelection({ ...complete, os: 'windows-11' }, demo);
  assert.equal(v.ready, false);
});

test('GPU indisponível é rejeitada; GPU disponível é aceita', () => {
  assert.equal(validateSelection({ ...complete, gpu: 'demo-gpu-b' }, demo).ready, false);
  assert.equal(validateSelection({ ...complete, gpu: 'demo-gpu-a' }, demo).ready, true);
});

test('perfil de jogos exige GPU', () => {
  const v = validateSelection({ ...complete, profile: 'jogos' }, demo);
  assert.equal(v.ready, false);
  assert.match(v.errors.join(' '), /exige uma GPU/);
  assert.equal(validateSelection({ ...complete, profile: 'jogos', gpu: 'demo-gpu-a' }, demo).ready, true);
});

test('capacidade diferente do volume existente gera aviso, não erro', () => {
  const v = validateSelection({ ...complete, storage: 100 }, demo);
  assert.equal(v.ready, true);
  assert.equal(v.warnings.length, 1);
});

test('sanitizeSelection descarta valores inválidos', () => {
  const s = sanitizeSelection({ ram: -1, cpu: 'x', storage: 0, profile: 'inexistente', resolution: 'abc', os: 42 });
  assert.equal(s.ram, null);
  assert.equal(s.cpu, null);
  assert.equal(s.storage, null);
  assert.equal(s.resolution, null);
  assert.equal(s.os, null);
  assert.equal(s.profile, 'equilibrado');
});

test('summarize marca escolha inexistente como "bad" e vazia como "empty"', () => {
  const rows = summarize({ ...complete, ram: 64, gpu: null }, demo);
  assert.equal(rows.find((r) => r.key === 'ram').state, 'bad');
  assert.equal(rows.find((r) => r.key === 'gpu').state, 'empty');
  assert.equal(rows.find((r) => r.key === 'infra').value, 'Demonstração (nenhuma máquina real)');
});

test('todo perfil tem id único e rótulo', () => {
  const ids = PROFILES.map((p) => p.id);
  assert.equal(new Set(ids).size, ids.length);
  assert.ok(PROFILES.every((p) => p.label));
});

test('formatGb formata GB e TB sem inventar valores', () => {
  assert.equal(formatGb(50), '50 GB');
  assert.equal(formatGb(1024), '1 TB');
  assert.equal(formatGb(1536), '1.5 TB');
  assert.equal(formatGb(0), '0 GB');
  assert.equal(formatGb(undefined), '—');
});

test('esc neutraliza HTML vindo do backend', () => {
  assert.equal(esc('<img src=x onerror=alert(1)>'), '&lt;img src=x onerror=alert(1)&gt;');
});
