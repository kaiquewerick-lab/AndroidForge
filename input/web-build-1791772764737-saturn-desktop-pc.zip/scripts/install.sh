#!/usr/bin/env bash
# Instala XFCE4, TigerVNC, noVNC e websockify no Ubuntu 24.04.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib.sh
. "$ROOT/scripts/lib.sh"

[ -r /etc/os-release ] || die "Não foi possível identificar o sistema operacional."
# shellcheck disable=SC1091
. /etc/os-release
[ "${VERSION_ID:-}" = "24.04" ] || die "Este projeto foi preparado para Ubuntu 24.04. Sistema encontrado: ${PRETTY_NAME:-desconhecido}."

sudo -n true 2>/dev/null || die "É necessário sudo sem senha para instalar os pacotes do desktop."

log "Atualizando a lista de pacotes..."
sudo apt-get update

log "Instalando XFCE4, TigerVNC, noVNC e websockify (pacotes do Ubuntu, sem serviços pagos)..."
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
  xfce4 xfce4-terminal dbus-x11 \
  tigervnc-standalone-server tigervnc-common \
  novnc websockify fonts-dejavu-core

command -v node >/dev/null 2>&1 && node -e 'process.exit(Number(process.versions.node.split(".")[0]) >= 22 ? 0 : 1)' \
  || die "Node.js 22 ou superior é necessário. No devcontainer, ele vem da feature 'node'."

mkdir -p "$HOME/.vnc"
chmod 700 "$HOME/.vnc"
if [ ! -e "$HOME/.vnc/xstartup" ]; then
  cp "$ROOT/config/xstartup" "$HOME/.vnc/xstartup"
  chmod +x "$HOME/.vnc/xstartup"
fi

log "Instalação concluída. Defina SATURN_PC_PASSWORD e rode: npm start"
