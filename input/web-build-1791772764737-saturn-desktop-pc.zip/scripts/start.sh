#!/usr/bin/env bash
# Inicia o VNC, o websockify e o gateway com login próprio.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib.sh
. "$ROOT/scripts/lib.sh"
load_env

[ -n "${SATURN_PC_PASSWORD:-}" ] || die "Defina SATURN_PC_PASSWORD (Codespaces: Settings > Codespaces > Secrets, ou .env local). Mínimo de 12 caracteres."
[ "${#SATURN_PC_PASSWORD}" -ge 12 ] || die "SATURN_PC_PASSWORD precisa ter pelo menos 12 caracteres."

require_cmd vncserver
require_cmd websockify
require_cmd node
require_cmd curl

[ -d "$NOVNC_DIR" ] || die "noVNC não encontrado em $NOVNC_DIR. Rode scripts/install.sh."

mkdir -p "$HOME/.vnc" "$RUN_DIR" "$LOG_DIR"
chmod 700 "$HOME/.vnc"

# Senha do VNC: 8 caracteres aleatórios (limite do VNC Auth). Gerada uma vez e guardada com permissão 600.
if [ ! -s "$HOME/.vnc/passwd" ]; then
  VNC_PW="$(head -c 256 /dev/urandom | tr -dc 'A-Za-z0-9' | cut -c1-8)"
  [ "${#VNC_PW}" -eq 8 ] || die "Falha ao gerar a senha do VNC."
  printf '%s\n' "$VNC_PW" | vncpasswd -f > "$HOME/.vnc/passwd"
  chmod 600 "$HOME/.vnc/passwd"
  unset VNC_PW
fi

if [ ! -e "$HOME/.vnc/xstartup" ]; then
  cp "$ROOT/config/xstartup" "$HOME/.vnc/xstartup"
  chmod +x "$HOME/.vnc/xstartup"
fi

if vncserver -list 2>/dev/null | grep -q "^:${VNC_DISPLAY}[[:space:]]"; then
  log "VNC já está ativo no display :${VNC_DISPLAY}."
else
  log "Iniciando VNC no display :${VNC_DISPLAY} (${RESOLUTION})..."
  vncserver ":${VNC_DISPLAY}" -geometry "$RESOLUTION" -depth 24 -localhost yes \
    -SecurityTypes VncAuth -rfbauth "$HOME/.vnc/passwd" >>"$LOG_DIR/vnc.log" 2>&1 \
    || die "Falha ao iniciar o VNC. Veja $LOG_DIR/vnc.log"
fi

VNC_PORT=$((5900 + VNC_DISPLAY))
if is_running "$RUN_DIR/websockify.pid"; then
  log "websockify já está ativo."
else
  log "Iniciando websockify (127.0.0.1:${WS_UPSTREAM_PORT} -> 127.0.0.1:${VNC_PORT})..."
  nohup websockify "127.0.0.1:${WS_UPSTREAM_PORT}" "127.0.0.1:${VNC_PORT}" >>"$LOG_DIR/websockify.log" 2>&1 &
  echo $! > "$RUN_DIR/websockify.pid"
fi

if is_running "$RUN_DIR/gateway.pid"; then
  log "Gateway já está ativo."
else
  log "Iniciando gateway na porta ${PORT}..."
  SATURN_PC_PASSWORD="$SATURN_PC_PASSWORD" nohup node "$ROOT/server/index.mjs" >>"$LOG_DIR/gateway.log" 2>&1 &
  echo $! > "$RUN_DIR/gateway.pid"
fi

for _ in $(seq 1 30); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/status" >/dev/null 2>&1; then
    log "Pronto. Abra a porta ${PORT} na aba Ports do Codespace e entre com a senha de acesso."
    exit 0
  fi
  sleep 0.5
done
die "O gateway não respondeu. Veja $LOG_DIR/gateway.log"
