#!/usr/bin/env bash
# Encerra o gateway, o websockify e o VNC. Os arquivos do usuário não são apagados.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib.sh
. "$ROOT/scripts/lib.sh"
load_env

for name in gateway websockify; do
  pidfile="$RUN_DIR/$name.pid"
  if is_running "$pidfile"; then
    kill "$(cat "$pidfile")" && log "$name encerrado."
  fi
  rm -f "$pidfile"
done

if command -v vncserver >/dev/null 2>&1; then
  vncserver -kill ":${VNC_DISPLAY}" >/dev/null 2>&1 && log "VNC encerrado." || log "VNC não estava ativo."
fi
