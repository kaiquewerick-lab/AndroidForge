#!/usr/bin/env bash
# Mostra o estado de cada componente. Sai com código 0 somente se tudo estiver ativo.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=lib.sh
. "$ROOT/scripts/lib.sh"
load_env

ok=0
check() { if "$@"; then log "[ativo]    $LABEL"; else log "[parado]   $LABEL"; ok=1; fi; }

LABEL="gateway (porta ${PORT})"; check is_running "$RUN_DIR/gateway.pid"
LABEL="websockify";              check is_running "$RUN_DIR/websockify.pid"
if command -v vncserver >/dev/null 2>&1 && vncserver -list 2>/dev/null | grep -q "^:${VNC_DISPLAY}[[:space:]]"; then
  log "[ativo]    VNC :${VNC_DISPLAY}"
else
  log "[parado]   VNC :${VNC_DISPLAY}"; ok=1
fi
exit "$ok"
