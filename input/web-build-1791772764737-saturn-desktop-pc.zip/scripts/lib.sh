#!/usr/bin/env bash
# Funções comuns aos scripts. Não contém segredos.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log()  { printf '%s\n' "$*"; }
die()  { printf 'ERRO: %s\n' "$*" >&2; exit 1; }

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "Comando '$1' não encontrado. Rode scripts/install.sh."
}

load_env() {
  if [ -f "$ROOT/.env" ]; then
    set -a
    # shellcheck disable=SC1091
    . "$ROOT/.env"
    set +a
  fi
  : "${HOST:=0.0.0.0}"
  : "${PORT:=6080}"
  : "${VNC_DISPLAY:=1}"
  : "${RESOLUTION:=1280x720}"
  : "${WS_UPSTREAM_PORT:=6081}"
  : "${NOVNC_DIR:=/usr/share/novnc}"
  : "${SESSION_IDLE_MINUTES:=30}"
  : "${SECURE_COOKIE:=1}"
  RUN_DIR="$ROOT/.run"
  LOG_DIR="$ROOT/logs"
  export HOST PORT VNC_DISPLAY RESOLUTION WS_UPSTREAM_PORT NOVNC_DIR SESSION_IDLE_MINUTES SECURE_COOKIE
}

# Verdadeiro se o processo do arquivo PID ainda existe.
is_running() {
  [ -f "$1" ] && kill -0 "$(cat "$1")" 2>/dev/null
}
