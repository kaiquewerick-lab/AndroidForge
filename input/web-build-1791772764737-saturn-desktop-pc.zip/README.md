# SaturnDesktop-PC

Desktop Linux remoto (Ubuntu 24.04, XFCE4) acessado pelo navegador do Android, dentro de um GitHub Codespace.
Pilha: **TigerVNC** (servidor gráfico virtual) + **noVNC** (cliente no navegador) + **websockify** (ponte WebSocket) + **gateway próprio** com login.

> Status: infraestrutura escrita e testada no que é possível fora do Codespace (gateway e scripts). Instalação dos pacotes, VNC e acesso real pelo Android **ainda precisam ser testados no Codespace**. Veja `docs/TESTES.md`.

## Arquitetura

```
Android (navegador)
   │  HTTPS (porta 6080 encaminhada pelo Codespace, visibilidade pública)
   ▼
gateway (server/index.mjs, Node 22, sem dependências)
   │  login com senha própria · cookie HttpOnly · limite de tentativas · noVNC só com sessão válida
   │  WebSocket autenticado
   ▼
websockify 127.0.0.1:6081  ──►  TigerVNC :1 (127.0.0.1:5901, senha VNC)  ──►  XFCE4
```

- O gateway é o único ponto exposto. O VNC e o websockify escutam só em `127.0.0.1`.
- O APK não precisa de login do GitHub: o acesso é protegido pela senha do próprio gateway.

## Arquivos

| Caminho | Função |
|---|---|
| `.devcontainer/devcontainer.json` | Ubuntu 24.04, Node 22, porta 6080 pública, instala ao criar o Codespace |
| `scripts/install.sh` | Instala XFCE4, TigerVNC, noVNC e websockify pelo apt |
| `scripts/start.sh` | Inicia VNC, websockify e gateway, e confirma que o gateway responde |
| `scripts/stop.sh` | Encerra gateway, websockify e VNC. Não apaga arquivos do usuário |
| `scripts/restart.sh` / `status.sh` | Reinicia / mostra o estado de cada componente |
| `scripts/lib.sh` | Funções comuns (leitura do `.env`, PIDs, mensagens) |
| `config/xstartup` | Sessão XFCE iniciada pelo VNC |
| `server/index.mjs` | Gateway: login, sessão, noVNC e proxy WebSocket |
| `test/*.test.mjs` | 16 testes (gateway e scripts) |
| `.env.example` | Variáveis disponíveis, sem valores secretos |
| `docs/TESTES.md` | Checklist de testes no Codespace |

## Permissões e requisitos

- **Sistema:** Ubuntu 24.04 (`install.sh` recusa outra versão).
- **sudo sem senha:** necessário só para `apt-get install`. No devcontainer `vscode`, a imagem `base:ubuntu-24.04` costuma incluir sudo sem senha. **Confirme com `sudo -n true`** antes de instalar.
- **Não precisa de systemd, Docker ou root permanente.** Os processos rodam como o usuário comum.
- **Memória:** o XFCE4 ocupa cerca de 300 a 600 MB em uso normal. A máquina de 4 núcleos e 8 GB do devcontainer atende.
- **Pacotes:** `xfce4`, `xfce4-terminal`, `dbus-x11`, `tigervnc-standalone-server`, `tigervnc-common`, `novnc`, `websockify`, `fonts-dejavu-core`. Todos são pacotes do repositório oficial do Ubuntu.
  - *Não consegui instalar nem verificar esses pacotes no ambiente de desenvolvimento, porque ele não acessa os servidores do Ubuntu. A verificação real é o primeiro item de `docs/TESTES.md`.*

## Custos e limites (sem cobrança)

- **Nenhum serviço pago** é usado. Não é preciso ativar faturamento nem cartão.
- **Cota gratuita do Codespaces:** 120 horas de computação e 15 GB-mês de armazenamento por mês, segundo a documentação do GitHub. A cobrança é por núcleo-hora: na máquina de **4 núcleos** (multiplicador 4), a cota equivale a **cerca de 30 horas por mês**, não 120. Confirme o consumo em Settings → Billing.
- **O Codespace para por inatividade.** Ele não fica disponível 24 horas. O tempo ocioso padrão e o prazo de retenção de Codespaces parados não foram confirmados pela documentação; verifique em Settings → Codespaces.
- **Excluir o Codespace apaga os arquivos** que não estiverem no Git. Para não perder trabalho, envie os arquivos importantes ao repositório (`git push`) ou ao armazenamento de sua preferência.
- **Porta pública:** a porta 6080 é configurada como pública para que o Android acesse sem login do GitHub. Por isso a senha e o limite de tentativas são obrigatórios (veja Segurança).

## Como usar no Codespace

1. Crie o Codespace a partir da branch do projeto. O `postCreateCommand` roda `scripts/install.sh`.
2. Defina a senha de acesso: **Settings → Codespaces → Secrets** → nome `SATURN_PC_PASSWORD`, valor com 12 caracteres ou mais. Ou crie um `.env` local a partir de `.env.example` (o `.env` já está no `.gitignore`).
3. Reconstrua o Codespace (ou defina o secret antes de criá-lo) para que a variável chegue ao ambiente.
4. No terminal:
   ```bash
   npm start      # inicia tudo
   npm run status # confere os componentes
   npm stop       # encerra
   npm restart    # reinicia
   ```
5. Na aba **Ports**, abra a linha `6080` (Desktop noVNC). Copie o endereço e abra no navegador do Android. Entre com a senha de acesso.

## Segurança

- **Senha de acesso:** mínimo de 12 caracteres, guardada só como hash scrypt com sal aleatório. Nunca vai para o Git nem para os logs.
- **Senha do VNC:** gerada automaticamente no primeiro `start` (8 caracteres, limite do protocolo VNC) e guardada em `~/.vnc/passwd` com permissão 600. É uma segunda camada; o VNC só aceita conexões de `127.0.0.1`.
- **Sessão:** cookie `HttpOnly`, `SameSite=Strict`, `Secure` (com `SECURE_COOKIE=1`). Expira após 30 minutos sem uso (configurável) e no máximo após 8 horas.
- **Tentativas:** 5 senhas erradas bloqueiam o IP por 15 minutos.
- **Cabeçalhos:** CSP restrita, `frame-ancestors 'none'`, `X-Frame-Options: DENY`, `no-store` nas respostas de login e status.
- **Arquivos:** só a pasta do noVNC é servida; caminhos com `..`, byte nulo ou diretórios retornam 404/400.
- **Limitações conhecidas:**
  - Com porta pública, qualquer pessoa com a URL vê a tela de login. A proteção depende da força da senha.
  - O limite de tentativas usa o IP que chega ao gateway. Atrás do proxy do Codespace, todos os acessos podem compartilhar o mesmo IP, então um bloqueio afeta todos. Para uso de uma pessoa, isso é aceitável.
  - A senha do VNC tem 8 caracteres por limite do protocolo. Ela é uma segunda camada, não a principal.
  - Sessões abertas no desktop permanecem até o limite de 8 horas, mesmo que a conexão fique ociosa.
- **Não há tokens, chaves ou senhas no repositório.** `.env.example` contém só nomes de variáveis.

## Testes

```bash
npm test
```
Executa 16 testes com `node --test`: autenticação, cookies, bloqueio por tentativas, 404 para caminhos suspeitos, recusa de WebSocket sem sessão, encaminhamento de WebSocket com sessão (com upstream simulado) e sintaxe dos scripts de shell.

**O que os testes não cobrem:** instalação dos pacotes, VNC real, XFCE, noVNC na tela e o websockify de verdade. Esses itens estão no checklist de `docs/TESTES.md`, e só podem ser validados no Codespace.

## Solução de problemas

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| `SATURN_PC_PASSWORD` não definida | Secret não criado ou Codespace criado antes | Crie o secret e reconstrua o Codespace |
| `Comando 'vncserver' não encontrado` | `install.sh` não rodou | `bash scripts/install.sh` |
| Página em branco no Android | Porta ainda privada | Aba Ports → 6080 → Port visibility: Public |
| 429 no login | 5 tentativas erradas | Aguarde 15 minutos |
| Sessão cai rápido | Expiração por inatividade (30 min) | Entre de novo; ajuste `SESSION_IDLE_MINUTES` se necessário |
| Tela preta no desktop | XFCE não iniciou | Veja `logs/vnc.log` e `~/.vnc/*.log` |

## Enviar ao GitHub (branch nova, sem alterar a main)

```bash
git checkout -b feature/desktop-remoto
git add -A
git commit -m "Adiciona infraestrutura do desktop remoto (XFCE, TigerVNC, noVNC, gateway)

Co-Authored-By: Claude Haiku 5.5 <noreply@anthropic.com>
Claude-Session: https://claude.ai/code/session_014oC1RNuYNzSUBRSpkSc8Ur"
git push -u origin feature/desktop-remoto
```

Os scripts precisam de permissão de execução no Git. Se o `git` não reconhecer, rode:
```bash
git update-index --chmod=+x scripts/*.sh
```

## Próximos passos

1. Testar a instalação e o acesso no Codespace (`docs/TESTES.md`).
2. Avaliar o Cloudflare Tunnel (gratuito) como caminho sem porta pública no Codespace, sem contratar serviço pago.
3. Só depois, atualizar o APK para apontar a WebView para a URL do desktop.
