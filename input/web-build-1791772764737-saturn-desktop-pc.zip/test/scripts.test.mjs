import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const scripts = readdirSync(path.join(root, 'scripts')).filter((f) => f.endsWith('.sh')).map((f) => path.join(root, 'scripts', f));

test('todos os scripts de shell têm sintaxe válida', () => {
  for (const s of scripts) execFileSync('bash', ['-n', s]);
  assert.ok(scripts.length >= 6);
});

test('start.sh não imprime a senha', () => {
  const start = readFileSync(path.join(root, 'scripts', 'start.sh'), 'utf8');
  assert.doesNotMatch(start, /echo[^\n]*SATURN_PC_PASSWORD|printf[^\n]*SATURN_PC_PASSWORD/);
});

test('o devcontainer expõe a porta 6080 e não contém segredos', () => {
  const dc = readFileSync(path.join(root, '.devcontainer', 'devcontainer.json'), 'utf8');
  const json = JSON.parse(dc);
  assert.deepEqual(json.forwardPorts, [6080]);
  assert.equal(json.portsAttributes['6080'].visibility, 'public');
  assert.doesNotMatch(dc, /password|token|secret/i);
});
