import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import net from 'node:net';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createGateway } from '../server/index.mjs';

const PW = 'senha-de-teste-123';
let server, base, upstream, upPort, novnc, gw;
const sockets = new Set();

before(async () => {
  novnc = fs.mkdtempSync(path.join(os.tmpdir(), 'novnc-'));
  fs.writeFileSync(path.join(novnc, 'vnc.html'), '<!doctype html><title>vnc</title>');
  fs.mkdirSync(path.join(novnc, 'app'));
  fs.writeFileSync(path.join(novnc, 'app', 'ui.js'), 'export default 1;');

  // Upstream que devolve tudo o que recebe: simula o websockify.
  upstream = net.createServer((s) => {
    sockets.add(s);
    s.on('error', () => {});
    s.on('data', (d) => s.write(d));
  });
  await new Promise((r) => upstream.listen(0, '127.0.0.1', r));
  upPort = upstream.address().port;

  gw = createGateway({
    appPassword: PW,
    novncDir: novnc,
    wsUpstream: { host: '127.0.0.1', port: upPort },
    sessionIdleMs: 60_000,
    secureCookie: false,
    wsCheckMs: 50,
  });
  server = http.createServer((req, res) => gw.handle(req, res).catch(() => { if (!res.headersSent) res.writeHead(500); res.end(); }));
  server.on('upgrade', gw.onUpgrade);
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  for (const s of sockets) s.destroy();
  server.close();
  upstream.close();
  fs.rmSync(novnc, { recursive: true, force: true });
});

const login = (pw = PW) => fetch(`${base}/login`, {
  method: 'POST',
  headers: { 'content-type': 'application/x-www-form-urlencoded' },
  body: new URLSearchParams({ password: pw }).toString(),
  redirect: 'manual',
});
const cookieOf = (res) => /spd_session=([^;]+)/.exec(res.headers.get('set-cookie') || '')?.[1];
const withCookie = (token, extra = {}) => ({ redirect: 'manual', ...extra, headers: { cookie: `spd_session=${token}`, ...(extra.headers || {}) } });

// Lê dados do socket até aparecer o texto esperado (ou estourar o tempo).
function readUntil(sock, needle, ms = 2000) {
  return new Promise((resolve, reject) => {
    let buf = '';
    const t = setTimeout(() => reject(new Error(`tempo esgotado; recebido: ${JSON.stringify(buf)}`)), ms);
    const onData = (d) => {
      buf += d.toString('latin1');
      if (buf.includes(needle)) { clearTimeout(t); sock.off('data', onData); resolve(buf); }
    };
    sock.on('data', onData);
  });
}

const upgradeRequest = (cookie) => [
  'GET /websockify HTTP/1.1', 'Host: x', 'Upgrade: websocket', 'Connection: Upgrade',
  'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==', 'Sec-WebSocket-Version: 13',
  ...(cookie ? [`Cookie: spd_session=${cookie}`] : []), '', '',
].join('\r\n');

test('recusa senha curta na criação do gateway', () => {
  assert.throws(() => createGateway({ appPassword: 'curta' }), /pelo menos 12 caracteres/);
  assert.throws(() => createGateway({ appPassword: undefined }), /pelo menos 12 caracteres/);
});

test('/api/status é público e não revela detalhes', async () => {
  const res = await fetch(`${base}/api/status`);
  assert.equal(res.status, 200);
  assert.deepEqual(await res.json(), { service: 'saturndesktop-pc', status: 'up' });
});

test('sem sessão, páginas redirecionam para /login', async () => {
  const res = await fetch(`${base}/`, { redirect: 'manual' });
  assert.equal(res.status, 302);
  assert.equal(res.headers.get('location'), '/login');
  const vnc = await fetch(`${base}/vnc.html`, { redirect: 'manual' });
  assert.equal(vnc.status, 302);
});

test('senha errada: 401, sem cookie', async () => {
  const res = await login('senha-errada-123456');
  assert.equal(res.status, 401);
  assert.equal(cookieOf(res), undefined);
  assert.match(await res.text(), /Senha incorreta/);
});

test('senha certa: cookie HttpOnly e SameSite=Strict', async () => {
  const res = await login();
  assert.equal(res.status, 303);
  const sc = res.headers.get('set-cookie');
  assert.match(sc, /HttpOnly/);
  assert.match(sc, /SameSite=Strict/);
  assert.match(sc, /Path=\//);
  assert.ok(cookieOf(res));
});

test('com sessão: noVNC é entregue com CSP restrita', async () => {
  const token = cookieOf(await login());
  const root = await fetch(`${base}/`, withCookie(token));
  assert.equal(root.status, 302);
  assert.match(root.headers.get('location'), /vnc\.html\?autoconnect=true/);

  const page = await fetch(`${base}/vnc.html`, withCookie(token));
  assert.equal(page.status, 200);
  assert.match(page.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  assert.equal(page.headers.get('x-frame-options'), 'DENY');

  const js = await fetch(`${base}/app/ui.js`, withCookie(token));
  assert.equal(js.status, 200);
  assert.match(js.headers.get('content-type'), /javascript/);
});

test('caminhos fora da pasta do noVNC e diretórios não são servidos', async () => {
  const token = cookieOf(await login());
  for (const p of ['/%2e%2e/%2e%2e/etc/passwd', '/..%2f..%2fetc%2fpasswd', '/app', '/%00', '/nao-existe.html']) {
    const res = await fetch(`${base}${p}`, withCookie(token));
    // Nunca 200. Byte nulo é recusado com 400; o resto, com 404.
    const want = p === "/%00" ? 400 : 404;
    assert.equal(res.status, want, `esperado ${want} para ${p}`);
  }
});

test('WebSocket sem sessão é recusado', async () => {
  const sock = net.connect(server.address().port, '127.0.0.1');
  sock.write(upgradeRequest(null));
  const reply = await readUntil(sock, '\r\n\r\n');
  assert.match(reply, /^HTTP\/1\.1 401/);
  sock.destroy();
});

test('WebSocket com sessão é encaminhado ao websockify nos dois sentidos', async () => {
  const token = cookieOf(await login());
  const sock = net.connect(server.address().port, '127.0.0.1');
  sock.write(upgradeRequest(token));
  // O upstream devolve o que recebe: primeiro ecoa a requisição de upgrade...
  const echoed = await readUntil(sock, 'Sec-WebSocket-Version: 13');
  assert.match(echoed, /GET \/websockify HTTP\/1\.1/);
  // ...e depois os bytes seguintes também passam.
  sock.write('PING-RFB');
  await readUntil(sock, 'PING-RFB');
  sock.destroy();
});

test('WebSocket com sessão fora de /websockify é recusado', async () => {
  const token = cookieOf(await login());
  const sock = net.connect(server.address().port, '127.0.0.1');
  sock.write(upgradeRequest(token).replace('/websockify', '/outro'));
  const reply = await readUntil(sock, '\r\n\r\n');
  assert.match(reply, /^HTTP\/1\.1 404/);
  sock.destroy();
});

test('logout invalida a sessão', async () => {
  const token = cookieOf(await login());
  const out = await fetch(`${base}/logout`, withCookie(token, { method: 'POST' }));
  assert.equal(out.status, 303);
  assert.match(out.headers.get('set-cookie'), /Max-Age=0/);
  const after = await fetch(`${base}/vnc.html`, withCookie(token));
  assert.equal(after.status, 302);
});

test('método não permitido é recusado', async () => {
  const res = await fetch(`${base}/api/status`, { method: 'POST' });
  assert.equal(res.status, 405);
  assert.equal(res.headers.get('allow'), 'GET, HEAD');
});

// Deve ser o último: bloqueia o IP de teste por 15 minutos.
test('após 5 falhas, o login fica bloqueado com 429', async () => {
  for (let i = 0; i < 5; i += 1) {
    const res = await login('errada-errada-123');
    assert.equal(res.status, 401);
  }
  const res = await login(PW);
  assert.equal(res.status, 429);
});
