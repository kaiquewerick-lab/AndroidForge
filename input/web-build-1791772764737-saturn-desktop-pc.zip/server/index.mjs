// SaturnDesktop-PC — gateway de acesso ao desktop.
// Faz login com senha própria, mantém a sessão em cookie HttpOnly, limita tentativas,
// entrega o noVNC somente com sessão válida e encaminha o WebSocket ao websockify.
// Sem dependências externas.
import http from 'node:http';
import net from 'node:net';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

export const MIN_PASSWORD = 12;
const COOKIE = 'spd_session';
const TOKEN_RE = /^[A-Za-z0-9_-]{43}$/;
const SESSION_MAX_MS = 8 * 60 * 60 * 1000;
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;
const FORM_LIMIT = 4096;

const SEC_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.gif': 'image/gif',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
};

const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const loginPage = (message = '') => `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Entrar — SaturnDesktop-PC</title></head>
<body style="font-family:system-ui,sans-serif;max-width:360px;margin:12vh auto;padding:0 16px;color:#000;background:#fff">
<h1 style="font:700 26px Georgia,serif;margin:0 0 20px">SaturnDesktop-PC</h1>
<form method="post" action="/login">
<label for="pw" style="display:block;margin-bottom:6px">Senha de acesso</label>
<input id="pw" name="password" type="password" autocomplete="current-password" required minlength="${MIN_PASSWORD}" style="display:block;width:100%;min-height:44px;padding:8px;margin-bottom:12px;font:inherit;border:1px solid #000">
<button type="submit" style="min-height:44px;width:100%;font:inherit;font-weight:700;border:1px solid #000;background:#000;color:#fff">Entrar</button>
</form>
<p role="alert" style="min-height:1.4em">${esc(message)}</p>
</body></html>`;

function text(res, code, msg, extra = {}) {
  res.writeHead(code, { ...SEC_HEADERS, 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...extra });
  res.end(msg);
}

function html(res, code, body) {
  res.writeHead(code, { ...SEC_HEADERS, 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}

function readForm(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('formulário grande demais')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(new URLSearchParams(Buffer.concat(chunks).toString('utf8'))));
    req.on('error', reject);
  });
}

export function createGateway(options = {}) {
  const {
    appPassword,
    novncDir = '/usr/share/novnc',
    wsUpstream = { host: '127.0.0.1', port: 6081 },
    sessionIdleMs = 30 * 60 * 1000,
    sessionMaxMs = SESSION_MAX_MS,
    secureCookie = true,
    wsCheckMs = 60 * 1000,
    now = () => Date.now(),
  } = options;

  if (typeof appPassword !== 'string' || appPassword.length < MIN_PASSWORD) {
    throw new Error(`A senha de acesso precisa ter pelo menos ${MIN_PASSWORD} caracteres.`);
  }

  // A senha não fica em texto no processo: guardamos só um hash scrypt com sal aleatório.
  const salt = crypto.randomBytes(16);
  const expected = crypto.scryptSync(appPassword, salt, 32);
  const passwordOk = (input) => crypto.timingSafeEqual(crypto.scryptSync(String(input), salt, 32), expected);

  const sessions = new Map(); // token -> { created, seen }
  const fails = new Map();    // ip -> { count, lockedUntil }

  function startSession() {
    const token = crypto.randomBytes(32).toString('base64url');
    const t = now();
    sessions.set(token, { created: t, seen: t });
    return token;
  }

  function sessionOk(token) {
    if (!token || !TOKEN_RE.test(token)) return false;
    const s = sessions.get(token);
    if (!s) return false;
    const t = now();
    if (t - s.seen > sessionIdleMs || t - s.created > sessionMaxMs) {
      sessions.delete(token);
      return false;
    }
    s.seen = t;
    return true;
  }

  const cookieFrom = (req) => {
    const m = /(?:^|;\s*)spd_session=([^;]+)/.exec(req.headers.cookie || '');
    return m ? m[1] : null;
  };
  const secureAttr = secureCookie ? '; Secure' : '';
  const setCookie = (token) => `${COOKIE}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${Math.floor(sessionMaxMs / 1000)}${secureAttr}`;
  const clearCookie = `${COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secureAttr}`;

  const ipOf = (req) => req.socket.remoteAddress || 'desconhecido';
  function isLocked(ip) {
    const f = fails.get(ip);
    if (!f) return false;
    if (f.lockedUntil > now()) return true;
    if (f.lockedUntil) fails.delete(ip);
    return false;
  }
  function recordFail(ip) {
    const f = fails.get(ip) || { count: 0, lockedUntil: 0 };
    f.count += 1;
    if (f.count >= MAX_FAILS) { f.lockedUntil = now() + LOCK_MS; f.count = 0; }
    fails.set(ip, f);
  }

  async function serveFile(req, res, pathname) {
    let rel;
    try { rel = decodeURIComponent(pathname.replace(/^\/+/, '')); }
    catch { return text(res, 400, 'Requisição inválida'); }
    if (rel.includes('\0')) return text(res, 400, 'Requisição inválida');
    const base = path.resolve(novncDir);
    const full = path.resolve(base, rel || 'vnc.html');
    if (full !== base && !full.startsWith(base + path.sep)) return text(res, 404, 'Não encontrado');
    let st;
    try { st = await fs.stat(full); } catch { return text(res, 404, 'Não encontrado'); }
    if (!st.isFile()) return text(res, 404, 'Não encontrado');
    const body = await fs.readFile(full);
    res.writeHead(200, {
      ...SEC_HEADERS,
      'Content-Type': MIME[path.extname(full).toLowerCase()] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(req.method === 'HEAD' ? undefined : body);
  }

  async function login(req, res) {
    if (req.method === 'GET' || req.method === 'HEAD') return html(res, 200, loginPage());
    if (req.method !== 'POST') return text(res, 405, 'Método não permitido', { Allow: 'GET, POST' });
    const ip = ipOf(req);
    if (isLocked(ip)) return html(res, 429, loginPage('Muitas tentativas. Aguarde 15 minutos.'));
    let form;
    try { form = await readForm(req, FORM_LIMIT); }
    catch { return text(res, 413, 'Formulário muito grande'); }
    if (passwordOk(form.get('password') ?? '')) {
      fails.delete(ip);
      const token = startSession();
      res.writeHead(303, { ...SEC_HEADERS, Location: '/', 'Set-Cookie': setCookie(token), 'Cache-Control': 'no-store' });
      return res.end();
    }
    recordFail(ip);
    return html(res, 401, loginPage('Senha incorreta.'));
  }

  async function handle(req, res) {
    const url = new URL(req.url || '/', 'http://localhost');
    const p = url.pathname;

    if (p === '/api/status') {
      if (req.method !== 'GET' && req.method !== 'HEAD') return text(res, 405, 'Método não permitido', { Allow: 'GET, HEAD' });
      res.writeHead(200, { ...SEC_HEADERS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      return res.end(JSON.stringify({ service: 'saturndesktop-pc', status: 'up' }));
    }
    if (p === '/login') return login(req, res);
    if (p === '/logout') {
      if (req.method !== 'POST') return text(res, 405, 'Método não permitido', { Allow: 'POST' });
      const token = cookieFrom(req);
      if (token) sessions.delete(token);
      res.writeHead(303, { ...SEC_HEADERS, Location: '/login', 'Set-Cookie': clearCookie, 'Cache-Control': 'no-store' });
      return res.end();
    }

    if (!sessionOk(cookieFrom(req))) {
      if (req.method === 'GET' || req.method === 'HEAD') {
        res.writeHead(302, { ...SEC_HEADERS, Location: '/login', 'Cache-Control': 'no-store' });
        return res.end();
      }
      return text(res, 401, 'Sessão expirada. Entre novamente.');
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') return text(res, 405, 'Método não permitido', { Allow: 'GET, HEAD' });
    if (p === '/') {
      res.writeHead(302, { ...SEC_HEADERS, Location: '/vnc.html?autoconnect=true&resize=scale&path=websockify', 'Cache-Control': 'no-store' });
      return res.end();
    }
    if (p === '/websockify') return text(res, 426, 'Use WebSocket neste endereço.', { Upgrade: 'websocket' });
    return serveFile(req, res, p);
  }

  function onUpgrade(req, socket, head) {
    const deny = (code, msg) => {
      socket.write(`HTTP/1.1 ${code} ${msg}\r\nConnection: close\r\nContent-Length: 0\r\n\r\n`);
      socket.destroy();
    };
    const url = new URL(req.url || '/', 'http://localhost');
    if (url.pathname !== '/websockify') return deny(404, 'Not Found');
    const token = cookieFrom(req);
    if (!sessionOk(token)) return deny(401, 'Unauthorized');

    const up = net.connect(wsUpstream.port, wsUpstream.host);
    let timer = null;
    const close = () => { clearInterval(timer); up.destroy(); socket.destroy(); };

    up.on('connect', () => {
      // Reenvia a requisição de upgrade inteira ao websockify, depois encaminha os bytes nos dois sentidos.
      const lines = [`${req.method} ${req.url} HTTP/${req.httpVersion}`];
      for (let i = 0; i < req.rawHeaders.length; i += 2) lines.push(`${req.rawHeaders[i]}: ${req.rawHeaders[i + 1]}`);
      up.write(lines.join('\r\n') + '\r\n\r\n');
      if (head && head.length) up.write(head);
      socket.pipe(up);
      up.pipe(socket);
    });
    up.on('error', () => { if (!socket.destroyed) deny(502, 'Bad Gateway'); });

    // Sessão aberta continua válida até o limite absoluto; cada verificação conta como atividade.
    timer = setInterval(() => {
      const s = token && sessions.get(token);
      if (!s || now() - s.created > sessionMaxMs) return close();
      s.seen = now();
    }, wsCheckMs);
    timer.unref?.();

    up.on('close', close);
    socket.on('error', close);
    socket.on('close', close);
  }

  return { handle, onUpgrade };
}

// Execução direta: lê a configuração do ambiente (feito por scripts/start.sh).
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const env = process.env;
  let gw;
  try {
    gw = createGateway({
      appPassword: env.SATURN_PC_PASSWORD || '',
      novncDir: env.NOVNC_DIR || '/usr/share/novnc',
      wsUpstream: { host: '127.0.0.1', port: Number(env.WS_UPSTREAM_PORT) || 6081 },
      sessionIdleMs: (Number(env.SESSION_IDLE_MINUTES) || 30) * 60 * 1000,
      secureCookie: env.SECURE_COOKIE !== '0',
    });
  } catch (err) {
    console.error(`Erro: ${err.message}`);
    process.exit(1);
  }
  const port = Number(env.PORT) || 6080;
  const host = env.HOST || '0.0.0.0';
  const server = http.createServer((req, res) => {
    gw.handle(req, res).catch(() => { if (!res.headersSent) text(res, 500, 'Erro interno'); else res.end(); });
  });
  server.on('upgrade', gw.onUpgrade);
  server.listen(port, host, () => console.log(`SaturnDesktop-PC gateway em http://${host}:${port}`));
}
