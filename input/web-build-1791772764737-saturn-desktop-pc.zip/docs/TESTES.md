# Checklist de testes no Codespace

Execute na ordem. Marque cada item só depois de ver o resultado real. Anote o que falhou e a mensagem exata.

## 1. Ambiente
- [ ] `cat /etc/os-release` mostra Ubuntu 24.04.
- [ ] `sudo -n true` retorna sem pedir senha.
- [ ] `node -v` mostra v22 ou superior.
- [ ] `free -h` mostra o que o Codespace oferece.

## 2. Instalação
- [ ] `bash scripts/install.sh` termina sem erro (anote o tempo).
- [ ] `command -v vncserver websockify` retorna dois caminhos.
- [ ] `ls /usr/share/novnc/vnc.html` existe.

## 3. Inicialização
- [ ] `SATURN_PC_PASSWORD` definida (com 12 caracteres ou mais). Não cole a senha no chat nem em arquivos.
- [ ] `npm start` termina com "Pronto".
- [ ] `npm run status` mostra gateway, websockify e VNC como ativos.
- [ ] `curl -s http://127.0.0.1:6080/api/status` retorna `{"service":"saturndesktop-pc","status":"up"}`.
- [ ] `ls ~/.vnc/passwd` existe e `stat -c %a ~/.vnc/passwd` mostra `600`.

## 4. Acesso pelo navegador (computador)
- [ ] Aba Ports mostra 6080 com visibilidade Public.
- [ ] Abrir a URL sem sessão leva à tela de login.
- [ ] Senha errada mostra "Senha incorreta" e não entra.
- [ ] Após 5 erradas, aparece o bloqueio (429).
- [ ] Senha certa abre o noVNC e conecta ao XFCE.

## 5. Acesso pelo Android
- [ ] Abrir a mesma URL no Chrome do Android.
- [ ] Tela de login aparece e funciona com a senha.
- [ ] O desktop aparece e se ajusta à tela (modo `scale`).
- [ ] Toque funciona como clique; arrastar faz arrastar.
- [ ] Teclado virtual abre e digita no XFCE.
- [ ] Rotacionar o celular mantém a imagem utilizável.

## 6. Teclado, mouse e resolução
- [ ] Digitar texto em um editor do XFCE (acentos incluídos).
- [ ] Clique direito e rolagem funcionam.
- [ ] Mudar `RESOLUTION` no `.env`, rodar `npm restart` e conferir o novo tamanho.

## 7. Reconexão e persistência
- [ ] Fechar a aba e voltar: a sessão ainda está lá (sem sair) ou pede senha de novo (com sair).
- [ ] `npm stop` e `npm start`: o XFCE volta e os arquivos em `~/` continuam.
- [ ] Criar `~/teste-persistencia.txt`, parar o Codespace, iniciar de novo e confirmar que o arquivo existe.
- [ ] Sessão ociosa por mais de `SESSION_IDLE_MINUTES` pede senha.
- [ ] `POST /logout` (botão, se adicionado, ou `curl`) derruba a sessão.

## 8. Segurança
- [ ] `curl -i http://127.0.0.1:6080/vnc.html` retorna 302 para `/login`.
- [ ] `git status` não mostra `.env`, `.run/`, `logs/` nem senhas.
- [ ] `grep -r "SATURN_PC_PASSWORD=" --include=*.md --include=*.sh --include=*.mjs .` mostra só nomes de variáveis, nunca valores.

## Resultado
Registre aqui a data, o tipo de máquina e o que passou ou falhou. Não marque como passou o que não foi executado.
