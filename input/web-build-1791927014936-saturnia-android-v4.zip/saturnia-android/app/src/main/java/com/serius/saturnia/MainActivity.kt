package com.serius.saturnia

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.provider.Settings
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Hospeda a SaturnIA em uma WebView. O HTML, CSS e JS são os mesmos do site,
 * copiados para app/src/main/assets/saturnia/index.html.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        /** Domínio interno do WebViewAssetLoader: a página local roda sob https, sem servidor. */
        private const val LOCAL_HOST = "appassets.androidplatform.net"
        private const val LOCAL_START = "https://$LOCAL_HOST/assets/saturnia/index.html"

        /** Pedido vindo do balão: abrir a galeria para anexar uma imagem à conversa. */
        const val ACTION_PICK_BUBBLE_IMAGE = "com.serius.saturnia.action.PICK_BUBBLE_IMAGE"
    }

    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var bridge: SaturnBridge? = null

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingMicRequest: PermissionRequest? = null
    private var voicePermissionPending = false

    /** Tela "Exibir sobre outros apps" do Android, aberta só depois de explicar o motivo. */
    private val overlayPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                afterOverlayGranted()
            } else {
                BubbleState.set(
                    BubbleState.NO_OVERLAY,
                    BubbleState.MODE_HIDDEN,
                    "Permissão “Exibir sobre outros apps” não concedida."
                )
            }
        }

    private val bubbleNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            resumeBubbleStart()
        }

    /** Avisa a página quando apps são instalados, atualizados ou removidos. */
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (::webView.isInitialized) {
                webView.evaluateJavascript(
                    "if(window.saturniaAppsChanged)window.saturniaAppsChanged();",
                    null
                )
            }
        }
    }

    /** Galeria para a imagem do balão. Só o arquivo escolhido é lido, e só depois da escolha. */
    private val bubbleImagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            Thread {
                val image = ImageEncoder.encode(applicationContext, uri)
                runOnUiThread {
                    if (image != null) {
                        BubbleChat.setPendingImage(image)
                    } else {
                        Toast.makeText(this, "Não consegui abrir esta imagem.", Toast.LENGTH_SHORT).show()
                    }
                    // Volta para o app de onde o usuário veio, com o balão por cima.
                    if (BubbleState.state == BubbleState.RUNNING) moveTaskToBack(true)
                }
            }.start()
        } else if (BubbleState.state == BubbleState.RUNNING) {
            moveTaskToBack(true)
        }
    }

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        fileCallback?.onReceiveValue(uris.takeIf { it.isNotEmpty() }?.toTypedArray())
        fileCallback = null
    }

    /** Permissão de microfone pedida pela própria página (ex.: ditado do chat). */
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val request = pendingMicRequest
        pendingMicRequest = null
        if (granted) {
            request?.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
        } else {
            request?.deny()
        }
    }

    /** Permissões do assistente de voz (microfone e notificações), pedidas só ao ligar o recurso. */
    private val voicePermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            voicePermissionPending = false
            if (missingVoicePermissions().isEmpty()) {
                VoiceService.start(this)
            } else {
                VoiceState.set(
                    VoiceState.PERMISSION,
                    "Permissão negada. Ative o microfone e as notificações nos ajustes do aparelho."
                )
            }
        }

    private val stateListener: (String) -> Unit = { _ ->
        runOnUiThread { pushStatusToPage() }
    }

    private val commandListener: () -> Unit = {
        runOnUiThread { drainCommandsToPage() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        configureWebView()
        setContentView(webView)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    webView.canGoBack() -> webView.goBack()
                    // Com o assistente ligado, o app vai para segundo plano e a escuta continua.
                    VoiceState.state != VoiceState.STOPPED -> moveTaskToBack(true)
                    else -> finish()
                }
            }
        })

        VoiceState.addStateListener(stateListener)
        VoiceState.addCommandListener(commandListener)
        handleBubbleIntent(intent)

        ContextCompat.registerReceiver(
            this,
            packageReceiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_CHANGED)
                addDataScheme("package")
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            webView.loadUrl(startUrl())
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportMultipleWindows(false)
        }
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        // Ponte nativa. O nome "SaturnIANative" é o que o HTML procura em window.
        bridge = SaturnBridge(this).also { webView.addJavascriptInterface(it, "SaturnIANative") }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                // Navegação dentro da própria página (ou do domínio configurado) fica na WebView.
                val allowedHosts = setOf(LOCAL_HOST, Uri.parse(BuildConfig.SATURNIA_URL).host)
                if (uri.scheme == "https" && uri.host in allowedHosts) return false
                // Qualquer outro link abre no navegador do aparelho.
                openExternal(uri)
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pushStatusToPage()
                drainCommandsToPage()
            }

            /** Se o processo de renderização da WebView morrer, recria a tela em vez de fechar o app. */
            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                if (isFinishing) return true
                recreate()
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Só microfone. Câmera e outros recursos são negados.
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE !in request.resources) {
                    request.deny()
                    return
                }
                if (hasPermission(Manifest.permission.RECORD_AUDIO)) {
                    request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                } else {
                    pendingMicRequest?.deny()
                    pendingMicRequest = request
                    micPermission.launch(Manifest.permission.RECORD_AUDIO)
                }
            }

            override fun onPermissionRequestCanceled(request: PermissionRequest) {
                if (pendingMicRequest == request) pendingMicRequest = null
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    filePicker.launch("*/*")
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            startDownload(url, userAgent, contentDisposition, mimeType)
        }
    }

    private fun startUrl(): String =
        BuildConfig.SATURNIA_URL.takeIf { it.isNotBlank() } ?: LOCAL_START

    // ------------------------------------------------------------ voz

    /** Chamado pela ponte quando o usuário liga o assistente. Pede as permissões que faltam. */
    fun requestVoiceStart() {
        if (voicePermissionPending) return
        val missing = missingVoicePermissions()
        if (missing.isEmpty()) {
            VoiceService.start(this)
            return
        }
        VoiceState.set(VoiceState.PERMISSION, "Conceda as permissões para ativar o assistente.")
        voicePermissionPending = true
        voicePermissions.launch(missing.toTypedArray())
    }

    // ------------------------------------------------------------ SaturnIA Bubble

    /**
     * Chamado pela ponte quando o usuário liga o balão. Se faltar "Exibir sobre outros apps",
     * explica antes o motivo e só então abre a tela do Android.
     */
    fun requestBubbleStart() {
        if (Settings.canDrawOverlays(this)) {
            afterOverlayGranted()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Permitir o balão da SaturnIA?")
            .setMessage(
                "Para mostrar o balão sobre outros apps, o Android pede a permissão " +
                    "“Exibir sobre outros apps”. Ela só deixa a SaturnIA desenhar o balão " +
                    "e a janela de conversa.\n\n" +
                    "A SaturnIA não lê a tela, não lê mensagens de outros apps e não grava " +
                    "nada sem você pedir."
            )
            .setPositiveButton("Continuar") { _, _ -> openOverlaySettings() }
            .setNegativeButton("Agora não") { _, _ ->
                BubbleState.set(
                    BubbleState.NO_OVERLAY,
                    BubbleState.MODE_HIDDEN,
                    "Permissão não concedida. O balão continua desligado."
                )
            }
            .show()
    }

    private fun openOverlaySettings() {
        try {
            overlayPermission.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } catch (e: ActivityNotFoundException) {
            BubbleState.set(
                BubbleState.NO_OVERLAY,
                BubbleState.MODE_HIDDEN,
                "Este aparelho não abriu a tela de permissão de sobreposição."
            )
        }
    }

    private fun afterOverlayGranted() {
        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            bubbleNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            resumeBubbleStart()
        }
    }

    /** Inicia o serviço só quando as duas permissões estão concedidas. */
    private fun resumeBubbleStart() {
        if (!Settings.canDrawOverlays(this)) {
            BubbleState.set(BubbleState.NO_OVERLAY, BubbleState.MODE_HIDDEN,
                "Permissão “Exibir sobre outros apps” não concedida.")
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            BubbleState.set(BubbleState.NO_NOTIFICATION, BubbleState.MODE_HIDDEN,
                "Sem permissão de notificações: o balão precisa dela para ser reaberto.")
            return
        }
        BubbleService.start(this)
    }

    private fun missingVoicePermissions(): List<String> = buildList {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !hasPermission(Manifest.permission.POST_NOTIFICATIONS)) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    /** Envia o estado atual para a página (atualiza o switch e o texto de status). */
    private fun pushStatusToPage() {
        if (!::webView.isInitialized) return
        webView.evaluateJavascript(
            "if(window.saturniaNativeStatus)window.saturniaNativeStatus(${JSONObject.quote(VoiceState.state)});",
            null
        )
    }

    /** Entrega os comandos ouvidos enquanto a página estava indisponível. */
    private fun drainCommandsToPage() {
        if (!::webView.isInitialized) return
        while (true) {
            val command = VoiceState.takeCommand() ?: break
            webView.evaluateJavascript(
                "if(window.saturniaNativeCommand)window.saturniaNativeCommand(${JSONObject.quote(command)});",
                null
            )
        }
    }

    // ------------------------------------------------------------ links e downloads

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Nenhum app para abrir este link.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startDownload(url: String, userAgent: String, contentDisposition: String, mimeType: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" && uri.scheme != "http") {
            Toast.makeText(this, "Este tipo de download não é suportado nesta versão.", Toast.LENGTH_SHORT).show()
            return
        }
        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(uri)
            .setMimeType(mimeType)
            .addRequestHeader("User-Agent", userAgent)
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setTitle(fileName)

        // Em Android 9 e anteriores, a pasta pública exige permissão de escrita (não declarada).
        // Nesses casos o arquivo vai para a pasta do próprio app.
        if (Build.VERSION.SDK_INT >= 29) {
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
        } else {
            request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, fileName)
        }

        val manager = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(this, "Baixando $fileName", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------ ciclo de vida

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::webView.isInitialized) webView.saveState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleBubbleIntent(intent)
    }

    private fun handleBubbleIntent(intent: Intent?) {
        if (intent?.action == ACTION_PICK_BUBBLE_IMAGE) {
            bubbleImagePicker.launch("image/*")
        }
    }

    override fun onDestroy() {
        VoiceState.removeStateListener(stateListener)
        VoiceState.removeCommandListener(commandListener)
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: IllegalArgumentException) {
            // Já estava desregistrado.
        }
        bridge?.shutdown()
        bridge = null
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
