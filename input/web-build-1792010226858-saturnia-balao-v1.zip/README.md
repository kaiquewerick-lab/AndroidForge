# SaturnIA Balão

Versão só com o balão flutuante da SaturnIA, para uso pessoal.

- Sem Firebase, sem login, sem servidor e sem microfone.
- A conversa usa a **sua** chave do Gemini, que fica só no aparelho e vai direto para a API do Google.
- O balão pode ler o texto do app aberto (quando você pedir) e executar ações (clicar, digitar, rolar, voltar, ir para a tela inicial). Ações só rodam depois que você toca em **Executar** no balão.

## Permissões

| Permissão | Para quê |
|---|---|
| Internet | Falar com a API do Gemini |
| Exibir sobre outros apps | Mostrar o balão |
| Notificações | Manter o balão ativo com aviso visível |
| Acessibilidade (opcional) | Ler e agir na tela, só se você ligar a opção |

Não pede microfone, arquivos, contatos, localização nem lista de apps.

## Como usar

1. Abra o app e cadastre sua chave do Gemini (crie em aistudio.google.com/apikey) e salve.
2. Toque em **Ativar balão** e permita **Exibir sobre outros apps** quando pedido.
3. Para o balão ler a tela: ligue **Ler e agir na tela** e, na tela de Acessibilidade, ative **SaturnIA Balão**.
4. No balão, toque em **Ver tela** para a IA ler o app aberto. Se ela propuser ações, toque em **Executar** para confirmar.

## Instalação e bloqueio do Play Protect

O app não é da Play Store, então o Android pode mostrar um alerta. O que ajuda:

- Quando aparecer o alerta, toque em **Mais detalhes** e depois em **Instalar assim mesmo**.
- No Brasil, a verificação de desenvolvedor do Android está em vigor desde 30/09/2026. Se o aparelho bloquear a instalação, use o fluxo avançado: ative **Opções do desenvolvedor**, autentique, reinicie, espere 24 horas e permita instalar apps não verificados. Esse fluxo fica nas configurações de segurança do aparelho.
- Não desligue o Play Protect para instalar: isso deixa o aparelho exposto a outros apps.

## Build

O projeto está na raiz do ZIP. No AndroidForge, envie o ZIP com os arquivos direto na raiz (sem pasta extra). O APK sai em `app/build/outputs/apk/`.
