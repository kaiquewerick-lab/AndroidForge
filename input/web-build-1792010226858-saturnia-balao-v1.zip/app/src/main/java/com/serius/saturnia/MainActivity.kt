package com.serius.saturnia

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Tela única do SaturnIA Balão: chave do Gemini, ligar o balão e a opção de ler e agir na tela.
 * Não há WebView, conta, servidor nem microfone.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var keyInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var screenSwitch: Switch

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startBubble() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BubblePrefs.init(applicationContext)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun buildUi(): ScrollView {
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        column.addView(text("SaturnIA Balão", 22f, bold = true))
        status = text("", 14f)
        column.addView(status)

        column.addView(section("Chave do Gemini"))
        column.addView(text("A chave fica só neste aparelho e vai direto para a API do Google. Crie a sua em aistudio.google.com/apikey.", 13f))
        keyInput = EditText(this).apply {
            hint = "AIza..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(BubblePrefs.apiKey)
        }
        column.addView(keyInput)
        modelInput = EditText(this).apply {
            hint = "Modelo (ex.: gemini-3.8-flash)"
            setText(BubblePrefs.model)
        }
        column.addView(modelInput)
        column.addView(button("Salvar chave e modelo") { save() })

        column.addView(section("Balão"))
        column.addView(button("Ativar balão") { enableBubble() })
        column.addView(button("Desligar balão") {
            BubbleService.stop(this)
            refresh()
        })

        column.addView(section("Ler e agir na tela"))
        column.addView(text("Quando ligada, o balão pode ler o texto do app aberto quando você pedir. Ações como clicar, digitar e rolar só rodam depois que você tocar em Executar no balão.", 13f))
        screenSwitch = Switch(this).apply {
            text = "Ler e agir na tela"
            setOnClickListener { toggleScreen(isChecked) }
        }
        column.addView(screenSwitch)

        return ScrollView(this).apply { addView(column) }
    }

    private fun refresh() {
        screenSwitch.isChecked = BubblePrefs.screenEnabled
        val overlay = Settings.canDrawOverlays(this)
        val screenConnected = ScreenAccessService.instance != null
        status.text = buildString {
            append(if (BubblePrefs.apiKey.isNotBlank()) "Chave: cadastrada\n" else "Chave: falta cadastrar\n")
            append(if (overlay) "Sobre outros apps: permitido\n" else "Sobre outros apps: falta permitir\n")
            append(if (BubbleState.state == BubbleState.RUNNING) "Balão: ativo\n" else "Balão: desligado\n")
            append(
                when {
                    !BubblePrefs.screenEnabled -> "Leitura da tela: desligada"
                    screenConnected -> "Leitura da tela: ativa"
                    else -> "Leitura da tela: falta ligar o serviço em Acessibilidade"
                }
            )
        }
    }

    private fun save() {
        BubblePrefs.apiKey = keyInput.text.toString()
        val model = modelInput.text.toString().trim()
        if (model.isNotEmpty()) BubblePrefs.model = model
        val message = if (model.isEmpty() || BubblePrefs.model == model) "Salvo." else "Nome de modelo inválido. Use algo como gemini-3.8-flash."
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun toggleScreen(on: Boolean) {
        BubblePrefs.screenEnabled = on
        if (on && ScreenAccessService.instance == null) {
            Toast.makeText(this, "Ligue \"SaturnIA Balão\" na lista de Acessibilidade e volte para cá.", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Não consegui abrir Acessibilidade.", Toast.LENGTH_SHORT).show()
            }
        }
        refresh()
    }

    private fun enableBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita \"Exibir sobre outros apps\" para o SaturnIA Balão.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startBubble()
    }

    private fun startBubble() {
        if (!Settings.canDrawOverlays(this)) return
        BubbleService.start(this)
        refresh()
    }

    private fun text(value: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun section(value: String): TextView = text(value, 17f, bold = true).apply {
        setPadding(0, dp(24), 0, dp(4))
    }

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }
}
