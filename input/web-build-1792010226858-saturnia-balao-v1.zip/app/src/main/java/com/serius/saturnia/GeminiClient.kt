package com.serius.saturnia

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente direto da API do Gemini, com a chave que o próprio usuário cadastrou no app.
 * Não há servidor intermediário: a chave vai só para generativelanguage.googleapis.com.
 */
object GeminiClient {

    private const val SYSTEM =
        "Você é a SaturnIA, uma assistente que responde em português do Brasil. " +
            "Você aparece em um balão flutuante sobre outros aplicativos, então seja clara e objetiva."

    private fun partsFor(m: ChatMessage): JSONArray {
        val parts = JSONArray()
        m.image?.let {
            parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", it.mime).put("data", it.base64)))
        }
        if (m.text.isNotBlank()) parts.put(JSONObject().put("text", m.text))
        return parts
    }

    fun buildDirectBody(history: List<ChatMessage>): JSONObject {
        val contents = JSONArray()
        for (m in history) {
            contents.put(JSONObject().put("role", m.role).put("parts", partsFor(m)))
        }
        return JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
            .put("generationConfig", JSONObject().put("temperature", 0.7))
    }

    /** Erro da API. Nunca inclui a chave na mensagem. */
    fun directErrorFor(status: Int): String = when (status) {
        400 -> "A chave da API foi recusada ou a requisição é inválida. Confira a chave no app."
        403 -> "Esta chave não tem permissão para usar este modelo."
        404 -> "Modelo não encontrado. Confira o nome do modelo no app."
        429 -> "Limite de uso da sua chave atingido. Aguarde ou confira sua cota no Google AI Studio."
        else -> "A API do Gemini respondeu com erro ($status). Tente de novo em instantes."
    }

    /** Chamada bloqueante: rodar sempre fora da thread principal. */
    fun call(key: String, model: String, history: List<ChatMessage>): GeminiResult {
        if (history.isEmpty()) return GeminiResult.Failed("Escreva uma mensagem para começar.")
        if (key.isBlank()) return GeminiResult.Failed("Cadastre sua chave do Gemini no app (abra o SaturnIA Balão e salve a chave).")
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(buildDirectBody(history).toString().toByteArray(Charsets.UTF_8)) }

            val status = conn.responseCode
            if (status !in 200..299) {
                GeminiResult.Failed(directErrorFor(status))
            } else {
                val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parts = JSONObject(raw).optJSONArray("candidates")
                    ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val text = buildString {
                    if (parts != null) {
                        for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
                    }
                }.trim()
                if (text.isEmpty()) GeminiResult.Failed("O modelo não enviou resposta. Tente reformular a pergunta.")
                else GeminiResult.Ok(text)
            }
        } catch (e: IOException) {
            GeminiResult.Failed("Não foi possível falar com a API do Gemini. Verifique a conexão.")
        } catch (e: Exception) {
            GeminiResult.Failed("Resposta inesperada da API do Gemini.")
        } finally {
            conn?.disconnect()
        }
    }
}
