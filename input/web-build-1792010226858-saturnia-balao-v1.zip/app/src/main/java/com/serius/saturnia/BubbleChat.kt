package com.serius.saturnia

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Conversa do balão, guardada só na memória do processo. Minimizar ou ocultar o balão
 * não apaga a conversa; ela some quando o app é encerrado pelo sistema ou pelo usuário.
 */
object BubbleChat {

    const val DEFAULT_MODEL = "gemini-3.8-flash"
    private const val MAX_STORED = 60
    private const val MAX_INPUT = 4000

    private val messages = CopyOnWriteArrayList<ChatMessage>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var busy: Boolean = false
        private set

    /** Ações propostas pela IA sobre a tela, aguardando o toque do usuário em "Executar". */
    @Volatile
    var proposedActions: List<ScreenAction> = emptyList()
        private set

    fun snapshot(): List<ChatMessage> = messages.toList()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    fun clear() {
        if (busy) return
        messages.clear()
        proposedActions = emptyList()
        notifyListeners()
    }

    /** Envia uma mensagem para a IA. Resposta e erro voltam pela thread principal. */
    fun send(text: String) {
        val clean = text.trim().take(MAX_INPUT)
        if (clean.isEmpty() || busy) return

        add(ChatMessage("user", clean))
        val history = ChatHistory.forRequest(messages.toList())
        val key = BubblePrefs.apiKey
        val model = BubblePrefs.model
        busy = true
        proposedActions = emptyList()
        notifyListeners()

        worker.execute {
            val result = GeminiClient.call(key, model, history)
            main.post {
                when (result) {
                    is GeminiResult.Ok -> {
                        add(ChatMessage("model", result.text))
                        proposedActions = ScreenActions.parse(result.text)
                    }
                    is GeminiResult.Failed -> add(ChatMessage("model", result.message, failed = true))
                }
                busy = false
                notifyListeners()
            }
        }
    }

    /**
     * Lê o texto da tela do app aberto e pergunta à IA. Só funciona se o usuário ligou a
     * opção no app e o serviço de acessibilidade está ativo. O texto lido aparece no chat.
     */
    fun analyzeScreen(userText: String) {
        if (busy) return
        if (!BubblePrefs.screenEnabled) {
            add(ChatMessage("model", "Ligue \"Ler e agir na tela\" no app SaturnIA Balão para eu ver o app aberto.", failed = true))
            notifyListeners()
            return
        }
        val service = ScreenAccessService.instance
        if (service == null) {
            add(ChatMessage("model", "Ative \"SaturnIA Balão\" em Acessibilidade para eu ver o app aberto.", failed = true))
            notifyListeners()
            return
        }
        val screen = service.snapshot()
        if (screen == null) {
            add(ChatMessage("model", "Não consegui ler a tela agora. Tente de novo.", failed = true))
            notifyListeners()
            return
        }
        val ask = userText.trim().ifEmpty { "Me ajude com esta tela." }
        send(
            ask + "\n\n" +
                "Elementos visíveis na tela atual do app aberto (numerados). Responda em português.\n" +
                "Se for útil agir na tela, termine com um bloco ```json no formato " +
                "{\"actions\":[{\"op\":\"click\",\"i\":N},{\"op\":\"type\",\"i\":N,\"text\":\"...\"}," +
                "{\"op\":\"scroll\",\"i\":N,\"dir\":\"down\"},{\"op\":\"back\"},{\"op\":\"home\"}]}. " +
                "Use só os números da lista. Não proponha enviar dinheiro, apagar dados ou publicar " +
                "nada que o usuário não tenha pedido.\n" +
                "---\n" + screen.ifEmpty { "(nenhum elemento legível)" }
        )
    }

    /** Executa as ações pendentes, somente depois que o usuário tocou em "Executar". */
    fun runProposed() {
        val actions = proposedActions
        if (actions.isEmpty() || busy) return
        proposedActions = emptyList()
        val service = if (BubblePrefs.screenEnabled) ScreenAccessService.instance else null
        val results = if (service == null) {
            listOf("A leitura e ação na tela estão desligadas")
        } else {
            actions.map { service.perform(it) }
        }
        add(ChatMessage("model", "Ações executadas:\n" + results.joinToString("\n") { "• $it" }))
        notifyListeners()
    }

    private fun add(message: ChatMessage) {
        messages.add(message)
        while (messages.size > MAX_STORED) messages.removeAt(0)
    }

    private fun notifyListeners() {
        listeners.forEach { it() }
    }
}
