package com.serius.saturnia

import android.content.Context

/**
 * Preferências do app. Ficam só no aparelho, em um arquivo privado do app.
 * A chave do Gemini nunca sai do aparelho: vai direto para a API do Google.
 */
object BubblePrefs {

    private const val PREFS = "saturnia_balao"
    private const val KEY_API = "gemini_key"
    private const val KEY_MODEL = "gemini_model"
    private const val KEY_SCREEN = "screen_enabled"
    private val MODEL_RE = Regex("^gemini-[a-z0-9.\\-]{3,40}$")

    private var app: Context? = null

    fun init(context: Context) {
        app = context.applicationContext
    }

    private fun prefs() = app?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var apiKey: String
        get() = try { prefs()?.getString(KEY_API, "").orEmpty() } catch (e: Exception) { "" }
        set(value) {
            try { prefs()?.edit()?.putString(KEY_API, value.trim().take(200))?.apply() } catch (e: Exception) { }
        }

    var model: String
        get() {
            val saved = try { prefs()?.getString(KEY_MODEL, null) } catch (e: Exception) { null }
            return saved?.takeIf { MODEL_RE.matches(it) } ?: BubbleChat.DEFAULT_MODEL
        }
        set(value) {
            val clean = value.trim()
            if (MODEL_RE.matches(clean)) {
                try { prefs()?.edit()?.putString(KEY_MODEL, clean)?.apply() } catch (e: Exception) { }
            }
        }

    /** Liga a leitura e a ação na tela. Mesmo ligada, a ação só roda com o toque do usuário. */
    var screenEnabled: Boolean
        get() = try { prefs()?.getBoolean(KEY_SCREEN, false) ?: false } catch (e: Exception) { false }
        set(value) {
            try { prefs()?.edit()?.putBoolean(KEY_SCREEN, value)?.apply() } catch (e: Exception) { }
        }
}
