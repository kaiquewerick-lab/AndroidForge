/* ===== Conexão direta com a API do Claude (streaming) ===== */
const Api = {
  MODELS: [
    { id: 'claude-fable-5-2',  name: 'Claude Fable 5.2',  desc: 'Máxima capacidade (Mythos)' },
    { id: 'claude-opus-5-5',   name: 'Claude Opus 5.5',   desc: 'Raciocínio avançado' },
    { id: 'claude-sonnet-5-5', name: 'Claude Sonnet 5.5', desc: 'Equilíbrio ideal' },
    { id: 'claude-haiku-5-5',  name: 'Claude Haiku 5.5',  desc: 'Rápido e econômico' },
  ],

  async stream({ model, max_tokens, system, messages, signal, onText }) {
    const key = Store.settings.apiKey;
    if (!key) throw new Error('Cole sua API Key do Claude nas configurações.');

    const body = { model, max_tokens, messages, stream: true };
    if (system && system.trim()) body.system = system;

    let res;
    try {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-api-key': key,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify(body),
        signal,
      });
    } catch (e) {
      if (e.name === 'AbortError') throw e;
      throw new Error('Falha de conexão com a API. Verifique sua internet.');
    }

    if (!res.ok) {
      let msg = `Erro ${res.status}`;
      try { const j = await res.json(); msg = j.error?.message || msg; } catch {}
      if (res.status === 401) msg = 'API Key inválida ou sem permissão.';
      throw new Error(msg);
    }

    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = '', full = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });

      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (!line.startsWith('data:')) continue;
        const data = line.slice(5).trim();
        if (!data || data === '[DONE]') continue;

        let ev;
        try { ev = JSON.parse(data); } catch { continue; }
        if (ev.type === 'error') throw new Error(ev.error?.message || 'Erro durante a resposta.');
        if (ev.type === 'content_block_delta' && ev.delta?.type === 'text_delta') {
          full += ev.delta.text;
          onText?.(ev.delta.text);
        }
      }
    }
    return full;
  },
};
