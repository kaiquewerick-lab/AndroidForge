/* ===== Armazenamento local: tudo fica apenas neste navegador ===== */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const Store = {
  SKEY: 'minhaia.settings.v1',
  CKEY: 'minhaia.chats.v1',

  defaults: {
    apiKey: '',
    model: 'claude-sonnet-5-5',
    maxTokens: 4096,
    system: 'Você é uma assistente de IA privada, clara e prestativa. Responda em português do Brasil, a menos que o usuário escreva em outro idioma.',
    theme: 'dark',
    palette: 'violeta',
    fontSize: 15,
    animations: true,
    particles: true,
    splash: true,
    widget: false,
    enterSends: true,
  },

  settings: {},
  chats: [],
  currentId: null,

  uid() { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36); },

  loadAll() {
    try { this.settings = { ...this.defaults, ...JSON.parse(localStorage.getItem(this.SKEY) || '{}') }; }
    catch { this.settings = { ...this.defaults }; }
    try { this.chats = JSON.parse(localStorage.getItem(this.CKEY) || '[]'); }
    catch { this.chats = []; }
    this.currentId = this.chats[0]?.id ?? null;
  },

  saveSettings() { localStorage.setItem(this.SKEY, JSON.stringify(this.settings)); },

  // Campos que começam com "_" são só da sessão (ex.: links de pré-visualização) e não são salvos
  strip(k, v) { return k.startsWith('_') ? undefined : v; },

  saveChats() {
    try { localStorage.setItem(this.CKEY, JSON.stringify(this.chats, this.strip)); }
    catch (e) { console.warn('Não foi possível salvar as conversas:', e); }
  },

  newChat() {
    const c = { id: this.uid(), title: 'Nova conversa', createdAt: Date.now(), messages: [] };
    this.chats.unshift(c);
    this.currentId = c.id;
    this.saveChats();
    return c;
  },

  current() { return this.chats.find(c => c.id === this.currentId) || null; },

  deleteChat(id) {
    this.chats = this.chats.filter(c => c.id !== id);
    if (this.currentId === id) this.currentId = this.chats[0]?.id ?? null;
    this.saveChats();
  },

  clearAll() { this.chats = []; this.currentId = null; this.saveChats(); },

  exportJSON() {
    return JSON.stringify({ exportado: new Date().toISOString(), conversas: this.chats }, this.strip, 2);
  },
};
