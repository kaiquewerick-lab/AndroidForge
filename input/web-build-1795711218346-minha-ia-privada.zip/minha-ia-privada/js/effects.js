/* ===== Efeitos visuais: partículas e digitação da capa ===== */
const Effects = {
  PALETTES: {
    violeta:  ['#7c5cff', '#22d3ee'],
    oceano:   ['#0ea5e9', '#22c55e'],
    sunset:   ['#f97316', '#ec4899'],
    floresta: ['#10b981', '#a3e635'],
    grafite:  ['#64748b', '#e2e8f0'],
  },

  bg: null,

  bgParticles(on) {
    if (this.bg) { this.bg.stop(); this.bg = null; }
    if (on) this.bg = this.particles(document.getElementById('bg-canvas'), { count: 55, speed: 0.35, connect: true });
  },

  particles(canvas, { count = 60, speed = 0.4, connect = false } = {}) {
    const ctx = canvas.getContext('2d');
    const color = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#7c5cff';
    let W = 0, H = 0, running = true;
    const parts = [];

    const resize = () => {
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      W = canvas.clientWidth; H = canvas.clientHeight;
      canvas.width = W * dpr; canvas.height = H * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener('resize', resize);

    for (let i = 0; i < count; i++) {
      parts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - 0.5) * speed, vy: (Math.random() - 0.5) * speed, r: Math.random() * 2 + 0.6 });
    }

    const tick = () => {
      if (!running) return;
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = color; ctx.strokeStyle = color;
      for (const p of parts) {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > W) p.vx *= -1;
        if (p.y < 0 || p.y > H) p.vy *= -1;
        ctx.globalAlpha = 0.6;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
      }
      if (connect) {
        ctx.lineWidth = 1;
        for (let i = 0; i < parts.length; i++) {
          for (let j = i + 1; j < parts.length; j++) {
            const a = parts[i], b = parts[j];
            const d = Math.hypot(a.x - b.x, a.y - b.y);
            if (d < 120) {
              ctx.globalAlpha = (1 - d / 120) * 0.25;
              ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
            }
          }
        }
      }
      ctx.globalAlpha = 1;
      requestAnimationFrame(tick);
    };
    tick();

    return {
      stop() {
        running = false;
        window.removeEventListener('resize', resize);
        ctx.clearRect(0, 0, W, H);
      },
    };
  },

  typeText(node, text, speed = 120) {
    return new Promise(res => {
      let i = 0;
      node.textContent = '';
      const t = setInterval(() => {
        node.textContent = text.slice(0, ++i);
        if (i >= text.length) { clearInterval(t); res(); }
      }, speed);
    });
  },
};
