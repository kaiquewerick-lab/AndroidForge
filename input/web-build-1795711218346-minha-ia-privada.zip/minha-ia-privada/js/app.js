/* ===== Aplicativo principal ===== */
const $ = id => document.getElementById(id);
const fmtSize = b => b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(0) + ' KB' : (b / 1048576).toFixed(1) + ' MB';
const ICONS = { image: '🖼️', video: '🎬', pdf: '📕', office: '📘', zip: '🗜️', text: '📄', unsupported: '⚠️' };

// Markdown leve: código, negrito, itálico, listas, títulos e links
function md(src = '') {
  const codes = [];
  let t = String(src).replace(/```([\w+-]*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    codes.push(`<pre><div class="code-head"><span>${esc(lang || 'código')}</span><button class="copy-code">copiar</button></div><code>${esc(code.replace(/\n$/, ''))}</code></pre>`);
    return `\u0000${codes.length - 1}\u0000`;
  });
  t = esc(t);
  const inline = s => s
    .replace(/`([^`\n]+)`/g, '<code>$1</code>')
    .replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[\s(])\*([^*\n]+)\*/g, '$1<em>$2</em>')
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

  const out = [];
  let list = null;
  for (const raw of t.split('\n')) {
    const line = raw.trimEnd();
    const ul = line.match(/^\s*[-*•]\s+(.*)$/);
    const ol = line.match(/^\s*\d+[.)]\s+(.*)$/);
    const h = line.match(/^(#{1,4})\s+(.*)$/);
    if (ul || ol) {
      const tag = ul ? 'ul' : 'ol';
      if (list !== tag) { if (list) out.push(`</${list}>`); out.push(`<${tag}>`); list = tag; }
      out.push(`<li>${inline((ul || ol)[1])}</li>`);
      continue;
    }
    if (list) { out.push(`</${list}>`); list = null; }
    if (/^\s*\u0000\d+\u0000\s*$/.test(line)) { out.push(line.trim()); continue; }
    if (h) { const n = h[1].length + 2; out.push(`<h${n}>${inline(h[2])}</h${n}>`); continue; }
    if (!line.trim()) { out.push('<br>'); continue; }
    out.push(`<p>${inline(line)}</p>`);
  }
  if (list) out.push(`</${list}>`);
  return out.join('').replace(/\u0000(\d+)\u0000/g, (_, i) => codes[+i]);
}

const App = {
  streaming: false,
  abort: null,
  unread: 0,
  splashFx: null,

  init() {
    Store.loadAll();
    this.el = {
      splash: $('splash'), splashTitle: $('splash-title'), splashEnter: $('splash-enter'), splashCanvas: $('splash-canvas'),
      bubble: $('bubble'), badge: $('badge'), app: $('app'), sidebar: $('sidebar'), menuToggle: $('menu-toggle'),
      chatList: $('chat-list'), messages: $('messages'), input: $('input'), send: $('send'), stop: $('stop'),
      fileInput: $('file-input'), attachments: $('attachments'), modelSelect: $('model-select'), sModel: $('s-model'),
      newChat: $('new-chat'), newChatTop: $('new-chat-top'), openSettings: $('open-settings'), openSettings2: $('open-settings-2'),
      widgetClose: $('widget-close'), settings: $('settings'), closeSettings: $('close-settings'), toast: $('toast'),
    };

    this.renderModels();
    this.buildSwatches();
    this.applySettings();
    this.bindEvents();
    this.renderSidebar();
    this.renderChat();
    this.renderAttachments();
    this.updateBadge();
    this.startSplash();
  },

  /* ---------- aparência e modo ---------- */
  applySettings() {
    const s = Store.settings;
    const pal = Effects.PALETTES[s.palette] || Effects.PALETTES.violeta;
    const st = document.documentElement.style;
    st.setProperty('--accent', pal[0]);
    st.setProperty('--accent2', pal[1]);
    st.setProperty('--fs', (s.fontSize || 15) + 'px');
    document.body.classList.toggle('light', s.theme === 'light');
    document.body.classList.toggle('no-anim', !s.animations);
    document.body.classList.toggle('mode-widget', !!s.widget);
    if (!s.widget) this.el.app.classList.remove('open');
    if (this.el.bubble) this.el.bubble.classList.toggle('hidden', !s.widget);
    Effects.bgParticles(s.animations && s.particles);
    document.querySelectorAll('.swatch').forEach(b => b.classList.toggle('on', b.dataset.p === s.palette));
    this.syncLabels();
  },

  syncLabels() {
    const s = Store.settings;
    const mx = $('s-max-val'), fv = $('s-font-val');
    if (mx) mx.textContent = s.maxTokens;
    if (fv) fv.textContent = s.fontSize;
    if (this.el.modelSelect) this.el.modelSelect.value = s.model;
    if (this.el.sModel) this.el.sModel.value = s.model;
  },

  renderModels() {
    const opts = Api.MODELS.map(m => `<option value="${m.id}">${m.name}</option>`).join('');
    this.el.modelSelect.innerHTML = opts;
    this.el.sModel.innerHTML = Api.MODELS.map(m => `<option value="${m.id}">${m.name} — ${m.desc}</option>`).join('');
    this.syncLabels();
  },

  buildSwatches() {
    $('swatches').innerHTML = Object.entries(Effects.PALETTES).map(([name, [a, b]]) =>
      `<button class="swatch" data-p="${name}" title="${name}" style="--a:${a};--b:${b}"></button>`).join('');
  },

  togglePanel(force) {
    if (!Store.settings.widget) return;
    const open = force ?? !this.el.app.classList.contains('open');
    this.el.app.classList.toggle('open', open);
    this.el.bubble.querySelector('.bubble-ico').textContent = open ? '✕' : '✦';
    if (open) {
      this.unread = 0;
      this.updateBadge();
      setTimeout(() => this.el.input.focus(), 250);
      this.scrollBottom(true);
    }
  },

  updateBadge() {
    this.el.bubble.classList.toggle('has-new', this.unread > 0);
    this.el.badge.textContent = this.unread;
  },

  /* ---------- capa ---------- */
  startSplash() {
    const s = Store.settings;
    if (!s.splash) { this.el.splash.classList.add('hidden'); return; }
    if (s.animations) this.splashFx = Effects.particles(this.el.splashCanvas, { count: 70, speed: 0.6 });
    Effects.typeText(this.el.splashTitle, 'Minha IA', 140).then(() => {
      setTimeout(() => this.el.splashEnter.classList.remove('hidden'), 400);
    });
  },

  enterApp() {
    const sp = this.el.splash;
    if (sp.classList.contains('out') || sp.classList.contains('hidden')) return;
    sp.classList.add('out');
    setTimeout(() => {
      sp.classList.add('hidden');
      if (this.splashFx) { this.splashFx.stop(); this.splashFx = null; }
    }, 900);
    if (!Store.settings.widget) setTimeout(() => this.el.input.focus(), 900);
  },

  /* ---------- conversas ---------- */
  renderSidebar() {
    if (!Store.chats.length) { this.el.chatList.innerHTML = '<p class="muted small pad">Nenhuma conversa ainda.</p>'; return; }
    this.el.chatList.innerHTML = Store.chats.map(c =>
      `<div class="chat-item ${c.id === Store.currentId ? 'active' : ''}" data-id="${c.id}">
         <span class="t">${esc(c.title)}</span>
         <button class="x" data-del="${c.id}" title="Excluir">🗑</button>
       </div>`).join('');
  },

  newChat() {
    Store.newChat();
    this.renderSidebar();
    this.renderChat();
    this.el.sidebar.classList.remove('show');
    this.el.input.focus();
  },

  selectChat(id) {
    Store.currentId = id;
    this.renderSidebar();
    this.renderChat();
    this.el.sidebar.classList.remove('show');
  },

  emptyHTML() {
    const hasKey = !!Store.settings.apiKey;
    const chips = ['Resuma um PDF que eu enviar', 'Explique um conceito difícil', 'Crie um plano de estudos', 'Analise uma imagem ou um vídeo'];
    return `
      <div class="empty">
        <div class="orb"></div>
        <h2>Olá! Como posso ajudar?</h2>
        <p class="muted">Converse de forma privada com o Claude. Envie imagens, PDFs, documentos, vídeos ou ZIPs.</p>
        ${hasKey ? '' : `
        <div class="keycard">
          <p>Para começar, cole sua <b>API Key do Claude</b>:</p>
          <div class="row2">
            <input id="quick-key" class="input" type="password" placeholder="sk-ant-..." autocomplete="off">
            <button id="quick-key-save" class="btn primary">Salvar</button>
          </div>
          <small>Crie a chave em console.anthropic.com. Ela fica salva só neste navegador.</small>
        </div>`}
        <div class="chips">${chips.map(t => `<button class="chip">${t}</button>`).join('')}</div>
      </div>`;
  },

  renderChat() {
    const chat = Store.current();
    this.el.messages.innerHTML = '';
    if (!chat || !chat.messages.length) { this.el.messages.innerHTML = this.emptyHTML(); return; }
    chat.messages.forEach(m => this.el.messages.appendChild(this.msgNode(m)));
    this.scrollBottom(true);
  },

  fileHTML(f) {
    const name = esc(f.name);
    if (f._url && f.kind === 'image') return `<div class="thumbs"><img src="${f._url}" alt="${name}"></div>`;
    if (f._url && f.kind === 'video') return `<div class="thumbs"><video src="${f._url}" controls></video></div>`;
    return `<span class="file-chip">${ICONS[f.kind] || '📎'} ${name}</span>`;
  },

  msgNode(m) {
    const div = document.createElement('div');
    div.className = `msg ${m.role}`;
    div.dataset.id = m.id;
    const files = (m.files || []).map(f => this.fileHTML(f)).join('');
    let body;
    if (m.role === 'user') body = esc(m.text).replace(/\n/g, '<br>');
    else body = m.text ? md(m.text) : '<div class="typing"><span></span><span></span><span></span></div>';
    div.innerHTML = `
      <div class="avatar">${m.role === 'user' ? 'EU' : '✦'}</div>
      <div class="stack">
        <div class="bubble">${files}<div class="content">${body}</div></div>
        ${m.role === 'assistant' && m.text ? '<div class="msg-actions"><button class="act copy">copiar</button></div>' : ''}
      </div>`;
    return div;
  },

  scrollBottom(force) {
    const m = this.el.messages;
    const nearBottom = m.scrollHeight - m.scrollTop - m.clientHeight < 140;
    if (force || nearBottom) m.scrollTop = m.scrollHeight;
  },

  /* ---------- anexos ---------- */
  renderAttachments() {
    this.el.attachments.innerHTML = Files.pending.map(p => {
      let thumb;
      if (p.previewUrl && p.kind === 'image') thumb = `<img src="${p.previewUrl}" alt="">`;
      else if (p.previewUrl && p.kind === 'video') thumb = `<video src="${p.previewUrl}" muted></video>`;
      else thumb = `<div class="ico">${ICONS[p.kind] || '📎'}</div>`;
      const status = p.loading ? '⏳ processando...' : p.error ? esc(p.error) : (p.info || fmtSize(p.size));
      return `<div class="att ${p.error ? 'warn' : ''}" data-id="${p.id}">
        ${thumb}
        <div class="meta"><div class="nm" title="${esc(p.name)}">${esc(p.name)}</div><small class="muted">${status}</small></div>
        <button class="rm" title="Remover">✕</button>
      </div>`;
    }).join('');
  },

  autosize() {
    const i = this.el.input;
    i.style.height = 'auto';
    i.style.height = Math.min(i.scrollHeight, 180) + 'px';
  },

  /* ---------- envio e streaming ---------- */
  setStreaming(on) {
    this.streaming = on;
    this.el.send.classList.toggle('hidden', on);
    this.el.stop.classList.toggle('hidden', !on);
  },

  async send() {
    if (this.streaming) return;
    const s = Store.settings;
    const text = this.el.input.value.trim();
    if (Files.pending.some(p => p.loading)) return this.toast('Aguarde os anexos terminarem de carregar');
    if (!text && !Files.pending.some(p => p.blocks.length)) return;
    if (!s.apiKey) { this.toast('Cole sua API Key do Claude nas configurações'); this.openSettings(); return; }

    const files = Files.takeReady();
    const chat = Store.current() || Store.newChat();
    const blocks = files.flatMap(f => f.blocks);
    blocks.push({ type: 'text', text: text || 'Analise o conteúdo anexado.' });

    const userMsg = {
      id: Store.uid(), role: 'user', text, time: Date.now(),
      files: files.map(f => ({ name: f.name, kind: f.kind, _url: f.previewUrl })),
      _blocks: files.length ? blocks : null,
    };
    const aMsg = { id: Store.uid(), role: 'assistant', text: '', time: Date.now(), model: s.model };

    if (!chat.messages.length) chat.title = (text || files[0]?.name || 'Conversa').slice(0, 48);
    chat.messages.push(userMsg, aMsg);
    this.el.input.value = '';
    this.autosize();
    Store.saveChats();
    this.renderSidebar();
    this.renderChat();

    const history = chat.messages.slice(0, -1)
      .map(m => ({ role: m.role, content: m._blocks || m.text }))
      .filter(m => m.content && m.content.length)
      .slice(-40);
    while (history.length && history[0].role !== 'user') history.shift();

    this.setStreaming(true);
    this.abort = new AbortController();
    const node = this.el.messages.querySelector(`[data-id="${aMsg.id}"] .content`);
    const bubble = node.closest('.bubble');
    bubble.classList.add('caret');

    let scheduled = false;
    const paint = () => { scheduled = false; node.innerHTML = md(aMsg.text); this.scrollBottom(); };

    try {
      await Api.stream({
        model: s.model, max_tokens: s.maxTokens, system: s.system, messages: history, signal: this.abort.signal,
        onText: t => {
          aMsg.text += t;
          if (!scheduled) { scheduled = true; requestAnimationFrame(paint); }
        },
      });
    } catch (e) {
      const sep = aMsg.text ? '\n\n' : '';
      if (e.name === 'AbortError') aMsg.text += sep + '*(resposta interrompida)*';
      else aMsg.text += sep + '⚠️ **Erro:** ' + e.message;
    } finally {
      bubble.classList.remove('caret');
      this.setStreaming(false);
      this.abort = null;
      if (!aMsg.text) aMsg.text = '(sem resposta)';
      Store.saveChats();
      this.renderSidebar();
      if (Store.currentId === chat.id) this.renderChat();
      if (s.widget && !this.el.app.classList.contains('open')) { this.unread++; this.updateBadge(); }
    }
  },

  toast(msg) {
    const t = this.el.toast;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(this._tt);
    this._tt = setTimeout(() => t.classList.remove('show'), 2600);
  },

  /* ---------- configurações ---------- */
  openSettings() {
    document.querySelectorAll('[data-key]').forEach(inp => {
      const v = Store.settings[inp.dataset.key];
      if (inp.type === 'checkbox') inp.checked = !!v;
      else inp.value = v ?? '';
    });
    this.syncLabels();
    $('key-status').textContent = '';
    this.el.settings.classList.remove('hidden');
  },

  closeSettings() { this.el.settings.classList.add('hidden'); },

  bindSettings() {
    document.querySelectorAll('[data-key]').forEach(inp => {
      const evt = (inp.type === 'checkbox' || inp.tagName === 'SELECT') ? 'change' : 'input';
      inp.addEventListener(evt, () => {
        let v;
        if (inp.type === 'checkbox') v = inp.checked;
        else if (inp.type === 'range' || inp.dataset.type === 'number') v = Number(inp.value);
        else v = inp.value;
        Store.settings[inp.dataset.key] = v;
        Store.saveSettings();
        this.applySettings();
      });
    });
  },

  /* ---------- eventos ---------- */
  bindEvents() {
    const el = this.el;

    el.send.onclick = () => this.send();
    el.stop.onclick = () => this.abort && this.abort.abort();
    el.input.addEventListener('input', () => this.autosize());
    el.input.addEventListener('keydown', e => {
      if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
      if (Store.settings.enterSends || e.ctrlKey || e.metaKey) { e.preventDefault(); this.send(); }
    });

    el.fileInput.addEventListener('change', e => {
      Files.addFiles([...e.target.files]);
      e.target.value = '';
    });
    el.attachments.addEventListener('click', e => {
      const rm = e.target.closest('.rm');
      if (rm) { Files.remove(rm.closest('.att').dataset.id); this.renderAttachments(); }
    });

    el.messages.addEventListener('click', e => {
      const t = e.target;
      const chip = t.closest('.chip');
      if (chip) { el.input.value = chip.textContent; el.input.focus(); this.autosize(); return; }
      if (t.id === 'quick-key-save') {
        const v = $('quick-key').value.trim();
        if (!v) return this.toast('Cole a chave primeiro');
        Store.settings.apiKey = v; Store.saveSettings();
        this.renderChat(); this.toast('Chave salva ✔');
        return;
      }
      const copy = t.closest('.copy');
      if (copy) {
        const m = Store.current()?.messages.find(x => x.id === copy.closest('.msg').dataset.id);
        if (m) navigator.clipboard?.writeText(m.text).then(() => this.toast('Copiado!'));
        return;
      }
      const cc = t.closest('.copy-code');
      if (cc) navigator.clipboard?.writeText(cc.closest('pre').querySelector('code').textContent).then(() => this.toast('Código copiado!'));
    });

    el.newChat.onclick = () => this.newChat();
    el.newChatTop.onclick = () => this.newChat();
    el.openSettings.onclick = () => this.openSettings();
    el.openSettings2.onclick = () => this.openSettings();
    el.menuToggle.onclick = () => el.sidebar.classList.toggle('show');

    el.chatList.addEventListener('click', e => {
      const del = e.target.closest('[data-del]');
      if (del) {
        e.stopPropagation();
        if (confirm('Excluir esta conversa?')) {
          Store.deleteChat(del.dataset.del);
          this.renderSidebar(); this.renderChat();
        }
        return;
      }
      const item = e.target.closest('.chat-item');
      if (item) this.selectChat(item.dataset.id);
    });

    el.modelSelect.onchange = () => { Store.settings.model = el.modelSelect.value; Store.saveSettings(); this.syncLabels(); };

    el.bubble.onclick = () => this.togglePanel();
    el.widgetClose.onclick = () => this.togglePanel(false);
    el.splashEnter.onclick = () => this.enterApp();

    el.closeSettings.onclick = () => this.closeSettings();
    el.settings.addEventListener('click', e => { if (e.target === el.settings) this.closeSettings(); });

    $('swatches').addEventListener('click', e => {
      const b = e.target.closest('.swatch');
      if (!b) return;
      Store.settings.palette = b.dataset.p;
      Store.saveSettings();
      this.applySettings();
    });

    $('toggle-key').onclick = () => { const i = $('s-key'); i.type = i.type === 'password' ? 'text' : 'password'; };

    $('test-key').onclick = async () => {
      const st = $('key-status');
      st.textContent = 'testando...';
      try {
        await Api.stream({ model: Store.settings.model, max_tokens: 16, messages: [{ role: 'user', content: 'Responda apenas: OK' }], onText() {} });
        st.textContent = '✅ Chave funcionando';
      } catch (e) { st.textContent = '❌ ' + e.message; }
    };

    $('export-chats').onclick = () => {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([Store.exportJSON()], { type: 'application/json' }));
      a.download = 'minha-ia-conversas.json';
      a.click();
    };
    $('clear-chats').onclick = () => {
      if (!confirm('Apagar todas as conversas deste navegador?')) return;
      Store.clearAll(); this.renderSidebar(); this.renderChat(); this.toast('Conversas apagadas');
    };
    $('wipe-all').onclick = () => {
      if (!confirm('Apagar TODAS as configurações, chave e conversas deste navegador?')) return;
      localStorage.clear(); location.reload();
    };
    this.bindSettings();

    // arrastar e soltar arquivos na janela
    document.addEventListener('dragover', e => { e.preventDefault(); document.body.classList.add('dragging'); });
    document.addEventListener('dragleave', e => { if (!e.relatedTarget) document.body.classList.remove('dragging'); });
    document.addEventListener('drop', e => {
      e.preventDefault();
      document.body.classList.remove('dragging');
      if (e.dataTransfer?.files?.length) Files.addFiles([...e.dataTransfer.files]);
    });

    document.addEventListener('keydown', e => {
      const splashOn = !el.splash.classList.contains('hidden') && !el.splash.classList.contains('out');
      if (splashOn && e.key === 'Enter') { e.preventDefault(); this.enterApp(); return; }
      if (e.altKey && e.key.toLowerCase() === 'b' && Store.settings.widget) this.togglePanel();
      if (e.key === 'Escape') { this.closeSettings(); el.sidebar.classList.remove('show'); }
    });
  },
};

document.addEventListener('DOMContentLoaded', () => App.init());
