/* ===== Leitura de anexos: imagens, PDFs, documentos, vídeos, textos e ZIP ===== */
const Files = {
  pending: [],
  MAX_BYTES: 20 * 1024 * 1024,
  TEXT_EXT: ['txt','md','csv','tsv','json','js','ts','jsx','tsx','py','html','htm','css','xml','yml','yaml','log','sql','sh','java','c','cpp','h','go','rs','rb','php','ini','toml','env'],

  ext(name) { return (name.split('.').pop() || '').toLowerCase(); },

  kindOf(file) {
    const e = this.ext(file.name);
    if (file.type.startsWith('image/') || ['png','jpg','jpeg','gif','webp','bmp'].includes(e)) return 'image';
    if (file.type.startsWith('video/') || ['mp4','webm','mov','m4v','ogv'].includes(e)) return 'video';
    if (e === 'pdf') return 'pdf';
    if (['docx','pptx','xlsx'].includes(e)) return 'office';
    if (e === 'zip') return 'zip';
    if (this.TEXT_EXT.includes(e) || file.type.startsWith('text/')) return 'text';
    return 'unsupported';
  },

  async addFiles(list) {
    for (const file of list) {
      const kind = this.kindOf(file);
      const item = { id: Store.uid(), file, name: file.name, size: file.size, kind, previewUrl: null, blocks: [], error: null, info: '', loading: true };
      this.pending.push(item);
      if (kind === 'image' || kind === 'video') item.previewUrl = URL.createObjectURL(file);
      App.renderAttachments();

      if (file.size > this.MAX_BYTES) { item.error = 'Maior que 20 MB'; }
      else if (kind === 'unsupported') { item.error = 'Formato não suportado diretamente'; }
      else {
        try { await this.process(file, item); }
        catch (e) { item.error = 'Erro ao ler: ' + e.message; }
      }
      item.loading = false;
      App.renderAttachments();
    }
  },

  // Usado no envio: só anexos prontos e sem erro
  takeReady() {
    const ok = this.pending.filter(p => !p.loading && !p.error && p.blocks.length);
    this.pending = [];
    return ok;
  },

  remove(id) {
    const p = this.pending.find(x => x.id === id);
    if (p?.previewUrl) URL.revokeObjectURL(p.previewUrl);
    this.pending = this.pending.filter(x => x.id !== id);
  },

  clip(t) { return t.length > 300000 ? t.slice(0, 300000) + '\n\n[... conteúdo truncado ...]' : t; },

  async process(file, item) {
    switch (item.kind) {
      case 'image':
        item.blocks = await this.imageBlocks(item.previewUrl);
        item.info = 'imagem pronta';
        break;
      case 'video':
        item.blocks = await this.videoBlocks(item);
        item.info = `${item.frames} quadros extraídos`;
        break;
      case 'pdf':
        item.blocks = [{ type: 'document', title: file.name, source: { type: 'base64', media_type: 'application/pdf', data: await this.b64(file) } }];
        item.info = 'PDF pronto';
        break;
      case 'text':
        item.blocks = [{ type: 'text', text: `Arquivo "${file.name}":\n\n${this.clip(await file.text())}` }];
        item.info = 'texto lido';
        break;
      case 'office':
        item.blocks = [{ type: 'text', text: `Conteúdo extraído de "${file.name}":\n\n${this.clip(await this.officeText(file))}` }];
        item.info = 'texto extraído';
        break;
      case 'zip':
        item.blocks = [{ type: 'text', text: this.clip(await this.zipText(file)) }];
        item.info = 'ZIP lido';
        break;
    }
  },

  b64(file) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result.split(',')[1]);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(file);
    });
  },

  loadImg(url) {
    return new Promise((res, rej) => {
      const i = new Image();
      i.onload = () => res(i);
      i.onerror = () => rej(new Error('imagem inválida ou não suportada pelo navegador'));
      i.src = url;
    });
  },

  // Redimensiona para no máx. 1568px (recomendado pela API) e envia em JPEG
  async imageBlocks(url) {
    const img = await this.loadImg(url);
    const scale = Math.min(1, 1568 / Math.max(img.naturalWidth, img.naturalHeight));
    const c = document.createElement('canvas');
    c.width = Math.round(img.naturalWidth * scale);
    c.height = Math.round(img.naturalHeight * scale);
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0, c.width, c.height);
    const data = c.toDataURL('image/jpeg', 0.9).split(',')[1];
    return [{ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data } }];
  },

  seek(v, t) {
    return new Promise(res => {
      const done = () => { v.removeEventListener('seeked', done); res(); };
      v.addEventListener('seeked', done);
      setTimeout(done, 1500);
      v.currentTime = t;
    });
  },

  // Vídeo: a API não aceita vídeo diretamente, então extraímos quadros espalhados ao longo do tempo
  async videoBlocks(item) {
    const v = document.createElement('video');
    v.muted = true; v.playsInline = true; v.preload = 'auto';
    v.src = item.previewUrl;
    await new Promise((res, rej) => {
      v.onloadedmetadata = res;
      v.onerror = () => rej(new Error('vídeo não suportado por este navegador'));
    });
    const dur = isFinite(v.duration) ? v.duration : 0;
    const N = dur ? Math.min(8, Math.max(2, Math.round(dur / 6))) : 4;
    const vw = v.videoWidth || 768, vh = v.videoHeight || 432;
    const W = Math.min(768, vw), H = Math.round(W * vh / vw);
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const ctx = c.getContext('2d');

    const blocks = [{ type: 'text', text: `Vídeo "${item.name}" (duração ${dur.toFixed(1)} s). Abaixo seguem ${N} quadros extraídos ao longo do tempo. O áudio não foi analisado.` }];
    for (let i = 0; i < N; i++) {
      const t = dur ? Math.max(0, Math.min((dur * (i + 0.5)) / N, dur - 0.1)) : 0;
      await this.seek(v, t);
      ctx.drawImage(v, 0, 0, W, H);
      blocks.push({ type: 'text', text: `Quadro ${i + 1} (${t.toFixed(1)} s):` });
      blocks.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: c.toDataURL('image/jpeg', 0.8).split(',')[1] } });
    }
    item.frames = N;
    return blocks;
  },

  /* ---------- Leitor de ZIP embutido (sem bibliotecas externas) ---------- */
  async unzip(buffer) {
    const dv = new DataView(buffer), u8 = new Uint8Array(buffer), dec = new TextDecoder();
    let eocd = -1;
    for (let i = buffer.byteLength - 22; i >= Math.max(0, buffer.byteLength - 65557); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('arquivo ZIP inválido');
    const count = dv.getUint16(eocd + 10, true);
    let off = dv.getUint32(eocd + 16, true);
    const files = new Map();
    for (let n = 0; n < count; n++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      const method = dv.getUint16(off + 10, true);
      const csize = dv.getUint32(off + 20, true);
      const nlen = dv.getUint16(off + 28, true);
      const xlen = dv.getUint16(off + 30, true);
      const clen = dv.getUint16(off + 32, true);
      const lho = dv.getUint32(off + 42, true);
      const name = dec.decode(u8.subarray(off + 46, off + 46 + nlen));
      off += 46 + nlen + xlen + clen;
      const start = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true);
      const data = u8.subarray(start, start + csize);
      let bytes = null;
      if (method === 0) bytes = data;
      else if (method === 8 && 'DecompressionStream' in window) {
        const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
        bytes = new Uint8Array(await new Response(stream).arrayBuffer());
      }
      if (bytes && !name.endsWith('/')) files.set(name, bytes);
    }
    return files;
  },

  decodeX(s) {
    return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'")
      .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d)).replace(/&amp;/g, '&');
  },

  async officeText(file) {
    const zip = await this.unzip(await file.arrayBuffer());
    const dec = new TextDecoder();
    const ext = this.ext(file.name);
    const xml = n => dec.decode(zip.get(n));
    const num = n => parseInt(n.replace(/\D/g, ''), 10) || 0;
    const byNum = re => [...zip.keys()].filter(n => re.test(n)).sort((a, b) => num(a) - num(b));
    const paras = s => s.split(/<\/(?:w|a):p>/)
      .map(p => [...p.matchAll(/<(?:w|a):t(?:\s[^>]*)?>([\s\S]*?)<\/(?:w|a):t>/g)].map(m => this.decodeX(m[1])).join(''))
      .filter(Boolean).join('\n');

    if (ext === 'docx') {
      return zip.has('word/document.xml') ? paras(xml('word/document.xml')) : 'Não foi possível localizar o texto do documento.';
    }
    if (ext === 'pptx') {
      return byNum(/^ppt\/slides\/slide\d+\.xml$/).map((n, i) => `--- Slide ${i + 1} ---\n` + paras(xml(n))).join('\n\n') || 'Apresentação sem texto legível.';
    }
    // xlsx
    const ss = zip.has('xl/sharedStrings.xml')
      ? (xml('xl/sharedStrings.xml').match(/<si>[\s\S]*?<\/si>/g) || []).map(si => this.decodeX(si.replace(/<[^>]+>/g, '')))
      : [];
    const sheets = byNum(/^xl\/worksheets\/sheet\d+\.xml$/);
    return sheets.map((n, i) => {
      const rows = (xml(n).match(/<row[\s\S]*?<\/row>/g) || []).map(row => {
        const cells = [];
        for (const m of row.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
          const t = (m[1].match(/\bt="(\w+)"/) || [])[1];
          const inner = m[2] || '';
          const raw = (inner.match(/<v>([\s\S]*?)<\/v>/) || [])[1] || '';
          let v;
          if (t === 's') v = ss[+raw] ?? '';
          else if (t === 'inlineStr') v = this.decodeX(inner.replace(/<[^>]+>/g, ''));
          else v = this.decodeX(raw);
          cells.push(v);
        }
        return cells.join(' | ');
      });
      return `--- Planilha ${i + 1} ---\n` + rows.filter(r => r.replace(/[ |]/g, '')).join('\n');
    }).join('\n\n') || 'Planilha sem conteúdo legível.';
  },

  async zipText(file) {
    const zip = await this.unzip(await file.arrayBuffer());
    const dec = new TextDecoder();
    const TEXT = /\.(txt|md|csv|json|js|ts|py|html|css|xml|log|sql|sh|yml|yaml)$/i;
    let out = `Conteúdo do ZIP "${file.name}" (${zip.size} arquivos legíveis):\n`;
    for (const [name, bytes] of zip) out += `- ${name} (${(bytes.length / 1024).toFixed(1)} KB)\n`;
    let read = 0;
    for (const [name, bytes] of zip) {
      if (!TEXT.test(name) || bytes.length > 200000 || read > 400000) continue;
      read += bytes.length;
      out += `\n--- ${name} ---\n${dec.decode(bytes)}\n`;
    }
    return out;
  },
};
