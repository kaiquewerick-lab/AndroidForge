# Minha IA Privada (com Claude)

Uma interface de IA particular, feita só para você, que conversa com os modelos do Claude usando a sua própria API Key.

## Como abrir

1. Extraia o ZIP em uma pasta qualquer.
2. Dê dois cliques em **index.html** (funciona no Chrome, Edge, Firefox ou Safari, sem instalar nada).
3. Na capa, clique em **Entrar ✦** (ou aperte Enter).
4. Abra ⚙ **Configurações** e cole sua **API Key** (crie em console.anthropic.com). Você também pode colar direto na tela inicial.

## O que você pode fazer

- **Modelos:** Claude Fable 5.2, Opus 5.5, Sonnet 5.5 e Haiku 5.5. Troque no seletor do topo a qualquer momento.
- **Anexos (botão 📎 ou arrastar e soltar na janela):**
  - **Imagens** (PNG, JPG, WEBP, GIF): enviadas diretamente ao Claude.
  - **PDF:** enviado diretamente, com leitura de texto e de páginas.
  - **Documentos Word, PowerPoint e Excel** (.docx, .pptx, .xlsx): o texto é extraído e enviado.
  - **Vídeos** (MP4, WEBM, MOV): são enviados como vários quadros extraídos ao longo do tempo. O áudio não é analisado.
  - **ZIP:** a lista de arquivos e o conteúdo dos arquivos de texto são lidos.
  - **Textos e código** (TXT, MD, CSV, JSON, JS, PY, HTML etc.).
- **Configurações:** tema claro/escuro, 5 paletas de cor, tamanho da letra, animações, partículas de fundo, capa animada, personalidade (instruções do sistema) e tamanho da resposta.
- **Modo balão (pop-up):** em Configurações, ative "Modo balão". A janela sai da tela e fica um balãozinho ✦ no canto inferior direito. Clique nele para abrir o chat flutuante, com seletor de modelo, configurações e tudo mais. Atalho: **Alt+B**.
- **Exportar** suas conversas em JSON e **apagar** dados quando quiser.

## Privacidade

- Conversas, configurações e a API Key ficam **somente no armazenamento do seu navegador** (localStorage).
- A API Key é enviada apenas para `api.anthropic.com`, diretamente do seu navegador.
- Não existe servidor intermediário deste projeto.
- Observação: a chave fica salva sem criptografia no navegador. Use em computadores de confiança e não publique esta pasta com a sua chave dentro.
- Anexos não são salvos no histórico. Depois de recarregar a página, as miniaturas somem, mas o texto da conversa permanece.

## Limitações conhecidas

- Vídeo: só são analisados alguns quadros, não o áudio nem o movimento completo.
- Office (.docx, .pptx, .xlsx): só o texto é extraído, sem imagens, gráficos ou formatação.
- Limite de 20 MB por arquivo.
- Para Office e ZIP, o navegador precisa suportar `DecompressionStream` (Chrome 80+, Edge 80+, Firefox 113+, Safari 16.4+).
- Os custos de uso são cobrados pela sua conta na Anthropic, de acordo com o modelo e o tamanho das mensagens.

## Estrutura

```
index.html        → página principal
css/style.css     → visual, temas e animações
js/store.js       → configurações e conversas (local)
js/api.js         → conexão com a API do Claude (streaming)
js/files.js       → leitura de imagens, PDFs, Office, vídeos e ZIP
js/effects.js     → partículas e efeitos da capa
js/app.js         → interface, chat, configurações e modo balão
```
