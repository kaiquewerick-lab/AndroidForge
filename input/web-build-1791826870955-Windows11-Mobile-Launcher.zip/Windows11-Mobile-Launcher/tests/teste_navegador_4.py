# -*- coding: utf-8 -*-
"""
Testes de regressão desta versão (requer: pip install playwright && playwright install chromium).

Verifica:
  1. Nenhum emoji ou símbolo pictórico no texto renderizado nem em rótulos/atributos visíveis.
  2. Ícones do desktop em grade correta (sem sobreposição e espaçados pela célula).
  3. Escala de exibição (DPI): a interface muda de tamanho, as janelas continuam dentro da tela,
     e arrastar um ícone funciona com a escala aplicada.
  4. Tecla Delete exclui um item uma única vez no Explorador.
  5. Copiar um item para outra pasta não o renomeia com "(2)".
  6. Bloco de Notas não ressuscita rascunho descartado.
  7. Botões da bandeja fecham o painel ao serem clicados de novo.
  8. Sem erros de JavaScript durante a navegação.

Uso: python tests/teste_navegador_4.py   (imprime PASS/FAIL; código de saída 1 se houver falha)
"""
import pathlib
import re
import sys
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL = (ROOT / "web" / "index.html").as_uri()

# Faixas Unicode de emojis e símbolos pictóricos
EMOJI_RE = re.compile(
    "[\U0001F000-\U0001FAFF\u2600-\u27BF\u2300-\u23FF\u2B00-\u2BFF\u25A0-\u25FF"
    "\u2190-\u21FF\uFE0F\u200D\u00A9\u00AE\u2122]"
)

results = []


def check(name, ok, detail=""):
    results.append(ok)
    print(("PASS" if ok else "FAIL"), name, ("- " + detail) if detail else "")


def visible_strings(page):
    """Textos e atributos visíveis ao usuário (texto, aria-label, title, placeholder, alt)."""
    return page.evaluate("""() => {
        const out = [];
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let n; while ((n = walker.nextNode())) { const t = n.nodeValue.trim(); if (t) out.push(t); }
        document.querySelectorAll('[aria-label],[title],[placeholder],[alt]').forEach(el => {
            ['aria-label', 'title', 'placeholder', 'alt'].forEach(a => { const v = el.getAttribute(a); if (v) out.push(v); });
        });
        return out;
    }""")


def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        page = browser.new_page(viewport={"width": 1100, "height": 760})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        page.goto(URL)
        page.wait_for_timeout(400)

        # 1. Emojis
        # Textos de conteúdo do usuário (Bem-vindo.txt) não são emojis, então verificamos a interface toda
        page.evaluate("W11Apps.open('explorer'); W11Apps.open('calculator'); W11Apps.open('settings', {page: 'exibicao'})")
        page.evaluate("W11Taskbar.openStart()")
        page.wait_for_timeout(250)
        strings = visible_strings(page)
        bad = sorted({s for s in strings if EMOJI_RE.search(s)})
        check("sem emojis ou símbolos pictóricos na interface", not bad, "; ".join(bad[:8]))
        html_bad = page.evaluate("""() => /[\\u{1F000}-\\u{1FAFF}\\u2600-\\u27BF]/u.test(document.body.innerHTML)""")
        check("sem emojis no HTML (inclusive atributos)", not html_bad)
        page.evaluate("W11Taskbar.closeStart()")
        page.evaluate("document.querySelectorAll('.win').forEach(w => w.remove())")
        page.evaluate("W11Windows.list().length && W11Windows.list().forEach(w => W11Windows.close(w))")

        # 2. Grade de ícones
        page.evaluate("W11Notify.clear()")
        page.wait_for_timeout(100)
        rects = page.evaluate("""() => [...document.querySelectorAll('.icon')].map(e => {
            const r = e.getBoundingClientRect(); return {x: r.left, y: r.top, w: r.width, h: r.height}; })""")
        overlap = False
        for i in range(len(rects)):
            for j in range(i + 1, len(rects)):
                a, b = rects[i], rects[j]
                if a["x"] < b["x"] + b["w"] and b["x"] < a["x"] + a["w"] and a["y"] < b["y"] + b["h"] and b["y"] < a["y"] + a["h"]:
                    overlap = True
        check("ícones do desktop não se sobrepõem", not overlap and len(rects) > 0, f"{len(rects)} ícones")
        ys = sorted({round(r["y"]) for r in rects})
        gaps_ok = all((ys[i + 1] - ys[i]) < 130 for i in range(len(ys) - 1)) if len(ys) > 1 else True
        check("ícones em grade compacta (sem vãos grandes)", gaps_ok, f"linhas: {ys[:4]}")

        # 3. Escala de exibição
        page.evaluate("W11Screen.set(125)")
        page.wait_for_timeout(120)
        tf = page.evaluate("getComputedStyle(document.getElementById('screen')).transform")
        check("escala 125% aplicada (transform)", "matrix" in tf and "1.25" in tf, tf)
        page.evaluate("W11Apps.open('notepad')")
        page.wait_for_timeout(200)
        win = page.locator(".win").last
        bb = win.bounding_box()
        vw, vh = 1100, 760
        check("janela dentro da tela com escala 125%", bb["x"] >= 0 and bb["y"] >= 0 and bb["x"] + bb["width"] <= vw + 1 and bb["y"] + bb["height"] <= vh + 1,
              f"x={round(bb['x'])} y={round(bb['y'])} w={round(bb['width'])} h={round(bb['height'])}")
        # Arrastar pela barra com a escala aplicada: o deslocamento na tela deve bater com o do mouse
        tb = win.locator(".win-titlebar").bounding_box()
        before = win.bounding_box()
        page.mouse.move(tb["x"] + 80, tb["y"] + 10)
        page.mouse.down()
        page.mouse.move(tb["x"] + 80 + 100, tb["y"] + 10 + 40, steps=8)
        page.mouse.up()
        after = win.bounding_box()
        dx, dy = round(after["x"] - before["x"]), round(after["y"] - before["y"])
        check("arrastar janela com escala 125% acompanha o mouse", abs(dx - 100) <= 3 and abs(dy - 40) <= 3, f"moveu {dx},{dy} (esperado 100,40)")
        page.evaluate("W11Screen.set(100)")
        page.wait_for_timeout(120)
        page.evaluate("W11Windows.list().forEach(w => W11Windows.close(w))")

        # 4. Delete uma única vez
        created = page.evaluate("W11FS.create('docs', 'Teste Delete.txt', 'file', 'x').ok")
        page.evaluate("W11Apps.open('explorer', {folderId: 'docs'})")
        page.wait_for_timeout(150)
        ex = page.locator(".win").last
        ex.locator(".fitem", has_text="Teste Delete.txt").click()
        before_count = page.evaluate("W11FS.children('docs').length")
        page.keyboard.press("Delete")
        page.wait_for_timeout(150)
        after_count = page.evaluate("W11FS.children('docs').length")
        check("Delete remove exatamente um item", created and before_count - after_count == 1,
              f"antes={before_count} depois={after_count}")
        page.evaluate("W11Windows.list().forEach(w => W11Windows.close(w))")

        # 5. Copiar para outra pasta sem renomear
        page.evaluate("W11FS.create('docs', 'Relatorio.txt', 'file', 'abc')")
        src = page.evaluate("W11FS.children('docs').find(c => c.name === 'Relatorio.txt').id")
        page.evaluate(f"W11FS.copy(['{src}'], 'images')")
        names = page.evaluate("W11FS.children('images').map(c => c.name)")
        check("copiar para outra pasta mantém o nome", "Relatorio.txt" in names, str(names))

        # 6. Rascunho do Bloco de Notas
        page.evaluate("W11Apps.open('notepad')")
        page.wait_for_timeout(150)
        nw = page.locator(".win").last
        nw.locator("textarea").fill("rascunho antigo")
        page.wait_for_timeout(500)
        nw.locator('[data-act="new"]').click()
        page.wait_for_timeout(200)
        # Confirma o descarte no diálogo
        page.locator(".dialog .btn.primary").click()
        page.wait_for_timeout(200)
        draft = page.evaluate("W11Storage.get('notepadDraft', null)")
        check("Novo descarta o rascunho salvo", draft is None, str(draft))
        page.evaluate("W11Windows.list().forEach(w => W11Windows.close(w))")

        # 7. Botões da bandeja alternam o painel
        page.locator("#btn-clock").click()
        page.wait_for_timeout(80)
        open1 = page.evaluate("!document.getElementById('calendar-panel').classList.contains('hidden')")
        page.locator("#btn-clock").click()
        page.wait_for_timeout(80)
        open2 = page.evaluate("!document.getElementById('calendar-panel').classList.contains('hidden')")
        check("relógio abre e fecha o calendário ao clicar de novo", open1 and not open2, f"abriu={open1} depois={open2}")

        # 8. Erros de script
        check("sem erros de JavaScript", not errors, "; ".join(errors[:5]))
        browser.close()

    total = len(results)
    failed = results.count(False)
    print(f"\n{total - failed}/{total} verificações passaram")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(run())
