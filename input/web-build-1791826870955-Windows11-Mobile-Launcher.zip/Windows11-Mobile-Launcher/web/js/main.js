/*
 * main.js - Inicialização do launcher e pontes de retorno para o Android.
 *
 * Hooks chamados pelo Android (MainActivity), todos sem argumentos perigosos:
 *   window.onAppsChanged()  -> a lista de apps instalados mudou
 *   window.handleBack()     -> botão Voltar: retorna true se tratou a ação
 */
(function () {
  "use strict";

  function start() {
    // A escala (DPI) vem primeiro: os demais módulos já trabalham no tamanho lógico
    W11Screen.init();
    W11Icons.mount(document);
    W11Windows.init();
    W11Desktop.init();
    W11Taskbar.init();
    W11Keys.init();
    W11Settings.apply();
    W11Desktop.loadApps();

    // Aviso quando a página roda fora do APK (modo de visualização)
    if (!W11Bridge.isNative) {
      W11Notify.push("Modo de visualização", "Aplicativos Android só aparecem dentro do APK.");
    }
    document.documentElement.classList.add("ready");
  }

  // Android chama após instalar/remover um app (BroadcastReceiver).
  window.onAppsChanged = function () {
    W11Desktop.loadApps();
    W11Notify.push("Aplicativos", "A lista de aplicativos foi atualizada.");
    W11UI.toast("Lista de aplicativos atualizada.", "ok", 2200);
  };

  // Botão Voltar: fecha o que estiver aberto antes de sair da tela inicial.
  window.handleBack = function () {
    if (W11UI.isMenuOpen()) { W11UI.hideMenu(); return true; }
    if (W11Taskbar.isStartOpen()) { W11Taskbar.closeStart(); return true; }
    var flyoutOpen = ["notif-panel", "quick-panel", "calendar-panel"].some(function (id) {
      return !document.getElementById(id).classList.contains("hidden");
    });
    if (flyoutOpen) { W11Taskbar.hideFlyouts(); return true; }
    var top = W11Windows.active();
    if (top) { W11Windows.close(top); return true; }
    return false; // nada aberto: o Android decide (MainActivity)
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
