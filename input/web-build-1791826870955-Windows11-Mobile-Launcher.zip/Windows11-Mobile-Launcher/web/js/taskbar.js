/*
 * taskbar.js - Barra de tarefas, menu Iniciar, pesquisa, calendário,
 * configurações rápidas, notificações próprias e visão de tarefas.
 */
(function () {
  "use strict";

  var startEl, startSearch, pinnedEl, allEl, resultsEl, allSection, pinnedSection, resultsSection;
  var startOpen = false;
  var kbIndex = -1;
  var calDate = new Date();
  var CLOSE_MS = 180;

  function esc(s) { return W11UI.escape(s); }

  function appTile(label, iconHtml, onClick) {
    var b = document.createElement("button");
    b.className = "app-tile";
    b.innerHTML = iconHtml + "<span></span>";
    b.querySelector("span").textContent = label;
    b.addEventListener("click", onClick);
    return b;
  }

  function appRow(label, iconHtml, meta, onClick) {
    var b = document.createElement("button");
    b.className = "app-row";
    b.innerHTML = iconHtml + "<span></span>" + (meta ? '<span class="meta"></span>' : "");
    b.querySelector("span").textContent = label;
    if (meta) b.querySelector(".meta").textContent = meta;
    b.addEventListener("click", onClick);
    return b;
  }

  function androidIcon(pkg, label) {
    var src = W11Bridge.getIcon(pkg);
    if (src) return '<div class="icon-img"><img alt="" src="' + src + '"></div>';
    return '<div class="icon-img">' + esc((label || "?").charAt(0).toUpperCase()) + '</div>';
  }

  function internalIcon(s) {
    return '<div class="icon-img">' + W11Icons.svg(s.icon) + '</div>';
  }

  function renderStart() {
    pinnedEl.innerHTML = "";
    (W11Apps.shortcuts || []).forEach(function (s) {
      pinnedEl.appendChild(appTile(s.label, internalIcon(s), function () { closeStart(); W11Apps.open(s.id); }));
    });
    W11Desktop.getPinned().forEach(function (pkg) {
      var a = W11Desktop.getAndroidApps().find(function (x) { return x.pkg === pkg; });
      if (!a) return;
      pinnedEl.appendChild(appTile(a.label, androidIcon(a.pkg, a.label), function () {
        closeStart(); W11Desktop.launch({ kind: "android", ref: a.pkg, label: a.label });
      }));
    });
    allEl.innerHTML = "";
    var all = [];
    (W11Apps.shortcuts || []).forEach(function (s) { all.push({ label: s.label, icon: internalIcon(s), meta: "Interno", run: function () { W11Apps.open(s.id); } }); });
    W11Desktop.getAndroidApps().forEach(function (a) {
      all.push({ label: a.label, icon: androidIcon(a.pkg, a.label), meta: "Android", run: function () { W11Desktop.launch({ kind: "android", ref: a.pkg, label: a.label }); } });
    });
    all.sort(function (x, y) { return x.label.localeCompare(y.label, "pt-BR", { sensitivity: "base" }); });
    all.forEach(function (it) {
      allEl.appendChild(appRow(it.label, it.icon, it.meta, function () { closeStart(); it.run(); }));
    });
  }

  function renderResults(q) {
    resultsEl.innerHTML = "";
    var needle = q.trim().toLowerCase();
    var count = 0;
    if (!needle) return 0;
    (W11Apps.shortcuts || []).forEach(function (s) {
      if (s.label.toLowerCase().indexOf(needle) !== -1) {
        count++;
        resultsEl.appendChild(appRow(s.label, internalIcon(s), "Interno", function () { closeStart(); W11Apps.open(s.id); }));
      }
    });
    W11Desktop.getAndroidApps().forEach(function (a) {
      if (a.label.toLowerCase().indexOf(needle) !== -1 || a.pkg.toLowerCase().indexOf(needle) !== -1) {
        count++;
        resultsEl.appendChild(appRow(a.label, androidIcon(a.pkg, a.label), "Android", function () {
          closeStart(); W11Desktop.launch({ kind: "android", ref: a.pkg, label: a.label });
        }));
      }
    });
    if (window.W11FS) {
      W11FS.search(needle).slice(0, 20).forEach(function (f) {
        count++;
        resultsEl.appendChild(appRow(f.name, '<div class="icon-img">' + W11Icons.svg(f.type === "folder" ? "folder" : "file") + '</div>', f.path, function () {
          closeStart(); W11Apps.openPath(f.path);
        }));
      });
    }
    if (count === 0) {
      var p = document.createElement("p");
      p.className = "muted pad";
      p.textContent = "Nada encontrado para “" + q + "”.";
      resultsEl.appendChild(p);
    }
    return count;
  }

  function setSections(mode) {
    // mode: "pinned" | "all" | "results"
    pinnedSection.classList.toggle("hidden", mode !== "pinned");
    allSection.classList.toggle("hidden", mode !== "all");
    resultsSection.classList.toggle("hidden", mode !== "results");
  }

  function openStart() {
    if (startOpen) return;
    startOpen = true;
    renderStart();
    startEl.classList.remove("hidden", "closing");
    startSearch.value = "";
    setSections("pinned");
    document.getElementById("btn-start").setAttribute("aria-expanded", "true");
    kbIndex = -1;
    setTimeout(function () { startSearch.focus(); }, 40);
  }

  function closeStart() {
    if (!startOpen) return;
    startOpen = false;
    startEl.classList.add("closing");
    document.getElementById("btn-start").setAttribute("aria-expanded", "false");
    setTimeout(function () {
      if (!startOpen) { startEl.classList.add("hidden"); startEl.classList.remove("closing"); }
    }, CLOSE_MS);
    kbIndex = -1;
  }

  function toggleStart() { startOpen ? closeStart() : openStart(); }

  function visibleStartItems() {
    var sections = [pinnedSection, allSection, resultsSection];
    var visible = sections.find(function (s) { return !s.classList.contains("hidden"); });
    return visible ? Array.prototype.slice.call(visible.querySelectorAll("button.app-row, button.app-tile")) : [];
  }

  function hideFlyouts() {
    ["notif-panel", "quick-panel", "calendar-panel"].forEach(function (id) {
      document.getElementById(id).classList.add("hidden");
    });
    document.getElementById("power-menu").classList.add("hidden");
    ["btn-quick", "btn-clock", "btn-notif", "btn-taskview"].forEach(function (id) {
      var b = document.getElementById(id); if (b) b.classList.remove("active");
    });
  }

  // ---------- Relógio e calendário ----------
  function tickClock() {
    var now = new Date();
    document.getElementById("clock-time").textContent = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
    document.getElementById("clock-date").textContent = now.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
  }

  function renderCalendar() {
    var panel = document.getElementById("calendar-panel");
    var y = calDate.getFullYear(), m = calDate.getMonth();
    var first = new Date(y, m, 1).getDay();
    var days = new Date(y, m + 1, 0).getDate();
    var prevDays = new Date(y, m, 0).getDate();
    var today = new Date();
    var names = ["D", "S", "T", "Q", "Q", "S", "S"];
    var html = '<div class="cal-head"><button class="icon-btn" data-cal="-1" aria-label="Mês anterior">' + W11Icons.svg("chevronL") + '</button>' +
      '<span>' + esc(calDate.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })) + '</span>' +
      '<button class="icon-btn" data-cal="1" aria-label="Próximo mês">' + W11Icons.svg("chevronR") + '</button></div>' +
      '<div class="cal-grid">';
    names.forEach(function (n) { html += '<div class="dow">' + n + '</div>'; });
    var cells = [];
    for (var i = first - 1; i >= 0; i--) cells.push({ d: prevDays - i, other: true });
    for (var d = 1; d <= days; d++) cells.push({ d: d, other: false });
    while (cells.length % 7 !== 0) cells.push({ d: cells.length - days - first + 1, other: true });
    cells.forEach(function (c) {
      var isToday = !c.other && today.getDate() === c.d && today.getMonth() === m && today.getFullYear() === y;
      html += '<div class="day' + (c.other ? " other" : "") + (isToday ? " today" : "") + '">' + c.d + '</div>';
    });
    html += '</div>';
    panel.innerHTML = html;
    panel.querySelectorAll("[data-cal]").forEach(function (b) {
      b.addEventListener("click", function () {
        calDate = new Date(y, m + Number(b.dataset.cal), 1);
        renderCalendar();
      });
    });
  }

  // ---------- Notificações próprias ----------
  var W11Notify = {
    list: function () { return W11Storage.get("notifications", []); },
    push: function (title, body) {
      var list = W11Notify.list();
      list.unshift({ title: title, body: body || "", t: Date.now() });
      if (list.length > 50) list.length = 50;
      W11Storage.set("notifications", list);
      updateBadge();
    },
    clear: function () {
      W11Storage.set("notifications", []);
      updateBadge();
    }
  };

  function updateBadge() {
    var n = W11Notify.list().length;
    var badge = document.getElementById("notif-badge");
    badge.textContent = String(n);
    badge.classList.toggle("hidden", n === 0);
  }

  function renderNotif() {
    var panel = document.getElementById("notif-panel");
    var list = W11Notify.list();
    panel.innerHTML = "<h3>Notificações</h3>" +
      (list.length ? "" : '<p class="muted">Nenhuma notificação. Notificações do próprio launcher aparecem aqui.</p>') +
      '<div id="notif-items"></div>' +
      (list.length ? '<div class="actions" style="display:flex;justify-content:flex-end"><button class="btn" id="notif-clear">Limpar tudo</button></div>' : "");
    var box = panel.querySelector("#notif-items");
    list.forEach(function (n) {
      var d = document.createElement("div");
      d.className = "notif-item";
      d.innerHTML = "<b></b><small></small>";
      d.querySelector("b").textContent = n.title;
      d.querySelector("small").textContent = n.body + " • " + new Date(n.t).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
      box.appendChild(d);
    });
    var clear = panel.querySelector("#notif-clear");
    if (clear) clear.addEventListener("click", function () { W11Notify.clear(); renderNotif(); });
  }

  // ---------- Configurações rápidas ----------
  function toggleTile(label, sub, on, onClick) {
    var b = document.createElement("button");
    b.className = "qs-tile" + (on ? " on" : "");
    b.innerHTML = "<span></span><small></small>";
    b.querySelector("span").textContent = label;
    b.querySelector("small").textContent = sub;
    b.addEventListener("click", onClick);
    return b;
  }

  function renderQuick() {
    var panel = document.getElementById("quick-panel");
    var scale = W11Screen.get();
    panel.innerHTML = "<h3>Configurações rápidas</h3><div class='toggle-grid' id='qs-grid'></div>" +
      "<div class='slider-row'><label for='qs-scale'>Escala de exibição</label>" +
        "<input type='range' id='qs-scale' min='" + W11Screen.MIN + "' max='" + W11Screen.MAX + "' step='" + W11Screen.STEP + "' value='" + scale + "' aria-label='Escala de exibição'>" +
        "<output id='qs-scale-out'>" + scale + "%</output></div>" +
      "<p class='muted'>Wi-Fi, Bluetooth, volume e brilho são controlados pelo Android. Os botões abaixo abrem a tela correspondente.</p>" +
      "<div class='toggle-grid' id='qs-sys'></div>";
    var scaleInput = panel.querySelector("#qs-scale");
    scaleInput.addEventListener("input", function () {
      panel.querySelector("#qs-scale-out").textContent = scaleInput.value + "%";
      W11Screen.set(Number(scaleInput.value));
    });
    var grid = panel.querySelector("#qs-grid");
    var theme = W11Storage.get("theme", "auto");
    var anim = W11Storage.get("animations", true);
    grid.appendChild(toggleTile("Tema escuro", theme === "dark" ? "Ativado" : "Desativado", theme === "dark", function () {
      W11Settings.setTheme(theme === "dark" ? "light" : "dark"); renderQuick();
    }));
    grid.appendChild(toggleTile("Animações", anim ? "Ativadas" : "Desativadas", anim, function () {
      W11Settings.setAnimations(!anim); renderQuick();
    }));
    grid.appendChild(toggleTile("Barra centralizada", W11Settings.getAlign() === "center" ? "Sim" : "Não", W11Settings.getAlign() === "center", function () {
      W11Settings.setAlign(W11Settings.getAlign() === "center" ? "left" : "center"); renderQuick();
    }));
    grid.appendChild(toggleTile("Janelas", W11Windows.list().length + " abertas", false, function () { showTaskView(); }));
    var sys = panel.querySelector("#qs-sys");
    [["wifi", "Wi-Fi"], ["bluetooth", "Bluetooth"], ["sound", "Som"], ["display", "Brilho"]].forEach(function (p) {
      sys.appendChild(toggleTile(p[1], "Abrir no Android", false, function () {
        if (!W11Bridge.openSystemSettings(p[0])) W11UI.toast("Ação disponível somente no APK, em Android.", "error");
      }));
    });
  }

  // ---------- Visão de tarefas ----------
  function showTaskView() {
    hideFlyouts();
    var panel = document.getElementById("quick-panel");
    panel.innerHTML = "<h3>Janelas abertas</h3><div id='tv-list' class='start-list'></div>";
    var list = panel.querySelector("#tv-list");
    var wins = W11Windows.recent();
    W11Windows.list().forEach(function (w) { if (wins.indexOf(w) === -1) wins.push(w); });
    if (!wins.length) list.innerHTML = "<p class='muted'>Nenhuma janela aberta.</p>";
    wins.forEach(function (w) {
      var b = document.createElement("button");
      b.className = "app-row";
      b.innerHTML = "<span class='tv-ico'></span><span class='tv-title'></span><span class='meta'></span>";
      b.querySelector(".tv-ico").innerHTML = W11Icons.svg(w.icon);
      b.querySelector(".tv-title").textContent = w.title;
      b.querySelector(".meta").textContent = w.state === "minimized" ? "Minimizada" : (w.state === "maximized" ? "Maximizada" : "Normal");
      b.addEventListener("click", function () { hideFlyouts(); W11Windows.restore(w); });
      list.appendChild(b);
    });
    panel.classList.remove("hidden");
    document.getElementById("btn-taskview").classList.add("active");
  }

  // ---------- Barra de tarefas (botões das janelas) ----------
  function renderTaskbarApps(wins) {
    var box = document.getElementById("taskbar-apps");
    box.innerHTML = "";
    var active = W11Windows.active();
    wins.forEach(function (w) {
      var b = document.createElement("button");
      b.className = "tb-btn" + (active === w ? " focused" : "") + (w.state === "minimized" ? " min" : "");
      b.setAttribute("aria-label", w.title + (w.state === "minimized" ? " (minimizada)" : ""));
      b.title = w.title;
      b.innerHTML = '<span class="tb-app-label"></span><span class="tb-indicator"></span>';
      b.querySelector(".tb-app-label").innerHTML = W11Icons.svg(w.icon);
      b.style.opacity = w.state === "minimized" ? "0.6" : "1";
      b.addEventListener("click", function () {
        if (active === w && w.state !== "minimized") W11Windows.minimize(w);
        else W11Windows.restore(w);
      });
      box.appendChild(b);
    });
  }

  var W11Taskbar = {
    init: function () {
      startEl = document.getElementById("start-menu");
      startSearch = document.getElementById("start-search");
      pinnedEl = document.getElementById("start-pinned");
      allEl = document.getElementById("start-all");
      resultsEl = document.getElementById("start-results");
      pinnedSection = document.getElementById("start-pinned-section");
      allSection = document.getElementById("start-all-section");
      resultsSection = document.getElementById("start-results-section");

      document.getElementById("btn-start").addEventListener("click", function (e) { e.stopPropagation(); hideFlyouts(); toggleStart(); });
      document.getElementById("btn-search").addEventListener("click", function (e) {
        e.stopPropagation(); hideFlyouts(); openStart();
      });
      document.getElementById("btn-taskview").addEventListener("click", function (e) {
        e.stopPropagation(); hideFlyouts(); showTaskView();
      });
      // Cada botão da bandeja abre o seu painel; clicar de novo nele fecha o painel
      function isOpen(id) { return !document.getElementById(id).classList.contains("hidden"); }
      document.getElementById("btn-clock").addEventListener("click", function (e) {
        e.stopPropagation();
        var was = isOpen("calendar-panel");
        hideFlyouts();
        if (was) return;
        calDate = new Date();
        renderCalendar();
        document.getElementById("calendar-panel").classList.remove("hidden");
        this.classList.add("active");
      });
      document.getElementById("btn-quick").addEventListener("click", function (e) {
        e.stopPropagation();
        var was = isOpen("quick-panel");
        hideFlyouts();
        if (was) return;
        renderQuick();
        document.getElementById("quick-panel").classList.remove("hidden");
        this.classList.add("active");
      });
      document.getElementById("btn-notif").addEventListener("click", function (e) {
        e.stopPropagation();
        var was = isOpen("notif-panel");
        hideFlyouts();
        if (was) return;
        renderNotif();
        document.getElementById("notif-panel").classList.remove("hidden");
        this.classList.add("active");
      });

      startSearch.addEventListener("input", function () {
        var q = startSearch.value;
        if (!q.trim()) { setSections("pinned"); kbIndex = -1; return; }
        renderResults(q);
        setSections("results");
        kbIndex = -1;
      });

      // Menu de energia
      document.getElementById("power-btn").addEventListener("click", function (e) {
        e.stopPropagation();
        document.getElementById("power-menu").classList.toggle("hidden");
      });
      startEl.addEventListener("click", function (e) {
        var act = e.target.closest("[data-action]");
        if (!act) return;
        var a = act.dataset.action;
        if (a === "show-all-apps") { setSections("all"); }
        else if (a === "show-pinned") { setSections("pinned"); }
        else if (a === "refresh-apps") { document.getElementById("power-menu").classList.add("hidden"); W11Desktop.refreshApps(); renderStart(); }
        else if (a === "reload-ui") { location.reload(); }
        else if (a === "exit-launcher") { W11Bridge.exitLauncher() || W11UI.toast("Saindo do launcher só está disponível no APK.", "error"); }
      });

      // Fecha painéis ao tocar fora
      document.addEventListener("pointerdown", function (e) {
        if (startOpen && !e.target.closest("#start-menu") && !e.target.closest("#btn-start") && !e.target.closest("#btn-search")) closeStart();
        if (!e.target.closest(".side-panel, .flyout, .taskbar, #power-menu, .toast-root")) hideFlyouts();
      });

      W11Windows.onChange(renderTaskbarApps);
      renderTaskbarApps(W11Windows.list());
      setInterval(tickClock, 15000);
      tickClock();
      updateBadge();
    },
    openStart: openStart,
    closeStart: closeStart,
    isStartOpen: function () { return startOpen; },
    /** Navegação por teclado no menu Iniciar. Retorna true se tratou a tecla. */
    startKey: function (key) {
      if (!startOpen) return false;
      if (key === "Escape") { closeStart(); return true; }
      var items = visibleStartItems();
      if (key === "ArrowDown" || key === "ArrowRight" || key === "ArrowUp" || key === "ArrowLeft") {
        if (!items.length) return true;
        kbIndex = key === "ArrowDown" || key === "ArrowRight"
          ? (kbIndex + 1) % items.length
          : (kbIndex <= 0 ? items.length - 1 : kbIndex - 1);
        items.forEach(function (b, i) { b.classList.toggle("kb-focus", i === kbIndex); });
        items[kbIndex].scrollIntoView({ block: "nearest" });
        return true;
      }
      if (key === "Enter" && kbIndex >= 0 && items[kbIndex]) { items[kbIndex].click(); return true; }
      return false;
    },
    showTaskView: showTaskView,
    hideFlyouts: hideFlyouts,
    renderCalendar: renderCalendar
  };

  window.W11Taskbar = W11Taskbar;
  window.W11Notify = W11Notify;
})();
