/*
 * calculator.js - Calculadora básica.
 * Avalia expressões com um analisador próprio (sem eval): + - * / ( ) e decimais.
 * Teclado: números, + - * /, ( ), vírgula ou ponto, Enter ou =, Backspace, Esc (limpar).
 */
(function () {
  "use strict";

  window.W11Impl = window.W11Impl || {};

  /** Avaliador seguro: recursive descent. Lança Error em entrada inválida. */
  function evaluate(src) {
    var s = src.replace(/\s+/g, "");
    if (!s) throw new Error("vazio");
    var pos = 0;
    function peek() { return s.charAt(pos); }
    function eat(ch) { if (peek() === ch) { pos++; return true; } return false; }
    function number() {
      var start = pos;
      while (/[0-9.]/.test(peek())) pos++;
      var txt = s.slice(start, pos);
      if (!txt || txt === "." || (txt.match(/\./g) || []).length > 1) throw new Error("número inválido");
      return parseFloat(txt);
    }
    function factor() {
      if (eat("-")) return -factor();
      if (eat("+")) return factor();
      if (eat("(")) {
        var v = expr();
        if (!eat(")")) throw new Error("parênteses");
        return v;
      }
      return number();
    }
    function term() {
      var v = factor();
      while (peek() === "*" || peek() === "/") {
        var op = s.charAt(pos++);
        var r = factor();
        if (op === "*") v *= r;
        else {
          if (r === 0) throw new Error("Divisão por zero");
          v /= r;
        }
      }
      return v;
    }
    function expr() {
      var v = term();
      while (peek() === "+" || peek() === "-") {
        var op = s.charAt(pos++);
        var r = term();
        v = op === "+" ? v + r : v - r;
      }
      return v;
    }
    var result = expr();
    if (pos !== s.length) throw new Error("expressão incompleta");
    if (!isFinite(result)) throw new Error("resultado inválido");
    // Evita erros de ponto flutuante na apresentação (ex.: 0.1 + 0.2)
    return Math.round(result * 1e10) / 1e10;
  }

  /**
   * Converte o resultado em texto decimal simples (sem notação científica),
   * para que ele possa ser usado de novo na conta seguinte.
   */
  function plain(n) {
    var s = String(n);
    if (!/e/i.test(s)) return s;
    if (Math.abs(n) >= 1e21) throw new Error("Número muito grande");
    return n.toFixed(12).replace(/\.?0+$/, "");
  }

  function fmt(text) {
    return text.replace(".", ",");
  }

  window.W11Impl.calculator = function (body, api) {
    var expr = "";
    var lastResult = null;

    body.innerHTML =
      '<div class="calc-wrap" tabindex="0" aria-label="Calculadora">' +
        '<div class="calc-display">' +
          '<div class="expr"></div>' +
          '<div class="result">0</div>' +
        '</div>' +
        '<div class="calc-keys">' +
          '<button data-k="C">C</button>' +
          '<button data-k="(">(</button>' +
          '<button data-k=")">)</button>' +
          '<button data-k="/" class="op">÷</button>' +
          '<button data-k="7">7</button>' +
          '<button data-k="8">8</button>' +
          '<button data-k="9">9</button>' +
          '<button data-k="*" class="op">×</button>' +
          '<button data-k="4">4</button>' +
          '<button data-k="5">5</button>' +
          '<button data-k="6">6</button>' +
          '<button data-k="-" class="op">−</button>' +
          '<button data-k="1">1</button>' +
          '<button data-k="2">2</button>' +
          '<button data-k="3">3</button>' +
          '<button data-k="+" class="op">+</button>' +
          '<button data-k="back" aria-label="Apagar último caractere">' + W11Icons.svg("backspace") + '</button>' +
          '<button data-k="0">0</button>' +
          '<button data-k=",">,</button>' +
          '<button data-k="=" class="eq">=</button>' +
        '</div>' +
      '</div>';

    var wrap = body.querySelector(".calc-wrap");
    var exprEl = body.querySelector(".expr");
    var resultEl = body.querySelector(".result");

    function render(resultText) {
      exprEl.textContent = expr.replace(/\*/g, "×").replace(/\//g, "÷").replace(/-/g, "−");
      resultEl.textContent = resultText !== undefined ? resultText : (expr || "0");
    }

    function press(k) {
      if (k === "C") { expr = ""; lastResult = null; render("0"); return; }
      if (k === "back") {
        if (lastResult !== null) { expr = ""; lastResult = null; }
        expr = expr.slice(0, -1);
        render();
        return;
      }
      if (k === "=") {
        try {
          var v = evaluate(expr.replace(/,/g, "."));
          var txt = plain(v);
          lastResult = v;
          render(fmt(txt));
          expr = txt;
        } catch (e) {
          render(e.message === "Divisão por zero" || e.message === "Número muito grande" ? e.message : "Erro");
          lastResult = null;
          expr = "";
        }
        return;
      }
      if (k === ",") k = ".";
      if (lastResult !== null) {
        // Após "=", digitar número recomeça; operador continua do resultado
        if (/[0-9.(]/.test(k)) expr = "";
        lastResult = null;
      }
      if (/[0-9]/.test(k) || k === "." || k === "(" || k === ")") {
        // Evita dois pontos decimais no mesmo número
        if (k === ".") {
          var m = expr.match(/[0-9.]*$/);
          if (m && m[0].indexOf(".") !== -1) return;
          if (!m || m[0] === "") expr += "0";
        }
        expr += k;
      } else if ("+-*/".indexOf(k) !== -1) {
        if (expr === "" && k !== "-") return;
        if (/[+\-*/]$/.test(expr)) expr = expr.slice(0, -1);
        expr += k;
      }
      render();
    }

    body.addEventListener("click", function (e) {
      var b = e.target.closest("[data-k]");
      if (b) press(b.dataset.k);
      wrap.focus();
    });

    wrap.addEventListener("keydown", function (e) {
      var k = e.key;
      if (/^[0-9]$/.test(k) || "+-*/().".indexOf(k) !== -1) { e.preventDefault(); press(k); }
      else if (k === "Enter" || k === "=") { e.preventDefault(); press("="); }
      else if (k === "Backspace") { e.preventDefault(); press("back"); }
      else if (k === "Escape") { e.preventDefault(); press("C"); }
      else if (k === ",") { e.preventDefault(); press(","); }
    });

    body.addEventListener("w11:delete", function () { press("C"); });
    api.setTitle("Calculadora");
    setTimeout(function () { wrap.focus(); }, 30);
    render();

    return {
      destroy: function () { /* nada a salvar */ }
    };
  };

  // Exposto para testes manuais
  window.W11Calc = { evaluate: evaluate };
})();
