/*
 * settings.js - Configurações e personalização.
 *
 * Preferências salvas em W11Storage (localStorage da WebView):
 *   theme        "light" | "dark" | "auto"
 *   accent       cor de destaque (#rrggbb)
 *   transparency número 0.6 a 1 (opacidade visual simulada de barras e menus)
 *   iconSize     "small" | "medium" | "large"
 *   density      "compact" | "normal" | "comfortable"
 *   animations   true | false
 *   align        "center" | "left"   (posição dos itens da barra de tarefas)
 *   showSearch   true | false
 *   showTaskView true | false
 *   wallpaper    { source: "default" | "custom", mode: "fill"|"fit"|"stretch"|"center"|"tile", data: dataURL }
 */
(function () {
  "use strict";

  window.W11Impl = window.W11Impl || {};

  var ACCENTS = ["#0067c0", "#8764b8", "#c239b3", "#e74856", "#ff8c00", "#107c10", "#00b7c3", "#4c4a48"];
  // Lista única de papéis predefinidos, definida em desktop.js
  var PRESET_WALLPAPERS = (window.W11Desktop && window.W11Desktop.WALLPAPER_PRESETS) || [];

  var W11Settings = {
    get: function (key, def) { return W11Storage.get(key, def); },
    set: function (key, value) {
      var ok = W11Storage.set(key, value);
      W11Settings.apply();
      return ok;
    },

    getTheme: function () { return W11Storage.get("theme", "auto"); },
    setTheme: function (t) { W11Storage.set("theme", t); W11Settings.apply(); },
    getAlign: function () { return W11Storage.get("align", "center"); },
    setAlign: function (a) { W11Storage.set("align", a); W11Settings.apply(); },
    setAnimations: function (on) { W11Storage.set("animations", !!on); W11Settings.apply(); },

    /** Aplica todas as preferências ao documento. */
    apply: function () {
      var root = document.documentElement;
      var theme = W11Storage.get("theme", "auto");
      var iconsBefore = root.getAttribute("data-icons");
      root.setAttribute("data-theme", theme);
      root.setAttribute("data-density", W11Storage.get("density", "normal") === "normal" ? "" : W11Storage.get("density", "normal"));
      root.setAttribute("data-icons", W11Storage.get("iconSize", "medium") === "medium" ? "" : W11Storage.get("iconSize", "medium"));
      root.setAttribute("data-anim", W11Storage.get("animations", true) ? "on" : "off");
      var accent = W11Storage.get("accent", "#0067c0");
      root.style.setProperty("--accent", accent);
      root.style.setProperty("--accent-hover", accent);
      var alpha = W11Storage.get("transparency", 0.92);
      root.style.setProperty("--glass-alpha", String(alpha));
      root.style.setProperty("--surface", "rgba(252,252,252," + alpha + ")");
      if (theme === "dark" || (theme === "auto" && window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches)) {
        root.style.setProperty("--surface", "rgba(32,32,32," + alpha + ")");
      }
      var tb = document.getElementById("taskbar");
      if (tb) tb.setAttribute("data-align", W11Settings.getAlign());
      var search = W11Storage.get("showSearch", true);
      var tv = W11Storage.get("showTaskView", true);
      document.getElementById("btn-search").classList.toggle("hidden", !search);
      document.getElementById("btn-taskview").classList.toggle("hidden", !tv);
      if (W11Desktop && W11Desktop.applyWallpaper) W11Desktop.applyWallpaper();
      // Só reorganiza os ícones quando o tamanho deles mudou (evita trabalho desnecessário)
      if (root.getAttribute("data-icons") !== iconsBefore && W11Desktop && W11Desktop.render) W11Desktop.render();
    },

    reset: function () {
      ["theme", "accent", "transparency", "iconSize", "density", "animations", "align", "showSearch", "showTaskView", "wallpaper"]
        .forEach(function (k) { W11Storage.remove(k); });
      if (window.W11Screen) W11Screen.set(W11Screen.DEFAULT);
      W11Settings.apply();
    }
  };

  window.W11Settings = W11Settings;

  /** Reduz a imagem para caber no armazenamento local (máx. 1600 px, JPEG). */
  function downscaleImage(file) {
    return new Promise(function (resolve, reject) {
      if (!/^image\//.test(file.type)) return reject(new Error("O arquivo escolhido não é uma imagem."));
      if (file.size > 15 * 1024 * 1024) return reject(new Error("Imagem muito grande (máximo 15 MB)."));
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        var max = 1600;
        var scale = Math.min(1, max / Math.max(img.width, img.height));
        var c = document.createElement("canvas");
        c.width = Math.round(img.width * scale);
        c.height = Math.round(img.height * scale);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        resolve(c.toDataURL("image/jpeg", 0.85));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error("Não foi possível abrir a imagem.")); };
      img.src = url;
    });
  }

  // ---------- Páginas ----------
  var NAV = [
    { id: "personalizacao", label: "Personalização" },
    { id: "papel", label: "Papel de parede" },
    { id: "temas", label: "Temas e cores" },
    { id: "barra", label: "Barra de tarefas" },
    { id: "exibicao", label: "Exibição" },
    { id: "apps", label: "Aplicativos" },
    { id: "sistema", label: "Sistema e dados" },
    { id: "sobre", label: "Sobre" }
  ];

  function row(label, sub, control) {
    return '<div class="setting-row"><div class="label">' + W11UI.escape(label) +
      (sub ? '<small>' + W11UI.escape(sub) + '</small>' : '') + '</div><div>' + control + '</div></div>';
  }

  function seg(name, options, current) {
    return '<div class="seg" role="group" aria-label="' + W11UI.escape(name) + '">' +
      options.map(function (o) {
        return '<button data-set="' + name + '" data-val="' + o[0] + '" class="' + (current === o[0] ? "on" : "") + '">' + W11UI.escape(o[1]) + '</button>';
      }).join("") + '</div>';
  }

  function switchCtl(name, on) {
    return '<button class="switch ' + (on ? "on" : "") + '" data-toggle="' + name + '" aria-pressed="' + (on ? "true" : "false") + '" aria-label="' + W11UI.escape(name) + '"></button>';
  }

  function pageHtml(id) {
    var s = W11Storage;
    switch (id) {
      case "personalizacao":
        return '<h2>Personalização</h2>' +
          '<div class="settings-group">' +
            row("Tema", "Claro, escuro ou seguir o sistema", seg("theme", [["light", "Claro"], ["dark", "Escuro"], ["auto", "Automático"]], s.get("theme", "auto"))) +
            row("Cor de destaque", "Usada em botões, seleções e indicadores", '<div class="color-grid" data-role="accents">' +
              ACCENTS.map(function (c) { return '<button class="swatch ' + (c === s.get("accent", "#0067c0") ? "on" : "") + '" data-accent="' + c + '" style="background:' + c + '" aria-label="Cor ' + c + '"></button>'; }).join("") +
              '<input type="color" data-role="custom-accent" value="' + s.get("accent", "#0067c0") + '" aria-label="Cor personalizada" style="width:34px;height:28px;border:none;background:none"></div>') +
          '</div>' +
          '<div class="settings-group">' +
            row("Transparência", "Opacidade visual simulada de barras e menus", '<input type="range" min="0.6" max="1" step="0.02" value="' + s.get("transparency", 0.92) + '" data-range="transparency" style="width:160px;accent-color:var(--accent)">') +
            row("Animações", "Transições leves de janelas e menus", switchCtl("animations", s.get("animations", true))) +
          '</div>';
      case "papel": {
        var wp = s.get("wallpaper", { source: "default", preset: "blue", mode: "fill", data: "" });
        var thumbs = PRESET_WALLPAPERS.map(function (p) {
          var on = wp.source === "default" && (wp.preset || "blue") === p.id;
          return '<button class="wp-thumb ' + (on ? "on" : "") + '" data-preset="' + p.id + '" style="background:' + p.css + '" aria-label="' + p.name + '"></button>';
        }).join("");
        return '<h2>Papel de parede</h2>' +
          '<div class="settings-group"><div class="setting-row" style="display:block"><div class="wp-thumbs">' + thumbs +
          '<button class="wp-thumb ' + (wp.source === "custom" ? "on" : "") + '" data-act="pick-wallpaper" style="background:var(--surface-2);display:flex;align-items:center;justify-content:center" aria-label="Escolher imagem da galeria">+ Galeria</button>' +
          '</div><p class="muted">A imagem escolhida é reduzida e salva neste aparelho. Imagens não são enviadas a nenhum servidor.</p></div></div>' +
          '<div class="settings-group">' +
            row("Modo de exibição", "Como a imagem preenche a tela", seg("mode", [["fill", "Preencher"], ["fit", "Ajustar"], ["stretch", "Esticar"], ["center", "Centralizar"], ["tile", "Repetir"]], wp.mode || "fill")) +
            row("Imagem padrão", "Volta ao papel de parede do launcher", '<button class="btn" data-act="default-wallpaper">Restaurar padrão</button>') +
          '</div>' +
          '<input type="file" accept="image/*" data-role="wp-file" style="display:none">';
      }
      case "temas":
        return '<h2>Temas e cores</h2>' +
          '<div class="settings-group">' +
            row("Tema", "Aplicado ao desktop, janelas, menus e ferramentas", seg("theme", [["light", "Claro"], ["dark", "Escuro"], ["auto", "Automático"]], s.get("theme", "auto"))) +
            row("Cor de destaque", "Escolha uma cor predefinida ou personalizada", '<div class="color-grid" data-role="accents">' +
              ACCENTS.map(function (c) { return '<button class="swatch ' + (c === s.get("accent", "#0067c0") ? "on" : "") + '" data-accent="' + c + '" style="background:' + c + '" aria-label="Cor ' + c + '"></button>'; }).join("") +
              '<input type="color" data-role="custom-accent" value="' + s.get("accent", "#0067c0") + '" aria-label="Cor personalizada" style="width:34px;height:28px;border:none;background:none"></div>') +
          '</div>';
      case "barra":
        return '<h2>Barra de tarefas</h2>' +
          '<div class="settings-group">' +
            row("Alinhamento", "Centralizada ou à esquerda", seg("align", [["center", "Centralizada"], ["left", "À esquerda"]], s.get("align", "center"))) +
            row("Botão de pesquisa", "Mostrar na barra", switchCtl("showSearch", s.get("showSearch", true))) +
            row("Visão de tarefas", "Mostrar o botão de janelas abertas", switchCtl("showTaskView", s.get("showTaskView", true))) +
          '</div>';
      case "exibicao": {
        var pct = W11Screen.get();
        return '<h2>Exibição</h2>' +
          '<div class="settings-group">' +
            row("Escala de exibição (DPI)", "Aumenta ou reduz toda a interface, como Escala e layout do Windows. Padrão: 100%.",
              '<div class="scale-control">' +
                '<input type="range" min="' + W11Screen.MIN + '" max="' + W11Screen.MAX + '" step="' + W11Screen.STEP + '" value="' + pct + '" data-range="uiscale" aria-label="Escala de exibição">' +
                '<output data-role="scale-out">' + pct + '%</output>' +
                '<button class="btn" data-act="scale-default">Padrão</button>' +
              '</div>') +
          '</div>' +
          '<div class="settings-group">' +
            row("Tamanho dos ícones", "Área de trabalho", seg("iconSize", [["small", "Pequeno"], ["medium", "Médio"], ["large", "Grande"]], s.get("iconSize", "medium"))) +
            row("Densidade da interface", "Tamanho de textos e espaçamentos", seg("density", [["compact", "Compacta"], ["normal", "Normal"], ["comfortable", "Confortável"]], s.get("density", "normal"))) +
            row("Organização dos ícones", "Ordenar por nome ou restaurar a posição padrão", '<button class="btn" data-act="arrange-name">Por nome</button> <button class="btn" data-act="arrange-default">Padrão</button>') +
          '</div>';
      }
      case "apps":
        return '<h2>Aplicativos</h2>' +
          '<div class="settings-group">' +
            row("Atualizar lista", "Consulta novamente os apps instalados que o Android permite ver", '<button class="btn" data-act="refresh-apps">Atualizar</button>') +
            row("Fixados na área de trabalho", "Mostra até 10 apps Android. Troque um fixado com o botão direito no ícone.", '<span class="muted">Regra: ordem alfabética dos 10 primeiros</span>') +
          '</div>' +
          '<div class="settings-group">' +
            row("Aplicativo inicial (HOME)", "Escolher este launcher nas configurações do Android", '<button class="btn" data-act="home-settings">Abrir configurações</button>') +
            row("Sair do launcher", "Volta para a tela inicial anterior", '<button class="btn" data-act="exit-launcher">Sair</button>') +
          '</div>';
      case "sistema":
        return '<h2>Sistema e dados</h2>' +
          '<div class="settings-group">' +
            row("Restaurar padrões", "Desfaz as personalizações (não apaga arquivos)", '<button class="btn" data-act="reset-prefs">Restaurar</button>') +
            row("Limpar Lixeira", "Exclui definitivamente os itens da Lixeira interna", '<button class="btn danger" data-act="empty-trash">Esvaziar</button>') +
            row("Apagar todos os dados do launcher", "Remove preferências, arquivos internos e notificações", '<button class="btn danger" data-act="wipe">Apagar tudo</button>') +
          '</div>' +
          '<p class="muted">Armazenamento: ' + (s.isPersistent() ? "local e persistente neste aparelho." : "indisponível; as alterações valerão só nesta sessão.") + '</p>';
      case "sobre":
        return '<h2>Sobre</h2>' +
          '<div class="settings-group">' +
            row("Windows 11 Mobile Launcher", "Versão 1.0.0 - interface HTML/CSS/JavaScript com ponte nativa Android", '') +
            row("Dados", "Tudo é processado localmente. Não há contas, serviços externos ou envio de dados.", '') +
          '</div>';
      default:
        return '<h2>Personalização</h2>';
    }
  }

  window.W11Impl.settings = function (body, api, opts) {
    opts = opts || {};
    var page = opts.page || "personalizacao";

    body.innerHTML =
      '<div class="settings-wrap">' +
        '<nav class="settings-nav">' + NAV.map(function (n) {
          return '<button data-page="' + n.id + '">' + W11UI.escape(n.label) + '</button>';
        }).join("") + '</nav>' +
        '<div class="settings-main" data-role="main"></div>' +
      '</div>';

    var main = body.querySelector('[data-role="main"]');

    function show(p) {
      page = p;
      body.querySelectorAll("[data-page]").forEach(function (b) { b.classList.toggle("active", b.dataset.page === p); });
      main.innerHTML = pageHtml(p);
      api.setTitle("Configurações - " + (NAV.find(function (n) { return n.id === p; }) || NAV[0]).label);
    }

    function refreshTheme() { W11Settings.apply(); show(page); }

    body.addEventListener("click", async function (e) {
      var t;
      if ((t = e.target.closest("[data-page]"))) { show(t.dataset.page); return; }
      if ((t = e.target.closest("[data-set]"))) {
        var name = t.dataset.set, val = t.dataset.val;
        if (name === "mode") {
          var wp = W11Storage.get("wallpaper", { source: "default", mode: "fill", data: "" });
          wp.mode = val; W11Settings.set("wallpaper", wp); show(page);
        } else {
          W11Storage.set(name, val);
          if (name === "align" || name === "theme" || name === "density" || name === "iconSize") W11Settings.apply();
          if (name === "iconSize" || name === "density") W11Desktop.render();
          show(page);
        }
        return;
      }
      if ((t = e.target.closest("[data-toggle]"))) {
        var key = t.dataset.toggle;
        var cur = W11Storage.get(key, key === "showSearch" || key === "showTaskView" || key === "animations");
        W11Storage.set(key, !cur);
        W11Settings.apply();
        show(page);
        return;
      }
      if ((t = e.target.closest("[data-accent]"))) {
        W11Storage.set("accent", t.dataset.accent);
        W11Settings.apply();
        show(page);
        return;
      }
      if ((t = e.target.closest("[data-preset]"))) {
        W11Settings.set("wallpaper", { source: "default", preset: t.dataset.preset, mode: W11Storage.get("wallpaper", { mode: "fill" }).mode || "fill", data: "" });
        show(page);
        return;
      }
      if ((t = e.target.closest("[data-act]"))) {
        var act = t.dataset.act;
        if (act === "pick-wallpaper") { body.querySelector('[data-role="wp-file"]').click(); }
        else if (act === "default-wallpaper") { W11Settings.set("wallpaper", { source: "default", preset: "blue", mode: "fill", data: "" }); show(page); }
        else if (act === "arrange-name") W11Desktop.arrange("name");
        else if (act === "arrange-default") W11Desktop.arrange("default");
        else if (act === "scale-default") { W11Screen.set(W11Screen.DEFAULT); show(page); }
        else if (act === "refresh-apps") W11Desktop.refreshApps();
        else if (act === "home-settings") { if (!W11Bridge.openSystemSettings("home")) W11UI.toast("Disponível somente no APK.", "error"); }
        else if (act === "exit-launcher") { if (!W11Bridge.exitLauncher()) W11UI.toast("Disponível somente no APK.", "error"); }
        else if (act === "reset-prefs") {
          if (await W11UI.confirm("Restaurar padrões", "Suas personalizações voltarão ao padrão. Arquivos não serão apagados.", "Restaurar")) {
            W11Settings.reset(); show(page); W11UI.toast("Padrões restaurados.", "ok");
          }
        }
        else if (act === "empty-trash") {
          if (await W11UI.confirm("Esvaziar Lixeira", "Os itens da Lixeira serão excluídos definitivamente.", "Esvaziar")) { W11FS.emptyTrash(); W11UI.toast("Lixeira esvaziada.", "ok"); }
        }
        else if (act === "wipe") {
          if (await W11UI.confirm("Apagar tudo", "Preferências, arquivos internos e notificações do launcher serão apagados. Esta ação não pode ser desfeita.", "Apagar")) {
            ["theme", "accent", "transparency", "iconSize", "density", "animations", "align", "showSearch", "showTaskView", "wallpaper", "uiScale", "pinned", "positions", "notifications", "notepadDraft", "explorerView"]
              .forEach(function (k) { W11Storage.remove(k); });
            W11FS.reset();
            W11UI.toast("Dados do launcher apagados. Recarregando...", "ok", 1500);
            setTimeout(function () { location.reload(); }, 1200);
          }
        }
        return;
      }
    });

    body.addEventListener("input", function (e) {
      var r = e.target.closest("[data-range]");
      if (!r) return;
      if (r.dataset.range === "transparency") {
        W11Storage.set("transparency", Number(r.value));
        W11Settings.apply();
      } else if (r.dataset.range === "uiscale") {
        // Atualiza a escala ao vivo; o texto ao lado acompanha o valor sem recriar a página
        W11Screen.set(Number(r.value));
        var out = body.querySelector('[data-role="scale-out"]');
        if (out) out.textContent = W11Screen.get() + "%";
      }
    });
    body.addEventListener("change", async function (e) {
      if (e.target.matches('[data-role="custom-accent"]')) {
        W11Storage.set("accent", e.target.value);
        W11Settings.apply();
        show(page);
      }
      if (e.target.matches('[data-role="wp-file"]')) {
        var f = e.target.files && e.target.files[0];
        e.target.value = "";
        if (!f) return;
        try {
          var dataUrl = await downscaleImage(f);
          var prev = W11Storage.get("wallpaper", { mode: "fill" });
          var ok = W11Settings.set("wallpaper", { source: "custom", mode: prev.mode || "fill", data: dataUrl });
          if (!ok) W11UI.toast("Armazenamento cheio. Tente uma imagem menor.", "error", 4000);
          show(page);
        } catch (err) {
          W11UI.toast(err.message, "error", 4000);
        }
      }
    });

    show(page);
    return { destroy: function () {} };
  };
})();
