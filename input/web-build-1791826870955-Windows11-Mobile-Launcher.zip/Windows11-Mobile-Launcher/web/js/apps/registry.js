/*
 * registry.js - Registro dos aplicativos INTERNOS do launcher.
 * Liga cada atalho à sua implementação (window.W11Impl.*) e abre-o
 * como janela interna pelo gerenciador de janelas.
 *
 * icon: nome de um ícone SVG de icons.js (nunca emoji ou caractere de símbolo).
 */
(function () {
  "use strict";

  // Apps que só podem ter uma janela aberta por vez
  var SINGLETON = { taskmanager: true, settings: true, run: true };

  var SHORTCUTS = [
    { id: "explorer", label: "Explorador", icon: "folder", impl: "explorer" },
    { id: "notepad", label: "Bloco de Notas", icon: "notepad", impl: "notepad" },
    { id: "calculator", label: "Calculadora", icon: "calc", impl: "calculator" },
    { id: "paint", label: "Paint", icon: "paint", impl: "paint" },
    { id: "settings", label: "Configurações", icon: "gear", impl: "settings" },
    { id: "taskmanager", label: "Gerenciador de tarefas", icon: "chart", impl: "taskmanager" },
    { id: "run", label: "Executar", icon: "run", impl: "run" },
    { id: "lixeira", label: "Lixeira", icon: "trash", impl: "explorer" }
  ];

  function shortcutFor(id) {
    return SHORTCUTS.find(function (s) { return s.id === id; }) || null;
  }

  var W11Apps = {
    shortcuts: SHORTCUTS,

    /**
     * Abre uma ferramenta interna.
     * opts (opcional): { fileId } para o Bloco de Notas, { folderId } para o Explorador,
     *                  { page } para Configurações.
     */
    open: function (id, opts) {
      opts = opts || {};
      var sc = shortcutFor(id);
      if (!sc) {
        W11UI.toast("Este atalho não existe mais.", "error");
        return null;
      }
      if (id === "lixeira") {
        opts = { folderId: W11FS.TRASH };
      }
      var impl = window.W11Impl && window.W11Impl[sc.impl];
      if (!impl) {
        W11UI.toast("Ferramenta indisponível: " + sc.label, "error");
        return null;
      }
      var singleton = !!SINGLETON[id];
      return W11Windows.open({
        appId: id,
        title: sc.label,
        icon: sc.icon,
        singleton: singleton,
        content: function (body, api) {
          var title = sc.label;
          if (id === "lixeira") title = "Lixeira";
          api.setTitle(title);
          return impl(body, api, opts);
        }
      });
    },

    /** Abre uma pasta ou arquivo a partir de um caminho interno (ex.: "/Documentos/Bem-vindo.txt"). */
    openPath: function (path) {
      var parts = String(path || "").split("/").filter(Boolean);
      var cur = W11FS.get(W11FS.ROOT);
      var found = null;
      for (var i = 0; i < parts.length; i++) {
        var next = W11FS.children(cur.id).find(function (c) { return c.name === parts[i]; });
        if (!next) return false;
        found = next;
        cur = next;
      }
      if (!found) return false;
      if (found.type === "folder") W11Apps.open("explorer", { folderId: found.id });
      else W11Apps.open("notepad", { fileId: found.id });
      return true;
    }
  };

  window.W11Apps = W11Apps;
})();
