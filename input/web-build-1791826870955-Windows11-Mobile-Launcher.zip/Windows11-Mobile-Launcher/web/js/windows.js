/*
 * windows.js - Gerenciador de janelas INTERNAS do launcher.
 *
 * Importante: estas janelas são elementos HTML dentro da própria página.
 * Elas NÃO controlam aplicativos Android externos.
 *
 * Responsabilidades:
 *   - abrir / fechar (destrói a instância da ferramenta, sem apagar dados);
 *   - minimizar / restaurar / maximizar / tela cheia;
 *   - arrastar pela barra de título e redimensionar pelas bordas (mouse e toque);
 *   - encaixe à esquerda / direita (Win+setas);
 *   - foco, ordem (z-index), janela ativa e histórico de uso (MRU, para Alt+Tab).
 *
 * Coordenadas: tudo é calculado no espaço lógico (W11Screen), para que a escala
 * de exibição (DPI) não altere o comportamento das janelas.
 * Estados: "normal", "maximized", "fullscreen", "minimized".
 *   - prevState: estado anterior à minimização (para restaurar corretamente).
 *   - restoreRect: tamanho e posição antes de encaixar a janela (Win+setas).
 */
(function () {
  "use strict";

  var MIN_W = 220;
  var MIN_H = 140;
  var zCounter = 10;
  var windows = [];      // ordem de criação
  var mru = [];          // ids das janelas, mais recente primeiro
  var listeners = [];
  var seq = 0;

  var root = null;

  function area() {
    // Área disponível acima da barra de tarefas (coordenadas lógicas)
    var s = W11Screen.size();
    var tb = document.getElementById("taskbar");
    var h = s.h - (tb ? tb.offsetHeight : 56);
    return { w: s.w, h: Math.max(h, 200) };
  }

  function copyRect(r) {
    return { x: r.x, y: r.y, w: r.w, h: r.h };
  }

  function emit() {
    listeners.forEach(function (fn) { try { fn(WM.list()); } catch (e) { console.error(e); } });
  }

  function touchMru(win) {
    mru = mru.filter(function (id) { return id !== win.id; });
    mru.unshift(win.id);
    if (mru.length > 30) mru.length = 30;
  }

  function clampRect(win) {
    var a = area();
    var r = win.rect;
    r.w = Math.min(Math.max(r.w, MIN_W), a.w);
    r.h = Math.min(Math.max(r.h, MIN_H), a.h);
    r.x = Math.min(Math.max(r.x, -r.w + 80), a.w - 80);
    r.y = Math.min(Math.max(r.y, 0), a.h - 34);
  }

  function applyRect(win) {
    var el = win.el;
    if (win.state === "maximized") {
      var a = area();
      el.style.left = "0px"; el.style.top = "0px";
      el.style.width = a.w + "px"; el.style.height = a.h + "px";
      return;
    }
    if (win.state === "fullscreen") {
      var s = W11Screen.size();
      el.style.left = "0px"; el.style.top = "0px";
      el.style.width = s.w + "px"; el.style.height = s.h + "px";
      return;
    }
    clampRect(win);
    el.style.left = win.rect.x + "px";
    el.style.top = win.rect.y + "px";
    el.style.width = win.rect.w + "px";
    el.style.height = win.rect.h + "px";
  }

  function setState(win, state) {
    win.state = state;
    win.el.classList.toggle("maximized", state === "maximized");
    win.el.classList.toggle("fullscreen", state === "fullscreen");
    win.el.classList.toggle("minimized", state === "minimized");
    var maxBtn = win.el.querySelector(".btn-max");
    if (maxBtn) {
      var isMax = state === "maximized" || state === "fullscreen";
      maxBtn.innerHTML = W11Icons.svg(isMax ? "restore" : "maximize");
      maxBtn.setAttribute("aria-label", isMax ? "Restaurar" : "Maximizar");
      maxBtn.title = isMax ? "Restaurar" : "Maximizar";
    }
    applyRect(win);
    // Tela cheia cobre também a barra de tarefas (ver CSS :root.has-fullscreen)
    var anyFullscreen = windows.some(function (w) { return w.state === "fullscreen"; });
    document.documentElement.classList.toggle("has-fullscreen", anyFullscreen);
  }

  /** Estado em que a janela volta quando sai da minimização. */
  function stateAfterMinimized(win) {
    return win.prevState && win.prevState !== "minimized" ? win.prevState : "normal";
  }

  function makeDraggable(win, handle) {
    var startX, startY, origX, origY, dragging = false, pid = null;

    handle.addEventListener("pointerdown", function (ev) {
      if (ev.target.closest(".win-controls")) return;
      if (win.state === "maximized" || win.state === "fullscreen") return;
      if (ev.button !== undefined && ev.button > 0) return;
      dragging = true; pid = ev.pointerId;
      var p = W11Screen.pt(ev);
      startX = p.x; startY = p.y;
      origX = win.rect.x; origY = win.rect.y;
      win.snapped = null; // arrastar solta o encaixe
      win.el.classList.add("dragging");
      handle.setPointerCapture(pid);
      WM.focus(win);
      ev.preventDefault();
    });
    handle.addEventListener("pointermove", function (ev) {
      if (!dragging) return;
      var p = W11Screen.pt(ev);
      win.rect.x = origX + (p.x - startX);
      win.rect.y = origY + (p.y - startY);
      applyRect(win);
    });
    function end() {
      if (!dragging) return;
      dragging = false;
      win.el.classList.remove("dragging");
      try { handle.releasePointerCapture(pid); } catch (e) { /* ignorar */ }
      applyRect(win);
    }
    handle.addEventListener("pointerup", end);
    handle.addEventListener("pointercancel", end);
    // Duplo clique na barra: alterna maximizar
    handle.addEventListener("dblclick", function (ev) {
      if (ev.target.closest(".win-controls")) return;
      WM.toggleMaximize(win);
    });
  }

  function makeResizable(win) {
    var dirs = ["e", "s", "se", "w"];
    dirs.forEach(function (d) {
      var h = document.createElement("div");
      h.className = "resize " + d;
      win.el.appendChild(h);
      var sx, sy, ow, oh, ox, dragging = false, pid = null;
      h.addEventListener("pointerdown", function (ev) {
        if (win.state !== "normal") return;
        dragging = true; pid = ev.pointerId;
        var p = W11Screen.pt(ev);
        sx = p.x; sy = p.y;
        ow = win.rect.w; oh = win.rect.h; ox = win.rect.x;
        win.snapped = null;
        win.el.classList.add("resizing");
        h.setPointerCapture(pid);
        WM.focus(win);
        ev.preventDefault(); ev.stopPropagation();
      });
      h.addEventListener("pointermove", function (ev) {
        if (!dragging) return;
        var p = W11Screen.pt(ev);
        var dx = p.x - sx, dy = p.y - sy;
        if (d.indexOf("e") !== -1) win.rect.w = Math.max(MIN_W, ow + dx);
        if (d.indexOf("s") !== -1) win.rect.h = Math.max(MIN_H, oh + dy);
        if (d === "w") {
          // A borda esquerda move a posição junto com o tamanho, sem "andar" além do mínimo
          var nw = Math.max(MIN_W, ow - dx);
          win.rect.w = nw;
          win.rect.x = ox + (ow - nw);
        }
        applyRect(win);
      });
      function end() {
        if (!dragging) return;
        dragging = false;
        win.el.classList.remove("resizing");
        try { h.releasePointerCapture(pid); } catch (e) { /* ignorar */ }
        applyRect(win);
        if (win.onResize) win.onResize();
      }
      h.addEventListener("pointerup", end);
      h.addEventListener("pointercancel", end);
    });
  }

  var WM = {
    /** Inicializa o contêiner. */
    init: function () {
      root = document.getElementById("windows");
      window.addEventListener("resize", function () {
        windows.forEach(applyRect);
      });
    },

    /**
     * Abre uma janela.
     * opts: { appId, title, icon (nome de ícone), singleton, content(body, api) }
     * content pode retornar { destroy() } opcional.
     */
    open: function (opts) {
      if (opts.singleton) {
        var existing = windows.find(function (w) { return w.appId === opts.appId; });
        if (existing) {
          WM.restore(existing);
          WM.focus(existing);
          return existing;
        }
      }
      var a = area();
      var small = W11Screen.isSmall();
      var s = W11Screen.size();
      var w = small ? s.w : Math.min(860, Math.round(s.w * 0.78));
      var h = small ? a.h : Math.min(600, Math.round(a.h * 0.8));
      var offset = (windows.length % 6) * 26;
      var win = {
        id: "w" + (++seq),
        appId: opts.appId || opts.id || "app",
        title: opts.title || "Janela",
        icon: opts.icon || "window",
        state: "normal",
        prevState: "normal",
        snapped: null,
        restoreRect: null,
        rect: { x: Math.max(8, Math.round((s.w - w) / 2) + offset - 60), y: 12 + offset, w: w, h: h },
        z: 0,
        destroy: null,
        el: null
      };

      var el = document.createElement("section");
      el.className = "win";
      el.setAttribute("role", "dialog");
      el.setAttribute("aria-label", win.title);
      el.dataset.winId = win.id;
      el.innerHTML =
        '<header class="win-titlebar">' +
          '<span class="win-icon" aria-hidden="true"></span>' +
          '<span class="win-title"></span>' +
          '<div class="win-controls">' +
            '<button class="btn-min" aria-label="Minimizar" title="Minimizar">' + W11Icons.svg("minimize") + '</button>' +
            '<button class="btn-max" aria-label="Maximizar" title="Maximizar">' + W11Icons.svg("maximize") + '</button>' +
            '<button class="close" aria-label="Fechar" title="Fechar">' + W11Icons.svg("close") + '</button>' +
          '</div>' +
        '</header>' +
        '<div class="win-body"></div>';
      el.querySelector(".win-icon").innerHTML = W11Icons.svg(win.icon);
      el.querySelector(".win-title").textContent = win.title;
      win.el = el;
      win.body = el.querySelector(".win-body");

      el.addEventListener("pointerdown", function () { WM.focus(win); }, true);
      el.querySelector(".btn-min").addEventListener("click", function (e) { e.stopPropagation(); WM.minimize(win); });
      el.querySelector(".btn-max").addEventListener("click", function (e) { e.stopPropagation(); WM.toggleMaximize(win); });
      el.querySelector(".close").addEventListener("click", function (e) { e.stopPropagation(); WM.close(win); });

      makeDraggable(win, el.querySelector(".win-titlebar"));
      makeResizable(win);

      root.appendChild(el);
      windows.push(win);
      if (small) setState(win, "maximized");
      else applyRect(win);

      var api = {
        win: win,
        close: function () { WM.close(win); },
        setTitle: function (t) { WM.setTitle(win, t); },
        focus: function () { WM.focus(win); },
        onResize: function (fn) { win.onResize = fn; }
      };
      try {
        var result = opts.content ? opts.content(win.body, api) : null;
        if (result && typeof result.destroy === "function") win.destroy = result.destroy;
      } catch (err) {
        console.error(err);
        win.body.innerHTML = '<div class="pad"><b>Não foi possível abrir esta ferramenta.</b><p class="muted"></p></div>';
        win.body.querySelector(".muted").textContent = String(err && err.message || err);
      }

      WM.focus(win);
      emit();
      return win;
    },

    setTitle: function (win, title) {
      win.title = title;
      win.el.querySelector(".win-title").textContent = title;
      win.el.setAttribute("aria-label", title);
      emit();
    },

    /** Fecha a janela: executa destroy() da ferramenta e remove o elemento. */
    close: function (win) {
      var idx = windows.indexOf(win);
      if (idx === -1) return;
      if (typeof win.destroy === "function") {
        try { win.destroy(); } catch (e) { console.error(e); }
      }
      windows.splice(idx, 1);
      mru = mru.filter(function (id) { return id !== win.id; });
      win.el.remove();
      document.documentElement.classList.toggle("has-fullscreen", windows.some(function (w) { return w.state === "fullscreen"; }));
      // Foco vai para a janela mais recente visível
      var next = WM.mostRecentVisible();
      if (next) WM.focus(next); else WM.blurAll();
      emit();
    },

    minimize: function (win) {
      if (win.state === "minimized") return;
      win.prevState = win.state;
      setState(win, "minimized");
      if (WM.active() === win) {
        var next = WM.mostRecentVisible(win);
        if (next) WM.focus(next); else WM.blurAll();
      }
      emit();
    },

    /** Restaura uma janela minimizada (ao estado anterior) ou volta uma maximizada/em tela cheia ao normal. */
    restore: function (win) {
      if (win.state === "minimized") {
        setState(win, stateAfterMinimized(win));
      } else if (win.state !== "normal") {
        setState(win, "normal");
      } else if (win.snapped && win.restoreRect) {
        win.rect = copyRect(win.restoreRect);
        win.snapped = null;
        applyRect(win);
      }
      WM.focus(win);
      emit();
    },

    toggleMaximize: function (win) {
      if (win.state === "minimized") return;
      if (win.state === "maximized") setState(win, "normal");
      else setState(win, "maximized");
      WM.focus(win);
      emit();
    },

    /** Tela cheia da janela (esconde barra de tarefas dentro dela). */
    toggleFullscreen: function (win) {
      if (win.state === "minimized") return;
      if (win.state === "fullscreen") setState(win, "normal");
      else setState(win, "fullscreen");
      WM.focus(win);
      emit();
    },

    /** Encaixa a janela em metade da tela. side: "left" | "right". */
    snap: function (win, side) {
      var a = area();
      if (win.state === "minimized") win.state = stateAfterMinimized(win);
      if (!win.snapped) win.restoreRect = copyRect(win.rect);
      win.snapped = side;
      win.rect = { x: side === "left" ? 0 : Math.round(a.w / 2), y: 0, w: Math.round(a.w / 2), h: a.h };
      setState(win, "normal");
      WM.focus(win);
      emit();
    },

    /** Foco: traz à frente, marca como ativa e registra no histórico. */
    focus: function (win) {
      if (!win || windows.indexOf(win) === -1) return;
      if (win.state === "minimized") setState(win, stateAfterMinimized(win));
      windows.forEach(function (w) {
        w.el.classList.toggle("inactive", w !== win);
        w.el.setAttribute("aria-current", w === win ? "true" : "false");
      });
      win.el.style.zIndex = String(++zCounter);
      win.z = zCounter;
      touchMru(win);
      emit();
    },

    blurAll: function () {
      windows.forEach(function (w) { w.el.classList.add("inactive"); });
      emit();
    },

    active: function () {
      var top = null;
      windows.forEach(function (w) {
        if (w.state !== "minimized" && !w.el.classList.contains("inactive") && (!top || w.z > top.z)) top = w;
      });
      return top;
    },

    /** Janela visível mais recente (exceto `except`). */
    mostRecentVisible: function (except) {
      for (var i = 0; i < mru.length; i++) {
        var w = WM.get(mru[i]);
        if (w && w !== except && w.state !== "minimized") return w;
      }
      return null;
    },

    /** Alt+Tab: alterna para a janela anterior no histórico. */
    cycle: function () {
      var visible = mru.map(WM.get).filter(function (w) { return w && w.state !== "minimized"; });
      if (visible.length < 2) return null;
      WM.focus(visible[1]);
      return visible[1];
    },

    /** Mostra todas as janelas (Win+Tab): restaura minimizadas em ordem de uso. */
    showAll: function () {
      WM.list().forEach(function (w) { if (w.state === "minimized") setState(w, stateAfterMinimized(w)); });
      emit();
    },

    /** Minimiza todas (Win+D). */
    showDesktop: function () {
      windows.forEach(function (w) { if (w.state !== "minimized") WM.minimize(w); });
      emit();
    },

    get: function (id) {
      return windows.find(function (w) { return w.id === id; }) || null;
    },

    list: function () {
      return windows.slice();
    },

    recent: function () {
      return mru.map(WM.get).filter(Boolean);
    },

    /** Registra um ouvinte de mudanças. Retorna função para cancelar. */
    onChange: function (fn) {
      listeners.push(fn);
      return function () {
        listeners = listeners.filter(function (f) { return f !== fn; });
      };
    }
  };

  window.W11Windows = WM;
})();
