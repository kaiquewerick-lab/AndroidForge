/*
 * screen.js - Escala de exibição (DPI) da interface, como "Escala e layout" do Windows.
 *
 * Como funciona:
 *   - Todo o launcher fica dentro de #screen. Essa camada tem o tamanho do
 *     viewport dividido pela escala e é reduzida/ampliada com transform: scale(s).
 *   - Assim, a interface inteira muda de tamanho (textos, ícones, janelas e
 *     barra de tarefas) e continua preenchendo a tela exatamente.
 *   - Coordenadas do ponteiro (clientX/clientY) e medidas do viewport são
 *     convertidas para o espaço lógico por W11Screen.pt(), size() e fromRect().
 *
 * Preferência salva: "uiScale" (inteiro, de 75 a 150, em passos de 5). Padrão: 100.
 */
(function () {
  "use strict";

  var MIN = 75, MAX = 150, STEP = 5, DEFAULT = 100;
  var pct = DEFAULT;
  var scale = 1;
  var el = null;

  function clampPct(v) {
    var n = Math.round(Number(v) / STEP) * STEP;
    if (!isFinite(n)) return DEFAULT;
    return Math.min(MAX, Math.max(MIN, n));
  }

  /** Recalcula o tamanho lógico e aplica a escala. Sem efeitos colaterais de dados. */
  function apply() {
    if (!el) return;
    scale = pct / 100;
    var lw = window.innerWidth / scale;
    var lh = window.innerHeight / scale;
    el.style.width = lw + "px";
    el.style.height = lh + "px";
    el.style.transform = scale === 1 ? "" : "scale(" + scale + ")";
    var root = document.documentElement;
    root.style.setProperty("--vw", lw + "px");
    root.style.setProperty("--vh", lh + "px");
    root.style.setProperty("--ui-scale", String(scale));
    // Os breakpoints usam o tamanho lógico, não o físico, para a escala funcionar em telas pequenas
    root.toggleAttribute("data-small", lw <= 600);
    root.toggleAttribute("data-short", lh <= 500);
  }

  var W11Screen = {
    MIN: MIN, MAX: MAX, STEP: STEP, DEFAULT: DEFAULT,

    /** Lê a preferência e aplica. Chamado antes de qualquer outro módulo de interface. */
    init: function () {
      el = document.getElementById("screen");
      pct = clampPct(W11Storage.get("uiScale", DEFAULT));
      apply();
      // Esta escuta é registrada antes das outras (windows, desktop), que usam o tamanho já corrigido
      window.addEventListener("resize", apply);
    },

    /** Escala atual em percentual (75 a 150). */
    get: function () { return pct; },

    /** Define a escala, salva a preferência e avisa a interface para se reorganizar. */
    set: function (value) {
      var next = clampPct(value);
      if (next === pct) return true;
      pct = next;
      var ok = W11Storage.set("uiScale", pct);
      apply();
      window.dispatchEvent(new Event("resize"));
      return ok;
    },

    /** Número de escala (ex.: 1.25). */
    factor: function () { return scale; },

    /** Tamanho lógico do viewport (o que a interface "enxerga" em CSS px). */
    size: function () {
      return { w: window.innerWidth / scale, h: window.innerHeight / scale };
    },

    /** Converte coordenadas da tela (clientX/clientY) para o espaço lógico. */
    pt: function (ev) {
      return { x: ev.clientX / scale, y: ev.clientY / scale };
    },

    /** Converte um retângulo da tela (getBoundingClientRect) para o ponto lógico do canto. */
    fromRect: function (r) {
      return { x: r.left / scale, y: r.top / scale };
    },

    isSmall: function () { return window.innerWidth / scale <= 600; }
  };

  window.W11Screen = W11Screen;
})();
