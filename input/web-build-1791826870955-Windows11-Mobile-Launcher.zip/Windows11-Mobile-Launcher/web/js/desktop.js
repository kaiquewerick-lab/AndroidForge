/*
 * desktop.js - Área de trabalho: ícones, fixados, papel de parede e menus.
 *
 * Regra de fixados (determinística e documentada):
 *   1. Os apps Android são ordenados por nome (pt-BR, sem diferenciar maiúsculas
 *      e acentos), com desempate pelo identificador de pacote.
 *   2. São fixados os 10 primeiros da lista (ou todos, se houver menos de 10).
 *   3. O usuário pode trocar qualquer fixado por outro app, em "Trocar aplicativo...".
 *      A escolha é salva e mantida após reiniciar.
 *   4. Se um app fixado for desinstalado, ele sai da lista e o próximo app
 *      da ordem alfabética ocupa o lugar, mantendo 10 ícones.
 *
 * Atalhos internos (Explorador, Bloco de Notas etc.) NÃO contam nos 10.
 */
(function () {
  "use strict";

  var PIN_COUNT = 10;
  var PAD = 8;
  var TAP_MS = 420;
  var DRAG_PX = 6;

  var androidApps = [];      // [{pkg, label}] ordenados
  var pinned = [];           // pacotes fixados, na ordem de exibição
  var positions = {};        // itemId -> {c, r}
  var iconCache = {};        // pkg -> dataURL
  var selected = null;
  var lastTap = { id: null, t: 0 };
  var rootEl = null;
  var iconsEl = null;
  var items = [];            // itens renderizados atuais

  function collator(a, b) {
    return a.localeCompare(b, "pt-BR", { sensitivity: "base", numeric: true }) ||
           (a < b ? -1 : a > b ? 1 : 0);
  }

  function sortApps(list) {
    return list.slice().sort(function (x, y) {
      return collator(x.label, y.label) || collator(x.pkg, y.pkg);
    });
  }

  function cellPx() {
    var v = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--cell"));
    return isNaN(v) ? 92 : v;
  }

  function gridSize() {
    var c = cellPx();
    var w = rootEl.clientWidth - PAD * 2;
    var h = rootEl.clientHeight - PAD * 2;
    return { cols: Math.max(1, Math.floor(w / c)), rows: Math.max(1, Math.floor(h / c)), cell: c };
  }

  // ---------- Fixados ----------
  function syncPinned() {
    var available = {};
    androidApps.forEach(function (a) { available[a.pkg] = a; });
    var kept = pinned.filter(function (pkg) { return available[pkg]; });
    var target = Math.min(PIN_COUNT, androidApps.length);
    if (kept.length < target) {
      androidApps.forEach(function (a) {
        if (kept.length < target && kept.indexOf(a.pkg) === -1) kept.push(a.pkg);
      });
    }
    pinned = kept.slice(0, target);
    W11Storage.set("pinned", pinned);
  }

  function labelOf(pkg) {
    var a = androidApps.find(function (x) { return x.pkg === pkg; });
    return a ? a.label : pkg;
  }

  // ---------- Itens ----------
  function buildItems() {
    var list = [];
    (W11Apps.shortcuts || []).forEach(function (s) {
      list.push({ id: "int:" + s.id, kind: "internal", ref: s.id, label: s.label, icon: s.icon });
    });
    pinned.forEach(function (pkg) {
      list.push({ id: "and:" + pkg, kind: "android", ref: pkg, label: labelOf(pkg), icon: null });
    });
    return list;
  }

  /** Calcula posições: primeiro as salvas válidas, depois preenche em colunas. */
  function computeLayout(list) {
    var g = gridSize();
    var used = {};
    var out = {};
    list.forEach(function (it) {
      var p = positions[it.id];
      if (p && p.c < g.cols && p.r < g.rows && !used[p.c + "," + p.r]) {
        out[it.id] = { c: p.c, r: p.r };
        used[p.c + "," + p.r] = true;
      }
    });
    var c = 0, r = 0;
    list.forEach(function (it) {
      if (out[it.id]) return;
      while (used[c + "," + r]) {
        r++;
        if (r >= g.rows) { r = 0; c++; }
      }
      out[it.id] = { c: c, r: r };
      used[c + "," + r] = true;
    });
    return out;
  }

  function place(el, c, r) {
    var g = gridSize();
    el.style.left = (PAD + c * g.cell) + "px";
    el.style.top = (PAD + r * g.cell) + "px";
    el.style.width = g.cell + "px";
    el.style.height = g.cell + "px";
  }

  function iconHtml(it) {
    if (it.kind === "internal") {
      return '<div class="icon-img">' + W11Icons.svg(it.icon) + '</div>';
    }
    var src = iconCache[it.ref];
    if (src === undefined) {
      src = W11Bridge.getIcon(it.ref);
      iconCache[it.ref] = src;
    }
    if (src) return '<div class="icon-img"><img alt="" src="' + src + '"></div>';
    var letter = (it.label || "?").trim().charAt(0).toUpperCase();
    return '<div class="icon-img">' + W11UI.escape(letter) + '</div>';
  }

  function render() {
    if (!rootEl) return;
    items = buildItems();
    var layout = computeLayout(items);
    iconsEl.innerHTML = "";
    items.forEach(function (it) {
      var el = document.createElement("div");
      el.className = "icon" + (selected === it.id ? " selected" : "");
      el.setAttribute("role", "gridcell");
      el.setAttribute("tabindex", "0");
      el.dataset.id = it.id;
      el.innerHTML = iconHtml(it) + '<div class="icon-label"></div>';
      el.querySelector(".icon-label").textContent = it.label;
      el.setAttribute("aria-label", it.label);
      place(el, layout[it.id].c, layout[it.id].r);
      iconsEl.appendChild(el);
      positions[it.id] = layout[it.id];
      bindIcon(el, it);
    });
    W11Storage.set("positions", positions);
  }

  function bindIcon(el, it) {
    var sx, sy, ox, oy, moved = false, pid = null, pressTimer = null;

    el.addEventListener("pointerdown", function (ev) {
      if (ev.button === 2) return; // botão direito tratado no contextmenu
      pid = ev.pointerId; moved = false;
      var p = W11Screen.pt(ev);
      sx = p.x; sy = p.y;
      ox = parseFloat(el.style.left); oy = parseFloat(el.style.top);
      // Toque longo abre o menu de contexto (equivalente ao botão direito)
      pressTimer = setTimeout(function () {
        if (!moved) {
          pressTimer = null;
          el.dataset.suppressTap = "1";
          showIconMenu(sx, sy, it);
        }
      }, 520);
      el.setPointerCapture(pid);
    });

    el.addEventListener("pointermove", function (ev) {
      if (pid === null) return;
      var p = W11Screen.pt(ev);
      var dx = p.x - sx, dy = p.y - sy;
      if (!moved && Math.hypot(dx, dy) < DRAG_PX) return;
      if (!moved) {
        moved = true;
        clearTimeout(pressTimer); pressTimer = null;
        el.classList.add("dragging");
      }
      el.style.left = (ox + dx) + "px";
      el.style.top = (oy + dy) + "px";
    });

    function end(ev) {
      if (pid === null) return;
      clearTimeout(pressTimer); pressTimer = null;
      try { el.releasePointerCapture(pid); } catch (e) { /* ignorar */ }
      pid = null;
      if (el.dataset.suppressTap) { delete el.dataset.suppressTap; return; }
      if (moved) {
        el.classList.remove("dragging");
        dropIcon(it, el);
        return;
      }
      // Toque simples: seleciona. Segundo toque rápido no mesmo ícone: abre.
      var now = Date.now();
      if (lastTap.id === it.id && now - lastTap.t < TAP_MS) {
        lastTap = { id: null, t: 0 };
        openItem(it);
      } else {
        lastTap = { id: it.id, t: now };
        select(it.id);
      }
    }
    el.addEventListener("pointerup", end);
    el.addEventListener("pointercancel", function () {
      clearTimeout(pressTimer); pressTimer = null; pid = null; el.classList.remove("dragging");
      render();
    });

    el.addEventListener("keydown", function (ev) {
      if (ev.key === "Enter") { ev.preventDefault(); openItem(it); }
      if (ev.key === "ContextMenu" || (ev.key === "F10" && ev.shiftKey)) {
        var r = W11Screen.fromRect(el.getBoundingClientRect());
        showIconMenu(r.x, r.y, it);
      }
    });
    el.addEventListener("contextmenu", function (ev) {
      ev.preventDefault();
      select(it.id);
      var p = W11Screen.pt(ev);
      showIconMenu(p.x, p.y, it);
    });
  }

  /** Solta o ícone na célula mais próxima livre. */
  function dropIcon(it, el) {
    var g = gridSize();
    var x = parseFloat(el.style.left) + g.cell / 2 - PAD;
    var y = parseFloat(el.style.top) + g.cell / 2 - PAD;
    var c = Math.min(g.cols - 1, Math.max(0, Math.floor(x / g.cell)));
    var r = Math.min(g.rows - 1, Math.max(0, Math.floor(y / g.cell)));
    var occupied = null;
    items.forEach(function (o) {
      if (o.id !== it.id && positions[o.id] && positions[o.id].c === c && positions[o.id].r === r) occupied = o;
    });
    if (occupied) {
      var free = nearestFree(c, r, g);
      if (free) { c = free.c; r = free.r; }
    }
    positions[it.id] = { c: c, r: r };
    W11Storage.set("positions", positions);
    render();
    select(it.id);
  }

  function nearestFree(c0, r0, g) {
    var best = null, bestD = Infinity;
    var taken = {};
    items.forEach(function (o) { var p = positions[o.id]; if (p) taken[p.c + "," + p.r] = true; });
    for (var c = 0; c < g.cols; c++) {
      for (var r = 0; r < g.rows; r++) {
        if (taken[c + "," + r]) continue;
        var d = (c - c0) * (c - c0) + (r - r0) * (r - r0);
        if (d < bestD) { bestD = d; best = { c: c, r: r }; }
      }
    }
    return best;
  }

  function select(id) {
    selected = id;
    iconsEl.querySelectorAll(".icon").forEach(function (el) {
      el.classList.toggle("selected", el.dataset.id === id);
    });
  }

  function openItem(it) {
    W11Desktop.launch(it);
  }

  // ---------- Menus ----------
  function showDesktopMenu(x, y) {
    W11UI.showMenu(x, y, [
      { label: "Organizar ícones por nome", action: function () { arrange("name"); } },
      { label: "Restaurar organização padrão", action: function () { arrange("default"); } },
      { sep: true },
      { label: "Atualizar lista de aplicativos", action: function () { W11Desktop.refreshApps(); } },
      { label: "Abrir Explorador", action: function () { W11Apps.open("explorer"); } },
      { sep: true },
      { label: "Personalizar", action: function () { W11Apps.open("settings", { page: "personalizacao" }); } }
    ]);
  }

  function showIconMenu(x, y, it) {
    var list = [{ label: "Abrir", action: function () { openItem(it); } }];
    if (it.kind === "android") {
      list.push({ label: "Trocar aplicativo...", action: function () { chooseReplacement(it); } });
    }
    list.push({ sep: true });
    list.push({ label: "Organizar ícones por nome", action: function () { arrange("name"); } });
    W11UI.showMenu(x, y, list);
  }

  function chooseReplacement(it) {
    var pickedPkg = null;
    var all = sortApps(androidApps);
    var old = it.ref;
    // Diálogo com lista pesquisável
    var root = document.getElementById("dialog-root");
    var back = document.createElement("div");
    back.className = "dialog-backdrop";
    back.innerHTML =
      '<div class="dialog" role="dialog" aria-modal="true" style="width:min(460px,100%)">' +
      '<h2>Trocar aplicativo fixado</h2>' +
      '<p>Escolha o aplicativo que ocupará o lugar de ' + W11UI.escape(it.label) + '.</p>' +
      '<input class="field" id="swap-search" placeholder="Pesquisar" autocomplete="off">' +
      '<div class="start-list" id="swap-list" style="max-height:340px;overflow:auto;margin-top:10px"></div>' +
      '<div class="actions"><button class="btn" data-cancel>Cancelar</button></div></div>';
    root.appendChild(back);
    var listEl = back.querySelector("#swap-list");
    function draw(q) {
      listEl.innerHTML = "";
      var needle = (q || "").toLowerCase();
      all.filter(function (a) { return !needle || a.label.toLowerCase().indexOf(needle) !== -1; })
         .slice(0, 300).forEach(function (a) {
        var b = document.createElement("button");
        b.className = "app-row";
        b.innerHTML = '<span></span>';
        b.querySelector("span").textContent = a.label;
        b.addEventListener("click", function () { pickedPkg = a.pkg; close(); });
        listEl.appendChild(b);
      });
    }
    function close() {
      back.remove();
      if (!pickedPkg || pickedPkg === old) return;
      var pos = pinned.indexOf(old);
      var other = pinned.indexOf(pickedPkg);
      if (pos === -1) return;
      if (other !== -1) pinned[other] = old; // troca com o outro fixado
      pinned[pos] = pickedPkg;
      W11Storage.set("pinned", pinned);
      render();
    }
    back.querySelector("[data-cancel]").addEventListener("click", function () { pickedPkg = null; close(); });
    back.querySelector("#swap-search").addEventListener("input", function (e) { draw(e.target.value); });
    back.addEventListener("keydown", function (e) { if (e.key === "Escape") { pickedPkg = null; close(); } });
    draw("");
    setTimeout(function () { back.querySelector("#swap-search").focus(); }, 30);
  }

  function arrange(mode) {
    var list = items.slice();
    if (mode === "name") {
      list.sort(function (a, b) { return collator(a.label, b.label); });
    }
    positions = {};
    var g = gridSize();
    var c = 0, r = 0;
    list.forEach(function (it) {
      positions[it.id] = { c: c, r: r };
      r++;
      if (r >= g.rows) { r = 0; c++; }
    });
    W11Storage.set("positions", positions);
    render();
    W11UI.toast(mode === "name" ? "Ícones organizados por nome." : "Organização restaurada.", "ok", 1800);
  }

  // ---------- Papel de parede ----------
  // Papéis predefinidos (gradientes locais, sem imagens externas)
  var WALLPAPER_PRESETS = [
    { id: "blue", name: "Azul", css: "linear-gradient(135deg,#0b3d91,#1f6fd1 40%,#58b0ff 75%,#bfe3ff)" },
    { id: "dusk", name: "Crepúsculo", css: "linear-gradient(160deg,#2b1055,#7597de 55%,#ffd3a5)" },
    { id: "forest", name: "Floresta", css: "linear-gradient(135deg,#0f3d2e,#1f7a5a 50%,#8fd3b6)" },
    { id: "night", name: "Noite", css: "linear-gradient(180deg,#0b0c10,#1f2833 60%,#45a29e)" }
  ];

  function applyWallpaper() {
    var wp = document.getElementById("wallpaper");
    var prefs = W11Storage.get("wallpaper", { source: "default", preset: "blue", mode: "fill", data: "" });
    wp.className = "wallpaper mode-" + (prefs.mode || "fill");
    wp.style.backgroundImage = "";
    if (prefs.source === "custom" && prefs.data) {
      wp.style.backgroundImage = "url(\"" + prefs.data + "\")";
    } else {
      var preset = WALLPAPER_PRESETS.find(function (p) { return p.id === (prefs.preset || "blue"); }) || WALLPAPER_PRESETS[0];
      wp.style.backgroundImage = preset.css;
    }
  }

  var W11Desktop = {
    WALLPAPER_PRESETS: WALLPAPER_PRESETS,

    init: function () {
      rootEl = document.getElementById("desktop");
      iconsEl = document.getElementById("icons");
      pinned = W11Storage.get("pinned", []);
      positions = W11Storage.get("positions", {});
      rootEl.addEventListener("pointerdown", function (ev) {
        if (ev.target === rootEl || ev.target === iconsEl || ev.target.id === "wallpaper") {
          select(null);
          W11UI.hideMenu();
        }
      });
      rootEl.addEventListener("contextmenu", function (ev) {
        if (ev.target.closest(".icon")) return;
        ev.preventDefault();
        var p = W11Screen.pt(ev);
        showDesktopMenu(p.x, p.y);
      });
      // Toque longo no fundo abre o menu
      var t = null, sx = 0, sy = 0;
      rootEl.addEventListener("pointerdown", function (ev) {
        if (ev.target.closest(".icon") || ev.pointerType === "mouse") return;
        var p = W11Screen.pt(ev);
        sx = p.x; sy = p.y;
        clearTimeout(t);
        t = setTimeout(function () { showDesktopMenu(sx, sy); }, 520);
      });
      rootEl.addEventListener("pointermove", function (ev) {
        if (!t) return;
        var p = W11Screen.pt(ev);
        if (Math.hypot(p.x - sx, p.y - sy) > 10) { clearTimeout(t); t = null; }
      });
      rootEl.addEventListener("pointerup", function () { clearTimeout(t); t = null; });
      window.addEventListener("resize", function () { render(); });
      applyWallpaper();
    },

    /** Carrega os apps Android a partir da ponte nativa. */
    loadApps: function () {
      androidApps = sortApps(W11Bridge.getApps());
      iconCache = {};
      syncPinned();
      render();
    },

    refreshApps: function () {
      W11Bridge.refreshApps();
      W11Desktop.loadApps();
      W11UI.toast("Lista de aplicativos atualizada (" + androidApps.length + " encontrados).", "ok");
    },

    getAndroidApps: function () {
      return androidApps.slice();
    },

    getPinned: function () {
      return pinned.slice();
    },

    render: render,
    applyWallpaper: applyWallpaper,
    arrange: arrange,
    select: select,

    /** Abre um item (interno ou Android) e mostra erro útil se não for possível. */
    launch: function (it) {
      if (it.kind === "internal") {
        W11Apps.open(it.ref);
        return;
      }
      var res = W11Bridge.launchApp(it.ref);
      if (!res.ok) {
        W11UI.toast("Não foi possível abrir " + it.label + ". " + (res.message || ""), "error", 4500);
      }
    }
  };

  window.W11Desktop = W11Desktop;
})();
