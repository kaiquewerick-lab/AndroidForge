/*
 * storage.js - Armazenamento local persistente.
 *
 * Usa window.localStorage (dentro da WebView do APK) para:
 *   - preferências (tema, cor, ícones, papel de parede, escala etc.);
 *   - posições dos ícones, lista de fixados e histórico de janelas;
 *   - sistema de arquivos interno (pastas, arquivos de texto e Lixeira).
 * O limite típico é de ~5 MB por origem. Imagens de papel de parede são
 * reduzidas antes de salvar para caber nesse limite.
 *
 * Regras:
 *   - set() retorna false quando a gravação falha (cota cheia). Nesse caso o
 *     valor antigo continua valendo, e quem chamou pode avisar o usuário.
 *   - Se localStorage não existir (navegador com bloqueio), os dados ficam
 *     em memória e valem só nesta sessão.
 *
 * Nenhum dado sai do aparelho.
 */
(function () {
  "use strict";

  var PREFIX = "w11l:";
  var memory = {};
  var hasLocal = true;

  try {
    var probe = "__w11l_probe__";
    window.localStorage.setItem(probe, "1");
    window.localStorage.removeItem(probe);
  } catch (e) {
    hasLocal = false;
  }

  function rawGet(key) {
    if (!hasLocal) return Object.prototype.hasOwnProperty.call(memory, key) ? memory[key] : null;
    try {
      return window.localStorage.getItem(PREFIX + key);
    } catch (e) {
      return null;
    }
  }

  function rawSet(key, value) {
    if (!hasLocal) { memory[key] = value; return true; }
    try {
      window.localStorage.setItem(PREFIX + key, value);
      return true;
    } catch (e) {
      // Quota excedida ou armazenamento indisponível: nada é alterado
      return false;
    }
  }

  var Storage = {
    /** Retorna o valor JSON desserializado ou o padrão. */
    get: function (key, defaultValue) {
      var raw = rawGet(key);
      if (raw === null || raw === undefined) return defaultValue;
      try {
        return JSON.parse(raw);
      } catch (e) {
        return defaultValue;
      }
    },
    /** Salva um valor como JSON. Retorna false se não foi possível gravar. */
    set: function (key, value) {
      return rawSet(key, JSON.stringify(value));
    },
    remove: function (key) {
      try {
        if (hasLocal) window.localStorage.removeItem(PREFIX + key);
      } catch (e) { /* ignorar */ }
      delete memory[key];
    },
    isPersistent: function () {
      return hasLocal;
    }
  };

  window.W11Storage = Storage;
})();
