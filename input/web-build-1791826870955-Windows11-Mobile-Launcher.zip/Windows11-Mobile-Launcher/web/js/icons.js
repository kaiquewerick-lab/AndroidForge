/*
 * icons.js - Conjunto de ícones vetoriais (SVG inline) usado em toda a interface.
 *
 * Nenhum ícone é emoji ou caractere de símbolo: todos são desenhos SVG com
 * traço na cor atual (currentColor), para ficarem nítidos em qualquer DPI e
 * seguirem o tema claro/escuro e a cor de destaque.
 *
 * Uso: W11Icons.svg("folder")  ->  "<svg ...>...</svg>" (string segura, sem dados externos)
 */
(function () {
  "use strict";

  // Cada ícone: lista de elementos SVG (sem o <svg> externo). Grade de 24x24.
  var PATHS = {
    folder:   '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    file:     '<path d="M6 3h8l4 4v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z"/><path d="M14 3v4h4"/><path d="M8.5 13h7M8.5 16.5h5"/>',
    image:    '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="9.5" r="1.8"/><path d="M3 17l5-5 4 4 3-3 6 6"/>',
    trash:    '<path d="M4 7h16"/><path d="M9 7V4.5h6V7"/><path d="M6 7l1 13h10l1-13"/><path d="M10 11v5M14 11v5"/>',
    monitor:  '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M9 20h6M12 16v4"/>',
    notepad:  '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/>',
    calc:     '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8"/><path d="M8.5 11.5h.01M12 11.5h.01M15.5 11.5h.01M8.5 15.5h.01M12 15.5h.01M15.5 15.5h.01" stroke-width="2.4"/>',
    paint:    '<path d="M14.5 4.5l5 5L10 19l-5 1 1-5z"/><path d="M13 6l5 5"/>',
    chart:    '<path d="M4 20V4"/><path d="M4 20h16"/><path d="M8 16v-4M12 16V8M16 16v-6"/>',
    gear:     '<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="7.5"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>',
    run:      '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9.5l3 2.5-3 2.5"/><path d="M12.5 14.5H17"/>',
    search:   '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.4-4.4"/>',
    bell:     '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    taskview: '<rect x="3" y="6" width="12" height="10" rx="2"/><rect x="9" y="9" width="12" height="10" rx="2"/>',
    power:    '<path d="M12 3v8.5"/><path d="M6.3 6.3a8 8 0 1 0 11.4 0"/>',
    close:    '<path d="M6 6l12 12M18 6L6 18"/>',
    minimize: '<path d="M5 12h14"/>',
    maximize: '<rect x="5" y="5" width="14" height="14" rx="1.5"/>',
    restore:  '<path d="M8 8V5.5h10.5V16H16"/><rect x="5" y="8" width="11" height="11" rx="1.5"/>',
    chevronL: '<path d="M15 6l-6 6 6 6"/>',
    chevronR: '<path d="M9 6l6 6-6 6"/>',
    arrowUp:  '<path d="M12 19V5"/><path d="M5.5 11.5L12 5l6.5 6.5"/>',
    backspace:'<path d="M9.5 5H20v14H9.5L3.5 12z"/><path d="M13 9.5l5 5M18 9.5l-5 5"/>',
    apps:     '<rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/>',
    window:   '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>',
    plus:     '<path d="M12 5v14M5 12h14"/>',
    sliders:  '<path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/>',
    cog:      '<circle cx="12" cy="12" r="3"/>'
  };

  // Ícones usados em cada contexto podem pedir nomes alternativos
  var ALIAS = {
    explorer: "folder", lixeira: "trash", notepad: "notepad", calculator: "calc",
    settings: "gear", taskmanager: "chart", desktop: "monitor", docs: "file", images: "image",
    document: "file", window: "window"
  };

  var W11Icons = {
    /** Nomes disponíveis. */
    names: Object.keys(PATHS),

    /** Retorna o SVG do ícone (ou o ícone genérico de janela, se o nome não existir). */
    svg: function (name, extraClass) {
      var key = PATHS[name] ? name : (ALIAS[name] && PATHS[ALIAS[name]] ? ALIAS[name] : "window");
      return '<svg class="ico' + (extraClass ? " " + extraClass : "") + '" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' +
        PATHS[key] + '</svg>';
    },

    /** Nome de ícone resolvido (para testes e checagens). */
    resolve: function (name) {
      return PATHS[name] ? name : (ALIAS[name] && PATHS[ALIAS[name]] ? ALIAS[name] : "window");
    },

    /** Preenche todo elemento [data-icon="nome"] dentro de root com o SVG correspondente. */
    mount: function (root) {
      (root || document).querySelectorAll("[data-icon]").forEach(function (el) {
        el.innerHTML = W11Icons.svg(el.dataset.icon);
      });
    }
  };

  window.W11Icons = W11Icons;
})();
