# Windows 11 Mobile Launcher

Um launcher para Android com aparência e experiência inspiradas no Windows 11: área de trabalho com ícones, barra de tarefas, menu Iniciar com pesquisa, janelas internas arrastáveis, Explorador de arquivos, Bloco de Notas, Calculadora, Paint simples, Gerenciador de tarefas, Executar e Configurações com personalização completa.

A interface é feita em **HTML, CSS e JavaScript** e roda dentro de uma **WebView** em um app Android (**Kotlin**). A camada nativa existe apenas para consultar os aplicativos instalados, abri-los e conversar com o sistema.

> **Importante:** este projeto **não** é um PC virtual, não usa RDP e não controla aplicativos Android como janelas de desktop. Os aplicativos Android são abertos pelos mecanismos oficiais do sistema. As ferramentas internas (Explorador, Bloco de Notas etc.) são janelas reais dentro do próprio launcher. Veja [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

---

## Sumário

1. [Estrutura de pastas](#estrutura-de-pastas)
2. [Projeto Gradle na raiz (AndroidForge)](#projeto-gradle-na-raiz-androidforge)
3. [Como compilar o APK](#como-compilar-o-apk)
4. [Como editar os arquivos pelo celular](#como-editar-os-arquivos-pelo-celular)
5. [Como testar a interface no navegador](#como-testar-a-interface-no-navegador)
6. [Como definir como tela inicial](#como-definir-como-tela-inicial)
7. [Regra dos 10 aplicativos fixados](#regra-dos-10-aplicativos-fixados)
8. [Atalhos de teclado](#atalhos-de-teclado)
9. [Armazenamento e privacidade](#armazenamento-e-privacidade)
10. [Estado de verificação](#estado-de-verificação)
11. [Documentação adicional](#documentação-adicional)
12. [Licença](#licença)

---

## Estrutura de pastas

A pasta `Windows11-Mobile-Launcher/` é **a raiz do projeto Gradle**. Os arquivos `settings.gradle.kts` e `build.gradle.kts` estão nela, e não em subpastas.

```
Windows11-Mobile-Launcher/            <- raiz do projeto (raiz Gradle)
├── settings.gradle.kts               Declara o projeto e o módulo :app
├── build.gradle.kts                  Plugins do projeto (AGP 8.1.0, Kotlin 1.9.24)
├── gradle.properties                 Configurações do Gradle e do AndroidX
├── gradlew                           Script do Gradle Wrapper (Linux/macOS)
├── gradlew.bat                       Script do Gradle Wrapper (Windows)
├── gradle/
│   └── wrapper/
│       ├── gradle-wrapper.jar        Launcher do wrapper (Gradle 8.0 é baixado na 1ª execução)
│       └── gradle-wrapper.properties Versão do Gradle: 8.0
├── app/                              Módulo Android (:app)
│   ├── build.gradle.kts              Configuração Android: SDK 34, minSdk 29, JDK 17, assets
│   └── src/main/
│       ├── AndroidManifest.xml       Atividade HOME/LAUNCHER, sem permissões, queries
│       ├── java/com/example/win11launcher/
│       │   ├── MainActivity.kt       WebView, Voltar, seletor de arquivos, eventos de pacotes
│       │   └── LauncherBridge.kt     Ponte nativa (única superfície exposta à página)
│       └── res/                      Textos, tema, cores e ícone adaptativo
├── web/                              Interface HTML/CSS/JS (empacotada como assets do APK)
│   ├── index.html                    Página principal
│   ├── css/style.css                 Estilos, temas e responsividade
│   ├── js/
│   │   ├── storage.js                Armazenamento local (localStorage)
│   │   ├── bridge.js                 Ponte com o Android (valida tudo antes de usar)
│   │   ├── windows.js                Gerenciador de janelas internas
│   │   ├── ui.js                     Menus de contexto, diálogos e avisos
│   │   ├── desktop.js                Área de trabalho, ícones, fixados e papel de parede
│   │   ├── taskbar.js                Barra de tarefas, menu Iniciar, calendário, notificações
│   │   ├── keyboard.js               Atalhos de teclado
│   │   ├── main.js                   Inicialização e ganchos chamados pelo Android
│   │   └── apps/                     Ferramentas internas
│   │       ├── fs.js                 Sistema de arquivos interno e Lixeira
│   │       ├── explorer.js           Explorador de arquivos
│   │       ├── notepad.js            Bloco de Notas
│   │       ├── calculator.js         Calculadora
│   │       ├── paint.js              Paint simples
│   │       ├── taskmanager.js        Gerenciador de tarefas
│   │       ├── run.js                Executar (lista fechada de comandos)
│   │       ├── settings.js           Configurações e personalização
│   │       └── registry.js           Registro dos aplicativos internos
│   └── assets/icon.svg               Ícone da página
├── tests/                            Testes de lógica (Node) e de interface (Playwright)
├── docs/
│   ├── INSTALLATION.md               Instalação e compilação
│   ├── FEATURES.md                   Recursos implementados
│   └── LIMITATIONS.md                Limitações reais do Android e do projeto
├── README.md
├── LICENSE
└── .gitignore
```

**Onde fica cada tipo de arquivo:**

| Tipo | Local |
|---|---|
| Gradle (projeto e módulo) | raiz (`settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`) e `app/build.gradle.kts` |
| Android (manifesto, Kotlin, recursos) | `app/src/main/` |
| Interface web (HTML, CSS, JavaScript) | `web/` |
| Interface web dentro do APK | `web/` é lida pelo Gradle como assets (`app/build.gradle.kts`, `assets.srcDirs("../web")`) e entra em `assets/` do APK |

---

## Projeto Gradle na raiz (AndroidForge)

O AndroidForge procura o projeto na pasta `Windows11-Mobile-Launcher`. Essa pasta precisa conter o `settings.gradle.kts` diretamente na raiz. É o que este projeto faz.

Para conferir antes de enviar:

```
Windows11-Mobile-Launcher/settings.gradle.kts     OK existe na raiz
Windows11-Mobile-Launcher/build.gradle.kts        OK
Windows11-Mobile-Launcher/app/build.gradle.kts    OK
Windows11-Mobile-Launcher/gradlew                 OK (com permissão de execução)
```

Se o AndroidForge extrair o ZIP numa pasta de trabalho, a estrutura esperada é `.../Windows11-Mobile-Launcher/settings.gradle.kts`. Não coloque o projeto dentro de outra subpasta.

**Android SDK:** o projeto não inclui `local.properties` (ele depende da máquina). Antes de compilar, o ambiente precisa informar o SDK por uma destas formas:

- variável `ANDROID_HOME` (ou `ANDROID_SDK_ROOT`) apontando para o SDK; ou
- arquivo `local.properties` na raiz com `sdk.dir=/caminho/do/Android/Sdk`.

O SDK precisa ter a plataforma **Android 34** e o **build-tools 34.0.0** (ou mais recente).

---

## Como compilar o APK

### Versões usadas

| Componente | Versão | Motivo |
|---|---|---|
| JDK | **17** | Exigido pelo AGP 8.1 e configurado em `app/build.gradle.kts` (Java 17 / jvmTarget 17) |
| Gradle | **8.0** | Mínimo exigido pelo AGP 8.1.0 (definido em `gradle-wrapper.properties`). É a versão que o AndroidForge fornece |
| Android Gradle Plugin | **8.1.0** | Exige Gradle 8.0 e JDK 17 (tabela oficial de compatibilidade do AGP 8.1.0) |
| Kotlin (plugin Android) | **1.9.24** | Tabela oficial do Kotlin: a faixa 1.9.20–1.9.25 aceita AGP até 8.1.0 e Gradle 8.0 |
| compileSdk / targetSdk | **34** | Plataforma Android 14 |
| minSdk | **29** | Android 10 (usa `MediaStore.Downloads`) |

> **Por que AGP 8.1 e não 8.5?** O AGP 8.5.x exige Gradle 8.7 no mínimo, e o AndroidForge (build com "Use Gradle wrapper: False") executa o Gradle 8.0. Com o AGP 8.5.2 o build falhava com `Minimum supported Gradle version is 8.7. Current version is 8.0`. O AGP 8.2.0 exige Gradle 8.2, então o AGP 8.1.0 é a versão mais nova que roda com Gradle 8.0. Para voltar ao AGP 8.5.x, o Gradle precisa ser 8.7 ou superior, no AndroidForge e no wrapper.

### Pelo Gradle Wrapper (recomendado)

A partir da pasta `Windows11-Mobile-Launcher/`:

```bash
# Linux / macOS
./gradlew assembleDebug

# Windows
gradlew.bat assembleDebug
```

Na primeira execução o wrapper baixa o Gradle 8.0. Depois, o Gradle baixa o AGP, o Kotlin e as bibliotecas AndroidX. Esse passo precisa de internet.

Saída: `app/build/outputs/apk/debug/app-debug.apk`

### Pelo Android Studio

1. **File > Open** e escolha a pasta `Windows11-Mobile-Launcher/` (a raiz, onde estão `settings.gradle.kts` e `gradlew`).
2. Aguarde o **Gradle Sync**.
3. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

### APK de release

```bash
./gradlew assembleRelease
```

O resultado é `app/build/outputs/apk/release/app-release-unsigned.apk`. Ele **não é assinado**. Para publicar, assine com sua própria chave (**Build > Generate Signed Bundle / APK** no Android Studio). A chave não é incluída no projeto.

---

## Como editar os arquivos pelo celular

Você pode editar o projeto inteiro sem computador, usando um app de edição de código e texto para Android com suporte a pastas e a arquivos `.html`, `.css`, `.js`, `.kt`, `.kts` e `.xml`:

1. **Descompacte o ZIP** com o gerenciador de arquivos do Android ou com um app de extração.
2. **Interface:** edite `web/index.html`, `web/css/style.css` e os arquivos de `web/js/`.
3. **Nome do app:** edite `app/src/main/res/values/strings.xml`.
4. **Cor do ícone:** edite `app/src/main/res/values/colors.xml`.
5. **Versão:** edite `versionCode` e `versionName` em `app/build.gradle.kts`.
6. Para testar a interface, abra `web/index.html` no navegador do celular. Não é preciso compilar nada para isso.

> Para gerar o APK é preciso um computador ou um serviço de compilação com Android SDK. Veja [docs/INSTALLATION.md](docs/INSTALLATION.md).

## Como testar a interface no navegador

1. Abra `web/index.html` em um navegador moderno.
2. Fora do APK, a ponte nativa não existe. O launcher usa então uma **lista simulada de aplicativos** e mostra um aviso no centro de notificações. As ferramentas internas, a personalização e os atalhos funcionam normalmente.
3. Os dados ficam no `localStorage` do próprio navegador, separados do APK.

---

## Como definir como tela inicial

1. Instale o APK e abra o app uma vez.
2. Vá em **Configurações > Apps > Aplicativo padrão de início** (o caminho exato varia conforme a marca do aparelho) e escolha **Windows 11 Mobile Launcher**.
3. Pressione o botão Início. O launcher aparece.
4. Para voltar ao launcher anterior, selecione-o nas mesmas configurações.

O launcher **nunca** se define como padrão sem a sua escolha.

---

## Regra dos 10 aplicativos fixados

- Os aplicativos Android são ordenados **por nome** (pt-BR, sem diferenciar maiúsculas e acentos; empate pelo identificador do pacote).
- Os **10 primeiros** aparecem na área de trabalho.
- Para trocar um deles, use o **botão direito** no ícone (ou **toque longo**) e escolha **Trocar aplicativo...**.
- Se um app fixado for desinstalado, o próximo da ordem alfabética ocupa o lugar.
- Atalhos internos (Explorador, Bloco de Notas etc.) são separados e não contam nos 10.

---

## Atalhos de teclado

| Atalho | Ação |
|---|---|
| Win | Abre ou fecha o menu Iniciar (quando a tecla chega ao launcher) |
| Win + E | Explorador |
| Win + D | Mostra a área de trabalho (minimiza as janelas) |
| Win + R | Executar |
| Win + I | Configurações |
| Win + S | Pesquisa no menu Iniciar |
| Win + Tab | Janelas abertas |
| Alt + Tab | Alterna para a janela anterior |
| Alt + F4 | Fecha a janela ativa |
| Win + Esquerda / Direita | Encaixa a janela à esquerda / direita |
| Win + Cima | Maximiza |
| Win + Baixo | Restaura ou minimiza |
| Ctrl + Shift + Esc | Gerenciador de tarefas |
| Ctrl + C / X / V | Copiar, recortar e colar (em campos e no Explorador) |
| Ctrl + Z / Y | Desfazer e refazer (Bloco de Notas e campos de texto) |
| F2 | Renomear no Explorador |
| Delete | Enviar à Lixeira (no Explorador) |
| F11 | Alterna a tela cheia da janela ativa (Esc também sai) |
| Esc | Fecha menus, painéis e diálogos |

Atalhos de gerenciamento de janelas (Win+setas, Alt+Tab, Alt+F4, F11) também funcionam com o cursor em um campo de texto. Teclas de digitação nunca são interceptadas. Limitações da tecla Windows estão em [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

---

## Armazenamento e privacidade

- **Preferências, posições dos ícones, fixados, notificações e arquivos internos** ficam no `localStorage` da WebView (armazenamento local do próprio app). Eles continuam disponíveis depois de fechar e reabrir o launcher.
- **Arquivos internos** são virtuais. Eles **não** são o armazenamento do aparelho. Para trazer um arquivo do celular, use **Importar do aparelho** no Explorador ou **Abrir do aparelho** no Bloco de Notas: o seletor do próprio Android abre e apenas o arquivo escolhido é lido.
- **Exportações** (Paint em PNG e textos em `.txt`) são gravadas com o MediaStore do Android em `Pictures/Win11Launcher` e `Download/Win11Launcher`, sem permissão de armazenamento.
- **Nenhuma permissão** é declarada no manifesto.
- **Nenhum dado é enviado** para servidores. Não há contas, Firebase, chaves de API, serviços pagos, inteligência artificial nem JavaScript remoto. A WebView bloqueia navegação para fora do pacote local.

---

## Estado de verificação

O que foi verificado, e como, está listado abaixo. Nada foi marcado como testado sem ter sido executado.

| Verificação | Situação |
|---|---|
| Estrutura: `settings.gradle.kts` na raiz da pasta do projeto | Sim: Corrigida e conferida |
| `settings.gradle.kts` avaliado pelo Gradle local (sintaxe e raiz do projeto) | Sim: Avaliado. A falha seguinte ocorre em `build.gradle.kts` e é de **rede** (ver abaixo) |
| Sintaxe dos arquivos Kotlin (`MainActivity.kt`, `LauncherBridge.kt`) com o compilador Kotlin 2.0 embutido no Gradle | Sim: Nenhum erro de sintaxe. Os erros restantes são de tipos Android não resolvidos, porque o `android.jar` não estava disponível |
| XML (manifesto, `strings.xml`, `themes.xml`, `colors.xml`, ícones) bem formados e recursos referenciados existentes | Sim: Verificado |
| Sintaxe dos arquivos JavaScript (`node --check`) | Sim: Sem erros |
| Lógica da calculadora e do sistema de arquivos (`tests/teste_logica.js`) | Sim: Aprovada |
| Interface no Chromium (Playwright), viewport de 390 px e 1100 px (`tests/teste_navegador_*.py`) | Sim: Sem erros de JavaScript. Cobre janelas, atalhos, menu Iniciar, Explorador, Bloco de Notas, menu de contexto, papel de parede, tema e persistência |
| Escala de exibição (DPI), grade de ícones, ausência de emojis e correções de comportamento (`tests/teste_navegador_4.py`) | Sim: 12 de 12 verificações passaram no Chromium |
| **Build do APK (`assembleDebug`)** | Não **Não executado com sucesso.** O ambiente de testes não consegue acessar `dl.google.com`, `maven.google.com` nem `services.gradle.org`. O proxy nega essas conexões (HTTP 403), então o plugin do Android não pode ser baixado |
| Execução dentro da Android WebView e em aparelho real | Não Não executado |

**Consequência prática:** o projeto está estruturado como um projeto Gradle válido, e os erros de configuração que eram verificáveis aqui foram corrigidos. Mas **não é possível afirmar que o build passa** sem executar `./gradlew assembleDebug` num ambiente com acesso ao Google Maven. Se o AndroidForge tiver esse acesso, o build deve ser executado lá, e o log dele é a verificação definitiva.

Para rodar os testes de navegador: Python 3 com Playwright (`pip install playwright && playwright install chromium`), depois `python3 tests/teste_navegador_1.py` (e os demais, incluindo `teste_navegador_4.py`, que verifica escala, ícones, ausência de emojis e as correções). Os testes de lógica rodam com `node tests/teste_logica.js`.

---

## Documentação adicional

- [docs/INSTALLATION.md](docs/INSTALLATION.md): instalação, compilação e roteiro de testes.
- [docs/FEATURES.md](docs/FEATURES.md): recursos implementados e como cada um funciona.
- [docs/LIMITATIONS.md](docs/LIMITATIONS.md): limitações impostas pelo Android e pelo projeto.

## Licença

Distribuído sob a licença MIT. Veja [LICENSE](LICENSE).
