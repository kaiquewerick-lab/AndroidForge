(() => {
"use strict";

/* ============ Configuração ============ */
// Logo: arquivo ao lado deste HTML. Quando o backend estiver no ar, troque pelo endereço dele,
// por exemplo "https://api.seudominio.com/assets/logo.png".
const LOGO_URL = "assets/logo.png";
const BACKEND_KEY = "saturn-desktop-beta:backend:v1";
const PREF_KEY = "saturn-desktop-beta:preferencias:v1";
const RETRY_MS = 15000;
const TIMEOUT_MS = 6000;
const ACTION_TIMEOUT_MS = 25000;
const API_DEFAULT = "https://saturndesktopbeta-api.kiiikaioxdogulox.workers.dev";

/* ============ Utilitários ============ */
const $ = (s) => document.querySelector(s);
const isPos = (n) => typeof n === "number" && Number.isFinite(n) && n > 0;
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const ESC = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ESC[c]);
function formatGb(gb) {
  if (typeof gb !== "number" || !Number.isFinite(gb) || gb < 0) return "—";
  if (gb >= 1024) { const tb = gb / 1024; return `${Number.isInteger(tb) ? tb : tb.toFixed(1)} TB`; }
  return `${gb} GB`;
}

/* ============ Perfis e seleção ============ */
const PROFILES = [
  { id: "economico", label: "Econômico", hint: "Menor consumo e custo para tarefas leves.", needsGpu: false },
  { id: "equilibrado", label: "Equilibrado", hint: "Equilíbrio entre desempenho e custo.", needsGpu: false },
  { id: "alto", label: "Alto desempenho", hint: "Prioriza CPU e RAM que o servidor puder oferecer.", needsGpu: false },
  { id: "jogos", label: "Jogos e gráficos", hint: "Requer uma GPU dedicada disponível.", needsGpu: true },
  { id: "desenvolvimento", label: "Desenvolvimento de software", hint: "Compilação, terminal e ferramentas de projeto.", needsGpu: false },
  { id: "renderizacao", label: "Renderização e aplicações pesadas", hint: "Combinação de vCPU, RAM e armazenamento para cargas longas.", needsGpu: false },
];
const EMPTY = { os: null, ram: null, cpu: null, gpu: null, storage: null, resolution: null, profile: "equilibrado" };

function sanitize(raw) {
  const s = { ...EMPTY };
  if (!isObj(raw)) return s;
  if (typeof raw.os === "string" && raw.os) s.os = raw.os;
  if (isPos(raw.ram)) s.ram = raw.ram;
  if (isPos(raw.cpu)) s.cpu = raw.cpu;
  if (typeof raw.gpu === "string" && raw.gpu) s.gpu = raw.gpu;
  if (isPos(raw.storage)) s.storage = raw.storage;
  if (typeof raw.resolution === "string" && /^\d{3,5}x\d{3,5}$/.test(raw.resolution)) s.resolution = raw.resolution;
  if (PROFILES.some((p) => p.id === raw.profile)) s.profile = raw.profile;
  return s;
}

/* ============ Catálogo ============ */
// Só existe o que o backend informa. Sem backend, o catálogo fica vazio.
function unavailable(reason) {
  return { status: "unavailable", reason, demo: false, os: [], ram: [], cpu: [], gpu: [], storage: [], resolutions: [], machines: [], limits: null, disk: null };
}

function normalize(raw) {
  if (!isObj(raw)) return unavailable("O backend retornou um catálogo em formato inválido.");
  const items = (list, ok) => (Array.isArray(list) ? list.filter((x) => isObj(x) && ok(x)) : []);
  const off = (x) => x.available !== false;
  const sortBy = (k) => (a, b) => a[k] - b[k];
  const disk = (d) => {
    if (!isObj(d) || !isPos(d.totalGb)) return null;
    const used = typeof d.usedGb === "number" && d.usedGb >= 0 ? Math.min(d.usedGb, d.totalGb) : 0;
    return {
      volumeId: String(d.volumeId ?? "—"), state: String(d.state ?? "desconhecido"),
      totalGb: d.totalGb, usedGb: used, freeGb: d.totalGb - used,
      files: Number.isInteger(d.files) ? d.files : null,
      persistent: d.persistent === true, expandable: d.expandable === true,
    };
  };
  return {
    status: "ok", reason: null, demo: raw.demo === true,
    os: items(raw.os, (x) => typeof x.id === "string" && typeof x.name === "string" && off(x)),
    ram: items(raw.ram, (x) => isPos(x.gb) && off(x)).sort(sortBy("gb")),
    cpu: items(raw.cpu, (x) => Number.isInteger(x.vcpus) && x.vcpus > 0 && off(x)).sort(sortBy("vcpus")),
    gpu: items(raw.gpu, (x) => typeof x.id === "string" && typeof x.name === "string").map((x) => ({
      id: x.id, name: x.name, vramGb: isPos(x.vramGb) ? x.vramGb : null, available: off(x),
      assignment: typeof x.assignment === "string" ? x.assignment : "não informada",
      features: Array.isArray(x.features) ? x.features.filter((f) => typeof f === "string") : [],
      notes: typeof x.notes === "string" ? x.notes : null,
    })),
    storage: items(raw.storage, (x) => isPos(x.gb) && off(x)).sort(sortBy("gb")),
    resolutions: Array.isArray(raw.resolutions) ? raw.resolutions.filter((r) => typeof r === "string" && /^\d{3,5}x\d{3,5}$/.test(r)) : [],
    machines: items(raw.machines, (x) => typeof x.id === "string" && typeof x.name === "string").map((m) => ({
      id: m.id, name: m.name, state: String(m.state ?? "desconhecido"), os: String(m.os ?? "—"),
    })),
    limits: isObj(raw.limits) ? {
      maxRamGb: isPos(raw.limits.maxRamGb) ? raw.limits.maxRamGb : null,
      maxVcpus: isPos(raw.limits.maxVcpus) ? raw.limits.maxVcpus : null,
      maxStorageGb: isPos(raw.limits.maxStorageGb) ? raw.limits.maxStorageGb : null,
    } : null,
    disk: disk(raw.disk),
  };
}

// Catálogo FICTÍCIO, usado só quando o usuário escolhe a demonstração.
const DEMO_RAW = {
  demo: true,
  os: [{ id: "ubuntu", name: "[DEMO] Ubuntu 24.04 LTS" }, { id: "win11", name: "[DEMO] Windows 11", available: false }],
  ram: [{ gb: 4 }, { gb: 8 }, { gb: 16 }, { gb: 32 }],
  cpu: [{ vcpus: 2 }, { vcpus: 4 }, { vcpus: 8 }],
  gpu: [
    { id: "gpu-a", name: "[DEMO] NVIDIA GeForce RTX 4070", vramGb: 12, available: true, assignment: "livre", features: ["Codificação de vídeo por hardware"] },
    { id: "gpu-b", name: "[DEMO] NVIDIA GeForce RTX 4090", vramGb: 24, available: false, assignment: "em uso por outra máquina", notes: "Indisponível no momento" },
  ],
  storage: [{ gb: 20 }, { gb: 50 }, { gb: 100 }, { gb: 256 }],
  resolutions: ["1280x720", "1920x1080", "2560x1440"],
  machines: [],
  limits: { maxRamGb: 32, maxVcpus: 8, maxStorageGb: 256 },
  disk: { volumeId: "demo-vol-01", state: "disponível", totalGb: 50, usedGb: 12, files: 143, persistent: true, expandable: false },
};

/* ============ Detecção do backend ============ */
async function request(url, { method = "GET", body, timeoutMs = TIMEOUT_MS } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  const t0 = performance.now();
  const init = { method, headers: { accept: "application/json" }, cache: "no-store", signal: ctrl.signal };
  if (body !== undefined) {
    init.headers["content-type"] = "application/json";
    init.body = JSON.stringify(body);
  }
  try {
    const res = await fetch(url, init);
    const data = await res.json().catch(() => null);
    return { res, body: data, latency: Math.round(performance.now() - t0) };
  } finally {
    clearTimeout(timer);
  }
}

const addressOf = (base) => base || API_DEFAULT;


function offlineMessage(err, base) {
  if (!base && location.protocol === "file:") {
    return "Este arquivo foi aberto direto do disco, então não há servidor de origem. Informe o endereço do backend em Diagnóstico (ex.: http://127.0.0.1:8080).";
  }
  if (err?.name === "AbortError") return `Sem resposta de ${addressOf(base)} em ${TIMEOUT_MS / 1000} segundos.`;
  return `Não foi possível alcançar ${addressOf(base)}. Confira se o servidor está no ar e se o endereço está certo. Se o backend estiver em outro domínio, ele precisa liberar o acesso desta página (CORS).`;
}

const messageOf = (body, status) => (isObj(body) && typeof body.message === "string" ? body.message : `O backend respondeu com erro ${status}.`);

async function probeHealth(base) {
  try {
    const { res, body, latency } = await request(`${base}/api/health`);
    if (res.status === 404) {
      return { state: "sem_api", http: 404, latency, detail: `${addressOf(base)} respondeu, mas não existe a rota /api/health. A API do backend ainda não foi implementada, ou o endereço aponta para outro serviço.` };
    }
    if (!res.ok) return { state: "erro", http: res.status, latency, detail: `O servidor respondeu com erro HTTP ${res.status}.` };
    if (isObj(body) && body.service !== undefined && body.service !== "saturndesktop-beta") {
      return { state: "inesperado", http: res.status, latency, detail: `${addressOf(base)} respondeu, mas não se identificou como o backend do SaturnDesktopBETA.` };
    }
    return { state: "ok", http: res.status, latency, version: typeof body.version === "string" ? body.version : null, detail: "O backend está no ar." };
  } catch (err) {
    return { state: "offline", http: null, latency: null, detail: offlineMessage(err, base) };
  }
}

// GET /api/config: carrega catálogo e seleção salva. Formato esperado (não verificado em produção):
// { selection: {...}, catalog: { os, ram, cpu, gpu, storage, resolutions, limits, disk, machines } }
async function loadConfig(base) {
  try {
    const { res, body } = await request(`${base}/api/config`);
    if (!res.ok) {
      app.catalog = unavailable("A API não retornou a configuração de hardware.");
      app.config = { state: "erro", message: `Erro ao carregar a configuração: ${messageOf(body, res.status)}` };
      return;
    }
    const data = isObj(body) ? body : {};
    app.catalog = isObj(data.catalog)
      ? normalize(data.catalog)
      : unavailable("A API não informou as capacidades de hardware (catálogo ausente).");
    if (isObj(data.selection)) {
      app.saved = sanitize(data.selection);
      savePrefs(app.saved);
      app.config = { state: "carregada", message: "Configuração carregada da API." };
    } else {
      app.config = { state: "sem_selecao", message: "A API não enviou uma configuração salva." };
    }
  } catch (err) {
    const msg = offlineMessage(err, base);
    app.catalog = unavailable(msg);
    app.config = { state: "erro", message: `Erro ao carregar a configuração: ${msg}` };
  }
}

/* ============ Validação e resumo ============ */
const find = (list, key, v) => list.find((i) => i[key] === v);

function validate(sel, c) {
  const errors = [], warnings = [];
  if (c.status !== "ok") {
    errors.push("Sem capacidades confirmadas pela API. Você pode montar a configuração, mas o PC virtual só inicia quando a API confirmar o início.");
    return { ready: false, errors, warnings };
  }
  if (!sel.os) errors.push("Escolha o sistema operacional.");
  else if (!find(c.os, "id", sel.os)) errors.push("O sistema operacional escolhido não está disponível.");
  if (!sel.ram) errors.push("Escolha a quantidade de RAM.");
  else if (!find(c.ram, "gb", sel.ram)) errors.push(`${formatGb(sel.ram)} de RAM não está disponível nesta infraestrutura.`);
  if (!sel.cpu) errors.push("Escolha a quantidade de vCPUs.");
  else if (!find(c.cpu, "vcpus", sel.cpu)) errors.push(`${sel.cpu} vCPUs não estão disponíveis nesta infraestrutura.`);
  if (!sel.storage) errors.push("Escolha a capacidade do armazenamento.");
  else if (!find(c.storage, "gb", sel.storage)) errors.push(`${formatGb(sel.storage)} de armazenamento não está disponível.`);
  if (sel.gpu) {
    const g = find(c.gpu, "id", sel.gpu);
    if (!g) errors.push("A GPU escolhida não consta mais no catálogo.");
    else if (!g.available) errors.push(`${g.name} está indisponível nesta infraestrutura.`);
  }
  if (sel.resolution && c.resolutions.length && !c.resolutions.includes(sel.resolution)) errors.push(`A resolução ${sel.resolution} não é suportada pelo servidor.`);
  const p = PROFILES.find((x) => x.id === sel.profile);
  if (p?.needsGpu && !sel.gpu) errors.push(`O perfil "${p.label}" exige uma GPU dedicada disponível.`);
  if (c.disk && sel.storage && sel.storage !== c.disk.totalGb) warnings.push(`O volume existente tem ${formatGb(c.disk.totalGb)}. Alterar a capacidade depende de expansão suportada pelo provedor.`);
  return { ready: errors.length === 0, errors, warnings };
}

function summarize(sel, c) {
  const st = (chosen, found) => (!chosen ? "empty" : found ? "ok" : "bad");
  const os = sel.os ? find(c.os, "id", sel.os) : null;
  const gpu = sel.gpu ? find(c.gpu, "id", sel.gpu) : null;
  const p = PROFILES.find((x) => x.id === sel.profile);
  return [
    { key: "os", label: "Sistema operacional", value: os ? os.name : sel.os ? "Indisponível nesta infraestrutura" : "Não escolhido", state: st(sel.os, os) },
    { key: "ram", label: "RAM", value: sel.ram ? formatGb(sel.ram) : "Não escolhida", state: st(sel.ram, find(c.ram, "gb", sel.ram)) },
    { key: "cpu", label: "CPU", value: sel.cpu ? `${sel.cpu} vCPUs` : "Não escolhida", state: st(sel.cpu, find(c.cpu, "vcpus", sel.cpu)) },
    { key: "gpu", label: "GPU", value: gpu ? gpu.name : sel.gpu ? "Indisponível nesta infraestrutura" : "Sem GPU dedicada", state: sel.gpu ? (gpu?.available ? "ok" : "bad") : "empty" },
    { key: "storage", label: "Armazenamento", value: sel.storage ? formatGb(sel.storage) : "Não escolhido", state: st(sel.storage, find(c.storage, "gb", sel.storage)) },
    { key: "resolution", label: "Resolução", value: sel.resolution ? sel.resolution.replace("x", "×") : "Padrão do servidor", state: sel.resolution ? "ok" : "empty" },
    { key: "profile", label: "Perfil", value: p ? p.label : "Equilibrado", state: "ok" },
    { key: "infra", label: "Capacidades", value: c.status !== "ok" ? "Não confirmadas pela API" : c.demo ? "Demonstração (nenhuma máquina real)" : "Confirmadas pela API", state: c.status !== "ok" ? "bad" : c.demo ? "empty" : "ok" },
  ];
}

/* ============ Renderização ============ */
const empty = (t) => `<p class="empty">${esc(t)}</p>`;
const hintP = (t) => (t ? `<p class="hint">${esc(t)}</p>` : "");
const chip = ({ pick, value, label, active, disabled = false, sub = "" }) =>
  `<button type="button" class="chip" data-pick="${esc(pick)}" data-value="${esc(value)}" aria-pressed="${active ? "true" : "false"}"${disabled ? " disabled" : ""}>`
  + `<span>${esc(label)}</span>${sub ? `<small>${esc(sub)}</small>` : ""}</button>`;
const section = (id, title, body, hint = "") => `<section class="cat" aria-labelledby="${id}"><h3 id="${id}">${esc(title)}</h3>${hintP(hint)}${body}</section>`;
const facts = (rows) => `<dl class="facts">${rows.map(([k, v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join("")}</dl>`;

function banner(c) {
  if (c.status !== "ok") return `<div class="banner err"><strong>Sem capacidades confirmadas.</strong> ${esc(c.reason)} As escolhas abaixo são apenas preferências: nenhuma capacidade foi confirmada.</div>`;
  if (c.demo) return `<div class="banner"><strong>Catálogo de demonstração.</strong> Os recursos listados são fictícios; nada será iniciado.</div>`;
  return "";
}

function issues(v) {
  const rows = [...v.errors.map((t) => ["err", t]), ...v.warnings.map((t) => ["warn", t])];
  return rows.length ? `<ul class="issues">${rows.map(([t, m]) => `<li class="${t}">${esc(m)}</li>`).join("")}</ul>` : "";
}

function renderHardwareCenter(c, sel, v) {
  const os = c.os.length
    ? `<div class="options">${c.os.map((o) => chip({ pick: "os", value: o.id, label: o.name, active: sel.os === o.id })).join("")}</div>`
    : empty("Nenhum sistema operacional foi confirmado pela infraestrutura.");

  const ram = c.ram.length
    ? `<div class="options">${c.ram.map((r) => chip({ pick: "ram", value: r.gb, label: formatGb(r.gb), active: sel.ram === r.gb })).join("")}</div>`
    : empty("Nenhuma capacidade de RAM foi confirmada pela infraestrutura.");
  const ramFacts = facts([
    ["Selecionada", sel.ram ? formatGb(sel.ram) : "—"],
    ["Disponível agora", c.ram.length ? formatGb(c.ram.at(-1).gb) : "—"],
    ["Limite da infraestrutura", c.limits?.maxRamGb ? formatGb(c.limits.maxRamGb) : "Não informado"],
    ["Uso atual", "Medido somente com a máquina em execução"],
  ]);

  const cpu = c.cpu.length
    ? `<div class="options">${c.cpu.map((p) => chip({ pick: "cpu", value: p.vcpus, label: `${p.vcpus} vCPUs`, active: sel.cpu === p.vcpus })).join("")}</div>`
    : empty("Nenhuma configuração de vCPU foi confirmada pela infraestrutura.");
  const cpuFacts = facts([
    ["Selecionadas", sel.cpu ? `${sel.cpu} vCPUs` : "—"],
    ["Limite da infraestrutura", c.limits?.maxVcpus ? `${c.limits.maxVcpus} vCPUs` : "Não informado"],
    ["Uso atual", "Medido somente com a máquina em execução"],
  ]);

  const gpuCards = c.gpu.map((g) => `
    <article class="gpu${g.available ? "" : " is-off"}">
      <div class="row"><strong>${esc(g.name)}</strong><span class="badge ${g.available ? "ok" : "err"}">${g.available ? "Disponível" : "Indisponível"}</span></div>
      <p class="meta">Memória de vídeo: ${g.vramGb ? esc(`${g.vramGb} GB`) : "não informada"} · Atribuição: ${esc(g.assignment)}</p>
      ${g.features.length ? `<p class="meta">Recursos: ${esc(g.features.join(", "))}</p>` : ""}
      ${g.notes ? `<p class="meta">${esc(g.notes)}</p>` : ""}
      ${chip({ pick: "gpu", value: g.id, label: sel.gpu === g.id ? "Selecionada" : "Selecionar", active: sel.gpu === g.id, disabled: !g.available })}
    </article>`).join("");
  const gpu = (c.gpu.length ? `<div class="gpu-list">${gpuCards}</div>` : empty("GPU indisponível nesta infraestrutura."))
    + `<div class="options">${chip({ pick: "gpu", value: "", label: "Sem GPU dedicada", active: !sel.gpu })}</div>`;

  const sto = c.storage.length
    ? `<div class="options">${c.storage.map((s) => chip({ pick: "storage", value: s.gb, label: formatGb(s.gb), active: sel.storage === s.gb })).join("")}</div>`
    : empty("Nenhuma capacidade de armazenamento foi confirmada pela infraestrutura.");
  const stoRows = [
    ["Selecionada", sel.storage ? formatGb(sel.storage) : "—"],
    ["Limite da infraestrutura", c.limits?.maxStorageGb ? formatGb(c.limits.maxStorageGb) : "Não informado"],
  ];
  if (c.disk) stoRows.push(["Volume atual", c.disk.volumeId], ["Estado do volume", c.disk.state]);

  const res = c.resolutions.length
    ? `<div class="options">${c.resolutions.map((r) => chip({ pick: "resolution", value: r, label: r.replace("x", "×"), active: sel.resolution === r })).join("")}</div>`
    : empty("A infraestrutura não informou resoluções. A sessão usará o padrão do servidor.");

  const cur = PROFILES.find((p) => p.id === sel.profile);
  const prof = `<div class="profiles">${PROFILES.map((p) => chip({ pick: "profile", value: p.id, label: p.label, active: sel.profile === p.id, sub: p.needsGpu ? "Exige GPU" : "" })).join("")}</div>${cur ? hintP(cur.hint) : ""}`;

  return banner(c) + issues(v)
    + section("cat-os", "Sistema operacional", os, "Lista vinda do catálogo do backend.")
    + section("cat-ram", "Memória RAM", ram + ramFacts, "A alteração só vale para a máquina real quando o backend e o hipervisor suportarem a operação.")
    + section("cat-cpu", "Processador (vCPU)", cpu + cpuFacts)
    + section("cat-gpu", "Placa de vídeo (GPU)", gpu, "Somente GPUs confirmadas pelo provedor podem ser selecionadas. Modelos de referência não garantem disponibilidade.")
    + section("cat-storage", "Armazenamento do PC virtual", sto + facts(stoRows), "Disco persistente do backend, separado do armazenamento interno do celular. Encerrar a sessão não o apaga.")
    + section("cat-res", "Resolução da tela", res, "Opcional.")
    + section("cat-profile", "Perfil de desempenho", prof, "O perfil escolhe combinações válidas; o desempenho efetivo depende do servidor.");
}

function renderStart(c, sum, v) {
  const rows = sum.map((r) => `<div><dt>${esc(r.label)}</dt><dd class="${r.state === "bad" ? "dd-bad" : r.state === "empty" ? "empty-state" : ""}">${esc(r.value)}</dd></div>`).join("");
  const steps = ["Validar a configuração solicitada", "Confirmar que os recursos estão disponíveis", "Provisionar ou selecionar a máquina virtual", "Associar o disco persistente correto", "Inicializar o sistema operacional", "Aguardar o serviço remoto ficar disponível", "Estabelecer a conexão segura", "Abrir o desktop virtual"]
    .map((s, i) => `<li><span class="step-n">${i + 1}</span>${esc(s)}</li>`).join("");
  return banner(c) + issues(v) + `<dl class="facts">${rows}</dl><h3 class="sub">Etapas previstas da inicialização</h3><ol class="steps">${steps}</ol>`;
}

function renderStorageInfo(c) {
  const rules = `<h3 class="sub">Regras de persistência</h3><ul class="rules">
    <li>Os arquivos devem continuar disponíveis depois que a sessão for encerrada.</li>
    <li>Reiniciar o PC virtual não deve apagar arquivos.</li>
    <li>Encerrar uma sessão não exclui o disco.</li>
    <li>Excluir um disco com dados exige confirmação.</li></ul>`;
  if (c.status !== "ok") return banner(c) + empty("Não é possível consultar o volume sem uma infraestrutura conectada.") + rules;
  if (!c.disk) return empty("Nenhum volume persistente foi provisionado ainda. Ao iniciar a máquina, o backend criará ou associará um disco dedicado.") + rules;
  const pct = Math.round((c.disk.usedGb / c.disk.totalGb) * 100);
  return banner(c)
    + `<progress class="meter" max="100" value="${pct}" aria-label="Espaço usado">${pct}%</progress>`
    + facts([
      ["Identificação do disco", c.disk.volumeId], ["Estado do volume", c.disk.state],
      ["Capacidade total", formatGb(c.disk.totalGb)], ["Espaço utilizado", formatGb(c.disk.usedGb)],
      ["Espaço livre", formatGb(c.disk.freeGb)], ["Arquivos armazenados", c.disk.files === null ? "Não informado" : String(c.disk.files)],
      ["Persistência", c.disk.persistent ? "Dados mantidos entre sessões" : "Não confirmada"],
      ["Expansão", c.disk.expandable ? "Suportada pelo provedor" : "Não suportada"],
    ])
    + `<div class="options"><button type="button" class="btn-ghost" disabled>Enviar do celular</button><button type="button" class="btn-ghost" disabled>Baixar para o celular</button></div>`
    + hintP("Transferências e expansão ficam disponíveis após a conexão com o backend.")
    + rules;
}

const ADVANCED = [
  ["Versão do sistema operacional", "Define a build instalada. Alterá-la pode exigir reinicialização ou uma nova máquina.", ["Exige reinicialização"]],
  ["Resolução e taxa de quadros", "Resolução da tela e limite de FPS enviado pela transmissão, quando o servidor suportar.", ["Depende da infraestrutura"]],
  ["Qualidade da imagem remota", "Equilíbrio entre nitidez e uso de banda. Pode ser ajustado automaticamente.", []],
  ["Configurações de rede", "Rede da máquina virtual e rota da sessão remota.", ["Exige reinicialização"]],
  ["Modo de tela cheia", "Ocupa a tela inteira com a sessão remota.", []],
  ["Inicialização automática da sessão", "Abre a sessão automaticamente quando desejado.", []],
  ["Suspensão e retomada", "Pausa a máquina e a retoma depois. Só aparece se o provedor suportar.", ["Depende da infraestrutura"]],
  ["Política de encerramento", "Define se a máquina continua ligada, suspende ou desliga ao encerrar a sessão. Encerrar a sessão nunca apaga os dados do disco.", []],
  ["Snapshots", "Pontos de restauração do disco. Depende do provedor.", ["Depende da infraestrutura"]],
  ["Backup e restauração", "Cópias do volume persistente. A exclusão definitiva exige confirmação.", []],
  ["Teclado e idioma", "Layout de teclado e idioma aplicados à sessão remota.", []],
  ["Dispositivos de entrada", "Mouse, teclado e toque usados na sessão.", []],
  ["Compartilhamento de arquivos", "Transferência explícita entre o celular e o PC virtual, com indicação de progresso.", []],
  ["Segurança", "Sessões autenticadas, comunicação criptografada e isolamento entre usuários.", []],
  ["Consumo e custos", "Tempo de uso e cobrança do provedor, quando houver.", ["Depende da infraestrutura"]],
];
function renderAdvancedInfo(c) {
  const items = ADVANCED.map(([t, x, tags]) => `<li><strong>${esc(t)}</strong><p>${esc(x)}</p>${tags.length ? `<div class="tags">${tags.map((g) => `<span class="badge warn">${esc(g)}</span>`).join("")}</div>` : ""}</li>`).join("");
  const note = c.status === "ok" ? "Os ajustes são aplicados ao iniciar a máquina." : "Estas opções só podem ser alteradas com o backend conectado.";
  return banner(c) + hintP(note) + `<ul class="adv-list">${items}</ul>`;
}

function renderManageInfo(c) {
  const create = `<button type="button" class="btn-primary" disabled>Criar nova máquina</button>${hintP("Criação e duplicação de máquinas ficam disponíveis após a conexão com o backend.")}`;
  if (c.status !== "ok") return banner(c) + empty("Nenhuma máquina virtual pode ser listada sem o backend conectado.") + create;
  if (!c.machines.length) return empty("Nenhuma máquina virtual cadastrada nesta conta.") + create;
  return `<ul class="machines">${c.machines.map((m) => `<li><div class="row"><strong>${esc(m.name)}</strong><span class="badge">${esc(m.state)}</span></div><p class="meta">${esc(m.os)} · ${esc(m.id)}</p></li>`).join("")}</ul>` + create;
}

/* ============ Estado ============ */
const app = {
  backendUrl: loadBackendUrl(),
  health: null,            // resultado da última sondagem de /api/health
  catalog: unavailable("Ainda não verificado."),
  checking: true,
  demo: false,
  checkedAt: null,
  nextAt: null,
  saved: loadPrefs(),
  draft: null,
  vm: { state: "desligada", message: "" },
  lastAction: "",
};
let retryTimer = null;

function loadPrefs() {
  try { return sanitize(JSON.parse(localStorage.getItem(PREF_KEY))); }
  catch { return sanitize(null); }
}
function savePrefs(sel) {
  try { localStorage.setItem(PREF_KEY, JSON.stringify(sel)); return true; }
  catch { return false; }
}
function loadBackendUrl() {
  try { return String(localStorage.getItem(BACKEND_KEY) || ""); }
  catch { return ""; }
}
function saveBackendUrl(url) {
  try { localStorage.setItem(BACKEND_KEY, url); return true; }
  catch { return false; }
}
function normalizeBase(value) {
  const t = String(value || "").trim().replace(/\/+$/, "");
  if (!t) return "";
  if (!/^https?:\/\/[^\s/]+/i.test(t)) throw new Error("Use um endereço que comece com http:// ou https://");
  return t;
}

// Estado do backend, em linguagem simples, para o menu e o diagnóstico.
function linkStatus() {
  if (app.demo) return { key: "demo", label: "Demonstração", tone: "warn", text: "Dados fictícios em uso. Nada é enviado nem iniciado na API." };
  const h = app.health;
  if (app.checking && !h) return { key: "checando", label: "Verificando…", tone: "muted", text: `Verificando ${addressOf(effectiveBase())}…` };
  if (!h) return { key: "nao_verificado", label: "Não verificada", tone: "muted", text: "Ainda não foi feita nenhuma verificação." };
  if (h.state === "ok") {
    return { key: "conectado", label: "API conectada", tone: "ok", text: `A API respondeu${h.latency != null ? ` em ${h.latency} ms` : ""}.` };
  }
  return { key: h.state, label: "API desconectada", tone: "err", text: h.detail };
}


const TIPS = {
  offline: "Inicie o servidor (npm start) e confira o endereço. Para testar pelo Android, o servidor precisa escutar na rede local (HOST=0.0.0.0) e o celular precisa estar na mesma rede Wi-Fi.",
  sem_api: "O backend precisa expor GET /api/health, respondendo JSON com service = saturndesktop-beta.",
  sem_infra: "O servidor está no ar, mas nenhuma infraestrutura foi configurada. Configure o adaptador do provedor para listar recursos reais.",
  erro_catalogo: "Confira o log do servidor. A resposta de /api/catalog não pôde ser usada.",
  erro: "Confira o log do servidor.",
  inesperado: "Confira se o endereço aponta para o backend do SaturnDesktopBETA.",
  demo: "Dados fictícios em uso. Toque em Verificar agora para voltar à detecção real.",
  conectado: "Tudo certo. O catálogo foi carregado do backend.",
};

/* ============ Renderização do estado ============ */
function setText(sel, text, tone) {
  const el = $(sel);
  el.textContent = text;
  if (tone) el.dataset.tone = tone; else delete el.dataset.tone;
}

function renderMenu() {
  const c = app.catalog;
  const ls = linkStatus();
  setText("#infra-state", ls.label, ls.tone);
  const vm = vmView();
  setText("#vm-state", vm.label, vm.tone);
  $("#power").dataset.state = app.vm.state;
  setText("#remote-state", SHUTDOWN_STATES.includes(app.vm.state) ? "Não integrada" : "Não aplicável", "muted");
  setText("#disk-free", c.disk ? `${formatGb(c.disk.freeGb)} livres de ${formatGb(c.disk.totalGb)}${c.demo ? " (demonstração)" : ""}` : c.status === "ok" ? "Nenhum volume provisionado" : "Indisponível sem backend", c.disk ? "ok" : "muted");

  for (const item of summarize(app.saved, c)) {
    if (item.key === "infra") continue;
    const el = $(`#hw-${item.key}`);
    el.textContent = item.value;
    el.classList.toggle("empty-state", item.state === "empty");
    el.classList.toggle("dd-bad", item.state === "bad");
  }
  $("#btn-shutdown").hidden = !SHUTDOWN_STATES.includes(app.vm.state);
  renderNotice();
}

function renderNotice() {
  const el = $("#menu-notice");
  const ls = linkStatus();
  const parts = [];
  if (app.lastAction) parts.push(esc(app.lastAction));
  if (ls.key === "demo") parts.push("Demonstração com dados fictícios: nada é enviado nem iniciado na API.");
  else if (ls.key === "checando") parts.push(esc(ls.text));
  else if (ls.key !== "conectado") {
    parts.push(`${esc(ls.text)} <button type="button" class="link" data-action="diag">Diagnóstico</button> · <button type="button" class="link" data-action="retry">Tentar novamente</button> · <button type="button" class="link" data-action="demo">Ver demonstração</button>`);
  }
  el.innerHTML = parts.join(" ");
}

function renderDiag() {
  const ls = linkStatus();
  const h = app.health;
  const count = app.catalog.status === "ok"
    ? `${app.catalog.ram.length + app.catalog.cpu.length + app.catalog.gpu.length + app.catalog.storage.length} recursos`
    : "Indisponível";
  const secs = app.nextAt && !app.demo && ls.key !== "conectado" ? Math.max(0, Math.round((app.nextAt - Date.now()) / 1000)) : null;
  $("#diag-result").innerHTML = `
    <div class="diag-state" data-tone="${esc(ls.tone)}">
      <div class="state-title">${esc(ls.label)}</div>
      <p>${esc(ls.text)}</p>
    </div>
    <dl class="kv">
      <div><dt>Endereço testado</dt><dd>${esc(addressOf(effectiveBase()))}</dd></div>
      <div><dt>Resposta do servidor</dt><dd>${h?.http ? `HTTP ${h.http}` : "Sem resposta HTTP"}</dd></div>
      <div><dt>Latência</dt><dd>${h?.latency != null ? `${h.latency} ms` : "—"}</dd></div>
      <div><dt>Versão do backend</dt><dd>${h?.version ? esc(h.version) : "—"}</dd></div>
      <div><dt>Configuração</dt><dd>${esc(app.config.message || "—")}</dd></div>
      <div><dt>Catálogo</dt><dd>${esc(count)}</dd></div>
      <div><dt>Última verificação</dt><dd>${app.checkedAt ? esc(app.checkedAt.toLocaleTimeString("pt-BR")) : "—"}</dd></div>
      <div><dt>Próxima tentativa automática</dt><dd>${secs !== null ? `em ${secs} s` : "Não agendada"}</dd></div>
    </dl>
    ${TIPS[ls.key] ? `<h3 class="sub">O que fazer</h3><p class="hint">${esc(TIPS[ls.key])}</p>` : ""}`;
}

function renderConfig(focus = null) {
  const v = validate(app.draft, app.catalog);
  const body = $("#config-body");
  body.innerHTML = renderHardwareCenter(app.catalog, app.draft, v);
  if (focus) {
    body.querySelectorAll("[data-pick]").forEach((b) => {
      if (b.dataset.pick === focus.pick && b.dataset.value === focus.value) b.focus();
    });
  }
}

function renderAll() {
  renderMenu();
  if ($("#config-dialog").open) renderConfig();
  if ($("#diag-dialog").open) renderDiag();
}

function openDialog(d) { typeof d.showModal === "function" ? d.showModal() : d.setAttribute("open", ""); }

function openInfo(title, html) {
  $("#info-title").textContent = title;
  $("#info-body").innerHTML = html;
  openDialog($("#info-dialog"));
}

function applyPick(draft, pick, value) {
  const next = { ...draft };
  if (pick === "ram" || pick === "cpu" || pick === "storage") next[pick] = Number(value);
  else next[pick] = value || null;
  return sanitize(next);
}

function openConfig() {
  $("#config-msg").textContent = "";
  app.draft = { ...app.saved };
  renderConfig();
  openDialog($("#config-dialog"));
}

function openStart() {
  const v = validate(app.saved, app.catalog);
  $("#start-body").innerHTML = renderStart(app.catalog, summarize(app.saved, app.catalog), v);
  $("#start-note").textContent = app.demo
    ? "Demonstração ativa: a inicialização não pode ser solicitada."
    : app.health?.state === "ok"
      ? "Ao confirmar, a solicitação é enviada à API. O PC só aparece como ligado se a API confirmar que foi iniciado."
      : "API desconectada: não é possível solicitar a inicialização.";
  $("#btn-confirm-start").disabled = !(app.health?.state === "ok" && !app.demo);
  $("#start-result").textContent = "";
  openDialog($("#start-dialog"));
}

function openDiag() {
  $("#backend-url").value = app.backendUrl;
  $("#diag-msg").textContent = "";
  renderDiag();
  openDialog($("#diag-dialog"));
}

/* ============ Ações de conexão ============ */
function effectiveBase() {
  return app.backendUrl || API_DEFAULT;
}

// Estado da máquina virtual. "ligada" só existe quando a API confirma.
const VM_LABELS = {
  desligada: ["Desligada", "muted"],
  iniciando: ["Iniciando", "warn"],
  ligada: ["Ligada", "ok"],
  nao_iniciada: ["Não iniciada", "err"],
  falhou: ["Falhou", "err"],
  desconhecido: ["Estado desconhecido", "warn"],
};
const SHUTDOWN_STATES = ["ligada","iniciando","desconhecido"];
function vmView() {
  const [label, tone] = VM_LABELS[app.vm.state] || VM_LABELS.desconhecido;
  return { label, tone };
}

// Converte a resposta real da API em estado. Sem confirmação explícita, nada é considerado ligado.
function interpretVm(res, body, action) {
  const msg = isObj(body) && typeof body.message === "string" ? body.message : "";
  if (!res.ok) {
    const fallback = res.status === 404 ? "A API não possui esta rota."
      : res.status === 501 ? "Ainda não implementado no backend."
        : `A API respondeu com erro HTTP ${res.status}.`;
    return { state: action === "start" ? "nao_iniciada" : "desconhecido", message: msg || fallback };
  }
  const st = isObj(body) && typeof body.state === "string" ? body.state : "";
  if (action === "start") {
    if (st === "running") return { state: "ligada", message: msg || "A API confirmou que a máquina está ligada." };
    if (st === "starting" || st === "accepted") return { state: "iniciando", message: msg || "A API aceitou a solicitação. A máquina ainda não está ligada." };
    return { state: "nao_iniciada", message: msg || "A API respondeu, mas não confirmou que a máquina foi iniciada." };
  }
  if (st === "stopped") return { state: "desligada", message: msg || "A API confirmou que a máquina está desligada." };
  return { state: "desconhecido", message: msg || "A API respondeu, mas não confirmou o desligamento." };
}

async function checkBackend() {
  clearTimeout(retryTimer);
  app.demo = false;
  app.checking = true;
  renderAll();
  const base = effectiveBase();
  const health = await probeHealth(base);
  app.health = health;
  app.checking = false;
  app.checkedAt = new Date();
  if (health.state === "ok") {
    await loadConfig(base);
    app.nextAt = null;
  } else {
    app.catalog = unavailable(health.detail);
    app.config = { state: "sem_conexao", message: "Configuração não carregada: API desconectada." };
    app.nextAt = Date.now() + RETRY_MS;
    retryTimer = setTimeout(checkBackend, RETRY_MS);
  }
  renderAll();
}

function useDemo() {
  clearTimeout(retryTimer);
  app.demo = true;
  app.catalog = normalize(DEMO_RAW);
  app.nextAt = null;
  app.lastAction = "";
  renderAll();
}

// POST /api/pc/start. Formato do corpo esperado (não verificado): { selection: {...} }
async function confirmStart() {
  const btn = $("#btn-confirm-start");
  const out = $("#start-result");
  const base = effectiveBase();
  btn.disabled = true;
  out.dataset.tone = "muted";
  out.textContent = "Enviando a solicitação à API…";
  try {
    const { res, body } = await request(`${base}/api/pc/start`, { method: "POST", body: { selection: app.saved }, timeoutMs: ACTION_TIMEOUT_MS });
    app.vm = interpretVm(res, body, "start");
  } catch (err) {
    app.vm = { state: "falhou", message: offlineMessage(err, base) };
  }
  app.lastAction = `Início: ${app.vm.message}`;
  out.textContent = app.vm.message;
  out.dataset.tone = app.vm.state === "ligada" ? "ok" : app.vm.state === "iniciando" ? "warn" : "err";
  btn.disabled = !(app.health?.state === "ok" && !app.demo);
  renderAll();
}

// POST /api/pc/stop
async function stopVm() {
  const base = effectiveBase();
  app.lastAction = "Desligamento: solicitando à API…";
  renderMenu();
  try {
    const { res, body } = await request(`${base}/api/pc/stop`, { method: "POST", body: {}, timeoutMs: ACTION_TIMEOUT_MS });
    app.vm = interpretVm(res, body, "stop");
  } catch (err) {
    app.vm = { state: "desconhecido", message: offlineMessage(err, base) };
  }
  app.lastAction = `Desligamento: ${app.vm.message}`;
  renderAll();
}

// POST /api/config. Só informa "salva" quando a API responde com sucesso.
async function saveConfig() {
  const msg = $("#config-msg");
  const btn = $("#btn-save-config");
  const sel = sanitize(app.draft);
  if (app.demo) {
    msg.dataset.tone = "err";
    msg.textContent = "Demonstração ativa: nada é salvo na API. Abra o Diagnóstico e toque em Verificar agora para voltar à API.";
    return;
  }
  const base = effectiveBase();
  btn.disabled = true;
  msg.dataset.tone = "muted";
  msg.textContent = "Salvando na API…";
  try {
    const { res, body } = await request(`${base}/api/config`, { method: "POST", body: { selection: sel }, timeoutMs: ACTION_TIMEOUT_MS });
    if (res.ok) {
      app.saved = sel;
      savePrefs(sel);
      app.config = { state: "salva", message: "Configuração salva na API." };
      app.lastAction = "Configuração salva na API.";
      msg.dataset.tone = "ok";
      msg.textContent = "Configuração salva na API.";
      $("#config-dialog").close();
    } else {
      msg.dataset.tone = "err";
      msg.textContent = `Configuração NÃO foi salva na API: ${messageOf(body, res.status)}`;
    }
  } catch (err) {
    msg.dataset.tone = "err";
    msg.textContent = `Configuração NÃO foi salva na API: ${offlineMessage(err, base)}`;
  } finally {
    btn.disabled = false;
    renderAll();
  }
}

/* ============ Eventos ============ */
document.querySelectorAll("[data-open-config]").forEach((b) => b.addEventListener("click", openConfig));
$("#infra-card").addEventListener("click", openDiag);
$("#btn-diagnostics").addEventListener("click", openDiag);
$("#btn-start").addEventListener("click", openStart);
$("#btn-storage").addEventListener("click", () => openInfo("Meu armazenamento", renderStorageInfo(app.catalog)));
$("#btn-advanced").addEventListener("click", () => openInfo("Configurações avançadas", renderAdvancedInfo(app.catalog)));
$("#btn-manage").addEventListener("click", () => openInfo("Computadores virtuais", renderManageInfo(app.catalog)));
$("#btn-adjust").addEventListener("click", () => { $("#start-dialog").close(); openConfig(); });
$("#btn-confirm-start").addEventListener("click", confirmStart);
$("#btn-shutdown").addEventListener("click", stopVm);
$("#power").addEventListener("click", () => (SHUTDOWN_STATES.includes(app.vm.state) ? stopVm() : openStart()));

$("#config-body").addEventListener("click", (e) => {
  const b = e.target.closest("[data-pick]");
  if (!b || b.disabled) return;
  const { pick, value } = b.dataset;
  app.draft = applyPick(app.draft, pick, value);
  renderConfig({ pick, value });
});

$("#btn-save-config").addEventListener("click", saveConfig);

function saveAndCheck() {
  let url;
  try { url = normalizeBase($("#backend-url").value); }
  catch (err) { $("#diag-msg").textContent = err.message; return; }
  app.backendUrl = url;
  if (!saveBackendUrl(url)) $("#diag-msg").textContent = "Endereço testado, mas não foi possível salvá-lo neste navegador.";
  else $("#diag-msg").textContent = "";
  checkBackend();
}

$("#btn-diag-save").addEventListener("click", saveAndCheck);
$("#btn-diag-check").addEventListener("click", () => { $("#diag-msg").textContent = ""; checkBackend(); });
$("#btn-diag-clear").addEventListener("click", () => { $("#backend-url").value = ""; saveAndCheck(); });
$("#btn-diag-demo").addEventListener("click", () => { $("#diag-dialog").close(); useDemo(); });
$("#backend-url").addEventListener("keydown", (e) => { if (e.key === "Enter") saveAndCheck(); });

$("#menu-notice").addEventListener("click", (e) => {
  const a = e.target.closest("[data-action]");
  if (!a) return;
  if (a.dataset.action === "diag") openDiag();
  if (a.dataset.action === "retry") checkBackend();
  if (a.dataset.action === "demo") useDemo();
});

document.querySelectorAll("dialog").forEach((d) => {
  d.addEventListener("click", (e) => { if (e.target === d || e.target.closest("[data-close]")) d.close(); });
});

/* ============ Logo ============ */
const logo = $("#logo");
logo.addEventListener("load", () => { logo.hidden = false; });
logo.addEventListener("error", () => { $("#logo-fallback").hidden = false; });
logo.src = LOGO_URL;

checkBackend();
})();
