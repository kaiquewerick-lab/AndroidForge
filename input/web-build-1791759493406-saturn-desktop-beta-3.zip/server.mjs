#!/usr/bin/env node
/**
 * SaturnDesktopBETA — servidor de desenvolvimento e adaptador provisório de catálogo.
 *
 * - Serve o cliente web (public/) com cabeçalhos de segurança.
 * - Expõe GET /api/catalog com as capacidades REALMENTE informadas pela infraestrutura.
 *
 * Fonte do catálogo, em ordem:
 *   1. variável SATURN_CATALOG_FILE, se definida;
 *   2. com --demo-catalog: data/catalog.demo.json (fictício, marcado como demo);
 *   3. backend/catalog.json.
 * Se nenhuma fonte existir, a API responde 503. Nenhum recurso é inventado.
 *
 * Uso: node server.mjs [--demo-catalog]
 */
import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(ROOT, 'public');
const DEFAULT_CATALOG = path.join(ROOT, 'backend', 'catalog.json');
const DEMO_CATALOG = path.join(ROOT, 'data', 'catalog.demo.json');

const demoMode = process.argv.includes('--demo-catalog');
const catalogFile = process.env.SATURN_CATALOG_FILE
  || (demoMode ? DEMO_CATALOG : DEFAULT_CATALOG);
const port = Number(process.env.PORT) || 8080;
const host = process.env.HOST || '127.0.0.1';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.webmanifest': 'application/manifest+json',
};

const SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'",
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'no-referrer',
  'Cross-Origin-Opener-Policy': 'same-origin',
};

function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

// CORS: a API é somente leitura. Em produção, restrinja com SATURN_CORS_ORIGIN.
const CORS_ORIGIN = process.env.SATURN_CORS_ORIGIN || '*';
const VERSION = '0.1.0-beta.1';

function sendJson(res, status, data) {
  send(res, status, JSON.stringify(data), {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': CORS_ORIGIN,
  });
}

async function loadCatalog() {
  let raw;
  try {
    raw = await readFile(catalogFile, 'utf8');
  } catch (err) {
    if (err.code === 'ENOENT') {
      return {
        ok: false,
        message: 'Nenhuma infraestrutura está configurada neste servidor. Configure o adaptador de provedor para listar recursos reais.',
      };
    }
    throw err;
  }
  try {
    const data = JSON.parse(raw);
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('formato');
    return { ok: true, data: { ...data, demo: demoMode && catalogFile === DEMO_CATALOG } };
  } catch {
    return { ok: false, message: 'O arquivo de catálogo da infraestrutura é inválido.' };
  }
}

async function handleApi(res, pathname) {
  if (pathname === '/api/health') {
    // Identifica este serviço para a interface, mesmo sem infraestrutura configurada.
    return sendJson(res, 200, { service: 'saturndesktop-beta', version: VERSION, status: 'up' });
  }
  if (pathname === '/api/catalog') {
    const result = await loadCatalog();
    if (!result.ok) {
      return sendJson(res, 503, { error: 'infra_not_configured', message: result.message });
    }
    return sendJson(res, 200, result.data);
  }
  return sendJson(res, 404, { error: 'not_found' });
}

async function serveStatic(req, res, pathname) {
  let rel;
  try {
    rel = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  } catch {
    return send(res, 400, 'Bad request', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) {
    return send(res, 403, 'Forbidden', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
  try {
    const body = await readFile(file);
    send(res, 200, req.method === 'HEAD' ? undefined : body, {
      'Content-Type': MIME[path.extname(file)] || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
  } catch {
    send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
}

const server = http.createServer(async (req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    return send(res, 405, 'Method not allowed', {
      Allow: 'GET, HEAD',
      'Content-Type': 'text/plain; charset=utf-8',
    });
  }
  let pathname;
  try {
    pathname = new URL(req.url, 'http://localhost').pathname;
  } catch {
    return send(res, 400, 'Bad request', { 'Content-Type': 'text/plain; charset=utf-8' });
  }
  try {
    if (pathname.startsWith('/api/')) return await handleApi(res, pathname);
    return await serveStatic(req, res, pathname);
  } catch (err) {
    console.error('erro interno:', err.code || err.name);
    if (!res.headersSent) sendJson(res, 500, { error: 'internal' });
  }
});

server.listen(port, host, () => {
  const mode = demoMode ? ' (catálogo de demonstração)' : '';
  console.log(`SaturnDesktopBETA em http://${host}:${port}${mode}`);
});
