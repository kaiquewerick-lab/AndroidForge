// Plugins de nível de projeto. Versões compatíveis entre si (AGP 8.5 + Kotlin 1.9 + Gradle 8.7).
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
