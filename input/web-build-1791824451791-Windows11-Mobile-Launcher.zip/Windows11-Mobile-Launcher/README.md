# Windows 11 Mobile Launcher

Um launcher para Android com aparência e experiência inspiradas no Windows 11: área de trabalho com ícones, barra de tarefas centralizada, menu Iniciar com pesquisa, janelas internas arrastáveis, Explorador de arquivos, Bloco de Notas, Calculadora, Paint simples, Gerenciador de tarefas, Executar e Configurações com personalização completa.

A interface é feita em **HTML, CSS e JavaScript** e roda dentro de uma **WebView** em um app Android (**Kotlin**). A camada nativa existe apenas para consultar os aplicativos instalados, abri-los e conversar com o sistema.

> **Importante:** este projeto **não** é um PC virtual, não usa RDP e não controla aplicativos Android como janelas de desktop. Os aplicativos Android são abertos pelos mecanismos oficiais do sistema. As ferramentas internas (Explorador, Bloco de Notas etc.) são janelas reais dentro do próprio launcher. Veja [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

---

## Sumário

1. [Estrutura do projeto](#estrutura-do-projeto)
2. [O que está no ZIP](#o-que-está-no-zip)
3. [Como editar os arquivos pelo celular](#como-editar-os-arquivos-pelo-celular)
4. [Como testar a interface no navegador](#como-testar-a-interface-no-navegador)
5. [Como compilar o APK](#como-compilar-o-apk)
6. [Como definir como tela inicial](#como-definir-como-tela-inicial)
7. [Regra dos 10 aplicativos fixados](#regra-dos-10-aplicativos-fixados)
8. [Atalhos de teclado](#atalhos-de-teclado)
9. [Armazenamento e privacidade](#armazenamento-e-privacidade)
10. [Estado de verificação](#estado-de-verificação)
11. [Documentação adicional](#documentação-adicional)
12. [Licença](#licença)

---

## Estrutura do projeto

```
Windows11-Mobile-Launcher/
├── README.md
├── LICENSE
├── .gitignore
├── web/                      Interface (HTML, CSS, JavaScript)
│   ├── index.html            Página principal
│   ├── css/style.css         Estilos, temas e responsividade
│   ├── js/
│   │   ├── storage.js        Armazenamento local (localStorage)
│   │   ├── bridge.js         Ponte com o Android (valida tudo antes de usar)
│   │   ├── windows.js        Gerenciador de janelas internas
│   │   ├── ui.js             Menus de contexto, diálogos e avisos
│   │   ├── desktop.js        Área de trabalho, ícones, fixados e papel de parede
│   │   ├── taskbar.js        Barra de tarefas, menu Iniciar, calendário, notificações
│   │   ├── keyboard.js       Atalhos de teclado
│   │   ├── main.js           Inicialização e ganchos chamados pelo Android
│   │   └── apps/             Ferramentas internas
│   │       ├── fs.js         Sistema de arquivos interno e Lixeira
│   │       ├── explorer.js   Explorador de arquivos
│   │       ├── notepad.js    Bloco de Notas
│   │       ├── calculator.js Calculadora
│   │       ├── paint.js      Paint simples
│   │       ├── taskmanager.js Gerenciador de tarefas
│   │       ├── run.js        Executar (lista fechada de comandos)
│   │       ├── settings.js   Configurações e personalização
│   │       └── registry.js   Registro dos aplicativos internos
│   └── assets/icon.svg       Ícone da página
├── tests/                    Testes de lógica (Node) e de interface (Playwright)
├── android/                  Projeto Android (Gradle Kotlin DSL)
│   ├── settings.gradle.kts
│   ├── build.gradle.kts
│   ├── gradle.properties
│   ├── gradle/wrapper/gradle-wrapper.properties
│   └── app/
│       ├── build.gradle.kts
│       └── src/main/
│           ├── AndroidManifest.xml
│           ├── java/com/example/win11launcher/
│           │   ├── MainActivity.kt     WebView, Voltar, seletor de arquivos, eventos de pacotes
│           │   └── LauncherBridge.kt   Ponte nativa (única superfície exposta à página)
│           └── res/                    Textos, tema, cores e ícone adaptativo
└── docs/
    ├── INSTALLATION.md       Instalação e compilação
    ├── FEATURES.md           Recursos implementados
    └── LIMITATIONS.md        Limitações reais do Android e do projeto
```

## O que está no ZIP

O arquivo `Windows11-Mobile-Launcher.zip` contém exatamente a pasta acima, sem caches, sem chaves de assinatura e sem `local.properties`. O conteúdo de `web/` é empacotado automaticamente como assets do APK pelo Gradle (`assets.srcDirs("../../web")` em `android/app/build.gradle.kts`), então **há uma única cópia da interface**.

---

## Como editar os arquivos pelo celular

Você pode editar o projeto inteiro sem computador, usando um app de edição de código e texto para Android (por exemplo, um editor com suporte a pastas e a arquivos `.html`, `.css`, `.js`, `.kt` e `.xml`):

1. **Descompacte o ZIP** com o gerenciador de arquivos do Android ou com um app de extração de ZIP.
2. **Abra a pasta `web/`** no editor e edite `index.html`, `css/style.css` ou os arquivos de `js/`.
3. **Teste no navegador do celular** (veja a próxima seção). Basta abrir `web/index.html`. Não é necessário compilar nada para testar a interface.
4. Para mudar o **nome do app**, edite `android/app/src/main/res/values/strings.xml`.
5. Para mudar a **cor do ícone**, edite `android/app/src/main/res/values/colors.xml`.
6. Para mudar a **versão** do app, edite `versionCode` e `versionName` em `android/app/build.gradle.kts`.

> Para compilar o APK você precisará de um computador (ou de um serviço de compilação na nuvem) com o Android SDK, porque o celular normalmente não tem as ferramentas de compilação. Veja [docs/INSTALLATION.md](docs/INSTALLATION.md).

## Como testar a interface no navegador

1. Abra `web/index.html` em um navegador moderno (Chrome, Firefox, Edge ou Safari).
2. Fora do APK, a ponte nativa não existe. O launcher usa então uma **lista simulada de aplicativos** e mostra um aviso no centro de notificações. Todas as ferramentas internas, a personalização e os atalhos funcionam normalmente.
3. Os dados ficam no `localStorage` do próprio navegador, separados do APK.

## Como compilar o APK

Resumo (detalhes completos em [docs/INSTALLATION.md](docs/INSTALLATION.md)):

1. Instale o **Android Studio** (recomendado) ou o **JDK 17** com o **Android SDK** (API 34).
2. Abra a pasta `android/` no Android Studio e aguarde a sincronização do Gradle.
3. Em **Build > Build Bundle(s) / APK(s) > Build APK(s)** gere o APK de depuração.
4. O arquivo estará em `android/app/build/outputs/apk/debug/app-debug.apk`.

Linha de comando, a partir de `android/`:

```bash
gradle wrapper --gradle-version 8.7    # gera gradlew e gradle-wrapper.jar (uma vez)
./gradlew assembleDebug
```

> **Gradle Wrapper:** o ZIP inclui `gradle/wrapper/gradle-wrapper.properties`, mas não inclui o `gradlew` nem o `gradle-wrapper.jar`, porque eles são binários gerados pela própria ferramenta. Use o comando acima em um computador com acesso à internet, ou deixe o Android Studio criá-los.

## Como definir como tela inicial

1. Instale o APK e abra o app uma vez.
2. Vá em **Configurações > Apps > Aplicativo padrão de início** (o caminho exato varia conforme a marca do aparelho) e escolha **Windows 11 Mobile Launcher**.
3. Pressione o botão Início. O launcher aparece.
4. Para voltar ao launcher anterior, selecione-o nas mesmas configurações.

O launcher **nunca** se define como padrão sem a sua escolha.

## Regra dos 10 aplicativos fixados

- Os aplicativos Android são ordenados **por nome** (pt-BR, sem diferenciar maiúsculas e acentos; empate pelo identificador do pacote).
- Os **10 primeiros** aparecem na área de trabalho.
- Para trocar um deles, use o **botão direito** no ícone (ou **toque longo**) e escolha **Trocar aplicativo...**.
- Se um app fixado for desinstalado, o próximo da ordem alfabética ocupa o lugar.
- Atalhos internos (Explorador, Bloco de Notas etc.) são separados e não contam nos 10.

## Atalhos de teclado

| Atalho | Ação |
|---|---|
| Win | Abre ou fecha o menu Iniciar (quando a tecla chega ao launcher) |
| Win + E | Explorador |
| Win + D | Mostra a área de trabalho (minimiza as janelas) |
| Win + R | Executar |
| Win + I | Configurações |
| Win + S | Pesquisa no menu Iniciar |
| Win + Tab | Janelas abertas |
| Alt + Tab | Alterna para a janela anterior |
| Alt + F4 | Fecha a janela ativa |
| Win + ← / → | Encaixa a janela à esquerda / direita |
| Win + ↑ | Maximiza |
| Win + ↓ | Restaura ou minimiza |
| Ctrl + Shift + Esc | Gerenciador de tarefas |
| Ctrl + C / X / V | Copiar, recortar e colar (em campos e no Explorador) |
| Ctrl + Z / Y | Desfazer e refazer (Bloco de Notas e campos de texto) |
| F2 | Renomear no Explorador |
| Delete | Enviar à Lixeira (no Explorador) |
| F11 | Alterna a tela cheia da janela ativa (Esc também sai) |
| Esc | Fecha menus, painéis e diálogos |

Os atalhos globais são ignorados enquanto você digita em um campo de texto. Limitações da tecla Windows estão em [docs/LIMITATIONS.md](docs/LIMITATIONS.md).

## Armazenamento e privacidade

- **Preferências, posições dos ícones, fixados, notificações e arquivos internos** ficam no `localStorage` da WebView (armazenamento local do próprio app). Eles continuam disponíveis depois de fechar e reabrir o launcher.
- **Arquivos internos** são virtuais. Eles **não** são o armazenamento do aparelho. Para trazer um arquivo do celular, use **Importar do aparelho** no Explorador ou **Abrir do aparelho** no Bloco de Notas: o seletor do próprio Android abre e apenas o arquivo escolhido é lido.
- **Exportações** (Paint em PNG e textos em `.txt`) são gravadas com o MediaStore do Android em `Pictures/Win11Launcher` e `Download/Win11Launcher`, sem permissão de armazenamento.
- **Nenhuma permissão** é declarada no manifesto.
- **Nenhum dado é enviado** para servidores. Não há contas, Firebase, chaves de API, serviços pagos, inteligência artificial nem JavaScript remoto. A WebView bloqueia navegação para fora do pacote local.

## Estado de verificação

Para ser transparente sobre o que foi e o que não foi verificado:

| Verificação | Situação |
|---|---|
| Sintaxe de todos os arquivos JavaScript (`node --check`) | ✅ Feita, sem erros |
| Lógica da calculadora e do sistema de arquivos (`tests/teste_logica.js`) | ✅ Feita, aprovada |
| Interface no Chromium headless (Playwright), viewport de 390 px e 1100 px (`tests/teste_navegador_*.py`) | ✅ Feita, sem erros de JavaScript. Cobre: abrir, fechar, minimizar, restaurar e maximizar janelas; arrastar e redimensionar; encaixe com Win+←; tela cheia (F11 e Esc); Alt+Tab e Alt+F4; Win+D; tecla Win abrindo o menu Iniciar; pesquisa no menu; calculadora; Explorador (criar pasta); Bloco de Notas (salvar e desfazer); menu de contexto; papel de parede, tema, cor, alinhamento, tamanho de ícones e persistência após recarregar |
| Compilação do APK | ❌ **Não feita.** O ambiente de testes não tinha acesso ao Google Maven, necessário para baixar o plugin do Android |
| Execução dentro da Android WebView e em aparelho real | ❌ **Não feita.** Os testes acima rodam em navegador de computador, não na WebView do Android |
| Ponte nativa (`MainActivity.kt`, `LauncherBridge.kt`) | ❌ Não compilada nem executada. Revisada por leitura, mas precisa ser verificada no build |
| Recursos que dependem do Android (apps reais, HOME, imersivo, MediaStore, seletor de arquivos) | ❌ Não testados. Estão descritos em [LIMITATIONS.md](docs/LIMITATIONS.md) |

Antes de publicar, compile o APK, instale-o em pelo menos um aparelho com Android 10 ou superior e siga o roteiro em [docs/INSTALLATION.md](docs/INSTALLATION.md). Para rodar os testes de navegador, use Python 3 com Playwright instalado (`pip install playwright && playwright install chromium`) e execute `python3 tests/teste_navegador_1.py`, e assim por diante. Os testes de lógica rodam com `node tests/teste_logica.js`.

## Documentação adicional

- [docs/INSTALLATION.md](docs/INSTALLATION.md): instalação, compilação e roteiro de testes.
- [docs/FEATURES.md](docs/FEATURES.md): recursos implementados e como cada um funciona.
- [docs/LIMITATIONS.md](docs/LIMITATIONS.md): limitações impostas pelo Android e pelo projeto.

## Licença

Distribuído sob a licença MIT. Veja [LICENSE](LICENSE).
