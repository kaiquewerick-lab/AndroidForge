# Instalação e compilação

Este guia cobre três caminhos: testar a interface no navegador, compilar o APK e instalá-lo no aparelho.

---

## 1. Testar a interface no navegador (sem compilar)

1. Descompacte o ZIP.
2. Abra `web/index.html` em um navegador (no computador ou no celular).
3. Como não há ponte Android, a lista de aplicativos é **simulada** e um aviso aparece no centro de notificações. Todo o restante funciona: janelas, menu Iniciar, Explorador, Bloco de Notas, Calculadora, Paint, personalização e atalhos de teclado.

> Dica para celular: alguns navegadores bloqueiam `localStorage` no modo anônimo. Nesse caso, as preferências valem só durante a sessão, e a aba mostra isso em **Sistema e dados**.

---

## 2. Requisitos para compilar o APK

| Item | Versão recomendada |
|---|---|
| Android Studio | Iguana ou mais recente (ou o JDK + SDK pela linha de comando) |
| JDK | 17 |
| Android SDK Platform | 34 |
| Android SDK Build-Tools | 34.0.0 ou mais recente |
| Gradle | 8.7 (definido em `gradle-wrapper.properties`) |
| Android Gradle Plugin | 8.5.2 |
| Kotlin | 1.9.24 |
| Acesso à internet | Necessário na primeira compilação, para baixar dependências do Google Maven e do Maven Central |

Dispositivo de destino: **Android 10 (API 29) ou superior**.

---

## 3. Compilar com o Android Studio (recomendado)

1. Abra o Android Studio e escolha **Open** → selecione a pasta `android/` (não a raiz do projeto).
2. Aguarde o **Gradle Sync**. Na primeira vez ele baixa o Gradle 8.7, o plugin do Android e as bibliotecas AndroidX.
3. Se o Android Studio pedir o caminho do SDK, aceite a sugestão ou aponte para o SDK instalado. Isso cria o `local.properties`, que **não** deve ser versionado nem incluído em ZIPs.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Quando terminar, clique em **locate** na notificação. O APK de depuração fica em:
   `android/app/build/outputs/apk/debug/app-debug.apk`

Para um APK de **release**, crie uma chave de assinatura (**Build → Generate Signed Bundle / APK**). A chave não é incluída no projeto, por segurança.

---

## 4. Compilar pela linha de comando

Requisitos: JDK 17, Android SDK configurado (variável `ANDROID_HOME` ou `local.properties` com `sdk.dir`).

```bash
cd Windows11-Mobile-Launcher/android

# 1) Gerar o Gradle Wrapper (uma vez). Isso cria gradlew, gradlew.bat e gradle/wrapper/gradle-wrapper.jar.
#    Requer o Gradle instalado localmente (qualquer versão recente) e internet.
gradle wrapper --gradle-version 8.7

# 2) Compilar o APK de depuração
./gradlew assembleDebug

# 3) (Opcional) APK de release sem assinatura
./gradlew assembleRelease
```

Saída: `app/build/outputs/apk/debug/app-debug.apk` (ou `release/app-release-unsigned.apk`).

### Por que o wrapper não vem pronto no ZIP

O `gradlew` e o `gradle-wrapper.jar` são arquivos binários gerados pela própria ferramenta. O projeto inclui o `gradle-wrapper.properties`, que define a versão 8.7. Ao rodar `gradle wrapper`, a ferramenta completa a estrutura.

---

## 5. Compilar pelo celular ou pela nuvem

Não há forma prática de compilar um APK com Android SDK diretamente no celular. Alternativas:

- Usar um serviço de compilação na nuvem que aceite projetos Gradle, enviando a pasta `android/` e a pasta `web/` (a pasta `web/` precisa ficar na raiz do projeto, ao lado de `android/`, porque o Gradle a lê como `../../web`). Confira se o serviço mantém essa estrutura.
- Usar um computador de terceiros ou de amigo com Android Studio.

---

## 6. Instalar o APK no aparelho

1. Copie `app-debug.apk` para o aparelho (cabo USB, nuvem pessoal ou computador).
2. Abra o arquivo pelo gerenciador de arquivos. Quando o Android pedir, permita **Instalar apps desconhecidos** para o app usado para abrir o arquivo (o nome da opção varia conforme a marca).
3. Toque em **Instalar**.
4. Abra **Windows 11 Mobile Launcher** uma vez.

Para instalar pelo computador com depuração USB ativada:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

---

## 7. Definir como tela inicial (opcional)

1. **Configurações → Apps → Aplicativo padrão de início** (ou **Início**, conforme a marca).
2. Escolha **Windows 11 Mobile Launcher**.
3. Pressione o botão Início.

Para voltar, escolha o launcher anterior na mesma tela. O launcher nunca se define sozinho como padrão.

---

## 8. Roteiro de testes recomendado (no aparelho)

Marque cada item após testar:

- [ ] O app abre e mostra o papel de parede padrão e a barra de tarefas.
- [ ] Após abrir, aparecem até **10 apps Android** na área de trabalho (ou todos, se houver menos).
- [ ] Toque no menu Iniciar e na aba **Todos os aplicativos**. Os apps aparecem em ordem alfabética.
- [ ] Pesquisar no menu Iniciar filtra os apps enquanto você digita.
- [ ] Tocar em um app Android o abre. Um app sem tela inicial mostra uma mensagem clara.
- [ ] Instalar ou desinstalar um app e voltar ao launcher atualiza a lista (ou use **Atualizar lista**).
- [ ] Abrir, minimizar, maximizar, restaurar e fechar uma janela interna.
- [ ] Arrastar uma janela pela barra de título e redimensioná-la pela borda.
- [ ] Alternar janelas com a barra de tarefas e com Alt + Tab (teclado físico).
- [ ] Trocar o papel de parede pela galeria e reiniciar o app: a imagem deve continuar.
- [ ] Alternar tema claro/escuro e cor de destaque. Fechar e reabrir: a escolha deve permanecer.
- [ ] Criar uma pasta e um arquivo de texto no Explorador, enviar um item para a Lixeira e restaurá-lo.
- [ ] Escrever no Bloco de Notas, salvar, fechar e reabrir o arquivo.
- [ ] Fazer uma conta na Calculadora (inclusive por teclado).
- [ ] Desenhar no Paint e exportar o PNG. Conferir em Imagens ou no app de galeria.
- [ ] Negar uma permissão do seletor de arquivos (ou cancelar a escolha) não deve travar o app.
- [ ] Botão Voltar: fecha menus e janelas antes de fazer qualquer outra coisa.
- [ ] Girar o aparelho: a interface se adapta sem perder as janelas abertas.

---

## 9. Solução de problemas

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| "Não foi possível abrir" ao tocar em um app | O app não tem tela inicial ou está desativado | Verifique se o app abre pelo próprio ícone do aparelho |
| Lista de apps vazia | Build sem `<queries>` ou sem permissão de visibilidade | Confira o manifesto (seção `queries`) e reinstale o APK |
| Tela branca na primeira abertura | Assets não empacotados | Confirme que a pasta `web/` existe na raiz do projeto ao compilar |
| Gradle Sync falha no download | Sem internet ou proxy | Configure o proxy do Android Studio ou tente novamente |
| `SDK location not found` | Falta `local.properties` | Aponte o SDK no Android Studio ou crie `android/local.properties` com `sdk.dir=...` |
| Preferências somem | Armazenamento limpo pelo sistema ou modo anônimo | Use **Sistema e dados** para verificar o armazenamento disponível |
