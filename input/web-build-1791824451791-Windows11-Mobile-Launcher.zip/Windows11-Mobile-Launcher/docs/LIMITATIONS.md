# Limitações

Este documento lista o que **não** é possível fazer, ou o que é possível apenas parcialmente, por causa do Android, da WebView ou de decisões do projeto. Leia antes de prometer qualquer recurso a alguém.

---

## 1. Aplicativos Android

### 1.1 Apps não podem ser embutidos em janelas
Cada app Android roda como processo separado, com sua própria Activity. Não é possível desenhar um app externo dentro de uma janela HTML nem controlá-lo como uma janela de desktop do Windows. O launcher apenas **inicia** o app pelo intent oficial. A partir daí, quem controla a tela é o Android.

### 1.2 Visibilidade de pacotes (Android 11 e superior)
- O launcher declara `<queries>` com `MAIN` + `LAUNCHER` no manifesto. Com isso, ele vê apps que têm ícone na tela inicial.
- **Apps sem tela inicial não aparecem.** Bibliotecas, serviços em segundo plano e apps ocultos pelo sistema ou pela política do aparelho ficam fora da lista. Isso é intencional.
- **Não usamos `QUERY_ALL_PACKAGES`.** Essa permissão exige justificativa e é restrita pelas políticas de publicação da Google Play. Por isso, a lista pode ser menor que a lista completa de apps instalados.
- Em aparelhos com perfil de trabalho, ou com restrições de administrador, a lista também pode estar reduzida.

### 1.3 Abrir um app pode falhar
Os motivos mais comuns, todos informados ao usuário com uma mensagem:
- o app não tem tela inicial (`getLaunchIntentForPackage` retorna nulo);
- o app foi desativado ou removido após a última atualização da lista;
- o Android bloqueia a abertura por política do sistema.

### 1.4 Ícones
Os ícones são convertidos para PNG de 96 px. Apps com ícones adaptativos ou muito complexos podem aparecer com resolução menor que a original. Se o ícone não puder ser lido, aparece a inicial do nome.

---

## 2. Detecção de mudanças na lista

- O launcher escuta broadcasts de instalação, remoção e alteração de pacotes **somente enquanto a Activity está ativa** (entre `onStart` e `onStop`).
- Quando o launcher está em segundo plano e um app é instalado, a lista é atualizada ao voltar ao launcher (recarga silenciosa em `onResume`) ou quando você tocar em **Atualizar lista**.
- Não há serviço em segundo plano. Isso economiza bateria e evita permissões extras.

---

## 3. Tecla Windows e atalhos globais

- **A tecla Windows (Meta) pode não chegar ao launcher.** Muitos sistemas Android e teclados USB/Bluetooth tratam essa tecla antes da WebView. Quando isso acontece, Win, Win+E, Win+D etc. não funcionam. O botão **Iniciar** na barra de tarefas e o toque na tela continuam funcionando.
- **Não há interceptação global de teclas.** Atalhos só funcionam enquanto o launcher está em primeiro plano e com foco na WebView. O projeto não tem API para capturar teclas fora dele, e não promete essa função.
- **Alt+Tab** alterna entre janelas internas. Não existe um seletor visual de janelas do sistema.
- **Ctrl+Shift+Esc** abre o Gerenciador de tarefas **interno**, não o do Android.
- Teclados sem tecla Esc, F11 ou F2 precisam de combinações específicas do próprio teclado, que dependem do fabricante.
- Dois toques de tecla não são duplicados: cada tecla é tratada uma única vez, pelo listener da página. A ponte nativa não repassa teclado.

---

## 4. Tela cheia e modo imersivo

- O **modo imersivo** (esconder barras do sistema) usa `WindowInsetsController`. O Android pode ignorar a configuração em certas telas, em modo de janela múltipla e em alguns fabricantes.
- A **tela cheia de janela interna** (F11) cobre a barra de tarefas do launcher, mas **não** esconde a barra de status ou de navegação do Android, a menos que o modo imersivo tenha sido ativado com sucesso.
- O projeto **não promete ocultação permanente das barras** em todos os aparelhos.
- A saída da tela cheia é sempre possível: F11, Esc, ou o botão de maximizar da janela.

---

## 5. Tela inicial (HOME)

- O launcher se declara como HOME, mas **nunca** se define como padrão sozinho. O usuário escolhe nas configurações do Android. Isso é uma exigência do sistema e da experiência do usuário.
- **Sair do launcher** (menu Iniciar → energia, ou Configurações → Sair) chama `finish()`. Se ele for o launcher padrão, o Android pode mostrar outra tela inicial, ou o seletor de launchers, no lugar.
- O botão **Voltar**, na tela inicial, não sai do launcher. Fora dela, ele volta para a tela anterior.
- Algumas marcas de celular mantêm um launcher próprio que pode ter prioridade sobre apps de terceiros. Nesses casos, a troca precisa ser feita manualmente, e o caminho nas configurações varia.

---

## 6. Wi-Fi, Bluetooth, volume e brilho

- Um app comum **não pode** ligar ou desligar Wi-Fi e Bluetooth, nem alterar volume ou brilho de forma direta, sem permissões especiais do sistema.
- O projeto **não solicita** essas permissões nem acessibilidade ou administrador do dispositivo.
- Os botões em **Configurações rápidas** e em **Aplicativos** abrem as telas correspondentes do Android. É o caminho oficial.

---

## 7. Arquivos e armazenamento

- **Arquivos internos não são o armazenamento do aparelho.** Ficam no `localStorage` da WebView e só o launcher os acessa.
- Para trazer um arquivo do celular, o usuário usa **Importar do aparelho** (Explorador) ou **Abrir do aparelho** (Bloco de Notas). O seletor do Android entrega apenas o arquivo escolhido, sem permissão de armazenamento.
- Importações estão limitadas a **1 MB** de texto por arquivo.
- Imagens do papel de parede são reduzidas para no máximo 1600 px e salvas em JPEG, para caber no armazenamento local.
- O `localStorage` costuma ter cerca de **5 MB** por origem. Quando o limite é atingido, o launcher avisa e não grava a alteração. Não há sincronização nem backup automático.
- Exportações (PNG e `.txt`) são gravadas com o MediaStore, em `Pictures/Win11Launcher` e `Download/Win11Launcher`. O projeto não lê outros arquivos do aparelho.
- **Limpar dados do app** nas configurações do Android apaga todos os arquivos internos e preferências. Esse processo não tem volta.
- O Explorador **não tem acesso irrestrito** ao armazenamento do celular, e a interface não afirma que tem.

---

## 8. Bloco de Notas, Paint e Calculadora

- O **Bloco de Notas** aceita arquivos de texto de até 1 MB. Não edita formatação rica, PDF, Word nem planilhas.
- O **Paint** não tem desfazer. Use **Limpar** para recomeçar o desenho. A exportação é só PNG.
- A **Calculadora** faz as quatro operações, parênteses e decimais. Não tem potência, raiz nem funções científicas.

---

## 9. Gerenciador de tarefas

- Mostra **somente** as janelas internas abertas e seu estado.
- **Não mostra CPU, memória, processos ou consumo de bateria** de aplicativos Android. O launcher não tem permissão para consultar essas métricas e não inventa números.

---

## 10. Executar

- Aceita apenas nomes de ferramentas internas. Não executa comandos de terminal nem simula um shell do Windows.

---

## 11. Notificações

- As notificações são **do próprio launcher**. Elas não exibem notificações de outros apps nem do sistema, porque isso exigiria acesso a notificações do Android, que o projeto não solicita.

---

## 12. Compatibilidade da WebView

- A interface usa recursos modernos de JavaScript e CSS (`pointer events`, `ResizeObserver`, `backdrop-filter`). Aparelhos com WebView muito antiga (anterior à versão do Android 10) podem apresentar falhas visuais.
- Atualizar o **Android System WebView** pela Google Play melhora a compatibilidade.
- Transparência visual (`backdrop-filter`) pode ser simplificada em aparelhos fracos, sem perda de funcionalidade.
- A interface foi escrita para ser fluida em aparelhos intermediários, mas o desempenho depende do aparelho e da quantidade de janelas abertas.

---

## 13. Barra de tarefas em telas estreitas

- A barra de tarefas não consegue ficar exatamente no centro quando a bandeja (configurações rápidas, relógio e notificações) ocupa o lado direito. Em um celular de 390 px de largura, centralizar tudo deixaria sobreposição.
- Por isso, o grupo de botões (Iniciar, pesquisa, visão de tarefas e janelas abertas) é centralizado **no espaço à esquerda da bandeja**. Quando há muitas janelas, a área de janelas rola horizontalmente.
- Em telas largas (tablets), o efeito é o mesmo, mas com mais espaço disponível.

---

## 14. O que não foi verificado

- O APK **não foi compilado** no ambiente de desenvolvimento deste projeto, porque ele não tinha acesso ao Google Maven, necessário para baixar o plugin do Android.
- A interface foi testada no **Chromium headless** (computador), não dentro da **WebView do Android** nem em aparelho real. Diferenças de renderização e de eventos de toque entre WebView e Chrome são possíveis.
- A ponte nativa (`MainActivity.kt`, `LauncherBridge.kt`) não foi compilada nem executada. Ela foi revisada, mas deve ser verificada no build.
- Os recursos que dependem do Android (lista real de apps, abertura de apps, HOME, modo imersivo, MediaStore, seletor de arquivos) precisam de teste no aparelho, seguindo [INSTALLATION.md](INSTALLATION.md).

---

## 15. Fora do escopo

- Sincronização entre aparelhos, contas de usuário e nuvem.
- Qualquer função de inteligência artificial.
- Controle remoto, espelhamento ou máquina virtual.
- Instalação de apps a partir do launcher (o Android faz isso, quando o usuário autoriza).
- Multi-usuário e perfis de trabalho.
- Suporte para iOS ou para Android anterior à versão 10.
