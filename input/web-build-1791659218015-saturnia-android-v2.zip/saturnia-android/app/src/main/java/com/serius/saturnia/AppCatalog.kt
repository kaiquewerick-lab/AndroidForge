package com.serius.saturnia

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.util.Base64
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Descoberta de apps instalados que podem ser abertos (têm ícone no launcher).
 *
 * Usa só a API pública de pacotes. Apps sem atividade de inicialização, ocultos
 * ou desinstalados simplesmente não aparecem na consulta. A consulta depende do
 * bloco <queries> do AndroidManifest (exigido a partir do Android 11).
 */
object AppCatalog {

    data class LaunchableApp(val pkg: String, val name: String, val category: String)

    private const val ICON_PX = 72
    private val icons = LruCache<String, String>(150)

    fun installed(context: Context): List<LaunchableApp> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<LaunchableApp>()
        for (info in pm.queryIntentActivities(launcher, 0)) {
            val pkg = info.activityInfo.packageName
            if (pkg == context.packageName || !seen.add(pkg)) continue
            val appInfo: ApplicationInfo = try {
                pm.getApplicationInfo(pkg, 0)
            } catch (e: PackageManager.NameNotFoundException) {
                continue
            }
            out.add(LaunchableApp(pkg, info.loadLabel(pm).toString(), categoryKey(appInfo.category)))
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /** JSON no formato que o HTML espera: [{"pkg","name","icon","cat"}]. Ícones são carregados sob demanda. */
    fun installedJson(context: Context): String {
        val array = JSONArray()
        for (app in installed(context)) {
            array.put(
                JSONObject()
                    .put("pkg", app.pkg)
                    .put("name", app.name)
                    .put("icon", JSONObject.NULL)
                    .put("cat", app.category)
            )
        }
        return array.toString()
    }

    /** Ícone do app como data URL PNG (72 px). Null se o app não tiver ícone legível. */
    fun iconDataUrl(context: Context, pkg: String): String? {
        val cached: String? = icons.get(pkg)
        if (cached != null) return cached
        return try {
            val bitmap = context.packageManager.getApplicationIcon(pkg).toBitmap(ICON_PX, ICON_PX)
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            val url = "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            icons.put(pkg, url)
            url
        } catch (e: Exception) {
            null
        }
    }

    private fun categoryKey(category: Int): String = when (category) {
        ApplicationInfo.CATEGORY_GAME -> "GAME"
        ApplicationInfo.CATEGORY_AUDIO -> "AUDIO"
        ApplicationInfo.CATEGORY_VIDEO -> "VIDEO"
        ApplicationInfo.CATEGORY_IMAGE -> "IMAGE"
        ApplicationInfo.CATEGORY_SOCIAL -> "SOCIAL"
        ApplicationInfo.CATEGORY_NEWS -> "NEWS"
        ApplicationInfo.CATEGORY_MAPS -> "MAPS"
        ApplicationInfo.CATEGORY_PRODUCTIVITY -> "PRODUCTIVITY"
        else -> ""
    }
}
