package com.serius.saturnia

import android.content.Context
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.roundToInt

/** Operações de cor puras (ARGB). Sem Android, então podem ser testadas na JVM. */
object ColorMath {

    fun argb(alpha: Int, rgb: Int): Int = ((alpha and 0xFF) shl 24) or (rgb and 0xFFFFFF)

    fun solid(rgb: Int): Int = argb(0xFF, rgb)

    /** Mistura os canais RGB de [a] e [b]; [t] = 0 devolve [a], [t] = 1 devolve [b]. A opacidade é a de [a]. */
    fun mix(a: Int, b: Int, t: Float): Int {
        fun channel(shift: Int): Int {
            val x = (a shr shift) and 0xFF
            val y = (b shr shift) and 0xFF
            return (x + (y - x) * t).roundToInt().coerceIn(0, 255)
        }
        return (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
    }

    /** Luminância relativa (WCAG), de 0 a 1. */
    fun luminance(rgb: Int): Double {
        fun lin(c: Int): Double {
            val v = c / 255.0
            return if (v <= 0.03928) v / 12.92 else Math.pow((v + 0.055) / 1.055, 2.4)
        }
        val r = lin((rgb shr 16) and 0xFF)
        val g = lin((rgb shr 8) and 0xFF)
        val b = lin(rgb and 0xFF)
        return 0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    /** Texto legível sobre [rgb]: escuro em fundo claro, branco em fundo escuro. */
    fun onColor(rgb: Int): Int = if (luminance(rgb) > 0.4) solid(0x111111) else solid(0xFFFFFF)

    /** "#RRGGBB" para rgb (sem alpha). Devolve null para qualquer outro formato. */
    fun parseHex(s: String): Int? =
        Regex("^#([0-9a-fA-F]{6})$").matchEntire(s.trim())?.groupValues?.get(1)?.toInt(16)
}

/**
 * Paleta do balão. Quatro cores escolhidas (fundo, texto, texto secundário, destaque)
 * geram todas as outras. Assim, "Seguir o app" e os temas prontos usam o mesmo caminho.
 */
data class Palette(
    val name: String,
    val bg: Int,
    val ink: Int,
    val mute: Int,
    val acc: Int,
    val glass: Boolean
) {
    val inkColor: Int = ColorMath.solid(ink)

    /** Fundo do painel. No Líquid Glass é translúcido, com o desfoque do Android por trás. */
    val surface: Int = ColorMath.argb(if (glass) 0x8C else 0xF2, bg)
    val stroke: Int = if (glass) ColorMath.argb(0x66, 0xFFFFFF) else ColorMath.argb(0x33, ink)
    val controlBg: Int = ColorMath.argb(0x26, ink)
    val inputBg: Int = ColorMath.mix(bg, ink, 0.07f).let { if (glass) ColorMath.argb(0x80, it) else ColorMath.solid(it) }
    val modelBubble: Int = ColorMath.mix(bg, ink, 0.09f).let { if (glass) ColorMath.argb(0xA6, it) else ColorMath.solid(it) }
    val userBubble: Int = ColorMath.mix(acc, bg, 0.35f).let { if (glass) ColorMath.argb(0xB8, it) else ColorMath.solid(it) }
    val failedBubble: Int = ColorMath.solid(ColorMath.mix(bg, 0xFF5555, 0.25f))
    val failedText: Int = ColorMath.solid(0xFFB4B4)
    val attachBg: Int = ColorMath.mix(acc, bg, 0.3f).let { ColorMath.solid(it) }
    val accent: Int = ColorMath.solid(acc)
    val sendText: Int = ColorMath.onColor(acc)
    val userText: Int = ColorMath.onColor(ColorMath.mix(acc, bg, 0.35f))
    val bubbleStart: Int = ColorMath.solid(acc)
    val bubbleEnd: Int = ColorMath.solid(ColorMath.mix(acc, bg, 0.55f))
}

/** Tema do balão, salvo no aparelho. Os temas prontos ficam aqui; "Seguir o app" vem do HTML. */
object BubbleTheme {

    val DARK = Palette("Escuro", 0x101423, 0xFFFFFF, 0xAAB2D6, 0x7C8CF8, glass = false)
    val LIGHT = Palette("Claro", 0xFFFFFF, 0x111827, 0x5B6175, 0x3B5BDB, glass = false)
    val LIQUID = Palette("Líquid Glass", 0x1A2440, 0xF4F6FF, 0xC5CCEB, 0x9DB0FF, glass = true)

    private const val PREFS = "saturnia_bubble"
    private const val KEY = "theme"

    @Volatile
    var current: Palette = DARK
        private set

    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    fun addListener(listener: () -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: () -> Unit) {
        listeners.remove(listener)
    }

    /** Lê a última paleta salva. Sem nada salvo, usa o tema escuro. */
    fun load(context: Context) {
        try {
            val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            if (saved != null) parse(saved)?.let { current = it }
        } catch (e: Exception) {
            // Preferências indisponíveis: fica o tema padrão.
        }
    }

    /** Aplica e salva uma paleta enviada pelo HTML. Retorna false se o JSON não for válido. */
    fun apply(context: Context, json: String): Boolean {
        val palette = parse(json) ?: return false
        if (palette == current) return true
        current = palette
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, json).apply()
        } catch (e: Exception) {
            // Sem salvar, a cor vale até o processo ser encerrado.
        }
        listeners.forEach { it() }
        return true
    }

    /** JSON: {"name":"...","bg":"#rrggbb","ink":"#rrggbb","mute":"#rrggbb","acc":"#rrggbb","glass":true|false} */
    fun parse(json: String): Palette? = try {
        val o = JSONObject(json)
        val bg = ColorMath.parseHex(o.optString("bg"))
        val ink = ColorMath.parseHex(o.optString("ink"))
        val mute = ColorMath.parseHex(o.optString("mute"))
        val acc = ColorMath.parseHex(o.optString("acc"))
        if (bg == null || ink == null || mute == null || acc == null) {
            null
        } else {
            Palette(
                name = o.optString("name", "Personalizado").take(40),
                bg = bg,
                ink = ink,
                mute = mute,
                acc = acc,
                glass = o.optBoolean("glass", false)
            )
        }
    } catch (e: Exception) {
        null
    }
}
