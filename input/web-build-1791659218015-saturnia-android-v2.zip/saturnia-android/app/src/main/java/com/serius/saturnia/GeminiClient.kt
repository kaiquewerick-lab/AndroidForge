package com.serius.saturnia

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cliente do endpoint /api/gemini do Worker, o mesmo usado pela versão web.
 * O app não tem chave de API: envia só o token de sessão Firebase do usuário.
 */
object GeminiClient {

    /** Endereço público do Worker (não é segredo). As chaves ficam no servidor. */
    const val WORKER_URL = "https://saturnia-api-proxy.kiiikaioxdogulox.workers.dev"

    /** Guia da SaturnIA enviado pelo HTML (criador, funções, temas). Só na memória. */
    @Volatile
    private var appContext: String = ""

    fun setAppContext(text: String) {
        appContext = text.trim().take(12_000)
    }

    /** Instrução do sistema: a base do balão mais o guia do app, quando houver. */
    private fun systemText(): String =
        if (appContext.isBlank()) SYSTEM else SYSTEM + "\n\n" + appContext

    private const val SYSTEM =
        "Você é a SaturnIA, uma assistente que responde em português do Brasil. " +
            "Você aparece em um balão flutuante sobre outros aplicativos, então seja clara e objetiva."

    /** Mensagem amigável para o erro HTTP recebido do Worker (regras em ChatRules). */
    fun errorFor(status: Int, code: String?): String = ChatRules.errorFor(status, code)

    /** Partes de uma mensagem: imagem (inline_data) antes do texto, no formato da API Gemini. */
    private fun partsFor(m: ChatMessage): JSONArray {
        val parts = JSONArray()
        m.image?.let {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", it.mime).put("data", it.base64)
                )
            )
        }
        if (m.text.isNotBlank()) parts.put(JSONObject().put("text", m.text))
        return parts
    }

    fun buildBody(model: String, history: List<ChatMessage>): JSONObject {
        val contents = JSONArray()
        for (m in history) {
            contents.put(JSONObject().put("role", m.role).put("parts", partsFor(m)))
        }
        return JSONObject()
            .put("model", model)
            .put("contents", contents)
            .put("system", systemText())
            .put("temperature", 0.7)
            .put("search", false)
    }

    /** Corpo no formato nativo da API Gemini (usado com a chave própria do usuário). */
    fun buildDirectBody(history: List<ChatMessage>): JSONObject {
        val contents = JSONArray()
        for (m in history) {
            contents.put(JSONObject().put("role", m.role).put("parts", partsFor(m)))
        }
        return JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemText()))))
            .put("generationConfig", JSONObject().put("temperature", 0.7))
    }

    /** Erro da API direta. Nunca inclui a chave na mensagem. */
    fun directErrorFor(status: Int): String = when (status) {
        400 -> "A chave da API foi recusada ou a requisição é inválida. Confira a chave em Configurações."
        403 -> "Esta chave não tem permissão para usar este modelo."
        404 -> "Modelo não encontrado. Confira o nome do modelo na lista do balão."
        429 -> "Limite de uso da sua chave atingido. Aguarde ou confira sua cota no Google AI Studio."
        else -> "A API do Gemini respondeu com erro ($status). Tente de novo em instantes."
    }

    /**
     * Chamada direta com a chave própria do usuário (a mesma regra do chat web).
     * A chave fica só na memória do processo; não é gravada nem enviada ao Worker.
     */
    private fun callDirect(key: String, model: String, history: List<ChatMessage>): GeminiResult {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("x-goog-api-key", key)
            conn.outputStream.use { it.write(buildDirectBody(history).toString().toByteArray(Charsets.UTF_8)) }

            val status = conn.responseCode
            if (status !in 200..299) {
                GeminiResult.Failed(directErrorFor(status))
            } else {
                val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parts = JSONObject(raw).optJSONArray("candidates")
                    ?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                val text = buildString {
                    if (parts != null) {
                        for (i in 0 until parts.length()) append(parts.optJSONObject(i)?.optString("text").orEmpty())
                    }
                }.trim()
                if (text.isEmpty()) {
                    GeminiResult.Failed("O modelo não enviou resposta. Tente reformular a pergunta.")
                } else {
                    GeminiResult.Ok(text)
                }
            }
        } catch (e: IOException) {
            GeminiResult.Failed("Não foi possível falar com a API do Gemini. Verifique a conexão.")
        } catch (e: Exception) {
            GeminiResult.Failed("Resposta inesperada da API do Gemini.")
        } finally {
            conn?.disconnect()
        }
    }

    /** Chamada bloqueante: rodar sempre fora da thread principal. */
    fun call(token: String, model: String, history: List<ChatMessage>, ownKey: String = ""): GeminiResult {
        if (history.isEmpty()) {
            return GeminiResult.Failed("Escreva uma mensagem para começar.")
        }
        if (ownKey.isNotBlank()) return callDirect(ownKey, model, history)
        if (token.isBlank()) {
            return GeminiResult.Failed("Entre na sua conta da SaturnIA no app para usar o balão.")
        }
        if (history.isEmpty()) {
            return GeminiResult.Failed("Escreva uma mensagem para começar.")
        }
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("$WORKER_URL/api/gemini").openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 10_000
            conn.readTimeout = 60_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.outputStream.use { it.write(buildBody(model, history).toString().toByteArray(Charsets.UTF_8)) }

            val status = conn.responseCode
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

            if (status !in 200..299) {
                val code = try {
                    JSONObject(raw).optJSONObject("error")?.optString("code")
                } catch (e: Exception) {
                    null
                }
                GeminiResult.Failed(ChatRules.errorFor(status, code))
            } else {
                val text = JSONObject(raw).optString("text").trim()
                if (text.isEmpty()) {
                    GeminiResult.Failed("O modelo não enviou resposta. Tente reformular a pergunta.")
                } else {
                    GeminiResult.Ok(text)
                }
            }
        } catch (e: IOException) {
            GeminiResult.Failed("Não foi possível falar com o servidor. Verifique a conexão.")
        } catch (e: Exception) {
            GeminiResult.Failed("Resposta inesperada do servidor.")
        } finally {
            conn?.disconnect()
        }
    }
}
