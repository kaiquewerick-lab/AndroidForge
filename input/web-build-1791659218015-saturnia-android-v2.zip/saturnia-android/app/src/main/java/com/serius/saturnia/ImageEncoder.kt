package com.serius.saturnia

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Prepara uma imagem escolhida na galeria para a IA: reduz para no máximo [MAX_SIDE] px,
 * troca a transparência por fundo branco e codifica em JPEG base64.
 *
 * Só lê o arquivo que o usuário escolheu. Não captura tela nem acessa outros apps.
 * Deve rodar fora da thread principal.
 */
object ImageEncoder {

    private const val MAX_SIDE = 1024
    private const val JPEG_QUALITY = 82

    fun encode(context: Context, uri: Uri): ImageData? {
        val bitmap = decodeScaled(context, uri) ?: return null
        val flat = flattenOnWhite(bitmap)
        bitmap.recycle()
        val out = ByteArrayOutputStream()
        val ok = flat.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        flat.recycle()
        if (!ok) return null
        return ImageData("image/jpeg", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
    }

    private fun decodeScaled(context: Context, uri: Uri): Bitmap? {
        val resolver = context.contentResolver
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // ImageDecoder aplica a rotação EXIF das fotos e já reduz na decodificação.
            try {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(resolver, uri)) { decoder, info, _ ->
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
                    val w = info.size.width
                    val h = info.size.height
                    val scale = MAX_SIDE.toFloat() / max(w, h)
                    if (scale < 1f) {
                        decoder.setTargetSize(
                            (w * scale).roundToInt().coerceAtLeast(1),
                            (h * scale).roundToInt().coerceAtLeast(1)
                        )
                    }
                }
            } catch (e: Exception) {
                null
            }
        } else {
            // Android 8/9: decodificação por amostragem (sem rotação EXIF).
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val largest = max(bounds.outWidth, bounds.outHeight)
                if (largest <= 0) return null
                var sample = 1
                while (largest / (sample * 2) >= MAX_SIDE) sample *= 2
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }?.let { raw ->
                    val scale = MAX_SIDE.toFloat() / max(raw.width, raw.height)
                    if (scale < 1f) {
                        Bitmap.createScaledBitmap(
                            raw,
                            (raw.width * scale).roundToInt().coerceAtLeast(1),
                            (raw.height * scale).roundToInt().coerceAtLeast(1),
                            true
                        ).also { if (it !== raw) raw.recycle() }
                    } else {
                        raw
                    }
                }
            } catch (e: Exception) {
                null
            }
        }
    }

    /** Cola a imagem sobre fundo branco (JPEG não tem transparência). Devolve sempre uma cópia nova. */
    private fun flattenOnWhite(source: Bitmap): Bitmap {
        val result = Bitmap.createBitmap(source.width, source.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(source, 0f, 0f, null)
        return result
    }
}
