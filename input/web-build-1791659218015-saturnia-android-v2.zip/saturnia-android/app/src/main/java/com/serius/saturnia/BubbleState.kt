package com.serius.saturnia

/**
 * Estado do SaturnIA Bubble. O HTML lê com getBubbleState().
 * Nada aqui guarda conteúdo de conversa: só status e modo de exibição.
 */
object BubbleState {
    const val STOPPED = "stopped"                        // desligado pelo usuário
    const val RUNNING = "running"                        // balão ativo
    const val NO_OVERLAY = "no_overlay_permission"       // falta "Exibir sobre outros apps"
    const val NO_NOTIFICATION = "no_notification_permission"
    const val BLOCKED = "blocked"                        // o Android impediu a exibição agora
    const val ERROR = "error"

    const val MODE_FLOATING = "floating"                 // balão visível; painel compacto opcional
    const val MODE_FULLSCREEN = "fullscreen"             // painel ocupa a tela
    const val MODE_HIDDEN = "hidden"                     // nada visível; reabre pela notificação

    @Volatile
    var state: String = STOPPED
        private set

    @Volatile
    var mode: String = MODE_HIDDEN
        private set

    @Volatile
    var detail: String = ""
        private set

    fun set(newState: String, newMode: String = mode, newDetail: String = "") {
        state = newState
        mode = newMode
        detail = newDetail
    }
}
