# PC Remoto — arquitetura, configuração e limites

## Estado

| Parte | Situação |
|---|---|
| Tela "PC Remoto" no SaturnDesktopBETA (estados, reconexão, desconexão, aviso de expiração) | ✅ Implementada e testada com API simulada (16 testes) |
| Contrato `/api/remote/session` no Worker | ❌ Não implementado (o Worker não foi acessado) |
| Workflow Windows com RDP + Tailscale (`infra/github-actions/windows-rdp.yml`) | ⚠️ Escrito e com YAML válido; **não executado** |
| Gateway web que converte RDP em tela no navegador (Apache Guacamole) | ❌ Não implementado |
| Sessão Windows real vista pelo celular | ❌ Não testada. Depende dos dois itens acima |

**Enquanto o gateway não existir, a área da tela fica vazia.** A página nunca mostra uma tela simulada.

## Por que um navegador comum não basta

RDP é um protocolo binário sobre TCP (porta 3389). Uma página HTML não abre esse tipo de conexão. É preciso um intermediário que:

1. fale RDP com o Windows (dentro da rede Tailscale);
2. converta a sessão para WebSocket/HTML5 (Guacamole faz isso com `guacd` e a aplicação web);
3. seja acessível pelo navegador do Android por HTTPS, com login próprio.

O SaturnDesktopBETA só precisa embutir essa página do gateway num `iframe`, com o endereço recebido da API.

## Arquitetura

```
Android (SaturnDesktopBETA)
   │ POST /api/remote/session   (sem endereço de máquina: o servidor escolhe)
   ▼
Worker (Cloudflare)  ── autentica o usuário, guarda segredos, dispara o workflow
   │ workflow_dispatch (GitHub API, token só no Worker)
   ▼
GitHub Actions: runner Windows (temporário, até 6 h por job)
   │ Tailscale (OAuth + tag:pc-remoto) ── firewall só para 100.64.0.0/10
   ▼
Gateway Guacamole na mesma rede Tailscale ──► RDP (3389, com NLA) ──► Windows
   ▲
   │ HTTPS + login próprio do gateway → iframe no SaturnDesktopBETA
Android
```

## Por que o runner não é acessado diretamente

- O runner **não tem endereço público** e não deve ter. Quem alcança o RDP é apenas o gateway, pela Tailscale.
- A porta **3389 nunca é aberta publicamente**: o workflow remove as regras genéricas e cria uma regra só para a faixa `100.64.0.0/10` (Tailscale).
- **NLA continua ativo** (`UserAuthentication=1`).

## Limites reais

- **Tempo:** cada job roda por até **6 horas** (documentação do GitHub). O workflow usa `timeout-minutes: 300` e tem duração padrão de 240 min. Ao terminar, a sessão acaba.
- **Efêmero:** o runner é descartado no fim do job. Arquivos não salvos somem. Não há disco persistente.
- **Cota:** execuções consomem minutos do GitHub Actions. O plano gratuito tem **2.000 minutos por mês**, segundo a documentação. A proporção para Windows não foi confirmada.
- **Sessão interativa:** runners hospedados não são máquinas de uso pessoal. Antes de usar para sessões interativas longas, **verifique os termos de uso do GitHub Actions e a política de runners hospedados**. Não foi possível confirmar isso aqui.
- **Não é Windows de verdade para uso diário:** o desktop do runner pode não se comportar como um PC pessoal (drivers, aplicativos, pilha de rede). Não testado.
- **IP muda a cada execução:** o gateway precisa receber o endereço Tailscale do runner atual, o que exige automação no Worker.

## Segredos (nunca no HTML, no JavaScript do cliente ou no Git)

| Onde | Nome | Para quê |
|---|---|---|
| Repositório de infra → ambiente `pc-remoto` | `RDP_PASSWORD` | senha do usuário `pcremoto` (mínimo 20 caracteres) |
| Repositório de infra → ambiente `pc-remoto` | `TS_OAUTH_CLIENT_ID` / `TS_OAUTH_SECRET` | cliente OAuth da Tailscale (recomendado no lugar de chave que expira) |
| Worker (Cloudflare) | `GITHUB_TOKEN` (fine-grained, só `Actions: write` no repositório de infra) | disparar o workflow |
| Gateway | senhas do Guacamole e do administrador | login do gateway |

Gere a senha do RDP com um gerenciador de senhas. Não reutilize senhas.

## Configuração (passo a passo)

1. **Tailscale (admin console):**
   - Crie a tag `tag:pc-remoto` nas ACLs e defina quem pode usá-la em `tagOwners`.
   - Crie um cliente OAuth com escopo para essa tag. Guarde o ID e o segredo no ambiente `pc-remoto`.
   - Crie uma regra de ACL que permita só o gateway acessar `tag:pc-remoto` na porta 3389.
2. **Repositório de infraestrutura (privado):** copie `infra/github-actions/windows-rdp.yml` para `.github/workflows/`. Crie o ambiente `pc-remoto` e os segredos acima.
3. **Gateway:** instale Apache Guacamole (guacd + aplicação web) num host que esteja na mesma tailnet. Configure HTTPS, login e, se possível, autenticação em dois fatores. A página de login do gateway é a única tela pública.
4. **Worker:** implemente as rotas do contrato abaixo. O Worker dispara o workflow, aguarda o runner ficar pronto, cadastra a conexão RDP no Guacamole com o IP Tailscale atual e devolve `viewerUrl`.
5. **Teste:** rode o workflow manualmente, confira os logs (sem senhas), acesse o gateway pelo navegador do celular e só depois use o SaturnDesktopBETA.

## Contrato da API (usado pela tela do SaturnDesktopBETA)

Todas as rotas exigem usuário autenticado. Não implementado no Worker até agora.

| Método | Rota | Resposta |
|---|---|---|
| GET | `/api/remote/session` | `{ "state": "...", "message"?, "viewerUrl"?, "expiresAt"? }` |
| POST | `/api/remote/session` | mesmo formato. Inicia o workflow e devolve `conectando` |
| POST | `/api/remote/session/end` | `{ "state": "desconectado" }` após cancelar o workflow e remover a conexão do gateway |

`state`: `desconectado`, `conectando`, `conectado`, `encerrado`, `erro`.

- `conectado` **só** com `viewerUrl` em `https://`. Sem isso, a tela mostra erro.
- A tela do SaturnDesktopBETA **nunca** mostra "conectado" por conta própria.
- Em queda de rede, a página tenta de novo três vezes (3 s, 6 s, 12 s) e depois mostra erro.

## Decisões pendentes (preciso da sua confirmação)

1. **Onde roda o gateway?** Ele precisa estar na tailnet. O Codespace pode não permitir o Tailscale (precisa de acesso a `/dev/net/tun`). Verifique antes de escolher. Alternativas: um host próprio, ou um VPS pago (fora do escopo sem sua aprovação).
2. **Repositório de infra:** você quer um repositório separado (recomendado) para o workflow e os segredos, ou prefere no `SaturnDesktop-PC`?
3. **Duração padrão:** 240 minutos é um palpite. Confirme o valor que você quer.
4. **Usuário no Windows:** só `Remote Desktop Users` (recomendado) ou também `Administrators`? Admin facilita instalar programas, mas aumenta o risco.

## Testes

- Automáticos (`npm test`): máquina de estados da tela, validação de `viewerUrl`, reconexão e demonstração. **Não** tocam o Windows.
- Manuais, na ordem: (1) workflow roda e mostra o IP Tailscale; (2) do notebook na mesma tailnet, RDP conecta com NLA; (3) gateway abre no navegador do computador; (4) gateway abre no celular; (5) teclado, mouse, rolagem e área de transferência; (6) desconectar encerra o workflow; (7) queda de rede e reconexão. Só marque como passado o que foi executado.
