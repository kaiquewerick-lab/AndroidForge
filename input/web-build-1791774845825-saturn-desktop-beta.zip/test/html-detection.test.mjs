import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const realSetTimeout = globalThis.setTimeout;
const html = await readFile(new URL('../SaturnDesktopBETA.html', import.meta.url), 'utf8');
const script = await readFile(new URL("../assets/app.js", import.meta.url), "utf8");
const API = 'https://saturndesktopbeta-api.kiiikaioxdogulox.workers.dev';

function makeEl() {
  return {
    textContent: '', innerHTML: '', value: '', hidden: false, disabled: false, open: false,
    dataset: {}, classList: { toggle() {}, add() {}, remove() {} },
    handlers: {},
    addEventListener(type, fn) { this.handlers[type] = fn; },
    setAttribute() {}, removeAttribute() {}, focus() {},
    showModal() { this.open = true; }, close() { this.open = false; },
    querySelectorAll() { return []; }, closest() { return null; }, src: '',
  };
}

/**
 * Executa a página com uma API simulada.
 * routes(url, init) devolve { status, body } ou um Error (falha de rede).
 */
async function runPage(routes) {
  const store = {};
  const calls = [];
  const ctx = {
    document: {
      querySelector: (s) => (store[s] ??= makeEl()),
      querySelectorAll: () => [],
    },
    location: { origin: 'null', protocol: 'file:' },
    localStorage: { getItem: () => null, setItem() {} },
    performance: { now: () => Date.now() },
    AbortController,
    setTimeout: () => 0,
    clearTimeout() {},
    fetch: async (url, init = {}) => {
      calls.push({ url, method: init.method || 'GET', body: init.body ? JSON.parse(init.body) : undefined });
      const r = routes(url, init);
      if (r instanceof Error) throw r;
      return { ok: r.status >= 200 && r.status < 300, status: r.status, json: async () => r.body };
    },
  };
  vm.createContext(ctx);
  vm.runInContext(script, ctx);
  await settle();
  return { store, calls };
}

const settle = () => new Promise((resolve) => realSetTimeout(resolve, 30));
const net = () => new TypeError('Failed to fetch');
const ok = (body = {}) => ({ status: 200, body });
const health = (body = { service: 'saturndesktop-beta', version: '0.1.0-beta.1', status: 'up' }) => ok(body);
const notFound = () => ({ status: 404, body: null });

/** Rotas padrão: API no ar e configuração sem seleção. */
const apiUp = (overrides = {}) => (url, init) => {
  for (const [suffix, handler] of Object.entries(overrides)) {
    if (url.endsWith(suffix)) return handler(url, init);
  }
  if (url.endsWith('/api/health')) return health();
  if (url.endsWith('/api/config')) return ok({});
  return { status: 404, body: null };
};

// ---------- Indicador de conexão ----------

test('API fora do ar: indicador mostra "API desconectada"', async () => {
  const { store } = await runPage(() => net());
  assert.equal(store['#infra-state'].textContent, 'API desconectada');
  assert.match(store['#menu-notice'].innerHTML, /Não foi possível alcançar/);
});

test('rota /api/health inexistente: "API desconectada" com explicação', async () => {
  const { store } = await runPage(() => notFound());
  assert.equal(store['#infra-state'].textContent, 'API desconectada');
  assert.match(store['#infra-state'].dataset.tone, /err/);
});

test('API responde: indicador mostra "API conectada"', async () => {
  const { store } = await runPage(apiUp());
  assert.equal(store['#infra-state'].textContent, 'API conectada');
  assert.equal(store['#infra-state'].dataset.tone, 'ok');
});

test('outro serviço no endereço: "API desconectada"', async () => {
  const { store } = await runPage(() => health({ service: 'outro-sistema' }));
  assert.equal(store['#infra-state'].textContent, 'API desconectada');
});

test('erro HTTP 500 no health: "API desconectada"', async () => {
  const { store } = await runPage(() => ({ status: 500, body: null }));
  assert.equal(store['#infra-state'].textContent, 'API desconectada');
});

test('o endereço padrão é o Worker do Cloudflare', async () => {
  const { calls } = await runPage(apiUp());
  assert.equal(calls[0].url, `${API}/api/health`);
});

test('diagnóstico mostra o endereço padrão e a última verificação', async () => {
  const { store } = await runPage(() => net());
  store['#btn-diagnostics'].handlers.click();
  assert.match(store['#diag-result'].innerHTML, /workers\.dev/);
  assert.match(store['#diag-result'].innerHTML, /Última verificação/);
});

// ---------- Configuração (GET /api/config) ----------

test('configuração carregada da API preenche a seleção', async () => {
  const { store } = await runPage(apiUp({
    '/api/config': () => ok({
      selection: { os: 'ubuntu', ram: 8, cpu: 4, storage: 50, profile: 'equilibrado' },
      catalog: { os: [{ id: 'ubuntu', name: 'Ubuntu' }], ram: [{ gb: 8 }], cpu: [{ vcpus: 4 }], storage: [{ gb: 50 }] },
    }),
  }));
  assert.equal(store['#hw-ram'].textContent, '8 GB');
  assert.equal(store['#hw-os'].textContent, 'Ubuntu');
});

test('sem catálogo na API, nenhuma capacidade é inventada', async () => {
  const { store } = await runPage(apiUp());
  assert.equal(store['#hw-ram'].textContent, 'Não escolhida');
  assert.equal(store['#hw-storage'].textContent, 'Não escolhido');
});

// ---------- Salvar configuração (POST /api/config) ----------

test('salvar envia POST /api/config e só então confirma', async () => {
  const { store, calls } = await runPage(apiUp({
    '/api/config': (_u, init) => (init.method === 'POST' ? ok({ saved: true }) : ok({})),
  }));
  store['#btn-save-config'].handlers.click();
  await settle();
  const post = calls.find((c) => c.method === 'POST' && c.url.endsWith('/api/config'));
  assert.ok(post, 'deveria enviar POST /api/config');
  assert.ok('selection' in post.body);
  assert.match(store['#config-msg'].textContent, /salva na API/);
  assert.doesNotMatch(store['#config-msg'].textContent, /NÃO/);
});

test('salvar com erro do servidor informa que NÃO foi salvo', async () => {
  const { store } = await runPage(apiUp({
    '/api/config': (_u, init) => (init.method === 'POST'
      ? { status: 500, body: { message: 'Banco indisponível.' } }
      : ok({})),
  }));
  store['#btn-save-config'].handlers.click();
  await settle();
  assert.match(store['#config-msg'].textContent, /NÃO foi salva na API: Banco indisponível/);
  assert.equal(store['#config-msg'].dataset.tone, 'err');
});

test('salvar com API fora do ar informa que NÃO foi salvo', async () => {
  const { store } = await runPage((url, init) => {
    if (init.method === 'POST') return net();
    return url.endsWith('/api/health') ? health() : ok({});
  });
  store['#btn-save-config'].handlers.click();
  await settle();
  assert.match(store['#config-msg'].textContent, /NÃO foi salva/);
});

// ---------- Iniciar (POST /api/pc/start) ----------

test('iniciar: sem confirmação da API, a máquina NUNCA aparece como ligada', async () => {
  const { store } = await runPage(apiUp({
    '/api/pc/start': () => ({ status: 501, body: { message: 'Provisionamento ainda não implementado.' } }),
  }));
  store['#btn-start'].handlers.click();
  await settle();
  store['#btn-confirm-start'].handlers.click();
  await settle();
  assert.equal(store['#vm-state'].textContent, 'Não iniciada');
  assert.match(store['#start-result'].textContent, /Provisionamento ainda não implementado/);
  assert.notEqual(store['#vm-state'].textContent, 'Ligada');
});

test('iniciar: resposta 200 sem estado confirmado não vira "Ligada"', async () => {
  const { store } = await runPage(apiUp({ '/api/pc/start': () => ok({}) }));
  store['#btn-start'].handlers.click();
  await settle();
  store['#btn-confirm-start'].handlers.click();
  await settle();
  assert.equal(store['#vm-state'].textContent, 'Não iniciada');
});

test('iniciar: state "starting" mostra "Iniciando", não "Ligada"', async () => {
  const { store } = await runPage(apiUp({ '/api/pc/start': () => ok({ state: 'starting', message: 'Solicitação aceita.' }) }));
  store['#btn-start'].handlers.click();
  await settle();
  store['#btn-confirm-start'].handlers.click();
  await settle();
  assert.equal(store['#vm-state'].textContent, 'Iniciando');
  assert.equal(store['#start-result'].textContent, 'Solicitação aceita.');
  assert.equal(store['#btn-shutdown'].hidden, false);
});

test('iniciar: state "running" confirmado mostra "Ligada"', async () => {
  const { store } = await runPage(apiUp({ '/api/pc/start': () => ok({ state: 'running' }) }));
  store['#btn-start'].handlers.click();
  await settle();
  store['#btn-confirm-start'].handlers.click();
  await settle();
  assert.equal(store['#vm-state'].textContent, 'Ligada');
  assert.equal(store['#vm-state'].dataset.tone, 'ok');
});

test('iniciar: falha de rede mostra "Falhou", não "Ligada"', async () => {
  const { store } = await runPage((url, init) => {
    if (init.method === 'POST') return net();
    return url.endsWith('/api/health') ? health() : ok({});
  });
  store['#btn-start'].handlers.click();
  await settle();
  store['#btn-confirm-start'].handlers.click();
  await settle();
  assert.equal(store['#vm-state'].textContent, 'Falhou');
});

test('botão de confirmar fica desabilitado com a API fora do ar', async () => {
  const { store } = await runPage(() => net());
  store['#btn-start'].handlers.click();
  await settle();
  assert.equal(store['#btn-confirm-start'].disabled, true);
  assert.match(store['#start-note'].textContent, /API desconectada/);
});

// ---------- Desligar (POST /api/pc/stop) ----------

test('desligar envia POST /api/pc/stop e mostra o resultado real', async () => {
  const { store, calls } = await runPage(apiUp({
    '/api/pc/stop': () => ok({ state: 'stopped' }),
  }));
  store['#btn-shutdown'].handlers.click();
  await settle();
  assert.ok(calls.some((c) => c.method === 'POST' && c.url.endsWith('/api/pc/stop')));
  assert.equal(store['#vm-state'].textContent, 'Desligada');
  assert.match(store['#menu-notice'].innerHTML, /desligada/);
});

test('desligar sem confirmação da API não mostra "Desligada"', async () => {
  const { store } = await runPage(apiUp({ '/api/pc/stop': () => ({ status: 501, body: null }) }));
  store['#btn-shutdown'].handlers.click();
  await settle();
  assert.notEqual(store['#vm-state'].textContent, 'Desligada');
});

// ---------- Demonstração ----------

test('demonstração não envia nada à API', async () => {
  const { store, calls } = await runPage(apiUp());
  store['#btn-diag-demo'].handlers.click();
  await settle();
  store['#btn-save-config'].handlers.click();
  await settle();
  assert.equal(calls.filter((c) => c.method === 'POST').length, 0);
  assert.match(store['#config-msg'].textContent, /Demonstração ativa/);
});

test('demonstração não permite solicitar a inicialização', async () => {
  const { store } = await runPage(apiUp());
  store['#btn-diag-demo'].handlers.click();
  await settle();
  store['#btn-start'].handlers.click();
  await settle();
  assert.equal(store['#btn-confirm-start'].disabled, true);
});

// ---------- Estrutura do HTML ----------

test('nenhuma capacidade aparece como escolhida sem configuração', async () => {
  const { store } = await runPage(() => net());
  assert.equal(store['#hw-ram'].textContent, 'Não escolhida');
  assert.match(html, /id="btn-confirm-start"[^>]*disabled/);
});
