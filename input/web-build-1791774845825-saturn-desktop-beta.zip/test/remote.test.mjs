import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const realSetTimeout = globalThis.setTimeout;
const script = await readFile(new URL('../assets/app.js', import.meta.url), 'utf8');
const API = 'https://saturndesktopbeta-api.kiiikaioxdogulox.workers.dev';
const VIEWER = 'https://pc-remoto.exemplo.test/vnc/ok';
const settle = () => new Promise((r) => realSetTimeout(r, 20));

function makeEl() {
  return {
    textContent: '', innerHTML: '', value: '', hidden: false, disabled: false, open: false,
    dataset: {}, src: '', handlers: {}, classList: { toggle() {}, add() {}, remove() {} },
    addEventListener(type, fn) { this.handlers[type] = fn; },
    setAttribute() {}, removeAttribute() {}, focus() {},
    showModal() { this.open = true; }, close() { this.open = false; },
    querySelectorAll() { return []; }, closest() { return null; },
  };
}

/** Executa a página com API simulada e um relógio e timers controlados pelo teste. */
async function runPage(routes) {
  const store = {};
  const calls = [];
  const timers = new Map();
  let nextId = 1;
  let clock = 1_000_000;
  class FakeDate extends Date { static now() { return clock; } }
  const ctx = {
    document: { querySelector: (s) => (store[s] ??= makeEl()), querySelectorAll: () => [] },
    location: { origin: 'null', protocol: 'file:' },
    localStorage: { getItem: () => null, setItem() {} },
    performance: { now: () => clock },
    AbortController,
    URL,
    Date: FakeDate,
    setTimeout: (fn) => { const id = nextId++; timers.set(id, fn); return id; },
    clearTimeout: (id) => { timers.delete(id); },
    fetch: async (url, init = {}) => {
      calls.push({ url, method: init.method || 'GET' });
      const r = routes(url, init);
      if (r instanceof Error) throw r;
      return { ok: r.status >= 200 && r.status < 300, status: r.status, json: async () => r.body };
    },
  };
  vm.createContext(ctx);
  vm.runInContext(script, ctx);
  await settle();
  const h = {
    store, calls,
    advance(ms) { clock += ms; },
    /** Executa as verificações agendadas do PC Remoto (pollRemote). */
    async poll() {
      const due = [...timers].filter(([, fn]) => fn.name === 'pollRemote');
      for (const [id, fn] of due) { timers.delete(id); fn(); }
      await settle();
      return due.length;
    },
  };
  return h;
}

const health = () => ({ status: 200, body: { service: 'saturndesktop-beta', version: '0.1.0', status: 'up' } });
const json = (body, status = 200) => ({ status, body });
const netErr = () => new TypeError('Failed to fetch');

/** Rotas padrão: API no ar. Overrides recebem (url, init) e devolvem a resposta. */
const api = (remoteHandler) => (url, init) => {
  if (url.endsWith('/api/health')) return health();
  if (url.endsWith('/api/config')) return json({});
  if (url.includes('/api/remote/')) return remoteHandler(url, init);
  return json(null, 404);
};

const remoteState = (h) => h.store['#remote-status'].dataset.state;
const frameSrc = (h) => h.store['#remote-frame'].src;
const remoteCalls = (h, method, end = '') => h.calls.filter((c) => c.method === method && c.url.includes('/api/remote/') && c.url.endsWith(end));

test('abre desconectado, sem tela e sem chamadas remotas', async () => {
  const h = await runPage(api(() => json({ state: 'desconectado' })));
  h.store['#btn-remote'].handlers.click();
  assert.equal(remoteState(h), 'desconectado');
  assert.equal(remoteCalls(h, 'POST').length, 0);
  assert.equal(h.store['#btn-remote-connect'].hidden, false);
});

test('conectar com sessão confirmada mostra a tela remota', async () => {
  const h = await runPage(api((url, init) => (init.method === 'POST'
    ? json({ state: 'conectado', viewerUrl: VIEWER, expiresAt: '2026-10-12T05:00:00Z' })
    : json({ state: 'conectado', viewerUrl: VIEWER }))));
  h.store['#btn-remote'].handlers.click();
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'conectado');
  assert.equal(frameSrc(h), VIEWER);
  assert.equal(h.store['#remote-screen'].hidden, false);
  assert.equal(h.store['#btn-remote-disconnect'].hidden, false);
  assert.match(h.store['#remote-expiry'].textContent, /Sessão até/);
});

test('conectado sem endereço https da tela vira erro, sem iframe', async () => {
  const h = await runPage(api(() => json({ state: 'conectado' })));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'erro');
  assert.equal(frameSrc(h), '');
  assert.match(h.store['#remote-state-text'].textContent, /https válido/);
});

test('endereço http da tela é recusado', async () => {
  const h = await runPage(api(() => json({ state: 'conectado', viewerUrl: 'http://inseguro.test/' })));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'erro');
  assert.equal(frameSrc(h), '');
});

test('conectando acompanha até ficar conectado', async () => {
  let polls = 0;
  const h = await runPage(api((url, init) => {
    if (init.method === 'POST') return json({ state: 'conectando', message: 'Iniciando a máquina.' });
    polls += 1;
    return polls < 2 ? json({ state: 'conectando' }) : json({ state: 'conectado', viewerUrl: VIEWER });
  }));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'conectando');
  assert.equal(frameSrc(h), '');
  await h.poll();
  assert.equal(remoteState(h), 'conectando');
  await h.poll();
  assert.equal(remoteState(h), 'conectado');
  assert.equal(frameSrc(h), VIEWER);
});

test('conectando além do limite vira erro real, não fica carregando', async () => {
  const h = await runPage(api((url, init) => (init.method === 'POST' ? json({ state: 'conectando' }) : json({ state: 'conectando' }))));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  h.advance(121_000);
  await h.poll();
  assert.equal(remoteState(h), 'erro');
  assert.match(h.store['#remote-state-text'].textContent, /não ficou pronto a tempo/);
});

test('erro HTTP da API aparece com a mensagem dela', async () => {
  const h = await runPage(api(() => json({ message: 'Nenhuma máquina disponível agora.' }, 503)));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'erro');
  assert.match(h.store['#remote-state-text'].textContent, /Nenhuma máquina disponível agora/);
});

test('estado desconhecido da API vira erro', async () => {
  const h = await runPage(api(() => json({ state: 'mágico' })));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'erro');
  assert.match(h.store['#remote-state-text'].textContent, /desconhecido/);
});

test('desconectar limpa a tela e confirma o encerramento da API', async () => {
  const h = await runPage(api((url, init) => (init.method === 'POST' && url.endsWith('/end')
    ? json({ state: 'desconectado', message: 'Sessão encerrada.' })
    : init.method === 'POST' ? json({ state: 'conectado', viewerUrl: VIEWER }) : json({ state: 'conectado', viewerUrl: VIEWER }))));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(frameSrc(h), VIEWER);
  h.store['#btn-remote-disconnect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'desconectado');
  assert.equal(frameSrc(h), 'about:blank');
  assert.equal(remoteCalls(h, 'POST', '/end').length, 1);
});

test('falha ao desconectar remove a tela e mostra erro, sem fingir encerramento', async () => {
  const h = await runPage(api((url, init) => (url.endsWith('/end') ? netErr()
    : init.method === 'POST' ? json({ state: 'conectado', viewerUrl: VIEWER }) : json({ state: 'conectado', viewerUrl: VIEWER }))));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  h.store['#btn-remote-disconnect'].handlers.click();
  await settle();
  assert.equal(remoteState(h), 'erro');
  assert.equal(frameSrc(h), 'about:blank');
  assert.match(h.store['#remote-state-text'].textContent, /Não foi possível conectar|Não foi possível alcançar/);
});

test('queda da conexão tenta de novo com limite e depois mostra erro', async () => {
  let fail = false;
  const h = await runPage(api((url, init) => {
    if (init.method === 'POST') return json({ state: 'conectado', viewerUrl: VIEWER });
    return fail ? netErr() : json({ state: 'conectado', viewerUrl: VIEWER });
  }));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  fail = true;
  await h.poll();
  assert.equal(remoteState(h), 'conectando');
  assert.match(h.store['#remote-state-text'].textContent, /1 de 3/);
  await h.poll();
  assert.match(h.store['#remote-state-text'].textContent, /2 de 3/);
  await h.poll();
  assert.match(h.store['#remote-state-text'].textContent, /3 de 3/);
  await h.poll();
  assert.equal(remoteState(h), 'erro');
  assert.equal(frameSrc(h), 'about:blank');
});

test('a API informar encerrado derruba a tela e oferece nova tentativa', async () => {
  let state = 'conectado';
  const h = await runPage(api((url, init) => (init.method === 'POST'
    ? json({ state: 'conectado', viewerUrl: VIEWER })
    : json({ state, viewerUrl: state === 'conectado' ? VIEWER : undefined, message: 'A execução do servidor terminou.' }))));
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  state = 'encerrado';
  await h.poll();
  assert.equal(remoteState(h), 'encerrado');
  assert.equal(frameSrc(h), 'about:blank');
  assert.equal(h.store['#btn-remote-connect'].textContent, 'Tentar de novo');
  assert.equal(h.store['#btn-remote-connect'].hidden, false);
});

test('demonstração não permite conectar e não chama a API remota', async () => {
  const h = await runPage(api(() => json({ state: 'conectado', viewerUrl: VIEWER })));
  h.store['#btn-diag-demo'].handlers.click();
  await settle();
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(remoteCalls(h, 'POST').length, 0);
  assert.equal(h.store['#btn-remote-connect'].disabled, true);
  assert.match(h.store['#remote-msg'].textContent, /Demonstração ativa/);
});

test('API fora do ar desabilita conectar com aviso', async () => {
  const h = await runPage((url) => (url.endsWith('/api/health') ? netErr() : json({})));
  h.store['#btn-remote'].handlers.click();
  await settle();
  assert.equal(h.store['#btn-remote-connect'].disabled, true);
  assert.match(h.store['#remote-msg'].textContent, /API desconectada/);
  assert.equal(remoteCalls(h, 'POST').length, 0);
});

test('o menu mostra o estado real do PC remoto', async () => {
  const h = await runPage(api(() => json({ state: 'conectado', viewerUrl: VIEWER })));
  assert.equal(h.store['#remote-state'].textContent, 'Desconectado');
  h.store['#btn-remote-connect'].handlers.click();
  await settle();
  assert.equal(h.store['#remote-state'].textContent, 'Conectado');
  assert.equal(h.store['#remote-state'].dataset.tone, 'ok');
});
