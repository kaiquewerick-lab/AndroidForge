package com.serius.saturnia

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.webkit.JavascriptInterface
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

/**
 * Ponte entre o HTML (window.SaturnIANative) e o código nativo.
 *
 * Segurança:
 *  - Só expõe as funções listadas abaixo. Nenhuma delas recebe código, URL ou caminho de arquivo.
 *  - launch() só abre apps que já têm ícone na tela inicial (validado pelo PackageManager).
 *  - Nenhuma chave de API existe aqui: as chamadas de IA continuam no Worker.
 *  - A ponte é exposta à página. Veja README: a WebView só carrega a própria página
 *    (ou a URL configurada) e bloqueia navegação para outros sites.
 */
class SaturnBridge(private val activity: MainActivity) {

    companion object {
        private val ROBLOX_PLACE_RE = Regex("^roblox://placeId=\\d{1,20}$")
    }

    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false

    init {
        tts = TextToSpeech(activity) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("pt", "BR"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    fun shutdown() {
        ttsReady = false
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    // ----------------------------------------------------- serviço de voz

    /** Chamado pelo switch "Assistente de voz em segundo plano" quando o usuário liga. */
    @JavascriptInterface
    fun startVoiceService() {
        activity.runOnUiThread { activity.requestVoiceStart() }
    }

    /** Chamado quando o usuário desliga o switch. */
    @JavascriptInterface
    fun stopVoiceService() {
        VoiceService.stop(activity)
        VoiceState.set(VoiceState.STOPPED)
    }

    /** Estado atual: stopped, starting, running, interrupted, error, permission ou unavailable. */
    @JavascriptInterface
    fun getVoiceServiceState(): String = VoiceState.state

    @JavascriptInterface
    fun setWakePhrase(phrase: String) {
        VoicePrefs.setWake(activity, phrase)
    }

    // ----------------------------------------------------- respostas faladas

    /** Lê a resposta em voz alta (pt-BR). Sem efeito se o TTS não estiver pronto. */
    @JavascriptInterface
    fun speak(text: String) {
        val clean = text.trim().take(4000)
        if (clean.isEmpty()) return
        activity.runOnUiThread {
            if (ttsReady) {
                tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "saturnia-${System.nanoTime()}")
            }
        }
    }

    // ----------------------------------------------------- SaturnIA Bubble

    /** Chamado pelo switch "Balão flutuante" no HTML. Pede as permissões que faltarem. */
    @JavascriptInterface
    fun startBubble() {
        activity.runOnUiThread { activity.requestBubbleStart() }
    }

    @JavascriptInterface
    fun stopBubble() {
        BubbleService.stop(activity)
    }

    /** Estado do balão: stopped, running, no_overlay_permission, no_notification_permission, blocked ou error. */
    @JavascriptInterface
    fun getBubbleState(): String = BubbleState.state

    /** Token de sessão do Firebase (ou "" ao sair). Fica só na memória do processo. */
    @JavascriptInterface
    fun setAuthToken(token: String) {
        BubbleChat.setToken(token)
    }

    /** Chave própria do Gemini digitada no app ("" para remover). Fica só na memória do processo. */
    @JavascriptInterface
    fun setGeminiKey(key: String) {
        BubbleChat.setOwnKey(key)
    }

    /** Paleta do balão (JSON com name, bg, ink, mute, acc, glass). Fica salva no aparelho. */
    @JavascriptInterface
    fun setBubbleTheme(json: String) {
        BubbleTheme.apply(activity.applicationContext, json.take(2000))
    }

    /** Guia da SaturnIA (criador, funções, temas) para o balão responder perguntas. Só na memória. */
    @JavascriptInterface
    fun setBubbleContext(text: String) {
        GeminiClient.setAppContext(text)
    }

    /** Modelo Gemini escolhido pelo usuário no HTML (validado pelo padrão de nomes). */
    @JavascriptInterface
    fun setChatModel(model: String) {
        BubbleChat.setModel(model)
    }

    // ----------------------------------------------------- apps do aparelho

    /**
     * Lista os apps que podem ser abertos, como JSON:
     * [{"pkg":"...","name":"...","icon":null,"cat":"SOCIAL"}]
     */
    @JavascriptInterface
    fun listApps(): String = AppCatalog.installedJson(activity)

    /** Ícone do app como data URL PNG, ou "" se não houver. Carregado sob demanda. */
    @JavascriptInterface
    fun appIcon(pkg: String): String {
        if (pkg.isBlank() || pkg.length > 200) return ""
        return AppCatalog.iconDataUrl(activity, pkg) ?: ""
    }

    /**
     * Abre um jogo do Roblox pelo ID do lugar. Só aceita roblox://placeId=<número>:
     * qualquer outro endereço é recusado, então esta ponte não vira um abridor de links.
     */
    @JavascriptInterface
    fun openUri(uri: String): Boolean {
        if (!ROBLOX_PLACE_RE.matches(uri)) return false
        return try {
            activity.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: Exception) {
            false
        }
    }

    /** Abre um app pelo nome do pacote. Retorna false se não for possível. */
    @JavascriptInterface
    fun launch(pkg: String): Boolean {
        if (pkg.isBlank() || pkg.length > 200) return false
        val intent = activity.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ----------------------------------------------------- compartilhar
    // O WebView do Android não tem navigator.share: o HTML chama estas funções quando ele falta.

    /** Abre a folha de compartilhamento do Android com um texto. Retorna false se o texto estiver vazio. */
    @JavascriptInterface
    fun shareText(title: String, text: String): Boolean {
        val body = text.take(200_000)
        if (body.isBlank()) return false
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title.take(200))
            putExtra(Intent.EXTRA_TEXT, body)
        }
        return openChooser(send, title)
    }

    /**
     * Abre a folha de compartilhamento com um arquivo enviado em base64.
     * O arquivo fica numa pasta de cache própria, só leitura para o app que receber.
     */
    @JavascriptInterface
    fun shareFile(name: String, mime: String, base64: String): Boolean {
        if (base64.isEmpty() || base64.length > 16_000_000) return false
        val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "saturnia.bin" }
        val safeMime = if (Regex("^[a-z]+/[a-z0-9.+-]+$").matches(mime)) mime else "application/octet-stream"
        return try {
            val dir = File(activity.cacheDir, "share").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val file = File(dir, safeName)
            file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
            val uri = FileProvider.getUriForFile(activity, "${activity.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = safeMime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            openChooser(send, safeName)
        } catch (e: Exception) {
            false
        }
    }

    private fun openChooser(send: Intent, title: String): Boolean {
        activity.runOnUiThread {
            try {
                activity.startActivity(
                    Intent.createChooser(send, title.take(100)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: ActivityNotFoundException) {
                Toast.makeText(activity, "Nenhum app disponível para compartilhar.", Toast.LENGTH_SHORT).show()
            }
        }
        return true
    }
}
