package com.serius.saturnia

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Serviço de acessibilidade do SaturnIA Bubble, usado só para LER a tela.
 *
 * Só funciona depois que o usuário liga "SaturnIA Tela" em Acessibilidade.
 * Lê os textos e botões visíveis do app aberto, quando o usuário pede no balão.
 * Não clica, não digita, não rola e não lê campos de senha. Não grava nada em disco.
 */
class ScreenAccessService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Não reagimos a eventos: a leitura acontece só quando o usuário pede.
    }

    override fun onInterrupt() {}

    /**
     * Lista numerada da tela atual, uma linha por elemento útil. Devolve null se não há
     * janela disponível e texto vazio se a tela não tem nada legível.
     */
    fun snapshot(maxNodes: Int = MAX_NODES, maxChars: Int = MAX_CHARS): String? {
        val root = rootInActiveWindow ?: return null
        val out = StringBuilder()
        var count = 0
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && count < maxNodes && out.length < maxChars) {
            val node = queue.removeFirst()
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
            if (node.packageName == packageName) continue
            if (!node.isVisibleToUser || node.isPassword) continue
            val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .joinToString(" / ")
                .take(200)
            if (label.isEmpty()) continue
            val kind = when {
                node.isEditable -> "campo"
                node.isClickable -> "botão"
                else -> "texto"
            }
            out.append("- ").append(kind).append(": ").append(label).append('\n')
            count++
        }
        return out.toString()
    }

    companion object {
        private const val MAX_NODES = 150
        private const val MAX_CHARS = 6000

        /** Instância ativa do serviço. Null quando o usuário não ligou o recurso. */
        @Volatile
        var instance: ScreenAccessService? = null
            private set
    }
}
