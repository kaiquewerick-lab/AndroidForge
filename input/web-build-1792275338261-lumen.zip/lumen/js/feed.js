// Feed de publicações, curtidas, salvos, comentários, opções e compartilhamento.
import {
  state, myUid, me, $, $$, on, esc, timeAgo, avatar, verifiedBadge, nomeDe, isBlocked, podeVer, toast,
  openModal, closeModal, confirmar, notificar, toggleSeguir, userRow, abrirLista, apagarArquivo,
  ref, set, push, remove, onValue, db
} from './core.js';

let feedObs = null;
let unsubComentarios = null;
let comPost = null;
let replyTo = null;
let comCache = [];
let postAberto = null;

// Normaliza mídias (formato antigo era lista de strings)
export function midiasDe(p) {
  return (p.midias || []).map(x => typeof x === 'string'
    ? { url: x, tipo: p.tipoMidia === 'video' ? 'video' : 'imagem' } : x);
}

export function mediaHtml(p) {
  const m = midiasDe(p);
  if (!m.length) return '';
  const slides = m.map(x => x.tipo === 'video'
    ? `<div class="slide"><video src="${esc(x.url)}" muted loop playsinline preload="metadata" data-vid></video></div>`
    : `<div class="slide"><img src="${esc(x.url)}" loading="lazy" alt=""></div>`).join('');
  const extra = m.length > 1
    ? `<div class="dots">${m.map((_, i) => `<i class="${i ? '' : 'on'}"></i>`).join('')}</div><span class="counter">1/${m.length}</span>`
    : '';
  return `<div class="media" data-media="${p.id}"><div class="carousel" data-carousel>${slides}</div>${extra}</div>`;
}

export function postCard(p) {
  const uid = myUid();
  const u = state.users[p.uid] || { nome: p.autor, username: p.username, foto: p.autorFoto, verificado: p.verificado };
  const curtidas = p.curtidas || {};
  const n = Object.keys(curtidas).length;
  const curtiu = !!curtidas[uid];
  const salvo = !!(p.salvos || {})[uid];
  const nCom = Object.keys(p.comentarios || {}).length;
  return `
  <article class="card post" data-post="${p.id}">
    <header class="post-head">
      <div class="post-user" data-profile="${p.uid}">
        ${avatar(u, 'av-sm')}
        <div class="stack-xs">
          <strong>${esc(nomeDe(u) || p.autor)}${verifiedBadge(u.verificado)}</strong>
          ${p.local ? `<small>${esc(p.local)}</small>` : ''}
        </div>
      </div>
      <button class="icon-btn" data-opts="${p.id}" aria-label="Mais opções"><i class="fa-solid fa-ellipsis"></i></button>
    </header>
    ${mediaHtml(p)}
    <div class="post-actions">
      <div class="left">
        <button class="icon-btn ${curtiu ? 'liked' : ''}" data-like="${p.id}" aria-label="Curtir"><i class="fa-${curtiu ? 'solid' : 'regular'} fa-heart"></i></button>
        <button class="icon-btn" data-comments="${p.id}" aria-label="Comentar"><i class="fa-regular fa-comment"></i></button>
        <button class="icon-btn" data-share="${p.id}" aria-label="Compartilhar"><i class="fa-regular fa-paper-plane"></i></button>
      </div>
      <button class="icon-btn" data-save="${p.id}" aria-label="Salvar"><i class="fa-${salvo ? 'solid' : 'regular'} fa-bookmark"></i></button>
    </div>
    <div class="post-body">
      <p class="likes"><button class="link-btn" data-likes="${p.id}" style="color:inherit;padding:0">${n} ${n === 1 ? 'curtida' : 'curtidas'}</button></p>
      ${p.legenda ? `<p><strong>${esc(nomeDe(u) || p.autor)}</strong> ${esc(p.legenda)}</p>` : ''}
      <button class="link-btn muted" data-comments="${p.id}">${nCom ? `Ver os ${nCom} comentários` : 'Adicionar um comentário'}</button>
      ${p.musicaNome ? `<p class="music"><i class="fa-solid fa-music"></i> ${esc(p.musicaNome)}</p>` : ''}
      ${p.audioUrl ? `<div class="music-player"><audio id="aud-${p.id}" src="${esc(p.audioUrl)}" loop preload="none"></audio>
        <button class="btn-soft sm" data-audio="${p.id}"><i class="fa-solid fa-play"></i> Ouvir</button></div>` : ''}
      <small class="time">${timeAgo(p.timestamp)}</small>
    </div>
  </article>`;
}

// ---------- Feed ----------
export function initFeed() {
  feedObs = new IntersectionObserver(entries => entries.forEach(en => {
    const v = en.target;
    if (en.isIntersecting && en.intersectionRatio > 0.6) v.play().catch(() => {});
    else v.pause();
  }), { threshold: [0, 0.6] });

  on('posts', () => { renderFeed(); renderSugestoes(); if (postAberto) renderPostModal(); });
  on('following', () => { renderFeed(); renderSugestoes(); });
  on('users', () => renderSugestoes());
  on('blocked', renderFeed);
  on('me', renderFeed);

  for (const id of ['feed', 'post-root']) {
    const el = document.getElementById(id);
    el.addEventListener('click', onClick);
    el.addEventListener('scroll', onCarouselScroll, true);
  }
  $('#reply-cancel').addEventListener('click', () => setReply(null));
  $('#comment-list').addEventListener('click', onClickComentario);
  $('#form-comment').addEventListener('submit', enviarComentario);
  $('#modal-post').addEventListener('click', e => {
    if (e.target.id === 'modal-post') { postAberto = null; closeModal('modal-post'); }
  });
  $('#modal-comments').addEventListener('click', e => {
    if (e.target.id === 'modal-comments') fecharComentarios();
  });
  document.querySelectorAll('[data-close="modal-comments"]').forEach(b => b.addEventListener('click', fecharComentarios));
  document.querySelectorAll('[data-close="modal-post"]').forEach(b => b.addEventListener('click', () => { postAberto = null; }));
}

export function openFeed() { renderFeed(); renderSugestoes(); }

function feedPosts() {
  const uid = myUid();
  return state.posts.filter(p => p.tipo !== 'reel' && (p.uid === uid || state.following[p.uid]) && !isBlocked(p.uid));
}

function renderFeed() {
  if (!state.user) return;
  const box = $('#feed');
  if (!box) return;
  const lista = feedPosts();
  feedObs.disconnect();
  if (!lista.length) {
    box.innerHTML = `<div class="empty">
      <i class="fa-regular fa-images"></i>
      <h3>Bem-vindo ao Instagram</h3>
      <p>Siga pessoas para ver as publicações delas aqui, ou publique a sua primeira foto.</p>
      <button class="btn-primary sm" data-create>Criar publicação</button></div>`;
    return;
  }
  box.innerHTML = lista.map(postCard).join('');
  box.querySelectorAll('video[data-vid]').forEach(v => feedObs.observe(v));
}

// Sugestões de contas que o usuário ainda não segue
function renderSugestoes() {
  const box = $('#suggest-box');
  if (!box) return;
  const uid = myUid();
  const sugestoes = Object.values(state.users)
    .filter(u => u.uid !== uid && !state.following[u.uid] && !isBlocked(u.uid))
    .slice(0, 10);
  if (!sugestoes.length) { box.innerHTML = ''; return; }
  box.innerHTML = `<section class="suggest">
    <div class="suggest-head"><strong>Sugestões para você</strong><button class="link-btn" data-nav="search">Ver tudo</button></div>
    <div class="suggest-row">${sugestoes.map(u => `
      <div class="suggest-card">
        <div data-profile="${u.uid}" style="cursor:pointer">${avatar(u, 'av-lg')}</div>
        <div style="margin-top:8px;font-weight:700">${esc(u.username || u.nome)}${verifiedBadge(u.verificado)}</div>
        <small>${esc(u.nome || '')}</small>
        <button class="btn-primary" data-follow="${u.uid}">Seguir</button>
      </div>`).join('')}</div>
  </section>`;
}

// ---------- Carrossel e curtida por duplo toque ----------
function onCarouselScroll(e) {
  const c = e.target;
  if (!c.matches || !c.matches('[data-carousel]')) return;
  const media = c.closest('.media');
  const n = c.children.length;
  const idx = Math.round(c.scrollLeft / c.clientWidth);
  $$('.dots i', media).forEach((d, i) => d.classList.toggle('on', i === idx));
  const counter = media.querySelector('.counter');
  if (counter) counter.textContent = `${idx + 1}/${n}`;
}

let ultimoToque = { id: null, t: 0 };
function duploToque(media, e) {
  const id = media.dataset.media;
  const agora = Date.now();
  if (ultimoToque.id === id && agora - ultimoToque.t < 350) {
    ultimoToque = { id: null, t: 0 };
    toggleCurtir(id, true);
    const h = document.createElement('i');
    h.className = 'fa-solid fa-heart heart-pop';
    media.appendChild(h);
    setTimeout(() => h.remove(), 800);
  } else {
    ultimoToque = { id, t: agora };
  }
}

// ---------- Ações ----------
function onClick(e) {
  const t = e.target;
  let el;
  if ((el = t.closest('[data-like]'))) return toggleCurtir(el.dataset.like);
  if ((el = t.closest('[data-save]'))) return toggleSalvo(el.dataset.save);
  if ((el = t.closest('[data-comments]'))) return abrirComentarios(el.dataset.comments);
  if ((el = t.closest('[data-opts]'))) return abrirOpcoes(el.dataset.opts);
  if ((el = t.closest('[data-share]'))) return compartilhar(el.dataset.share);
  if ((el = t.closest('[data-likes]'))) return listarCurtidas(el.dataset.likes);
  if ((el = t.closest('[data-audio]'))) return alternarAudio(el);
  if ((el = t.closest('video[data-vid]'))) { el.muted = !el.muted; return; }
  if ((el = t.closest('[data-media]'))) return duploToque(el, e);
  if ((el = t.closest('[data-post-open]'))) return abrirPost(el.dataset.postOpen);
}

export async function toggleCurtir(postId, forcar = false) {
  const uid = myUid();
  const p = state.posts.find(x => x.id === postId);
  if (!p || !uid) return;
  const jaCurtiu = !!(p.curtidas || {})[uid];
  if (jaCurtiu && forcar) return;
  const r = ref(db, `posts/${postId}/curtidas/${uid}`);
  if (jaCurtiu) return remove(r);
  await set(r, true);
  notificar(p.uid, 'curtida', { postId });
}

async function toggleSalvo(postId) {
  const uid = myUid();
  const p = state.posts.find(x => x.id === postId);
  if (!p) return;
  const r = ref(db, `posts/${postId}/salvos/${uid}`);
  if ((p.salvos || {})[uid]) { await remove(r); toast('Removido dos salvos'); }
  else { await set(r, true); toast('Salvo nos seus itens salvos'); }
}

function alternarAudio(btn) {
  const aud = document.getElementById('aud-' + btn.dataset.audio);
  if (!aud) return;
  if (aud.paused) {
    document.querySelectorAll('audio').forEach(a => a.pause());
    aud.play().catch(() => {});
    btn.innerHTML = '<i class="fa-solid fa-pause"></i> Pausar';
  } else {
    aud.pause();
    btn.innerHTML = '<i class="fa-solid fa-play"></i> Ouvir';
  }
}

async function compartilhar(postId) {
  const url = `${location.origin}${location.pathname}#post-${postId}`;
  if (navigator.share) {
    try { await navigator.share({ title: 'Instagram', url }); } catch { /* cancelado */ }
  } else {
    try { await navigator.clipboard.writeText(url); toast('Link copiado'); }
    catch { toast('Não foi possível copiar o link'); }
  }
}

function listarCurtidas(postId) {
  const p = state.posts.find(x => x.id === postId);
  if (!p) return;
  abrirLista('Curtidas', Object.keys(p.curtidas || {}));
}

// ---------- Menu de opções ----------
function abrirOpcoes(postId) {
  const p = state.posts.find(x => x.id === postId);
  if (!p) return;
  const dono = p.uid === myUid();
  const seguindo = !!state.following[p.uid];
  const itens = dono
    ? [['Editar legenda', 'editar'], ['Copiar link', 'copiar'], ['Excluir publicação', 'excluir', 'danger']]
    : [['Copiar link', 'copiar'], [seguindo ? 'Deixar de seguir' : 'Seguir', 'seguir'],
       ['Denunciar', 'denunciar', 'danger'], ['Bloquear conta', 'bloquear', 'danger']];
  $('#opts-list').innerHTML = itens.map(([l, a, c]) =>
    `<button class="opt ${c || ''}" data-opt="${a}">${l}</button>`).join('') +
    `<button class="opt" data-close="modal-opts">Cancelar</button>`;
  $('#opts-list').onclick = ev => {
    const b = ev.target.closest('[data-opt]');
    if (!b) return;
    closeModal('modal-opts');
    executarOpcao(b.dataset.opt, p);
  };
  openModal('modal-opts');
}

async function executarOpcao(acao, p) {
  const uid = myUid();
  if (acao === 'copiar') return compartilhar(p.id);
  if (acao === 'editar') {
    const nova = prompt('Editar legenda', p.legenda || '');
    if (nova !== null) await set(ref(db, `posts/${p.id}/legenda`), nova.slice(0, 2200));
    return;
  }
  if (acao === 'excluir') {
    if (!(await confirmar('Excluir esta publicação? Essa ação não pode ser desfeita.'))) return;
    midiasDe(p).forEach(m => apagarArquivo(m.url));
    await remove(ref(db, `posts/${p.id}`));
    toast('Publicação excluída');
    return;
  }
  if (acao === 'seguir') return toggleSeguir(p.uid);
  if (acao === 'denunciar') {
    await set(push(ref(db, 'denuncias')), { postId: p.id, autorUid: p.uid, deUid: uid, timestamp: Date.now() });
    return toast('Denúncia enviada. Obrigado por ajudar.');
  }
  if (acao === 'bloquear') {
    if (!(await confirmar(`Bloquear ${nomeDe(state.users[p.uid]) || 'esta conta'}? Ela deixará de aparecer para você.`))) return;
    await set(ref(db, `bloqueados/${uid}/${p.uid}`), true);
    await remove(ref(db, `seguindo/${uid}/${p.uid}`));
    await remove(ref(db, `seguidores/${uid}/${p.uid}`));
    toast('Conta bloqueada');
  }
}

// ---------- Publicação individual ----------
export function abrirPost(postId) {
  const p = state.posts.find(x => x.id === postId);
  if (!p) return toast('Publicação não encontrada');
  postAberto = postId;
  renderPostModal();
  openModal('modal-post');
}

function renderPostModal() {
  const p = state.posts.find(x => x.id === postAberto);
  if (!p) { closeModal('modal-post'); postAberto = null; return; }
  $('#post-root').innerHTML = `<div style="padding:0">${postCard(p)}</div>`;
}

// ---------- Comentários ----------
export function abrirComentarios(postId) {
  comPost = postId;
  setReply(null);
  openModal('modal-comments');
  if (unsubComentarios) unsubComentarios();
  unsubComentarios = onValue(ref(db, `posts/${postId}/comentarios`), s => renderComentarios(s.val() || {}));
}

function fecharComentarios() {
  if (unsubComentarios) unsubComentarios();
  unsubComentarios = null;
  comPost = null;
  closeModal('modal-comments');
}

function renderComentarios(obj) {
  const box = $('#comment-list');
  comCache = Object.entries(obj).map(([id, c]) => ({ id, ...c })).sort((a, b) => a.timestamp - b.timestamp);
  if (!comCache.length) {
    box.innerHTML = '<p class="empty-sm">Nenhum comentário ainda. Seja o primeiro!</p>';
    return;
  }
  const post = state.posts.find(p => p.id === comPost);
  const tops = comCache.filter(c => !c.replyToId);
  const replies = comCache.filter(c => c.replyToId);
  const orfas = replies.filter(r => !tops.some(t => t.id === r.replyToId));
  box.innerHTML = tops.map(c => itemComentario(c, post) +
    replies.filter(r => r.replyToId === c.id).map(r => itemComentario(r, post, true)).join('')
  ).join('') + orfas.map(r => itemComentario(r, post, true)).join('');
}

function itemComentario(c, post, reply = false) {
  const uid = myUid();
  const u = state.users[c.autorUid] || { nome: c.autor, username: c.autor };
  const curtidas = c.curtidas || {};
  const n = Object.keys(curtidas).length;
  const liked = !!curtidas[uid];
  const podeApagar = c.autorUid === uid || post?.uid === uid;
  return `<div class="cmt ${reply ? 'reply' : ''}">
    <div data-profile="${c.autorUid}" style="cursor:pointer">${avatar(u, 'av-xs')}</div>
    <div class="cmt-body">
      <p><strong>${esc(u.username || c.autor)}</strong>${verifiedBadge(u.verificado)} ${esc(c.texto)}</p>
      <small>${timeAgo(c.timestamp)}${n ? ` · ${n} curtida${n > 1 ? 's' : ''}` : ''}
        · <button class="link-btn" data-reply="${c.id}" data-rname="${esc(u.username || c.autor)}">Responder</button>
        ${podeApagar ? ` · <button class="link-btn danger-t" data-delcom="${c.id}">Excluir</button>` : ''}</small>
    </div>
    <button class="icon-btn sm ${liked ? 'liked' : ''}" data-likecom="${c.id}" aria-label="Curtir comentário">
      <i class="fa-${liked ? 'solid' : 'regular'} fa-heart"></i></button>
  </div>`;
}

function onClickComentario(e) {
  let el;
  if ((el = e.target.closest('[data-reply]'))) return setReply(el.dataset.reply, el.dataset.rname);
  if ((el = e.target.closest('[data-delcom]'))) return apagarComentario(el.dataset.delcom);
  if ((el = e.target.closest('[data-likecom]'))) return curtirComentario(el.dataset.likecom);
}

function setReply(id, nome) {
  if (!id) {
    replyTo = null;
    $('#reply-banner').classList.add('hidden');
    return;
  }
  // Respostas sempre apontam para o comentário principal da conversa
  const c = comCache.find(x => x.id === id);
  replyTo = { id: c?.replyToId || id, nome };
  $('#reply-text').textContent = `Respondendo a @${nome}`;
  $('#reply-banner').classList.remove('hidden');
  $('#comment-input').focus();
}

async function enviarComentario(e) {
  e.preventDefault();
  const input = $('#comment-input');
  const texto = input.value.trim();
  const uid = myUid();
  if (!texto || !comPost || !uid) return;
  const post = state.posts.find(p => p.id === comPost);
  await set(push(ref(db, `posts/${comPost}/comentarios`)), {
    autorUid: uid,
    autor: me().username || me().nome || 'usuário',
    texto: texto.slice(0, 500),
    replyToId: replyTo?.id || '',
    replyToAutor: replyTo?.nome || '',
    timestamp: Date.now()
  });
  if (post && post.uid !== uid) notificar(post.uid, 'comentario', { postId: comPost, texto: texto.slice(0, 80) });
  input.value = '';
  setReply(null);
}

async function apagarComentario(id) {
  if (!(await confirmar('Excluir este comentário?'))) return;
  await remove(ref(db, `posts/${comPost}/comentarios/${id}`));
  toast('Comentário excluído');
}

async function curtirComentario(id) {
  const uid = myUid();
  const c = comCache.find(x => x.id === id);
  if (!c) return;
  const r = ref(db, `posts/${comPost}/comentarios/${id}/curtidas/${uid}`);
  if ((c.curtidas || {})[uid]) await remove(r);
  else await set(r, true);
}

// Exposto para outros módulos (ex.: perfil e reels)
export { toggleCurtir as curtirPost, toggleSalvo as salvarPost, compartilhar, abrirOpcoes, abrirComentarios as comentariosDe };
