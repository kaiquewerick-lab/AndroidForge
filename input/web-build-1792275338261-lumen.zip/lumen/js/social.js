// Pesquisa/Explorar, Notificações, Perfil e Editar perfil.
import {
  state, myUid, me, $, $$, on, esc, timeAgo, avatar, verifiedBadge, nomeDe, isBlocked, podeVer,
  toast, openModal, closeModal, go, abrirLista, userRow, compressImage, uploadArquivo, toggleSeguir,
  ref, get, set, remove, runTransaction, db, auth, update
} from './core.js';
import { updateProfile } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { abrirPost, midiasDe } from './feed.js';
import { storiesDe, openStoriesOf } from './stories.js';
import { trocarSenha } from './auth.js';

let profUid = null;
let profTab = 'posts';
let relacoesExtra = { seguindo: {}, seguidores: {} };
let novaFoto = null;      // blob da nova foto de perfil (edição)
let fotoPreviewUrl = null;

const ativa = id => $('#view-' + id).classList.contains('active');
const LIMITE_EXPLORAR = 60;

// ---------- Inicialização ----------
export function initSocial() {
  $('#search-input').addEventListener('input', e => renderBusca(e.target.value));

  $('#notifs-root').addEventListener('click', onNotifClick);
  $('#profile-root').addEventListener('click', onProfileClick);
  $('#search-results').addEventListener('click', onPesquisaClick);

  $('#form-edit').addEventListener('submit', salvarPerfil);
  $('#edit-foto').addEventListener('change', e => {
    const f = e.target.files[0];
    if (!f) return;
    compressImage(f, 400, 0.85).then(blob => {
      novaFoto = blob;
      if (fotoPreviewUrl) URL.revokeObjectURL(fotoPreviewUrl);
      fotoPreviewUrl = URL.createObjectURL(blob);
      $('#edit-foto-prev').innerHTML = `<span class="av av-xl"><img src="${fotoPreviewUrl}" alt=""></span>`;
    }).catch(() => toast('Não foi possível usar esta imagem.'));
  });

  on('posts', refrescarAtivas);
  on('users', refrescarAtivas);
  on('following', refrescarAtivas);
  on('followers', refrescarAtivas);
  on('blocked', refrescarAtivas);
  on('notifs', () => { if (ativa('notifs')) renderNotifs(); });
  on('me', refrescarAtivas);
}

function refrescarAtivas() {
  if (!state.user) return;
  if (ativa('search') && !$('#search-input').value.trim()) renderExplorar();
  else if (ativa('search')) renderBusca($('#search-input').value);
  if (ativa('notifs')) renderNotifs();
  if (ativa('profile')) renderProfile(profUid || myUid());
}

// ---------- Roteamento ----------
export function openSocial(view, params = {}) {
  if (view === 'search') {
    $('#search-input').value = '';
    renderExplorar();
  } else if (view === 'notifs') {
    renderNotifs();
  } else if (view === 'profile') {
    const uid = params.uid || myUid();
    if (uid !== profUid) profTab = 'posts';
    renderProfile(uid);
  }
}

// ---------- Explorar e busca ----------
function publicasVisiveis() {
  return state.posts.filter(p => podeVer(p.uid) && !isBlocked(p.uid));
}

function renderExplorar() {
  const box = $('#search-results');
  const lista = publicasVisiveis().slice(0, LIMITE_EXPLORAR);
  box.innerHTML = lista.length
    ? `<div class="section-title">Explorar</div>${gradeHtml(lista)}`
    : '<p class="empty-sm">Ainda não há publicações para explorar.</p>';
}

function renderBusca(termo) {
  const box = $('#search-results');
  const t = termo.trim().toLowerCase();
  if (!t) return renderExplorar();

  const uid = myUid();
  if (t.startsWith('#')) {
    const tag = t.slice(1);
    const posts = publicasVisiveis().filter(p => (p.legenda || '').toLowerCase().includes('#' + tag));
    box.innerHTML = posts.length
      ? `<div class="section-title">#${esc(tag)}</div>${gradeHtml(posts)}`
      : '<p class="empty-sm">Nenhuma publicação com essa hashtag.</p>';
    return;
  }

  const pessoas = Object.values(state.users)
    .filter(u => u.uid !== uid && !isBlocked(u.uid) &&
      ((u.username || '').toLowerCase().includes(t) || (u.nome || '').toLowerCase().includes(t)))
    .slice(0, 20);
  const posts = publicasVisiveis().filter(p => (p.legenda || '').toLowerCase().includes(t)).slice(0, 30);

  box.innerHTML = `
    <div class="section-title">Contas</div>
    <div style="padding:0 6px">${pessoas.map(u => userRow(u)).join('') || '<p class="empty-sm">Nenhuma conta encontrada.</p>'}</div>
    ${posts.length ? `<div class="section-title">Publicações</div>${gradeHtml(posts)}` : ''}`;
}

function gradeHtml(lista) {
  return `<div class="explore">${lista.map(p => {
    const m = midiasDe(p)[0] || {};
    const multi = midiasDe(p).length > 1 ? '<i class="fa-solid fa-clone multi"></i>' : '';
    const thumb = m.tipo === 'video'
      ? `<video src="${esc(m.url)}" muted preload="metadata"></video>`
      : `<img src="${esc(m.url || '')}" loading="lazy" alt="">`;
    const curtidas = Object.keys(p.curtidas || {}).length;
    const coment = Object.keys(p.comentarios || {}).length;
    return `<div class="thumb" data-post-open="${p.id}">${thumb}${multi}
      <div class="ov"><span><i class="fa-solid fa-heart"></i> ${curtidas}</span><span><i class="fa-solid fa-comment"></i> ${coment}</span></div>
    </div>`;
  }).join('')}</div>`;
}

function onPesquisaClick(e) {
  const el = e.target.closest('[data-post-open]');
  if (el) abrirPost(el.dataset.postOpen);
}

// ---------- Notificações ----------
function prefsNotif() {
  try {
    return { curtida: true, comentario: true, seguir: true, mensagem: true,
      ...JSON.parse(localStorage.getItem('lumen_notif') || '{}') };
  } catch { return { curtida: true, comentario: true, seguir: true, mensagem: true }; }
}

function renderNotifs() {
  const box = $('#notifs-root');
  const prefs = prefsNotif();
  const lista = state.notifs.filter(n => prefs[n.tipo] !== false);
  if (!lista.length) {
    box.innerHTML = `<h2 class="view-title">Notificações</h2><div class="empty"><i class="fa-regular fa-heart"></i>
      <p>Quando alguém curtir, comentar ou seguir você, verá aqui.</p></div>`;
    return;
  }
  const novas = lista.filter(n => !n.lida);
  const antigas = lista.filter(n => n.lida);
  const item = n => {
    const u = state.users[n.deUid] || { nome: n.deNome, username: n.deUser, foto: n.deFoto };
    const frase = {
      curtida: 'curtiu sua publicação.',
      comentario: `comentou: ${esc(n.texto || '')}`,
      seguir: 'começou a seguir você.',
      mensagem: 'enviou uma mensagem.',
    }[n.tipo] || 'interagiu com você.';
    const seguindo = !!state.following[n.deUid];
    const botao = n.tipo === 'seguir' && !seguindo
      ? `<button class="btn-primary sm" data-follow="${n.deUid}">Seguir</button>` : '';
    return `<div class="notif ${n.lida ? '' : 'unread'}" data-notif="${n.id}" data-ntipo="${n.tipo}" data-npost="${n.postId || ''}" data-nuid="${n.deUid || ''}">
      ${avatar(u, 'av-md')}
      <div class="txt"><strong>${esc(u.username || u.nome || 'Alguém')}</strong> ${frase}
        <small>${timeAgo(n.timestamp)}</small></div>
      ${botao}
    </div>`;
  };
  box.innerHTML = `<h2 class="view-title">Notificações</h2>
    ${novas.length ? `<div class="notif-sec">Novas</div>${novas.map(item).join('')}` : ''}
    ${antigas.length ? `<div class="notif-sec">Anteriores</div>${antigas.map(item).join('')}` : ''}`;

  // Marca como lidas depois de um breve instante na tela
  const ids = novas.map(n => n.id);
  if (ids.length) setTimeout(() => {
    if (!ativa('notifs')) return;
    const up = {};
    ids.forEach(id => up[`notificacoes/${myUid()}/${id}/lida`] = true);
    update(ref(db), up).catch(() => {});
  }, 1500);
}

function onNotifClick(e) {
  if (e.target.closest('[data-follow]')) return;
  const el = e.target.closest('[data-notif]');
  if (!el) return;
  if (el.dataset.npost) return abrirPost(el.dataset.npost);
  if (el.dataset.nuid) return go('profile', { uid: el.dataset.nuid });
}

// ---------- Perfil ----------
async function carregarRelacoes(uid) {
  const [seg, seguidores] = await Promise.all([
    get(ref(db, `seguindo/${uid}`)), get(ref(db, `seguidores/${uid}`))
  ]);
  return { seguindo: seg.val() || {}, seguidores: seguidores.val() || {} };
}

async function renderProfile(uid) {
  profUid = uid;
  const root = $('#profile-root');
  const own = uid === myUid();
  const base = state.users[uid];
  if (!own && !base) {
    root.innerHTML = '<div class="empty"><i class="fa-regular fa-circle-question"></i><h3>Conta não encontrada</h3></div>';
    return;
  }
  const u = own ? { uid, ...state.me } : { uid, ...base };
  relacoesExtra = own
    ? { seguindo: state.following, seguidores: state.followers }
    : await carregarRelacoes(uid);
  if (profUid !== uid) return; // navegou para outro perfil enquanto carregava

  const posts = state.posts.filter(p => p.uid === uid && p.tipo !== 'reel');
  const reels = state.posts.filter(p => p.uid === uid && p.tipo === 'reel');
  const salvos = own ? state.posts.filter(p => (p.salvos || {})[uid]) : [];
  const seguindo = !!state.following[uid];
  const pode = podeVer(uid);
  const bloqueado = isBlocked(uid);
  const stories = storiesDe(uid);

  const botoes = own
    ? `<button class="btn-soft" id="btn-edit">Editar perfil</button>
       <button class="btn-soft" id="btn-compartilhar-perfil">Compartilhar perfil</button>`
    : bloqueado
      ? `<button class="btn-soft" data-desbloquear="${uid}">Desbloquear</button>`
      : `<button class="${seguindo ? 'btn-soft' : 'btn-primary'}" data-follow="${uid}">${seguindo ? 'Seguindo' : 'Seguir'}</button>
         <button class="btn-soft" data-msg="${uid}">Mensagem</button>`;

  const abas = own
    ? [['posts', 'fa-solid fa-table-cells'], ['reels', 'fa-solid fa-clapperboard'], ['saved', 'fa-regular fa-bookmark']]
    : [['posts', 'fa-solid fa-table-cells'], ['reels', 'fa-solid fa-clapperboard']];
  if (!abas.some(([k]) => k === profTab)) profTab = 'posts';

  const conteudo = (() => {
    if (!own && bloqueado) return `<div class="private-note"><i class="fa-solid fa-ban"></i>Você bloqueou esta conta.</div>`;
    if (!pode) return `<div class="private-note"><i class="fa-solid fa-lock"></i><h3 style="color:var(--text)">Esta conta é privada</h3>
      <p>Siga esta conta para ver as publicações dela.</p></div>`;
    const lista = profTab === 'reels' ? reels : profTab === 'saved' ? salvos : posts;
    if (!lista.length) return `<div class="empty"><i class="fa-regular fa-image"></i>
      <p>${profTab === 'saved' ? 'Nenhuma publicação salva ainda.' : own ? 'Compartilhe fotos e vídeos para aparecerem aqui.' : 'Ainda não há nada por aqui.'}</p></div>`;
    return gradePerfil(lista);
  })();

  root.innerHTML = `
    <div class="profile-head">
      <div class="profile-top">
        <div data-story-of-own="${uid}" style="cursor:${stories.length ? 'pointer' : 'default'}">
          ${stories.length ? `<span class="ring"><span style="display:block;border:3px solid var(--surface);border-radius:50%">${avatar(u, 'av-xl')}</span></span>` : avatar(u, 'av-xl')}
        </div>
        <div class="stats">
          <div><strong>${posts.length}</strong><small>publicações</small></div>
          <div data-lista="seguidores"><strong>${Object.keys(relacoesExtra.seguidores).length}</strong><small>seguidores</small></div>
          <div data-lista="seguindo"><strong>${Object.keys(relacoesExtra.seguindo).length}</strong><small>seguindo</small></div>
        </div>
      </div>
      <div>
        <div class="profile-name">${esc(u.nome || u.username || '')} ${verifiedBadge(u.verificado)}</div>
        <small>@${esc(u.username || '')}${u.privado ? ' · <i class="fa-solid fa-lock"></i> Conta privada' : ''}</small>
        ${u.bio ? `<p class="bio" style="margin-top:6px">${esc(u.bio)}</p>` : ''}
      </div>
      <div class="profile-btns">${botoes}</div>
    </div>
    <div class="ptabs">${abas.map(([k, ic]) => `<button data-ptab="${k}" class="${profTab === k ? 'active' : ''}"><i class="${ic}"></i></button>`).join('')}</div>
    <div id="prof-conteudo">${conteudo}</div>`;
}

function gradePerfil(lista) {
  return `<div class="explore" style="padding:2px 0 0">${lista.map(p => {
    const m = midiasDe(p)[0] || {};
    const multi = midiasDe(p).length > 1 ? '<i class="fa-solid fa-clone multi"></i>' : '';
    const thumb = m.tipo === 'video'
      ? `<video src="${esc(m.url)}" muted preload="metadata"></video>`
      : `<img src="${esc(m.url || '')}" loading="lazy" alt="">`;
    const cur = Object.keys(p.curtidas || {}).length;
    const com = Object.keys(p.comentarios || {}).length;
    return `<div class="thumb" data-post-open="${p.id}">${thumb}${multi}
      <div class="ov"><span><i class="fa-solid fa-heart"></i> ${cur}</span><span><i class="fa-solid fa-comment"></i> ${com}</span></div></div>`;
  }).join('')}</div>`;
}

function onProfileClick(e) {
  const t = e.target;
  let el;
  if ((el = t.closest('[data-ptab]'))) { profTab = el.dataset.ptab; return renderProfile(profUid); }
  if ((el = t.closest('[data-lista]'))) {
    const tipo = el.dataset.lista;
    const uids = Object.keys(tipo === 'seguidores' ? relacoesExtra.seguidores : relacoesExtra.seguindo);
    return abrirLista(tipo === 'seguidores' ? 'Seguidores' : 'Seguindo', uids);
  }
  if ((el = t.closest('[data-post-open]'))) return abrirPost(el.dataset.postOpen);
  if ((el = t.closest('[data-story-of-own]'))) return openStoriesOf(el.dataset.storyOfOwn);
  if ((el = t.closest('[data-msg]'))) return go('direct', { uid: el.dataset.msg });
  if ((el = t.closest('[data-desbloquear]'))) return desbloquear(el.dataset.desbloquear);
  if (t.closest('#btn-edit')) return abrirEditar();
  if (t.closest('#btn-compartilhar-perfil')) {
    const url = `${location.origin}${location.pathname}#profile-${profUid}`;
    if (navigator.share) navigator.share({ title: 'Instagram', url }).catch(() => {});
    else navigator.clipboard?.writeText(url).then(() => toast('Link do perfil copiado')).catch(() => {});
  }
}

async function desbloquear(uid) {
  await remove(ref(db, `bloqueados/${myUid()}/${uid}`));
  toast('Conta desbloqueada');
}

// ---------- Editar perfil ----------
export function abrirEditar() {
  const p = me();
  $('#edit-nome').value = p.nome || '';
  $('#edit-user').value = p.username || '';
  $('#edit-bio').value = p.bio || '';
  novaFoto = null;
  $('#edit-foto-prev').innerHTML = avatar(p, 'av-xl');
  openModal('modal-edit');
}

async function salvarPerfil(e) {
  e.preventDefault();
  const uid = myUid();
  const nome = $('#edit-nome').value.trim();
  const username = $('#edit-user').value.trim().toLowerCase();
  const bio = $('#edit-bio').value.trim().slice(0, 150);
  if (!/^[a-z0-9._]{3,24}$/.test(username)) return toast('Usuário: de 3 a 24 caracteres (letras, números, . e _).');
  const antigo = me().username || '';
  try {
    if (username !== antigo) {
      const res = await runTransaction(ref(db, 'usernames/' + username), cur => cur ? undefined : uid);
      if (!res.committed) return toast('Esse nome de usuário já está em uso.');
      if (antigo) await remove(ref(db, 'usernames/' + antigo));
    }
    const dados = { nome, username, bio };
    if (novaFoto) dados.foto = await uploadArquivo(`avatars/${uid}_${Date.now()}.jpg`, novaFoto);
    await update(ref(db, 'usuarios/' + uid), dados);
    await updateProfile(auth.currentUser, { displayName: nome, ...(dados.foto ? { photoURL: dados.foto } : {}) });
    novaFoto = null;
    closeModal('modal-edit');
    toast('Perfil atualizado');
  } catch (err) {
    console.error(err);
    toast('Não foi possível salvar. Tente novamente.');
  }
}

export { trocarSenha, toggleSeguir };
