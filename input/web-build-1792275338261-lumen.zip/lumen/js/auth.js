// Login, cadastro, recuperação de senha e controle de sessão.
import { auth, db, ref, set, get, runTransaction, $, $$, toast, myUid } from './core.js';
import { ALLOWED_EMAILS } from './config.js';
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, updateProfile,
  sendPasswordResetEmail, onAuthStateChanged, deleteUser
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

const ERROS = {
  'auth/email-already-in-use': 'Este e-mail já está cadastrado.',
  'auth/invalid-email': 'E-mail inválido.',
  'auth/weak-password': 'A senha deve ter pelo menos 6 caracteres.',
  'auth/invalid-credential': 'E-mail ou senha incorretos.',
  'auth/wrong-password': 'E-mail ou senha incorretos.',
  'auth/user-not-found': 'E-mail ou senha incorretos.',
  'auth/too-many-requests': 'Muitas tentativas. Aguarde um pouco.',
  'auth/network-request-failed': 'Sem conexão com a internet.',
  'auth/operation-not-allowed': 'Ative o login por e-mail/senha no console do Firebase.'
};
const msgErro = e => ERROS[e.code] || 'Algo deu errado. Tente novamente.';

let emCadastro = false;

function trocarCartao(nome) {
  ['login', 'cadastro', 'reset'].forEach(c => $('#card-' + c).classList.toggle('hidden', c !== nome));
}

export function initAuth(onChange) {
  $$('#auth [data-go]').forEach(b => b.onclick = () => trocarCartao(b.dataset.go));
  $('#form-login').addEventListener('submit', entrar);
  $('#form-cadastro').addEventListener('submit', cadastrar);
  $('#form-reset').addEventListener('submit', recuperar);
  onAuthStateChanged(auth, async user => {
    if (emCadastro) return;
    if (user && !ALLOWED_EMAILS.includes((user.email || '').toLowerCase())) {
      await signOut(auth);
      toast('Esta conta não tem acesso ao Instagram.');
      return onChange(null);
    }
    if (user) await garantirPerfil(user);
    onChange(user);
  });
}

// Cria o perfil no banco caso ainda não exista (contas antigas, por exemplo)
async function garantirPerfil(user) {
  const r = ref(db, 'usuarios/' + user.uid);
  const snap = await get(r);
  if (snap.exists()) return;
  const username = (user.email || 'usuario').split('@')[0].toLowerCase().replace(/[^a-z0-9._]/g, '').slice(0, 24) || 'usuario';
  await set(r, {
    uid: user.uid, nome: user.displayName || username, username, email: user.email || '',
    foto: '', bio: '', privado: false, verificado: false, online: true, criadoEm: Date.now()
  });
  await set(ref(db, 'usernames/' + username), user.uid).catch(() => {});
}

async function entrar(e) {
  e.preventDefault();
  try {
    await signInWithEmailAndPassword(auth, $('#login-email').value.trim(), $('#login-senha').value);
  } catch (err) { toast(msgErro(err)); }
}

async function cadastrar(e) {
  e.preventDefault();
  const email = $('#cad-email').value.trim();
  const nome = $('#cad-nome').value.trim();
  const username = $('#cad-user').value.trim().toLowerCase();
  const senha = $('#cad-senha').value;
  if (!/^[a-z0-9._]{3,24}$/.test(username)) return toast('Usuário: de 3 a 24 caracteres (letras, números, . e _).');
  if (senha !== $('#cad-confirmar').value) return toast('As senhas não coincidem.');
  emCadastro = true; // evita abrir o app no meio do cadastro
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, senha);
    const uid = cred.user.uid;
    // Reserva o nome de usuário de forma atômica; se já existir, desfaz o cadastro.
    const res = await runTransaction(ref(db, 'usernames/' + username), cur => cur ? undefined : uid);
    if (!res.committed) {
      await deleteUser(cred.user);
      emCadastro = false;
      return toast('Esse nome de usuário já está em uso.');
    }
    await updateProfile(cred.user, { displayName: nome });
    await set(ref(db, 'usuarios/' + uid), {
      uid, nome, username, email, foto: '', bio: '', privado: false, verificado: false, online: true, criadoEm: Date.now()
    });
    await signOut(auth);
    emCadastro = false;
    $('#form-cadastro').reset();
    trocarCartao('login');
    toast('Conta criada! Faça login para continuar.');
  } catch (err) {
    emCadastro = false;
    toast(msgErro(err));
  }
}

async function recuperar(e) {
  e.preventDefault();
  try {
    await sendPasswordResetEmail(auth, $('#reset-email').value.trim());
    toast('Se o e-mail existir, enviamos o link de redefinição.');
    trocarCartao('login');
  } catch (err) { toast(msgErro(err)); }
}

export async function logout() {
  const uid = myUid();
  if (uid) await set(ref(db, `usuarios/${uid}/online`), false).catch(() => {});
  await signOut(auth);
  location.reload();
}

export async function trocarSenha() {
  const email = auth.currentUser?.email;
  if (!email) return;
  await sendPasswordResetEmail(auth, email);
  toast('Enviamos um link para redefinir sua senha no seu e-mail.');
}
