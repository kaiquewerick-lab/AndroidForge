// Configuração do Firebase do seu projeto.
// Para usar outro projeto, substitua estes valores pelos do seu console do Firebase
// (Configurações do projeto > Seus apps > SDK setup and configuration).
export const firebaseConfig = {
  apiKey: "AIzaSyAmvmtzA4ntB1wvktoKEv8oXz2RzV2XR1I",
  authDomain: "instagram-74816.firebaseapp.com",
  databaseURL: "https://instagram-74816-default-rtdb.firebaseio.com",
  projectId: "instagram-74816",
  storageBucket: "instagram-74816.firebasestorage.app",
  messagingSenderId: "362040152469",
  appId: "1:362040152469:web:8e36337100fe7344d2269c",
  measurementId: "G-GZG5H2DQ7N"
};

// Únicas contas autorizadas a usar o app (somente você e seu irmão).
export const ALLOWED_EMAILS = [
  "kaioeduardosousap@gmail.com",
  "kaiquewerick@gmail.com"
];
