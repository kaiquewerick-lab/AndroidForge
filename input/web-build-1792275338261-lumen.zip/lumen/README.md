# Instagram

Rede social privada de fotos, vídeos, reels e stories, com mensagens privadas e notificações em tempo real.
Feita com HTML, CSS e JavaScript puro (módulos ES), usando Firebase como backend.

## Funcionalidades

- **Autenticação**: cadastro com nome de usuário único, login, recuperação de senha, sair.
- **Início**: feed de quem você segue, carrossel de fotos, curtir (botão ou duplo toque), salvar, comentar, respostas e curtir comentários, excluir, sugestões de contas.
- **Publicar**: fotos e vídeos (até 10 por publicação), legenda, localização, música e áudio de fundo.
- **Reels**: vídeos verticais em tela cheia com reprodução automática ao rolar.
- **Stories**: publicação de fotos e vídeos, expiram em 24 h, barra de progresso, toque nas laterais para navegar, responder por mensagem, ver quem visualizou, excluir.
- **Pesquisar / Explorar**: grade de publicações, busca por contas, legendas e #hashtags.
- **Notificações**: curtidas, comentários, novos seguidores e mensagens, com marcação de lidas.
- **Mensagens diretas**: conversas em tempo real, nova conversa, apagar mensagem própria, apagar conversa, contador de não lidas.
- **Perfil**: foto, bio, estatísticas, seguidores e seguindo, abas de publicações, reels e salvos, editar perfil, seguir/deixar de seguir, bloquear.
- **Conta privada**: só seguidores veem publicações, reels e stories.
- **Publicação**: editar legenda, excluir, copiar link, denunciar, bloquear conta.
- **Configurações**: conta, privacidade, notificações, aparência (claro, escuro, sistema), salvos, contas bloqueadas, ajuda, sobre, sair.
- **Layout**: barra inferior no celular e barra lateral em telas grandes.

## Estrutura

```
lumen/
├─ index.html
├─ css/
│  ├─ style.css        # tema, layout e base
│  └─ components.css   # stories, posts, reels, modais, mensagens, configurações
├─ js/
│  ├─ config.js        # configuração do Firebase (edite aqui)
│  ├─ core.js          # Firebase, estado global, utilitários
│  ├─ app.js           # roteamento, sincronização em tempo real, eventos globais
│  ├─ auth.js          # login, cadastro, recuperação de senha
│  ├─ feed.js          # feed, curtidas, salvos, comentários, opções
│  ├─ stories.js       # barra e visualizador de stories
│  ├─ create.js        # criar publicação, reel e story
│  ├─ reels.js         # reels
│  ├─ social.js        # explorar, notificações, perfil, editar perfil
│  ├─ direct.js        # mensagens diretas
│  └─ settings.js      # configurações
├─ database.rules.json # regras do Realtime Database
└─ storage.rules       # regras do Storage
```

## Como executar

1. Crie um projeto no [Console do Firebase](https://console.firebase.google.com).
2. Ative **Authentication > Sign-in method > E-mail/senha**.
3. Crie o **Realtime Database** e o **Storage**.
4. Em *Configurações do projeto > Seus apps > Web*, copie a configuração e cole em `js/config.js`.
5. Publique as regras:
   - Realtime Database: conteúdo de `database.rules.json`.
   - Storage: conteúdo de `storage.rules`.
6. Sirva a pasta por HTTP (os módulos ES não funcionam abrindo o arquivo direto):
   ```bash
   npx serve lumen
   # ou
   python3 -m http.server 8080 --directory lumen
   ```
   Depois abra `http://localhost:8080`. Para o celular, use uma URL HTTPS (Firebase exige contexto seguro para algumas funções).

## Observações

- **Selo de verificação**: não há mais um botão para se auto-verificar. Para marcar uma conta como verificada, altere `verificado: true` em `usuarios/{uid}` pelo console do Firebase (uso administrativo).
- **Dados antigos**: contas criadas pela versão anterior recebem perfil automaticamente no primeiro login.
- **Limites**: vídeos até 60 MB, áudios até 5 MB, fotos são comprimidas para no máximo 1080 px.
- **Escalabilidade**: o app carrega todos os perfis e publicações em tempo real, o que é adequado para projetos pequenos e médios. Para milhares de usuários, convém paginar o feed.
- **Notificações push** (com o app fechado) não estão incluídas; as notificações aparecem enquanto o app está aberto.
- **Gemini / comentários automáticos** da versão anterior foram removidos: a IA publicava comentários e curtidas como se fossem pessoas reais, o que engana outros usuários.
- As regras de segurança são um ponto de partida. Revise-as antes de publicar.

## Acesso restrito

Somente as contas listadas em `ALLOWED_EMAILS` (`js/config.js`) entram no app, e as regras do
banco e do Storage (`database.rules.json` e `storage.rules`) repetem a mesma verificação.
Para trocar um e-mail, altere os dois arquivos. O cadastro público foi removido da tela de login:
crie as contas pelo console do Firebase em *Authentication > Usuários > Adicionar usuário*.
