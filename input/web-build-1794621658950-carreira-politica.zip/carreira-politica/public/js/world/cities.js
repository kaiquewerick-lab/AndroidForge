// Estados e cidades usados como origem do personagem.
// Lista inicial da Parte 1; novas cidades podem ser adicionadas aqui sem alterar outros módulos.
export const STATES = [
  { uf: 'AC', name: 'Acre', cities: ['Rio Branco', 'Cruzeiro do Sul'] },
  { uf: 'AL', name: 'Alagoas', cities: ['Maceió', 'Arapiraca'] },
  { uf: 'AP', name: 'Amapá', cities: ['Macapá', 'Santana'] },
  { uf: 'AM', name: 'Amazonas', cities: ['Manaus', 'Parintins'] },
  { uf: 'BA', name: 'Bahia', cities: ['Salvador', 'Feira de Santana'] },
  { uf: 'CE', name: 'Ceará', cities: ['Fortaleza', 'Juazeiro do Norte'] },
  { uf: 'DF', name: 'Distrito Federal', cities: ['Brasília', 'Taguatinga'] },
  { uf: 'ES', name: 'Espírito Santo', cities: ['Vitória', 'Vila Velha'] },
  { uf: 'GO', name: 'Goiás', cities: ['Goiânia', 'Anápolis'] },
  { uf: 'MA', name: 'Maranhão', cities: ['São Luís', 'Imperatriz'] },
  { uf: 'MT', name: 'Mato Grosso', cities: ['Cuiabá', 'Várzea Grande'] },
  { uf: 'MS', name: 'Mato Grosso do Sul', cities: ['Campo Grande', 'Dourados'] },
  { uf: 'MG', name: 'Minas Gerais', cities: ['Belo Horizonte', 'Uberlândia'] },
  { uf: 'PA', name: 'Pará', cities: ['Belém', 'Ananindeua'] },
  { uf: 'PB', name: 'Paraíba', cities: ['João Pessoa', 'Campina Grande'] },
  { uf: 'PR', name: 'Paraná', cities: ['Curitiba', 'Londrina'] },
  { uf: 'PE', name: 'Pernambuco', cities: ['Recife', 'Jaboatão dos Guararapes'] },
  { uf: 'PI', name: 'Piauí', cities: ['Teresina', 'Parnaíba'] },
  { uf: 'RJ', name: 'Rio de Janeiro', cities: ['Rio de Janeiro', 'Niterói'] },
  { uf: 'RN', name: 'Rio Grande do Norte', cities: ['Natal', 'Mossoró'] },
  { uf: 'RS', name: 'Rio Grande do Sul', cities: ['Porto Alegre', 'Caxias do Sul'] },
  { uf: 'RO', name: 'Rondônia', cities: ['Porto Velho', 'Ji-Paraná'] },
  { uf: 'RR', name: 'Roraima', cities: ['Boa Vista', 'Rorainópolis'] },
  { uf: 'SC', name: 'Santa Catarina', cities: ['Florianópolis', 'Joinville'] },
  { uf: 'SP', name: 'São Paulo', cities: ['São Paulo', 'Campinas'] },
  { uf: 'SE', name: 'Sergipe', cities: ['Aracaju', 'Lagarto'] },
  { uf: 'TO', name: 'Tocantins', cities: ['Palmas', 'Araguaína'] },
];

export const findState = (uf) => STATES.find((s) => s.uf === uf) || null;

export const cityExists = (uf, city) => {
  const st = findState(uf);
  return Boolean(st && st.cities.includes(city));
};
