// Cenas 2D do carregamento e logotipo da SaturnGames. Tudo em SVG, sem imagens externas.
const W = 480;
const H = 270;

const wrap = (defs, body) => `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMid slice" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><defs>${defs}</defs>${body}</svg>`;
const sky = (id, top, bottom) =>
  `<linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${top}"/><stop offset="1" stop-color="${bottom}"/></linearGradient>`;

export const SCENES = [
  { id: 'paisagem', name: 'Paisagem brasileira', svg: () => wrap(sky('g1', '#ffb36b', '#1f5f7a'),
    `<rect width="${W}" height="${H}" fill="url(#g1)"/><circle cx="360" cy="90" r="36" fill="#ffe7a3" opacity="0.9"/>` +
    `<path d="M0 180 Q80 120 160 170 T340 160 T480 150 V270 H0Z" fill="#2e6e4e"/><path d="M0 214 Q120 172 240 208 T480 202 V270 H0Z" fill="#1e4d37"/>`) },
  { id: 'cidade', name: 'Cidade brasileira', svg: () => wrap(sky('g2', '#7fb3d5', '#d6eaf8'),
    `<rect width="${W}" height="${H}" fill="url(#g2)"/>` +
    [[40, 110, 60], [110, 80, 70], [190, 130, 55], [255, 90, 80], [345, 120, 60], [415, 70, 70]]
      .map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="${H - y}" fill="#34495e"/>` +
        [0, 1, 2].map((r) => [0, 1].map((c) => `<rect x="${x + 10 + c * (w / 2 - 6)}" y="${y + 14 + r * 26}" width="10" height="12" fill="#f9e79f"/>`).join('')).join('')).join('') +
    `<rect y="240" width="${W}" height="30" fill="#2c3e50"/>`) },
  { id: 'brasilia', name: 'Brasília', svg: () => wrap(sky('g3', '#f5b041', '#5dade2'),
    `<rect width="${W}" height="${H}" fill="url(#g3)"/><circle cx="90" cy="70" r="26" fill="#fff3c4" opacity="0.8"/>` +
    `<rect y="190" width="${W}" height="80" fill="#2e7d4f"/>` +
    `<path d="M120 190 L120 150 Q240 110 360 150 L360 190 Z" fill="#ecf0f1"/>` +
    `<rect x="180" y="120" width="16" height="70" fill="#dfe6e9"/><rect x="284" y="120" width="16" height="70" fill="#dfe6e9"/>` +
    `<path d="M236 120 L240 96 L244 120 Z" fill="#c0392b"/><path d="M200 190 Q240 138 280 190 Z" fill="#bdc3c7"/>`) },
  { id: 'congresso', name: 'Congresso Nacional', svg: () => wrap(sky('g4', '#e8daef', '#5d6d7e'),
    `<rect width="${W}" height="${H}" fill="url(#g4)"/>` +
    `<rect x="60" y="180" width="360" height="30" fill="#d5d8dc"/>` +
    `<path d="M160 180 A80 60 0 0 1 320 180 Z" fill="#f4f6f7"/><path d="M170 180 A70 45 0 0 1 310 180 Z" fill="#aab7b8" opacity="0.5"/>` +
    `<rect x="225" y="80" width="30" height="100" fill="#ecf0f1"/>` +
    `<rect x="180" y="110" width="12" height="70" fill="#ecf0f1"/><rect x="288" y="110" width="12" height="70" fill="#ecf0f1"/>` +
    `<rect y="210" width="${W}" height="60" fill="#27ae60"/>`) },
  { id: 'palacio', name: 'Palácio governamental', svg: () => wrap(sky('g5', '#fad7a0', '#2c3e50'),
    `<rect width="${W}" height="${H}" fill="url(#g5)"/>` +
    `<rect x="110" y="120" width="260" height="110" fill="#f8f9f9"/><path d="M100 120 L240 70 L380 120 Z" fill="#e5e8e8"/>` +
    [0, 1, 2, 3, 4, 5].map((i) => `<rect x="${130 + i * 40}" y="136" width="10" height="94" fill="#bdc3c7"/>`).join('') +
    `<rect x="236" y="30" width="3" height="40" fill="#34495e"/><rect x="239" y="30" width="22" height="13" fill="#1e8449"/>` +
    `<rect y="230" width="${W}" height="40" fill="#1e8449" opacity="0.7"/>`) },
  { id: 'praca', name: 'Praça pública', svg: () => wrap(sky('g6', '#fdebd0', '#a9dfbf'),
    `<rect width="${W}" height="${H}" fill="url(#g6)"/>` +
    `<circle cx="60" cy="150" r="40" fill="#27ae60"/><circle cx="420" cy="150" r="46" fill="#229954"/>` +
    `<ellipse cx="240" cy="205" rx="120" ry="28" fill="#d7bde2"/><ellipse cx="240" cy="200" rx="90" ry="20" fill="#85c1e9"/>` +
    `<rect x="236" y="150" width="8" height="46" fill="#7f8c8d"/><path d="M240 150 Q210 130 200 160 M240 150 Q270 130 280 160" stroke="#48c9b0" stroke-width="6" fill="none"/>` +
    `<rect x="330" y="200" width="60" height="8" fill="#8d6e63"/><rect x="330" y="186" width="60" height="6" fill="#a1887f"/>`) },
  { id: 'campo', name: 'Campo e área rural', svg: () => wrap(sky('g7', '#f9e79f', '#7dcea0'),
    `<rect width="${W}" height="${H}" fill="url(#g7)"/><circle cx="410" cy="60" r="28" fill="#fdfefe" opacity="0.7"/>` +
    `<path d="M0 170 L480 170 L480 270 L0 270 Z" fill="#c9a23a"/>` +
    [0, 1, 2, 3, 4].map((i) => `<path d="M0 ${190 + i * 16} L480 ${190 + i * 16}" stroke="#8a6d1f" stroke-width="2" opacity="0.5"/>`).join('') +
    `<rect x="60" y="120" width="90" height="60" fill="#c0392b"/><path d="M50 122 L105 86 L160 122 Z" fill="#7b241c"/>` +
    `<rect x="80" y="150" width="20" height="30" fill="#fdfefe"/>`) },
  { id: 'urbano', name: 'Cenário urbano', svg: () => wrap(sky('g8', '#34495e', '#8e9eab'),
    `<rect width="${W}" height="${H}" fill="url(#g8)"/>` +
    `<rect x="0" y="0" width="${W}" height="150" fill="#2c3e50" opacity="0.6"/>` +
    [[20, 60, 90], [120, 40, 70], [300, 50, 80], [380, 30, 100]].map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="${H - y - 60}" fill="#5d6d7e"/>`).join('') +
    `<rect y="210" width="${W}" height="60" fill="#333"/>` +
    [60, 200, 340, 440].map((x) => `<line x1="${x}" y1="210" x2="${x}" y2="132" stroke="#1c2833" stroke-width="4"/><circle cx="${x}" cy="130" r="8" fill="#f9e79f"/>`).join('') +
    `<rect x="150" y="230" width="60" height="18" rx="6" fill="#e74c3c"/><circle cx="165" cy="250" r="6" fill="#111"/><circle cx="195" cy="250" r="6" fill="#111"/>`) },
  { id: 'eleicao', name: 'Eleições', svg: () => wrap(sky('g9', '#1f4e79', '#f4c542'),
    `<rect width="${W}" height="${H}" fill="url(#g9)"/>` +
    `<rect x="170" y="130" width="140" height="100" rx="6" fill="#8d6e63"/><rect x="170" y="130" width="140" height="18" fill="#6d4c41"/>` +
    `<rect x="210" y="150" width="60" height="6" fill="#2c1e16"/>` +
    `<rect x="230" y="60" width="50" height="62" fill="#fdfefe" transform="rotate(-6 255 90)"/>` +
    `<path d="M242 92 L252 104 L272 76" stroke="#1e8449" stroke-width="6" fill="none" transform="rotate(-6 255 90)"/>` +
    `<rect x="60" y="210" width="360" height="8" fill="#ffffff" opacity="0.4"/>`) },
];

export function sceneSvg(index) {
  return SCENES[index % SCENES.length].svg();
}

// Logotipo SaturnGames: planeta com anel, em SVG.
export function logoSvg({ cls = 'logo', label = 'Logotipo SaturnGames' } = {}) {
  return `<svg class="${cls}" viewBox="0 0 200 200" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg">` +
    `<defs><linearGradient id="planet" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd166"/><stop offset="1" stop-color="#e76f51"/></linearGradient></defs>` +
    `<ellipse class="ring-back" cx="100" cy="100" rx="90" ry="26" fill="none" stroke="#f4c86a" stroke-width="5" transform="rotate(-18 100 100)" opacity="0.45"/>` +
    `<circle cx="100" cy="100" r="54" fill="url(#planet)"/>` +
    `<path d="M100 66 L107 92 L134 100 L107 108 L100 134 L93 108 L66 100 L93 92Z" fill="#fff8e7" opacity="0.92"/>` +
    `<ellipse class="ring-front" cx="100" cy="100" rx="90" ry="26" fill="none" stroke="#f4c86a" stroke-width="5" transform="rotate(-18 100 100)" stroke-dasharray="150 400" opacity="0.9"/>` +
    `</svg>`;
}
