// Login com Firebase Authentication (e-mail e senha, Google e recuperação de senha).
// Os módulos vêm do CDN oficial do Google (gstatic), na versão fixa abaixo.
import { FIREBASE_CONFIG } from './firebase-config.js';

const SDK = 'https://www.gstatic.com/firebasejs/10.12.5';
let authRef = null;
let sdk = null;
let ready = null;

// Inicializa o Firebase e espera o estado inicial de sessão. Chamada única.
export function initFirebase() {
  if (ready) return ready;
  ready = (async () => {
    const appMod = await import(`${SDK}/firebase-app.js`);
    const authMod = await import(`${SDK}/firebase-auth.js`);
    const app = appMod.initializeApp(FIREBASE_CONFIG);
    authRef = authMod.getAuth(app);
    sdk = authMod;
    await authMod.setPersistence(authRef, authMod.browserLocalPersistence);
    await new Promise((resolve) => {
      const unsub = authMod.onAuthStateChanged(authRef, () => { unsub(); resolve(); });
    });
    return authRef;
  })();
  ready.catch(() => { ready = null; });
  return ready;
}

export const currentFirebaseUser = () => (authRef ? authRef.currentUser : null);

// Token de identificação atual (renovado automaticamente pelo SDK). Sem sessão: null.
export async function currentToken() {
  const u = currentFirebaseUser();
  if (!u) return null;
  try {
    return await u.getIdToken();
  } catch {
    return null;
  }
}

export async function signUpWithEmail(email, password) {
  await initFirebase();
  return sdk.createUserWithEmailAndPassword(authRef, email, password);
}

export async function signInWithEmail(email, password) {
  await initFirebase();
  return sdk.signInWithEmailAndPassword(authRef, email, password);
}

export async function signInWithGoogle() {
  await initFirebase();
  const provider = new sdk.GoogleAuthProvider();
  provider.setCustomParameters({ prompt: 'select_account' });
  return sdk.signInWithPopup(authRef, provider);
}

export async function sendPasswordReset(email) {
  await initFirebase();
  return sdk.sendPasswordResetEmail(authRef, email);
}

export async function signOutFirebase() {
  await initFirebase();
  return sdk.signOut(authRef);
}

// Mensagens em português para os erros mais comuns do Firebase.
const MESSAGES = {
  'auth/invalid-email': 'O e-mail informado não é válido.',
  'auth/missing-password': 'Informe a senha.',
  'auth/weak-password': 'A senha precisa ter pelo menos 6 caracteres.',
  'auth/email-already-in-use': 'Já existe uma conta com este e-mail. Entre com sua senha.',
  'auth/invalid-credential': 'E-mail ou senha incorretos.',
  'auth/wrong-password': 'E-mail ou senha incorretos.',
  'auth/user-not-found': 'E-mail ou senha incorretos.',
  'auth/too-many-requests': 'Muitas tentativas seguidas. Aguarde alguns minutos.',
  'auth/network-request-failed': 'Sem conexão com o serviço de login. Verifique a internet.',
  'auth/popup-closed-by-user': 'A janela de login com Google foi fechada antes de concluir.',
  'auth/popup-blocked': 'O navegador bloqueou a janela do Google. Permita pop-ups e tente de novo.',
  'auth/cancelled-popup-request': 'Login com Google cancelado.',
  'auth/account-exists-with-different-credential': 'Este e-mail já está ligado a outra forma de entrada.',
  'auth/user-disabled': 'Esta conta foi desativada.',
  'auth/operation-not-allowed': 'Este tipo de entrada não está ativado no projeto Firebase.',
};

export function authErrorMessage(err) {
  const code = err && err.code;
  return MESSAGES[code] || 'Não foi possível concluir a entrada. Tente novamente.';
}
