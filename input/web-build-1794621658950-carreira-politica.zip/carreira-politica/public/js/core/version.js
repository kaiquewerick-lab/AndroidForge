export const VERSION = '0.4.0';
export const BUILD_LABEL = 'Partes 1 a 4 — Base, partidos, carreira, campanha, Presidência e governo federal';
