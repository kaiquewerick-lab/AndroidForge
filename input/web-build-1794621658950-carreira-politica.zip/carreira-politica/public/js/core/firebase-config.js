// Configuração pública do projeto Firebase (identificadores do cliente, não são segredos).
// A segurança do login é garantida pelo servidor, que verifica o token de cada requisição.
export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyDrgP5ej4YrxMEvOINXJrep3mqsB_v6V3Y',
  authDomain: 'politica-fb74a.firebaseapp.com',
  projectId: 'politica-fb74a',
  storageBucket: 'politica-fb74a.firebasestorage.app',
  messagingSenderId: '977718245945',
  appId: '1:977718245945:web:3c8d243663a4e3942b6be8',
  measurementId: 'G-B91T5F2YV0',
};
