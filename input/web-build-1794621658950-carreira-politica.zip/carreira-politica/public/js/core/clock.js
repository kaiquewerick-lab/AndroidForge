// Relógio da carreira: controla a velocidade do tempo e chama o servidor para avançar os dias.
// O servidor é a autoridade: o relógio só pede dias; quem calcula é o motor.
// Pausa sozinho quando surge uma decisão do jogador (evento, lei, debate) ou a carreira termina.
import { api } from './api.js';
import { store, saveCareerBackup } from './state.js';

export const SPEEDS = {
  pausado: { label: 'Pausado', days: 0, ms: 0 },
  normal: { label: 'Normal', days: 1, ms: 1500 },
  rapido: { label: 'Rápido', days: 3, ms: 1000 },
  muito_rapido: { label: 'Muito rápido', days: 10, ms: 700 },
};

let speed = 'pausado';
let timer = null;
let busy = false;
let lastError = '';
const listeners = new Set();

// Quantidade de decisões que esperam o jogador: eventos, leis para sancionar, debates.
export function pendingCount(c) {
  if (!c) return 0;
  const a = (c.events || []).filter((e) => e.status === 'pendente').length;
  const b = (c.presidential?.government?.events || []).filter((e) => e.status === 'pendente').length;
  const d = (c.summary?.presidency?.debates || []).filter((x) => x.playerNeeded).length;
  const e = (c.presidential?.government?.congress?.bills || []).filter((x) => x.status === 'sancao').length;
  return a + b + d + e;
}

export function onClock(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function emit(extra = {}) {
  const state = { speed, busy, error: lastError, ...extra };
  for (const fn of listeners) {
    try { fn(state); } catch { /* ouvinte com erro não para o relógio */ }
  }
}

export const currentSpeed = () => speed;

export function setSpeed(next) {
  if (!SPEEDS[next]) return;
  speed = next;
  clearInterval(timer);
  timer = null;
  if (next !== 'pausado') {
    timer = setInterval(tick, SPEEDS[next].ms);
    tick();
  }
  emit();
}

export function stopClock() {
  setSpeed('pausado');
  listeners.clear();
}

async function tick() {
  const c = store.career;
  if (busy || !c || c.status === 'encerrada') return;
  busy = true;
  emit();
  try {
    const before = pendingCount(c);
    const res = await api.careerTime(c.id, SPEEDS[speed].days);
    store.career = res.career;
    saveCareerBackup(res.career);
    lastError = '';
    const after = pendingCount(res.career);
    const stop = after > before || res.career.status === 'encerrada' || after > 0;
    if (stop) setSpeed('pausado');
    emit({ tick: true, stopped: stop, pending: after });
  } catch (err) {
    lastError = err.message;
    setSpeed('pausado');
    emit({ error: err.message });
  } finally {
    busy = false;
  }
}
