// Textos de interface em português (base), inglês e espanhol.
// Textos ausentes em um idioma usam o português automaticamente.
const DICT = {
  pt: {
    'nav.start': 'COMEÇAR', 'nav.settings': 'CONFIGURAÇÕES', 'nav.store': 'LOJA', 'nav.createParty': 'CRIAR PARTIDO',
    'nav.back': 'Voltar', 'nav.logout': 'Sair da conta', 'nav.save': 'Salvar', 'nav.cancel': 'Cancelar',
    'nav.newCharacter': 'CRIAR NOVO PERSONAGEM', 'nav.continue': 'CONTINUAR', 'nav.confirm': 'Confirmar personagem',
    'auth.login': 'Entrar em uma conta existente', 'auth.register': 'Cadastrar uma nova conta', 'auth.google': 'Entrar com Google',
    'auth.loginField': 'E-mail ou usuário', 'auth.username': 'Nome de usuário', 'auth.email': 'E-mail',
    'auth.password': 'Senha', 'auth.confirm': 'Confirmar senha', 'auth.submitLogin': 'Entrar',
    'auth.submitRegister': 'Criar conta', 'auth.forgot': 'Esqueci minha senha', 'auth.sendLink': 'Enviar link de recuperação',
    'auth.newPassword': 'Nova senha', 'auth.setPassword': 'Redefinir senha',
    'settings.title': 'Configurações', 'settings.graphics': 'Gráficos', 'settings.language': 'Idioma',
    'settings.volume': 'Volume geral', 'settings.music': 'Música', 'settings.sfx': 'Efeitos sonoros',
    'settings.animations': 'Qualidade das animações', 'settings.screen': 'Modo de tela',
    'settings.sensitivity': 'Sensibilidade dos controles', 'settings.battery': 'Economia de bateria',
    'settings.effects': 'Efeitos visuais', 'settings.saved': 'Preferências salvas.',
    'store.soon': 'EM BREVE', 'home.version': 'Versão do jogo',
  },
  en: {
    'nav.start': 'START', 'nav.settings': 'SETTINGS', 'nav.store': 'STORE', 'nav.createParty': 'CREATE PARTY',
    'nav.back': 'Back', 'nav.logout': 'Sign out', 'nav.save': 'Save', 'nav.cancel': 'Cancel',
    'nav.newCharacter': 'CREATE NEW CHARACTER', 'nav.continue': 'CONTINUE', 'nav.confirm': 'Confirm character',
    'auth.login': 'Sign in to an existing account', 'auth.register': 'Create a new account', 'auth.google': 'Sign in with Google',
    'auth.loginField': 'Email or username', 'auth.username': 'Username', 'auth.email': 'Email',
    'auth.password': 'Password', 'auth.confirm': 'Confirm password', 'auth.submitLogin': 'Sign in',
    'auth.submitRegister': 'Create account', 'auth.forgot': 'Forgot my password', 'auth.sendLink': 'Send recovery link',
    'auth.newPassword': 'New password', 'auth.setPassword': 'Reset password',
    'settings.title': 'Settings', 'settings.graphics': 'Graphics', 'settings.language': 'Language',
    'settings.volume': 'Master volume', 'settings.music': 'Music', 'settings.sfx': 'Sound effects',
    'settings.animations': 'Animation quality', 'settings.screen': 'Screen mode',
    'settings.sensitivity': 'Control sensitivity', 'settings.battery': 'Battery saver',
    'settings.effects': 'Visual effects', 'settings.saved': 'Preferences saved.',
    'store.soon': 'COMING SOON', 'home.version': 'Game version',
  },
  es: {
    'nav.start': 'COMENZAR', 'nav.settings': 'CONFIGURACIÓN', 'nav.store': 'TIENDA', 'nav.createParty': 'CREAR PARTIDO',
    'nav.back': 'Volver', 'nav.logout': 'Cerrar sesión', 'nav.save': 'Guardar', 'nav.cancel': 'Cancelar',
    'nav.newCharacter': 'CREAR NUEVO PERSONAJE', 'nav.continue': 'CONTINUAR', 'nav.confirm': 'Confirmar personaje',
    'auth.login': 'Entrar en una cuenta existente', 'auth.register': 'Registrar una nueva cuenta', 'auth.google': 'Entrar con Google',
    'auth.loginField': 'Correo o usuario', 'auth.username': 'Nombre de usuario', 'auth.email': 'Correo',
    'auth.password': 'Contraseña', 'auth.confirm': 'Confirmar contraseña', 'auth.submitLogin': 'Entrar',
    'auth.submitRegister': 'Crear cuenta', 'auth.forgot': 'Olvidé mi contraseña', 'auth.sendLink': 'Enviar enlace de recuperación',
    'auth.newPassword': 'Nueva contraseña', 'auth.setPassword': 'Restablecer contraseña',
    'settings.title': 'Configuración', 'settings.graphics': 'Gráficos', 'settings.language': 'Idioma',
    'settings.volume': 'Volumen general', 'settings.music': 'Música', 'settings.sfx': 'Efectos de sonido',
    'settings.animations': 'Calidad de las animaciones', 'settings.screen': 'Modo de pantalla',
    'settings.sensitivity': 'Sensibilidad de los controles', 'settings.battery': 'Ahorro de batería',
    'settings.effects': 'Efectos visuales', 'settings.saved': 'Preferencias guardadas.',
    'store.soon': 'PRÓXIMAMENTE', 'home.version': 'Versión del juego',
  },
};

const HTML_LANG = { pt: 'pt-BR', en: 'en', es: 'es' };
let lang = 'pt';

export function setLang(l) {
  if (DICT[l]) lang = l;
  document.documentElement.lang = HTML_LANG[lang];
}

export const getLang = () => lang;

export function t(key, vars) {
  let s = (DICT[lang] && DICT[lang][key]) ?? DICT.pt[key] ?? key;
  if (vars) for (const k of Object.keys(vars)) s = s.replaceAll(`{${k}}`, String(vars[k]));
  return s;
}
