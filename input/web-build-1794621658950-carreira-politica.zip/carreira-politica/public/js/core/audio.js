// Áudio gerado pelo navegador (Web Audio API). Não há arquivos de áudio externos:
// o clique é um tom curto e a música é uma trilha ambiente sintetizada em loop.
let ctx = null;
let master = null;
let drone = null;
let volume = 0.8;
let musicOn = false;
let sfxOn = true;

function ensure() {
  if (!ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume * 0.3;
    master.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return ctx;
}

function startMusic() {
  if (drone) return;
  const c = ensure();
  if (!c) return;
  const g = c.createGain();
  g.gain.value = 0.0001;
  g.gain.setTargetAtTime(0.4, c.currentTime, 1.2);
  g.connect(master);
  const oscs = [110, 164.8, 146.8].map((f) => {
    const o = c.createOscillator();
    o.type = 'triangle';
    o.frequency.value = f;
    o.connect(g);
    o.start();
    return o;
  });
  drone = { g, oscs };
}

function stopMusic() {
  if (!drone || !ctx) return;
  const d = drone;
  drone = null;
  d.g.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.3);
  setTimeout(() => d.oscs.forEach((o) => o.stop()), 1200);
}

export const audio = {
  setVolume(v, music, sfx) {
    volume = v;
    sfxOn = sfx;
    musicOn = music;
    if (master) master.gain.value = v * 0.3;
    if (musicOn) startMusic();
    else stopMusic();
  },
  click() {
    if (!sfxOn) return;
    try {
      const c = ensure();
      if (!c) return;
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = 'sine';
      o.frequency.value = 660;
      g.gain.setValueAtTime(0.0001, c.currentTime);
      g.gain.exponentialRampToValueAtTime(0.4, c.currentTime + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 0.12);
      o.connect(g).connect(master);
      o.start();
      o.stop(c.currentTime + 0.13);
    } catch {
      /* áudio indisponível: o jogo continua normalmente */
    }
  },
};
