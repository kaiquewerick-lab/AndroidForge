// Cliente da API do servidor. Cada requisição leva o token do Firebase (Authorization: Bearer).
import { currentToken } from './firebase.js';

export class ApiError extends Error {
  constructor(message, status, data = {}) {
    super(message);
    this.status = status;
    this.data = data;
  }
}

async function request(method, path, body) {
  const headers = {};
  const token = await currentToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const opts = { method, credentials: 'same-origin', headers };
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch {
    throw new ApiError('Não foi possível conectar ao servidor. Verifique sua conexão.', 0);
  }
  let data = {};
  try {
    data = await res.json();
  } catch {
    /* resposta sem JSON */
  }
  if (!res.ok) throw new ApiError(data.error || `Erro ${res.status}`, res.status, data);
  return data;
}

const enc = encodeURIComponent;

export const api = {
  health: () => request('GET', '/api/health'),
  me: () => request('GET', '/api/auth/me'),
  createProfile: (username) => request('POST', '/api/auth/profile', { username }),
  getSettings: () => request('GET', '/api/settings'),
  saveSettings: (s) => request('PUT', '/api/settings', s),
  listParties: () => request('GET', '/api/parties'),
  createParty: (party) => request('POST', '/api/parties', { party }),
  updateParty: (id, party) => request('PUT', `/api/parties/${enc(id)}`, { party }),
  latestCareer: () => request('GET', '/api/career/latest'),
  prepareCareer: (b) => request('POST', '/api/career/prepare', b),
  importCareer: (state) => request('POST', '/api/career/import', { state }),
  // Ação do jogador. payload vai junto quando a ação precisa de dados (quantidades, escolhas, textos).
  careerAction: (id, action, payload = {}) => request('POST', `/api/career/${enc(id)}/action`, { action, payload }),
  // Avança o tempo em dias inteiros (1 a 60). O servidor pode parar antes num debate que espera resposta.
  careerTime: (id, days) => request('POST', `/api/career/${enc(id)}/time`, { days }),
};
