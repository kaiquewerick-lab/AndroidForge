// Estado global da sessão no navegador. Só é alterado pelos módulos de núcleo e pelas telas.
import { SETTINGS_DEFAULTS, pickSettings } from './validate.js';
import { setLang } from './i18n.js';
import { audio } from './audio.js';

const LOCAL_KEY = 'sp.settings.v1';
const CAREER_BACKUP_KEY = 'sp.career.backup.v1';

export const store = {
  user: null,
  settings: { ...SETTINGS_DEFAULTS },
  parties: [],
  server: null,
  career: null, // partida em uso (espelho do servidor, que é a autoridade)
};

export function loadLocalSettings() {
  try {
    return pickSettings(JSON.parse(localStorage.getItem(LOCAL_KEY) || 'null'));
  } catch {
    return { ...SETTINGS_DEFAULTS };
  }
}

// Aplica as configurações ao documento (idioma, gráficos, animações, efeitos e áudio).
export function applySettings(s) {
  store.settings = s;
  setLang(s.language);
  const b = document.body;
  b.dataset.graphics = s.graphics;
  b.dataset.anim = s.batterySaver || s.animations === 'baixa' ? 'off' : s.animations === 'media' ? 'reduced' : 'full';
  b.classList.toggle('no-effects', !s.effects || s.batterySaver);
  b.dataset.sensitivity = String(s.sensitivity);
  audio.setVolume(s.volume / 100, s.music && !s.batterySaver, s.sfx);
}

export function persistLocalSettings(s) {
  try {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(s));
  } catch {
    /* armazenamento indisponível: preferências valem só nesta sessão */
  }
}

// Cópia de segurança local da partida (recuperação se o servidor falhar ou a conexão cair).
export function saveCareerBackup(career) {
  try {
    localStorage.setItem(CAREER_BACKUP_KEY, JSON.stringify({ userId: store.user?.id, savedAt: Date.now(), career }));
  } catch {
    /* sem espaço local: o servidor continua sendo a fonte principal */
  }
}

export function loadCareerBackup() {
  try {
    const raw = JSON.parse(localStorage.getItem(CAREER_BACKUP_KEY) || 'null');
    if (!raw || !raw.career || raw.userId !== store.user?.id) return null;
    return raw.career;
  } catch {
    return null;
  }
}
