// Validação compartilhada (navegador e servidor).
// O servidor SEMPRE valida de novo: a validação do navegador é apenas para dar retorno rápido.
import { OPTIONS, SKIN_TONES, CLOTHING_KEYS, ACCESSORY_KEYS, APPEARANCE_KEYS, POSES } from '../game/characterData.js';
import { SHAPE_KEYS, ICON_KEYS, FLAG_KEYS, SYMBOL_TYPES, MAX_UPLOAD_CHARS } from '../game/partyData.js';
import { findState, cityExists } from '../world/cities.js';
import { OFFICE_ORDER, INDICATOR_KEYS } from '../game/offices.js';

const SCOPES_LIST = ['municipal', 'estadual', 'federal'];

const HEX = /^#[0-9a-fA-F]{6}$/;
const NAME_RE = /^[\p{L}][\p{L}'’ -]{0,29}$/u;
const DATA_URL_RE = /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/;

const isObj = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
const isHex = (v) => typeof v === 'string' && HEX.test(v);
const isInt = (v, min, max) => Number.isInteger(v) && v >= min && v <= max;
const isNum = (v, min, max) => typeof v === 'number' && Number.isFinite(v) && v >= min && v <= max;
const str = (v) => (typeof v === 'string' ? v.trim().replace(/\s+/g, ' ') : '');
const hasOpt = (group, value) => Object.prototype.hasOwnProperty.call(OPTIONS[group], value);
const todayIso = () => new Date().toISOString().slice(0, 10);
const isIsoDate = (v) => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && !Number.isNaN(Date.parse(v));
const round2 = (v) => Math.round(v * 100) / 100;

// ---------------- Personagem ----------------
export function validateCharacter(c) {
  const e = [];
  if (!isObj(c)) return ['Personagem inválido.'];
  if (!NAME_RE.test(str(c.firstName))) e.push('Informe um nome válido (até 30 letras).');
  if (!NAME_RE.test(str(c.lastName))) e.push('Informe um sobrenome válido (até 30 letras).');
  if (!isInt(c.age, 18, 90)) e.push('A idade deve estar entre 18 e 90 anos.');
  if (!findState(c.birthState)) e.push('Estado de origem inválido.');
  else if (!cityExists(c.birthState, c.birthCity)) e.push('A cidade de nascimento não pertence ao estado escolhido.');

  const ap = c.appearance;
  if (!isObj(ap)) {
    e.push('Aparência inválida.');
  } else {
    if (!hasOpt('hair', ap.hair)) e.push('Cabelo inválido.');
    if (!isHex(ap.hairColor)) e.push('Cor do cabelo inválida.');
    if (!hasOpt('face', ap.face)) e.push('Formato do rosto inválido.');
    if (!SKIN_TONES.includes(ap.skinTone)) e.push('Tom de pele inválido.');
    if (!hasOpt('eyes', ap.eyes)) e.push('Olhos inválidos.');
    if (!isHex(ap.eyeColor)) e.push('Cor dos olhos inválida.');
    if (!hasOpt('beard', ap.beard)) e.push('Barba inválida.');
    if (!hasOpt('mustache', ap.mustache)) e.push('Bigode inválido.');
  }

  e.push(...validateItemGroup(c.clothing, CLOTHING_KEYS, 'roupa'));
  e.push(...validateItemGroup(c.accessories, ACCESSORY_KEYS, 'acessório'));
  if (!POSES.includes(c.pose)) e.push('Pose inválida.');
  return e;
}

function validateItemGroup(group, keys, label) {
  if (!isObj(group)) return [`Dados de ${label}s inválidos.`];
  const out = [];
  for (const k of keys) {
    const item = group[k];
    // As chaves de OPTIONS coincidem com as chaves de roupa e acessórios.
    if (!isObj(item) || !hasOpt(k, item.style)) out.push(`Estilo inválido em ${label} (${k}).`);
    if (!isObj(item) || !isHex(item.color)) out.push(`Cor inválida em ${label} (${k}).`);
  }
  return out;
}

export function pickCharacter(c) {
  const ap = {};
  for (const k of APPEARANCE_KEYS) ap[k] = c.appearance[k];
  const pickGroup = (src, keys) => Object.fromEntries(keys.map((k) => [k, { style: src[k].style, color: src[k].color }]));
  return {
    firstName: str(c.firstName),
    lastName: str(c.lastName),
    age: c.age,
    birthState: c.birthState,
    birthCity: c.birthCity,
    appearance: ap,
    clothing: pickGroup(c.clothing, CLOTHING_KEYS),
    accessories: pickGroup(c.accessories, ACCESSORY_KEYS),
    pose: c.pose,
  };
}

// ---------------- Partido ----------------
function validateSymbol(sym, e) {
  if (!isObj(sym) || !SYMBOL_TYPES.includes(sym.type)) {
    e.push('Símbolo do partido inválido.');
    return;
  }
  if ((sym.type === 'shape' || sym.type === 'combo') && !SHAPE_KEYS.includes(sym.shape)) e.push('Forma inválida.');
  if ((sym.type === 'icon' || sym.type === 'combo') && !ICON_KEYS.includes(sym.icon)) e.push('Ícone inválido.');
  if (sym.type === 'upload') {
    if (typeof sym.dataUrl !== 'string' || sym.dataUrl.length > MAX_UPLOAD_CHARS || !DATA_URL_RE.test(sym.dataUrl)) {
      e.push('Imagem inválida: envie PNG, JPEG ou WEBP com até 250 KB.');
    }
  }
}

export function validateParty(p) {
  const e = [];
  if (!isObj(p)) return ['Partido inválido.'];
  const name = str(p.name);
  if (name.length < 3 || name.length > 60) e.push('O nome do partido deve ter entre 3 e 60 caracteres.');
  if (!/^[A-Za-z]{2,8}$/.test(str(p.acronym))) e.push('A sigla deve ter de 2 a 8 letras, sem acentos.');
  if (!/^\d{2,5}$/.test(str(p.number))) e.push('O número eleitoral deve ter de 2 a 5 dígitos.');
  if (typeof p.motto !== 'string' || p.motto.length > 140) e.push('O lema deve ter até 140 caracteres.');
  if (!isIsoDate(p.foundedAt) || p.foundedAt > todayIso()) e.push('Data de fundação inválida.');
  validateSymbol(p.symbol, e);
  if (!isHex(p.primary) || !isHex(p.secondary)) e.push('Cores do partido inválidas.');
  if (!FLAG_KEYS.includes(p.flagPattern)) e.push('Padrão da bandeira inválido.');
  if (!isObj(p.ideology) || !isInt(p.ideology.economic, 0, 100) || !isInt(p.ideology.social, 0, 100)) {
    e.push('Ideologia inválida.');
  }
  return e;
}

export function pickParty(p) {
  const sym = p.symbol;
  const symbol = { type: sym.type };
  if (sym.type === 'shape' || sym.type === 'combo') symbol.shape = sym.shape;
  if (sym.type === 'icon' || sym.type === 'combo') symbol.icon = sym.icon;
  if (sym.type === 'upload') symbol.dataUrl = sym.dataUrl;
  return {
    name: str(p.name),
    acronym: str(p.acronym).toUpperCase(),
    number: str(p.number),
    motto: p.motto.trim(),
    foundedAt: p.foundedAt,
    symbol,
    primary: p.primary,
    secondary: p.secondary,
    flagPattern: p.flagPattern,
    ideology: { economic: p.ideology.economic, social: p.ideology.social },
  };
}

// ---------------- Configurações ----------------
export const SETTINGS_DEFAULTS = {
  language: 'pt',
  graphics: 'medio',
  volume: 80,
  music: true,
  sfx: true,
  animations: 'alta',
  screenMode: 'janela',
  sensitivity: 50,
  batterySaver: false,
  effects: true,
};

const SETTINGS_ENUMS = {
  language: ['pt', 'en', 'es'],
  graphics: ['baixo', 'medio', 'alto', 'ultra'],
  animations: ['baixa', 'media', 'alta'],
  screenMode: ['janela', 'tela-cheia'],
};

export function validateSettings(s) {
  const e = [];
  if (!isObj(s)) return ['Configurações inválidas.'];
  for (const [k, allowed] of Object.entries(SETTINGS_ENUMS)) {
    if (!allowed.includes(s[k])) e.push(`Valor inválido para ${k}.`);
  }
  if (!isInt(s.volume, 0, 100)) e.push('Volume inválido.');
  if (!isInt(s.sensitivity, 0, 100)) e.push('Sensibilidade inválida.');
  for (const k of ['music', 'sfx', 'batterySaver', 'effects']) {
    if (typeof s[k] !== 'boolean') e.push(`Valor inválido para ${k}.`);
  }
  return e;
}

export function pickSettings(s) {
  const out = { ...SETTINGS_DEFAULTS };
  if (!isObj(s)) return out;
  for (const k of Object.keys(SETTINGS_DEFAULTS)) {
    const v = s[k];
    const expected = typeof SETTINGS_DEFAULTS[k];
    if (SETTINGS_ENUMS[k] ? SETTINGS_ENUMS[k].includes(v) : typeof v === expected) {
      if (k === 'volume' || k === 'sensitivity') {
        if (isInt(v, 0, 100)) out[k] = v;
      } else {
        out[k] = v;
      }
    }
  }
  return out;
}

// ---------------- Partida ----------------
const ARRAY_KEYS = [
  'bills', 'events', 'projects', 'ledger', 'careerLog', 'approvalHistory', 'pastOffices',
  'electionHistory', 'inventory', 'history', 'decisions',
  'citizens', 'installs', 'digital', 'conversations', 'supportHistory', 'fameHistory',
];

export function validateCareerState(s) {
  const e = [];
  if (!isObj(s)) return ['Partida inválida.'];
  const charErrors = validateCharacter(s.character);
  if (charErrors.length) e.push('Personagem da partida inválido.');
  if (s.partyId !== null && typeof s.partyId !== 'string') e.push('Partido da partida inválido.');
  if (!isObj(s.location) || !cityExists(s.location.state, s.location.city)) e.push('Localização inválida.');
  if (!['ativa', 'encerrada'].includes(s.status)) e.push('Situação da carreira inválida.');
  if (!isNum(s.money, 0, 1e12)) e.push('Dinheiro pessoal inválido.');
  if (!isNum(s.campaignFund, 0, 1e12)) e.push('Dinheiro de campanha inválido.');
  if (!isNum(s.partyFund, 0, 1e12)) e.push('Dinheiro do partido inválido.');
  if (!isObj(s.publicBudgets) || !SCOPES_LIST.every((k) => isNum(s.publicBudgets[k], -1e15, 1e15))) {
    e.push('Orçamentos públicos inválidos.');
  }
  if (!isInt(s.support, 0, 1e12)) e.push('Apoio popular inválido.');
  if (!isNum(s.fame, 0, 100)) e.push('Fama inválida.');
  if (!isNum(s.approval, 0, 100)) e.push('Aprovação inválida.');
  if (!isObj(s.indicators) || !INDICATOR_KEYS.every((k) => isNum(s.indicators[k], 0, 100))) e.push('Indicadores inválidos.');
  for (const k of ['health', 'hunger', 'thirst']) {
    if (!isNum(s[k], 0, 100)) e.push(`Valor inválido para ${k}.`);
  }
  if (!isInt(s.day, 0, 100000)) e.push('Dia da partida inválido.');
  if (typeof s.position !== 'string' || s.position.length > 60) e.push('Cargo inválido.');
  if (s.office !== null && !(isObj(s.office) && OFFICE_ORDER.includes(s.office.id))) e.push('Cargo ocupado inválido.');
  if (!isInt(s.rng, 0, 0xffffffff)) e.push('Semente da partida inválida.');
  for (const k of ARRAY_KEYS) {
    if (!Array.isArray(s[k])) e.push(`Campo ${k} inválido.`);
  }
  if (!isObj(s.electoral) || typeof s.electoral.stage !== 'string') e.push('Progresso eleitoral inválido.');
  // Parte 3: regiões, campanha e celulares.
  if (!Array.isArray(s.regions) || s.regions.length !== 4) e.push('Regiões inválidas.');
  if (!isObj(s.stats)) e.push('Estatísticas de campanha inválidas.');
  if (typeof s.currentRegion !== 'string') e.push('Região atual inválida.');
  if (s.equippedPhone !== null && typeof s.equippedPhone !== 'string') e.push('Celular equipado inválido.');
  if (s.presidential !== null && s.presidential !== undefined && !isObj(s.presidential)) e.push('Dados da Presidência inválidos.');
  return e;
}

// Copia somente campos conhecidos, com limites de tamanho. Nada fora da lista é gravado.
export function pickCareer(s) {
  const lim = (arr, n) => (Array.isArray(arr) ? arr.slice(-n) : []);
  const plain = (v) => (v === undefined || v === null ? null : JSON.parse(JSON.stringify(v)));
  const pb = {};
  for (const k of SCOPES_LIST) pb[k] = round2(s.publicBudgets[k]);
  const ind = {};
  for (const k of INDICATOR_KEYS) ind[k] = Math.round(s.indicators[k] * 10) / 10;
  return {
    status: s.status === 'encerrada' ? 'encerrada' : 'ativa',
    character: pickCharacter(s.character),
    partyId: s.partyId ?? null,
    party: s.party ? {
      id: String(s.party.id).slice(0, 64),
      name: String(s.party.name).slice(0, 60),
      acronym: String(s.party.acronym).slice(0, 8),
      number: String(s.party.number).slice(0, 5),
    } : null,
    location: { state: s.location.state, city: s.location.city },
    money: round2(s.money),
    campaignFund: round2(s.campaignFund),
    partyFund: round2(s.partyFund),
    publicBudgets: pb,
    support: Math.floor(s.support),
    fame: Math.round(s.fame * 10) / 10,
    approval: Math.round(s.approval * 10) / 10,
    indicators: ind,
    health: s.health,
    hunger: s.hunger,
    thirst: s.thirst,
    day: Math.floor(s.day),
    position: String(s.position).slice(0, 60),
    office: plain(s.office),
    lastOffice: plain(s.lastOffice),
    election: plain(s.election),
    lastElectionYear: Math.floor(s.lastElectionYear || 0),
    bills: lim(s.bills, 60),
    events: lim(s.events, 80),
    projects: lim(s.projects, 200),
    ledger: lim(s.ledger, 1500),
    careerLog: lim(s.careerLog, 500),
    approvalHistory: lim(s.approvalHistory, 400),
    pastOffices: lim(s.pastOffices, 100),
    electionHistory: lim(s.electionHistory, 50),
    inventory: lim(s.inventory, 200),
    history: lim(s.history, 500),
    decisions: lim(s.decisions, 500),
    electoral: { stage: String(s.electoral.stage || '').slice(0, 80) },
    // Parte 3
    regions: s.regions.map((r) => ({
      id: String(r.id), name: String(r.name), population: Math.floor(r.population),
      reached: Math.floor(r.reached), dayKey: Math.floor(r.dayKey), dayUsed: Math.floor(r.dayUsed),
    })),
    citizens: lim(s.citizens, 40),
    digital: lim(s.digital, 50),
    installs: lim(s.installs, 200),
    equippedPhone: s.equippedPhone ?? null,
    currentRegion: String(s.currentRegion).slice(0, 20),
    conversations: lim(s.conversations, 40),
    supportHistory: lim(s.supportHistory, 400),
    fameHistory: lim(s.fameHistory, 400),
    stats: plain(s.stats),
    // Parte 4 (dados da Presidência: eleição, debates, governo e Congresso)
    presidential: plain(s.presidential),
    rng: s.rng >>> 0,
  };
}
