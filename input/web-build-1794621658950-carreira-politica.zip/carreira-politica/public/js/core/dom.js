// Utilidades de DOM compartilhadas pelas telas.
export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function esc(v) {
  return String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function money(v) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(v) || 0);
}

export function formatDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso.length === 10 ? `${iso}T12:00:00` : iso);
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString('pt-BR');
}

export function clamp(v, min, max) {
  return Math.min(max, Math.max(min, v));
}

export function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

export function debounce(fn, ms) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

export function toast(message, kind = 'info') {
  let box = $('#toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    box.setAttribute('role', 'status');
    box.setAttribute('aria-live', 'polite');
    document.body.appendChild(box);
  }
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = message;
  box.appendChild(el);
  setTimeout(() => el.classList.add('out'), 2600);
  setTimeout(() => el.remove(), 3000);
}

// Substitui o conteúdo da tela principal e reinicia a animação de entrada.
export function setView(html) {
  const app = $('#app');
  app.innerHTML = html;
  app.classList.remove('enter');
  void app.offsetWidth;
  app.classList.add('enter');
}

// Lê um arquivo de imagem como data URL, validando tipo e tamanho.
export function readImageFile(file, maxChars) {
  return new Promise((resolve, reject) => {
    if (!file) return reject(new Error('Nenhum arquivo selecionado.'));
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) {
      return reject(new Error('Use uma imagem PNG, JPEG ou WEBP.'));
    }
    if (file.size > 250 * 1024) return reject(new Error('A imagem deve ter no máximo 250 KB.'));
    const reader = new FileReader();
    reader.onload = () => {
      const url = String(reader.result);
      if (url.length > maxChars) return reject(new Error('Imagem grande demais.'));
      resolve(url);
    };
    reader.onerror = () => reject(new Error('Não foi possível ler a imagem.'));
    reader.readAsDataURL(file);
  });
}
