// Pequenos blocos de interface reutilizados entre as telas.
import { esc } from '../core/dom.js';
import { logoSvg } from '../world/scenes.js';
import { t } from '../core/i18n.js';

export function header(title, { back = 'home', subtitle = '' } = {}) {
  return `
    <header class="topbar">
      ${back ? `<button class="btn btn-ghost" type="button" data-go="${esc(back)}">← ${t('nav.back')}</button>` : '<span></span>'}
      <div class="topbar-title">
        <h2>${esc(title)}</h2>
        ${subtitle ? `<p class="muted small">${esc(subtitle)}</p>` : ''}
      </div>
      <div class="topbar-logo">${logoSvg({ cls: 'logo logo-mini', label: 'SaturnGames' })}</div>
    </header>`;
}

// Liga os botões data-go ao roteador. Deve ser chamado depois de setView().
export function bindGo(go, root = document) {
  root.querySelectorAll('[data-go]').forEach((b) => {
    b.addEventListener('click', () => go(b.dataset.go, JSON.parse(b.dataset.params || '{}')));
  });
}

export function bar(value, max = 100, cls = '') {
  const pct = Math.max(0, Math.min(100, Math.round((value / max) * 100)));
  return `<div class="stat-bar ${cls}" role="meter" aria-valuemin="0" aria-valuemax="${max}" aria-valuenow="${Math.round(value)}">
    <div class="stat-fill" style="width:${pct}%"></div></div>`;
}
