// Apoio comum às telas da carreira: moldura, menu, formatação, ações e avisos.
import { setView, esc, toast, money } from '../core/dom.js';
import { api } from '../core/api.js';
import { store, saveCareerBackup } from '../core/state.js';
import { go } from './router.js';
import { header, bindGo } from './components.js';
import { pendingCount } from '../core/clock.js';

export const fmtInt = (v) => new Intl.NumberFormat('pt-BR').format(Math.round(Number(v) || 0));
export const fmtDec = (v, d = 1) => new Intl.NumberFormat('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d }).format(Number(v) || 0);
export const fmtMoney = (v) => money(v);
export const fmtPct = (v, d = 1) => `${fmtDec(v, d)}%`;

// Menu das seções da carreira. A Presidência aparece para quem já tem candidatura ou cargo federal.
export function navItems(c) {
  const items = [
    ['career', 'Minha carreira'],
    ['mandato', 'Mandato e calendário'],
    ['concorrer', 'Concorrer a um cargo'],
    ['campanha', 'Minha campanha'],
    ['mapa', 'Mapa e conversas'],
    ['fabrica', 'Fábrica de materiais'],
    ['inventario', 'Inventário'],
    ['loja', 'Loja de celulares'],
  ];
  if (c && (c.election?.registered === 'presidente' || c.office?.id === 'presidente' || c.presidential)) {
    items.push(['presidencia', 'Presidência']);
  }
  return items;
}

// Moldura de tela: cabeçalho, menu e corpo. Chame depois de montar o conteúdo.
export function shell(active, title, body, subtitle = '') {
  const c = store.career;
  const pending = pendingCount(c);
  const banner = pending
    ? `<div class="notice warn" role="alert"><strong>Decisão pendente:</strong> há ${pending} assunto(s) esperando você. <button class="btn btn-small" type="button" data-go="mandato">Ver agora</button></div>`
    : '';
  setView(`${header(title, { back: 'career', subtitle })}
    ${banner}
    <nav class="game-nav" aria-label="Seções da carreira">
      ${navItems(c).map(([n, l]) => `<button type="button" class="chip${n === active ? ' is-on' : ''}" data-go="${n}"${n === active ? ' aria-current="page"' : ''}>${esc(l)}</button>`).join('')}
    </nav>
    <div class="game-body">${body}</div>`);
  bindGo(go);
}

// Envia uma ação ao servidor. Devolve a partida nova ou null (com aviso na tela).
export async function act(name, payload = {}) {
  const c = store.career;
  if (!c) {
    toast('Nenhuma partida em andamento.', 'error');
    return null;
  }
  try {
    const res = await api.careerAction(c.id, name, payload);
    store.career = res.career;
    saveCareerBackup(res.career);
    return res.career;
  } catch (err) {
    toast(err.message || 'Ação não concluída.', 'error');
    return null;
  }
}

// Lê um formulário em objeto (números convertidos quando o campo é numérico).
export function readForm(form) {
  const out = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'number') out[el.name] = el.value === '' ? null : Number(el.value);
    else if (el.type === 'checkbox') out[el.name] = el.checked;
    else out[el.name] = el.value;
  }
  return out;
}

export function card(title, body, cls = '') {
  return `<article class="card ${cls}">${title ? `<h3>${esc(title)}</h3>` : ''}${body}</article>`;
}

export function stat(label, value, hint = '') {
  return `<div class="stat-card"><span class="stat-label">${esc(label)}</span><strong class="stat-value">${value}</strong>${hint ? `<span class="muted small">${esc(hint)}</span>` : ''}</div>`;
}

export function table(headers, rows) {
  return `<div class="table-wrap"><table class="data-table"><thead><tr>${headers.map((h) => `<th scope="col">${esc(h)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${headers.length}" class="muted">Nada por aqui ainda.</td></tr>`}</tbody></table></div>`;
}

// Atalho para a seção atual caso a partida não exista (ex.: após sair).
export function requireCareer() {
  if (!store.career) {
    go('start');
    return false;
  }
  return true;
}
