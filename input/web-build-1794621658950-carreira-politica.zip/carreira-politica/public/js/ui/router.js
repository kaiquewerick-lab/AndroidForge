// Roteador de telas: cada tela é registrada com um nome e chamada com parâmetros.
// onLeave() registra limpeza (temporizadores, relógio) executada antes de trocar de tela.
const screens = new Map();
let leaveHooks = [];

export function defineScreen(name, render) {
  screens.set(name, render);
}

export function onLeave(fn) {
  leaveHooks.push(fn);
}

export async function go(name, params = {}) {
  const hooks = leaveHooks;
  leaveHooks = [];
  for (const fn of hooks) {
    try { fn(); } catch { /* limpeza não pode impedir a navegação */ }
  }
  const render = screens.get(name);
  if (!render) throw new Error(`Tela desconhecida: ${name}`);
  document.body.dataset.screen = name;
  window.scrollTo(0, 0);
  await render(params);
}
