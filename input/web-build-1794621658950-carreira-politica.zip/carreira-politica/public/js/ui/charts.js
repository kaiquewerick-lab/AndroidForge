// Gráficos de linha em SVG (sem bibliotecas). Recebe séries com pontos {x, y}.
import { esc } from '../core/dom.js';

export function lineChart({ series, height = 180, yMin = 0, yMax = 100, title = '', yLabel = '' }) {
  const w = 640;
  const h = height;
  const pad = { l: 46, r: 12, t: 14, b: 26 };
  const all = series.flatMap((s) => s.points);
  if (!all.length) {
    return `<figure class="chart"><p class="muted small">Ainda não há dados suficientes para o gráfico.</p></figure>`;
  }
  const xs = all.map((p) => p.x);
  const x0 = Math.min(...xs);
  const x1 = Math.max(...xs, x0 + 1);
  const lo = yMin;
  const hi = yMax > lo ? yMax : lo + 1;
  const sx = (x) => pad.l + ((x - x0) / (x1 - x0)) * (w - pad.l - pad.r);
  const sy = (y) => pad.t + (1 - (Math.min(hi, Math.max(lo, y)) - lo) / (hi - lo)) * (h - pad.t - pad.b);
  const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => {
    const v = lo + (hi - lo) * f;
    const y = sy(v);
    return `<line x1="${pad.l}" x2="${w - pad.r}" y1="${y}" y2="${y}" class="grid"/>
      <text x="${pad.l - 6}" y="${y + 4}" text-anchor="end" class="axis">${Math.round(v)}</text>`;
  }).join('');
  const lines = series.map((s) => {
    if (!s.points.length) return '';
    const d = s.points.map((p, i) => `${i ? 'L' : 'M'}${sx(p.x).toFixed(1)},${sy(p.y).toFixed(1)}`).join(' ');
    const last = s.points[s.points.length - 1];
    return `<path d="${d}" fill="none" stroke="${esc(s.color)}" stroke-width="2.4" stroke-linejoin="round"/>
      <circle cx="${sx(last.x).toFixed(1)}" cy="${sy(last.y).toFixed(1)}" r="3.5" fill="${esc(s.color)}"/>`;
  }).join('');
  const legend = series.map((s) => `<span class="legend-item"><i style="background:${esc(s.color)}"></i>${esc(s.label)}</span>`).join('');
  return `<figure class="chart">
    ${title ? `<figcaption>${esc(title)}${yLabel ? ` <span class="muted small">(${esc(yLabel)})</span>` : ''}</figcaption>` : ''}
    <svg viewBox="0 0 ${w} ${h}" role="img" aria-label="${esc(title || 'Gráfico de evolução')}" preserveAspectRatio="none">
      ${grid}${lines}
    </svg>
    <div class="legend">${legend}</div>
  </figure>`;
}
