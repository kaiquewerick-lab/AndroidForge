// Entrada na conta com Firebase: cadastro e login por e-mail, Google, recuperação de senha
// e escolha do nome de usuário (perfil do jogo) no primeiro acesso.
import { setView, $, toast } from '../../core/dom.js';
import { api, ApiError } from '../../core/api.js';
import { store, applySettings, persistLocalSettings, loadLocalSettings } from '../../core/state.js';
import { pickSettings } from '../../core/validate.js';
import { logoSvg } from '../../world/scenes.js';
import { go } from '../router.js';
import { VERSION } from '../../core/version.js';
import {
  signUpWithEmail, signInWithEmail, signInWithGoogle, sendPasswordReset, authErrorMessage,
} from '../../core/firebase.js';

function shell(title, body) {
  return `
    <section class="auth">
      <div class="auth-card card">
        <div class="auth-brand">${logoSvg({ cls: 'logo logo-small' })}
          <div><h1>Carreira Política</h1><p class="muted">SaturnGames · v${VERSION}</p></div>
        </div>
        <h2 class="auth-title">${title}</h2>
        ${body}
      </div>
    </section>`;
}

const field = (id, label, type, autocomplete) => `
  <label class="field"><span>${label}</span>
    <input id="${id}" name="${id}" type="${type}" autocomplete="${autocomplete}" required></label>`;

function setBusy(btn, busy) {
  btn.disabled = busy;
  btn.dataset.label ||= btn.textContent;
  btn.textContent = busy ? 'Aguarde...' : btn.dataset.label;
}

function showError(msg) {
  const box = $('#form-error');
  if (!box) return toast(msg, 'error');
  box.hidden = !msg;
  box.textContent = msg || '';
}

const back = `<button class="link back" type="button" data-go="choose">← Voltar</button>`;

export function renderAuth({ mode = 'choose' } = {}) {
  if (mode === 'login') return renderLogin();
  if (mode === 'register') return renderRegister();
  if (mode === 'forgot') return renderForgot();
  if (mode === 'profile') return renderProfile();
  setView(shell('Bem-vindo', `
    <div class="stack">
      <button class="btn btn-primary btn-block" type="button" data-go="login">Entrar com e-mail</button>
      <button class="btn btn-secondary btn-block" type="button" data-go="register">Criar conta</button>
      <button class="btn btn-google btn-block" type="button" id="google-btn">Entrar com Google</button>
    </div>
    <p class="muted small center">Suas partidas e personagens ficam guardados na sua conta.</p>`));
  bindNav();
  $('#google-btn').addEventListener('click', () => guard(async () => {
    const cred = await signInWithGoogle();
    if (cred) await afterFirebaseSignIn();
  }));
}

function bindNav() {
  document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => renderAuth({ mode: b.dataset.go })));
}

// Executa uma ação de autenticação mostrando erros em português.
async function guard(fn) {
  try {
    await fn();
  } catch (err) {
    showError(authErrorMessage(err));
    if (!$('#form-error')) toast(authErrorMessage(err), 'error');
  }
}

function renderLogin() {
  setView(shell('Entrar', `
    <form id="login-form" class="stack" novalidate>
      ${field('email', 'E-mail', 'email', 'email')}
      ${field('password', 'Senha', 'password', 'current-password')}
      <p class="notice error" id="form-error" hidden></p>
      <button class="btn btn-primary btn-block" type="submit">Entrar</button>
    </form>
    <div class="links">
      <button class="link" type="button" data-go="forgot">Esqueci minha senha</button>
      <button class="link" type="button" data-go="register">Criar conta</button>
    </div>
    ${back}`));
  bindNav();
  $('#login-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    showError('');
    setBusy(btn, true);
    guard(async () => {
      await signInWithEmail($('#email').value.trim(), $('#password').value);
      await afterFirebaseSignIn();
    }).finally(() => setBusy(btn, false));
  });
}

function renderRegister() {
  setView(shell('Criar conta', `
    <form id="register-form" class="stack" novalidate>
      ${field('email', 'E-mail', 'email', 'email')}
      ${field('password', 'Senha (mínimo de 6 caracteres)', 'password', 'new-password')}
      ${field('confirm', 'Confirme a senha', 'password', 'new-password')}
      <p class="notice error" id="form-error" hidden></p>
      <button class="btn btn-primary btn-block" type="submit">Criar conta</button>
    </form>
    ${back}`));
  bindNav();
  $('#register-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    showError('');
    if ($('#password').value !== $('#confirm').value) return showError('As senhas não coincidem.');
    setBusy(btn, true);
    guard(async () => {
      await signUpWithEmail($('#email').value.trim(), $('#password').value);
      await afterFirebaseSignIn();
    }).finally(() => setBusy(btn, false));
  });
}

function renderForgot() {
  setView(shell('Recuperar senha', `
    <form id="forgot-form" class="stack" novalidate>
      ${field('email', 'E-mail da conta', 'email', 'email')}
      <p class="notice error" id="form-error" hidden></p>
      <button class="btn btn-primary btn-block" type="submit">Enviar link de redefinição</button>
    </form>
    ${back}`));
  bindNav();
  $('#forgot-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    setBusy(btn, true);
    guard(async () => {
      await sendPasswordReset($('#email').value.trim());
      toast('Se a conta existir, você receberá um e-mail com o link.', 'ok');
      renderAuth({ mode: 'login' });
    }).finally(() => setBusy(btn, false));
  });
}

// Primeiro acesso: a conta do Firebase existe, mas o jogo ainda pede um nome de usuário.
function renderProfile() {
  setView(shell('Escolha seu nome de usuário', `
    <form id="profile-form" class="stack" novalidate>
      <label class="field"><span>Nome de usuário (3 a 20 letras, números ou _)</span>
        <input id="username" name="username" autocomplete="username" required minlength="3" maxlength="20"></label>
      <p class="notice error" id="form-error" hidden></p>
      <button class="btn btn-primary btn-block" type="submit">Continuar</button>
    </form>`));
  $('#profile-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]');
    setBusy(btn, true);
    guard(async () => {
      const r = await api.createProfile($('#username').value.trim());
      await enterAccount(r.user, r.settings);
    }).finally(() => setBusy(btn, false));
  });
}

// Depois de entrar no Firebase: consulta o servidor para saber se o perfil já existe.
async function afterFirebaseSignIn() {
  const me = await api.me();
  if (!me.user) return renderAuth({ mode: 'profile' });
  await enterAccount(me.user, me.settings);
}

// Aplica as preferências da conta (ou as deste aparelho, se a conta ainda estiver com padrão) e entra.
export async function enterAccount(user, accountSettings) {
  store.user = user;
  const merged = pickSettings(accountSettings);
  const local = loadLocalSettings();
  const isDefault = JSON.stringify(merged) === JSON.stringify(pickSettings(null));
  const final = isDefault ? local : merged;
  applySettings(final);
  persistLocalSettings(final);
  if (isDefault) api.saveSettings(local).catch(() => {});
  try {
    store.parties = (await api.listParties()).parties;
  } catch {
    store.parties = [];
  }
  toast(`Bem-vindo, ${user.username}!`, 'ok');
  go('home');
}

export { ApiError };
