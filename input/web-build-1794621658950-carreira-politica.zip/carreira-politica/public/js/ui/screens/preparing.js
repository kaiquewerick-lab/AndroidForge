// Tela especial "PREPARANDO SUA CARREIRA POLÍTICA": envia os dados ao servidor, que valida,
// gera o texto de abertura (IA ou contingência local) e cria a partida.
import { setView, $, toast, esc } from '../../core/dom.js';
import { api, ApiError } from '../../core/api.js';
import { store, saveCareerBackup } from '../../core/state.js';
import { go } from '../router.js';
import { clearCreatorDraft } from './characterCreator.js';

const PHASES = [
  'Verificando os dados do personagem',
  'Validando o partido escolhido',
  'Gerando a introdução da carreira',
  'Calculando as condições iniciais',
  'Salvando sua carreira',
];

export async function renderPreparing({ character, partyId = null } = {}) {
  if (!store.user) return go('auth');
  setView(`
    <section class="prep" aria-live="polite">
      <h2 class="prep-title">PREPARANDO SUA CARREIRA POLÍTICA</h2>
      <ol class="prep-steps" id="prep-steps">
        ${PHASES.map((p, i) => `<li data-i="${i}">${esc(p)}</li>`).join('')}
      </ol>
      <div class="bar"><div class="bar-fill" id="prep-fill" style="width:0%"></div></div>
      <p class="muted small" id="prep-msg">Aguarde um momento...</p>
      <div id="prep-error" class="notice error" hidden></div>
    </section>`);

  let current = 0;
  const mark = (i) => {
    document.querySelectorAll('#prep-steps li').forEach((li) => {
      const n = Number(li.dataset.i);
      li.classList.toggle('done', n < i);
      li.classList.toggle('active', n === i);
    });
    $('#prep-fill').style.width = `${Math.round((i / PHASES.length) * 100)}%`;
  };
  mark(0);
  const ticker = setInterval(() => {
    current = Math.min(current + 1, PHASES.length - 1);
    mark(current);
  }, 900);

  try {
    const [res] = await Promise.all([
      api.prepareCareer({ character, partyId }),
      new Promise((r) => setTimeout(r, 2400)),
    ]);
    clearInterval(ticker);
    mark(PHASES.length);
    $('#prep-fill').style.width = '100%';
    saveCareerBackup(res.career);
    clearCreatorDraft();
    const msg = res.ai.used
      ? 'Análise concluída pela inteligência artificial.'
      : 'Inteligência artificial indisponível no momento: usando o sistema local de contingência.';
    $('#prep-msg').textContent = msg;
    toast('Sua carreira política começou!', 'ok');
    setTimeout(() => go('career', { career: res.career }), 900);
  } catch (err) {
    clearInterval(ticker);
    const box = $('#prep-error');
    box.hidden = false;
    box.innerHTML = `<p>${esc(err instanceof ApiError ? err.message : 'Erro inesperado ao preparar a carreira.')}</p>
      <p class="small">Seus dados do personagem foram mantidos.</p>
      <button class="btn btn-primary" type="button" id="back-creator">Voltar ao criador de personagem</button>`;
    $('#back-creator').addEventListener('click', () => go('creator'));
  }
}
