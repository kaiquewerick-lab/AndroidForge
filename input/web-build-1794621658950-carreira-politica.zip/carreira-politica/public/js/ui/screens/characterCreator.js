// Criador de personagem: editor 2D com prévia em tempo real, poses e dados de origem.
import { setView, $, $$, esc, toast, clamp } from '../../core/dom.js';
import { t } from '../../core/i18n.js';
import { store } from '../../core/state.js';
import { validateCharacter } from '../../core/validate.js';
import {
  DEFAULT_CHARACTER, OPTIONS, SKIN_TONES, HAIR_COLORS, EYE_COLORS,
  CLOTHING_KEYS, ACCESSORY_KEYS, CLOTHING_LABELS, ACCESSORY_LABELS,
} from '../../game/characterData.js';
import { renderCharacter } from '../../game/characterSvg.js';
import { STATES, findState } from '../../world/cities.js';
import { header, bindGo } from '../components.js';
import { go } from '../router.js';

const DRAFT_KEY = 'sp.creator.draft.v1';

export function loadCreatorDraft() {
  try {
    const raw = JSON.parse(sessionStorage.getItem(DRAFT_KEY) || 'null');
    return raw && typeof raw === 'object' ? raw : null;
  } catch {
    return null;
  }
}

export function clearCreatorDraft() {
  sessionStorage.removeItem(DRAFT_KEY);
}

// Lê/escreve um caminho como "clothing.shirt.style".
const getPath = (obj, path) => path.split('.').reduce((o, k) => (o ? o[k] : undefined), obj);
function setPath(obj, path, value) {
  const keys = path.split('.');
  const last = keys.pop();
  const target = keys.reduce((o, k) => o[k], obj);
  target[last] = value;
}

export function renderCreator() {
  if (!store.user) return go('auth');
  const draft = loadCreatorDraft() || structuredClone(DEFAULT_CHARACTER);
  if (!findState(draft.birthState)) draft.birthState = DEFAULT_CHARACTER.birthState;
  const state = { draft, partyId: draft.partyId || '', mirror: 1 };
  if (state.draft.partyId !== undefined) delete state.draft.partyId;

  setView(`
    <section class="screen creator">
      ${header('Criar personagem', { back: 'start' })}
      <div class="creator-layout">
        <aside class="preview-stage card" aria-label="Prévia do personagem">
          <div class="pose-buttons" role="group" aria-label="Posições">
            ${Object.entries(OPTIONS.pose).map(([k, l]) => `<button type="button" class="chip" data-pose="${k}" aria-pressed="false">${l}</button>`).join('')}
          </div>
          <div id="char-preview" class="char-preview" title="Arraste para os lados para girar o personagem"></div>
          <p class="muted small center">Arraste a prévia para girar o personagem.</p>
        </aside>

        <form id="creator-form" class="card creator-form" novalidate>
          <fieldset>
            <legend>Identidade</legend>
            ${textInput('firstName', 'Nome', draft.firstName, 30)}
            ${textInput('lastName', 'Sobrenome', draft.lastName, 30)}
            <label class="field"><span>Idade</span>
              <input type="number" name="age" id="age" min="18" max="90" value="${draft.age}"></label>
            <label class="field"><span>Estado de origem</span>
              <select id="birthState" name="birthState">${STATES.map((s) => `<option value="${s.uf}" ${s.uf === draft.birthState ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select></label>
            <label class="field"><span>Cidade de nascimento</span>
              <select id="birthCity" name="birthCity">${cityOptions(draft.birthState, draft.birthCity)}</select></label>
          </fieldset>

          <fieldset>
            <legend>Aparência</legend>
            ${selectField('appearance.hair', 'Cabelo', OPTIONS.hair, draft.appearance.hair)}
            ${colorChips('appearance.hairColor', 'Cor do cabelo', HAIR_COLORS, draft.appearance.hairColor)}
            ${selectField('appearance.face', 'Rosto', OPTIONS.face, draft.appearance.face)}
            ${colorChips('appearance.skinTone', 'Tom de pele', SKIN_TONES, draft.appearance.skinTone)}
            ${selectField('appearance.eyes', 'Olhos', OPTIONS.eyes, draft.appearance.eyes)}
            ${colorChips('appearance.eyeColor', 'Cor dos olhos', EYE_COLORS, draft.appearance.eyeColor)}
            ${selectField('appearance.beard', 'Barba', OPTIONS.beard, draft.appearance.beard)}
            ${selectField('appearance.mustache', 'Bigode', OPTIONS.mustache, draft.appearance.mustache)}
          </fieldset>

          <fieldset>
            <legend>Roupas</legend>
            ${CLOTHING_KEYS.map((k) => itemRow('clothing', k, CLOTHING_LABELS[k], draft.clothing[k])).join('')}
          </fieldset>

          <fieldset>
            <legend>Acessórios</legend>
            ${ACCESSORY_KEYS.map((k) => itemRow('accessories', k, ACCESSORY_LABELS[k], draft.accessories[k])).join('')}
          </fieldset>

          <fieldset>
            <legend>Partido inicial</legend>
            <label class="field"><span>Partido</span>
              <select id="partyId">
                <option value="">Sem partido (independente)</option>
                ${store.parties.map((p) => `<option value="${esc(p.id)}" ${p.id === state.partyId ? 'selected' : ''}>${esc(p.name)} (${esc(p.acronym)})</option>`).join('')}
              </select></label>
            ${store.parties.length ? '' : '<small class="muted">Você ainda não criou partidos. Pode começar sem partido e criar um depois.</small>'}
          </fieldset>

          <p class="field-error" id="creator-error" role="alert"></p>
          <div class="form-actions">
            <button class="btn btn-ghost" type="button" data-go="start">Cancelar</button>
            <button class="btn btn-primary" type="submit" id="confirm-char">${t('nav.confirm')}</button>
          </div>
        </form>
      </div>
    </section>`);

  bindGo(go);
  bindCreator(state);
}

function cityOptions(uf, selected) {
  const st = findState(uf);
  const list = st ? st.cities : [];
  const chosen = list.includes(selected) ? selected : list[0];
  return list.map((c) => `<option value="${esc(c)}" ${c === chosen ? 'selected' : ''}>${esc(c)}</option>`).join('');
}

function textInput(name, label, value, max) {
  return `<label class="field"><span>${label}</span>
    <input name="${name}" id="${name}" value="${esc(value)}" maxlength="${max}" autocomplete="off"></label>`;
}

function selectField(path, label, options, value) {
  const id = path.replace('.', '-');
  return `<label class="field"><span>${label}</span>
    <select id="${id}" data-path="${path}">${Object.entries(options)
      .map(([k, l]) => `<option value="${k}" ${k === value ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
}

function colorChips(path, label, palette, value) {
  return `<div class="field"><span>${label}</span>
    <div class="swatches" role="radiogroup" aria-label="${label}">${palette.map((c) => `
      <button type="button" class="swatch ${c === value ? 'selected' : ''}" style="background:${c}" data-path="${path}" data-color="${c}"
        role="radio" aria-checked="${c === value}" aria-label="${label} ${c}"></button>`).join('')}
      <input type="color" data-path="${path}" value="${esc(value)}" aria-label="Escolher outra cor" class="color-pick"></div></div>`;
}

function itemRow(group, key, label, item) {
  return `<div class="item-row">
    <label class="field"><span>${label}</span>
      <select data-path="${group}.${key}.style">${Object.entries(OPTIONS[key])
        .map(([k, l]) => `<option value="${k}" ${k === item.style ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>
    <label class="field inline"><span>Cor</span>
      <input type="color" data-path="${group}.${key}.color" value="${esc(item.color)}"></label>
  </div>`;
}

function bindCreator(state) {
  const { draft } = state;
  const preview = () => {
    $('#char-preview').innerHTML = renderCharacter(draft, { mirror: state.mirror, title: 'Prévia do personagem' });
    $$('[data-pose]').forEach((b) => {
      const on = b.dataset.pose === draft.pose;
      b.classList.toggle('selected', on);
      b.setAttribute('aria-pressed', String(on));
    });
  };

  const setValue = (path, value) => setPath(draft, path, value);

  // Campos com data-path (selects, cores, paleta).
  document.querySelectorAll('[data-path]').forEach((el) => {
    if (el.tagName === 'BUTTON') return;
    el.addEventListener('input', () => {
      setValue(el.dataset.path, el.value);
      preview();
    });
    el.addEventListener('change', () => {
      setValue(el.dataset.path, el.value);
      preview();
    });
  });
  $$('button[data-path]').forEach((b) => b.addEventListener('click', () => {
    setValue(b.dataset.path, b.dataset.color);
    document.querySelectorAll(`button[data-path="${b.dataset.path}"]`).forEach((x) => {
      const on = x === b;
      x.classList.toggle('selected', on);
      x.setAttribute('aria-checked', String(on));
    });
    preview();
  }));

  $('#firstName').addEventListener('input', (e) => { draft.firstName = e.target.value; });
  $('#lastName').addEventListener('input', (e) => { draft.lastName = e.target.value; });
  $('#age').addEventListener('input', (e) => { draft.age = Number(e.target.value); });
  $('#birthState').addEventListener('change', (e) => {
    draft.birthState = e.target.value;
    $('#birthCity').innerHTML = cityOptions(draft.birthState, '');
    draft.birthCity = $('#birthCity').value;
    preview();
  });
  $('#birthCity').addEventListener('change', (e) => { draft.birthCity = e.target.value; });
  $('#partyId').addEventListener('change', (e) => { state.partyId = e.target.value; });

  $$('[data-pose]').forEach((b) => b.addEventListener('click', () => {
    draft.pose = b.dataset.pose;
    preview();
  }));

  // Girar: arrastar horizontalmente na prévia. A sensibilidade vem das configurações.
  const stage = $('#char-preview');
  let dragging = false;
  let lastX = 0;
  stage.addEventListener('pointerdown', (e) => {
    dragging = true;
    lastX = e.clientX;
    stage.setPointerCapture?.(e.pointerId);
  });
  stage.addEventListener('pointermove', (e) => {
    if (!dragging) return;
    const sens = (store.settings.sensitivity ?? 50) / 50;
    const dx = e.clientX - lastX;
    lastX = e.clientX;
    state.mirror = clamp(state.mirror + dx * 0.012 * sens, -1, 1);
    preview();
  });
  const stop = () => { dragging = false; };
  stage.addEventListener('pointerup', stop);
  stage.addEventListener('pointercancel', stop);
  stage.addEventListener('pointerleave', stop);

  $('#creator-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const character = structuredClone(draft);
    character.age = Number(character.age);
    const errors = validateCharacter(character);
    const box = $('#creator-error');
    box.textContent = errors[0] || '';
    if (errors.length) return;
    // Guarda o rascunho: se a criação falhar, o personagem não se perde.
    sessionStorage.setItem(DRAFT_KEY, JSON.stringify({ ...character, partyId: state.partyId }));
    toast('Personagem confirmado. Preparando sua carreira...', 'ok');
    go('preparing', { character, partyId: state.partyId || null });
  });

  preview();
}
