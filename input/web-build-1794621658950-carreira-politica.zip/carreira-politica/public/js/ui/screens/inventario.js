// INVENTÁRIO: celulares, santinhos, banners e placas; distribuição, instalação e manutenção.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { shell, act, card, table, fmtInt, fmtDec, fmtMoney, readForm, requireCareer } from '../game.js';
import { REGIONS, PLACA } from '../../game/campaignData.js';

const KIND = { celular: 'Celular', santinho: 'Santinhos', banner: 'Banner', placa: 'Placa' };
const regionOptions = (sel) => REGIONS.map((r) => `<option value="${r.id}"${r.id === sel ? ' selected' : ''}>${esc(r.name)}</option>`).join('');

export function renderInventario() {
  if (!requireCareer()) return;
  const c = store.career;
  const inv = c.inventory || [];

  const rows = inv.map((it) => {
    let actions = '';
    if (it.kind === 'celular') {
      const on = c.equippedPhone === it.id;
      actions = `${on ? '<span class="badge ok">equipado</span>' : `<button class="btn btn-small" type="button" data-equip="${esc(it.id)}">Equipar</button>`}
        <button class="btn btn-small btn-danger" type="button" data-discard="${esc(it.id)}" data-qty="1">Descartar</button>`;
    } else if (it.kind === 'santinho') {
      actions = `<form class="inline-form" data-dist="${esc(it.id)}">
        <input name="quantity" type="number" min="1" max="${it.quantity}" value="${Math.min(50, it.quantity)}" aria-label="Quantidade">
        <select name="regionId" aria-label="Região">${regionOptions(c.currentRegion)}</select>
        <button class="btn btn-small" type="submit">Distribuir aqui</button></form>
        <button class="btn btn-small btn-danger" type="button" data-discard="${esc(it.id)}" data-qty="${it.quantity}">Descartar todos</button>`;
    } else {
      actions = `<form class="inline-form" data-install="${esc(it.id)}">
        <select name="regionId" aria-label="Região">${regionOptions(c.currentRegion)}</select>
        <button class="btn btn-small" type="submit">Instalar</button></form>
        <button class="btn btn-small btn-danger" type="button" data-discard="${esc(it.id)}" data-qty="1">Descartar</button>`;
    }
    const qty = it.kind === 'santinho' ? fmtInt(it.quantity) : '1';
    return [esc(it.name), KIND[it.kind] || it.kind, qty, `${fmtInt(it.condition ?? 100)}%`, actions];
  });

  const installs = (c.installs || []).map((ins) => {
    const region = REGIONS.find((r) => r.id === ins.regionId)?.name || ins.regionId;
    const isPlaca = ins.kind === 'placa';
    const actions = `${isPlaca ? `<button class="btn btn-small" type="button" data-repair="${esc(ins.id)}" ${ins.condition >= 100 ? 'disabled' : ''}>Reparar</button>` : ''}
      <button class="btn btn-small btn-danger" type="button" data-remove="${esc(ins.id)}">Retirar</button>`;
    return [esc(ins.name), esc(region), `${fmtDec(ins.condition, 0)}%`,
      `vence dia ${fmtInt(ins.expiresDay)}`, isPlaca && ins.condition < PLACA.condicaoMinima ? '<span class="badge warn">não gera apoio</span>' : '', actions];
  });

  const phones = card('Celulares', `<p class="small muted">Celular equipado é necessário para campanhas digitais. Eficiência: ${c.equippedPhone ? 'com celular' : 'sem celular (reduzida)'}.</p>
    ${table(['Aparelho', 'Tipo', 'Qtd.', 'Estado', 'Ações'], rows.filter((r) => r[1] === 'Celular'))}`, 'wide');

  shell('inventario', 'Inventário', `
    ${card('Materiais', table(['Item', 'Tipo', 'Qtd.', 'Estado', 'Ações'], rows.filter((r) => r[1] !== 'Celular')), 'wide')}
    ${phones}
    ${card('Instalados nas regiões', table(['Item', 'Região', 'Conservação', 'Validade', '', 'Ações'], installs), 'wide')}`);

  bind();
}

function bind() {
  document.querySelectorAll('[data-equip]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('equiparCelular', { itemId: b.dataset.equip });
    if (res) { toast('Celular equipado.', 'ok'); renderInventario(); }
  }));
  document.querySelectorAll('[data-discard]').forEach((b) => b.addEventListener('click', async () => {
    if (!confirm('Descartar este item?')) return;
    const res = await act('descartarItem', { itemId: b.dataset.discard, quantity: Number(b.dataset.qty) });
    if (res) { toast('Item descartado.', 'info'); renderInventario(); }
  }));
  document.querySelectorAll('[data-dist]').forEach((f) => f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const d = readForm(e.currentTarget);
    const res = await act('distribuirSantinhos', { itemId: f.dataset.dist, quantity: Number(d.quantity), regionId: d.regionId });
    if (res) { toast('Santinhos distribuídos.', 'ok'); renderInventario(); }
  }));
  document.querySelectorAll('[data-install]').forEach((f) => f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const d = readForm(e.currentTarget);
    const res = await act('instalarItem', { itemId: f.dataset.install, regionId: d.regionId });
    if (res) { toast('Instalado na região.', 'ok'); renderInventario(); }
  }));
  document.querySelectorAll('[data-repair]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('repararPlaca', { installId: b.dataset.repair });
    if (res) { toast('Placa reparada.', 'ok'); renderInventario(); }
  }));
  document.querySelectorAll('[data-remove]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('removerInstalacao', { installId: b.dataset.remove });
    if (res) { toast('Retirado da região.', 'info'); renderInventario(); }
  }));
}
