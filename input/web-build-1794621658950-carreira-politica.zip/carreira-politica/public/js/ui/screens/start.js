// Menu COMEÇAR: criar novo personagem ou continuar a última partida salva.
import { setView, $, toast } from '../../core/dom.js';
import { t } from '../../core/i18n.js';
import { api } from '../../core/api.js';
import { store, loadCareerBackup, saveCareerBackup } from '../../core/state.js';
import { header, bindGo } from '../components.js';
import { go } from '../router.js';

export function renderStart() {
  if (!store.user) return go('auth');
  setView(`
    <section class="screen">
      ${header(t('nav.start'))}
      <div class="stack-lg">
        <button class="menu-btn primary wide" type="button" data-go="creator">${t('nav.newCharacter')}</button>
        <button class="menu-btn wide" type="button" id="continue-btn">${t('nav.continue')}</button>
      </div>
      <div id="start-msg" class="notice info" hidden></div>
    </section>`);
  bindGo(go);
  $('#continue-btn').addEventListener('click', continueCareer);
}

async function continueCareer() {
  const msg = $('#start-msg');
  msg.hidden = true;
  const btn = $('#continue-btn');
  btn.disabled = true;
  try {
    const { career } = await api.latestCareer();
    if (career) {
      saveCareerBackup(career);
      return go('career', { career });
    }
    const backup = loadCareerBackup();
    if (backup) return showRestore(backup);
    showNoCareer();
  } catch (err) {
    // Servidor indisponível: tenta a cópia local da partida.
    const backup = loadCareerBackup();
    if (backup) return go('career', { career: backup, offline: true });
    toast(err.message, 'error');
  } finally {
    btn.disabled = false;
  }
}

function showNoCareer() {
  const msg = $('#start-msg');
  msg.hidden = false;
  msg.innerHTML = `<p>Ainda não existe uma carreira salva nesta conta.</p>
    <button class="btn btn-primary" type="button" data-go="creator">${t('nav.newCharacter')}</button>`;
  bindGo(go, msg);
}

function showRestore(backup) {
  const msg = $('#start-msg');
  msg.hidden = false;
  msg.className = 'notice info';
  msg.innerHTML = `<p>Encontramos uma cópia local da sua carreira, mas o servidor não tem nenhuma partida salva.</p>
    <button class="btn btn-primary" type="button" id="restore-btn">Restaurar partida</button>`;
  $('#restore-btn').addEventListener('click', async () => {
    try {
      const { career } = await api.importCareer(backup);
      saveCareerBackup(career);
      toast('Partida restaurada com sucesso.', 'ok');
      go('career', { career });
    } catch (err) {
      toast(err.message, 'error');
    }
  });
}
