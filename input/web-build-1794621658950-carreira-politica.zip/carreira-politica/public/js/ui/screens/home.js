// Tela inicial: menu principal, perfil, informações da conta, versão e saída.
import { setView, $, toast, esc, formatDate } from '../../core/dom.js';
import { t } from '../../core/i18n.js';
import { signOutFirebase } from '../../core/firebase.js';
import { store, applySettings, loadLocalSettings, persistLocalSettings } from '../../core/state.js';
import { logoSvg } from '../../world/scenes.js';
import { VERSION, BUILD_LABEL } from '../../core/version.js';
import { go } from '../router.js';
import { bindGo } from '../components.js';

export function renderHome() {
  if (!store.user) return go('auth');
  const u = store.user;
  const initial = esc(u.username.charAt(0).toUpperCase());
  setView(`
    <section class="home">
      <div class="home-hero">
        <div class="hero-logo">${logoSvg({ cls: 'logo logo-hero' })}</div>
        <div>
          <p class="eyebrow">SaturnGames apresenta</p>
          <h1 class="game-title">Carreira Política</h1>
        </div>
      </div>

      <nav class="menu-grid" aria-label="Menu principal">
        <button class="menu-btn primary" type="button" data-go="start">${t('nav.start')}</button>
        <button class="menu-btn" type="button" data-go="settings">${t('nav.settings')}</button>
        <button class="menu-btn" type="button" data-go="store">${t('nav.store')}</button>
        <button class="menu-btn" type="button" data-go="parties">${t('nav.createParty')}</button>
      </nav>

      <div class="home-panels">
        <article class="card profile">
          <div class="avatar" aria-hidden="true">${initial}</div>
          <div>
            <h3>Perfil do jogador</h3>
            <p class="profile-name">${esc(u.username)}</p>
            <p class="muted small">${store.parties.length} partido(s) criado(s)</p>
          </div>
        </article>

        <article class="card">
          <h3>Informações da conta</h3>
          <dl class="info-list">
            <dt>E-mail</dt><dd>${esc(u.email)}</dd>
            <dt>Entrada</dt><dd>Firebase (conta ${esc(u.provider === 'google' ? 'Google' : 'e-mail')})</dd>
            <dt>Conta criada em</dt><dd>${formatDate(u.createdAt)}</dd>
          </dl>
        </article>

        <article class="card">
          <h3>${t('home.version')}</h3>
          <p><strong>v${VERSION}</strong></p>
          <p class="muted small">${esc(BUILD_LABEL)}</p>
          <p class="muted small">IA: ${store.server?.ai ? 'ativa' : 'contingência local'} · Entrada: Firebase</p>
        </article>
      </div>

      <div class="home-footer">
        <button class="btn btn-danger" type="button" id="logout-btn">${t('nav.logout')}</button>
      </div>
    </section>`);

  bindGo(go);
  $('#logout-btn').addEventListener('click', logout);
}

async function logout() {
  try {
    await signOutFirebase();
  } catch {
    /* mesmo se o Firebase falhar, encerra a sessão local */
  }
  store.user = null;
  store.parties = [];
  // Volta às preferências locais deste dispositivo.
  const local = loadLocalSettings();
  applySettings(local);
  persistLocalSettings(local);
  toast('Você saiu da conta.', 'info');
  go('auth');
}
