// Configurações: salvas automaticamente (localmente e na conta, se houver login).
import { setView, $, toast, esc, debounce } from '../../core/dom.js';
import { t } from '../../core/i18n.js';
import { api } from '../../core/api.js';
import { store, applySettings, persistLocalSettings } from '../../core/state.js';
import { pickSettings } from '../../core/validate.js';
import { header, bindGo } from '../components.js';
import { go } from '../router.js';

const SELECTS = {
  graphics: { label: () => t('settings.graphics'), options: { baixo: 'Baixo', medio: 'Médio', alto: 'Alto', ultra: 'Ultra' } },
  language: { label: () => t('settings.language'), options: { pt: 'Português brasileiro', en: 'English', es: 'Español' } },
  animations: { label: () => t('settings.animations'), options: { baixa: 'Baixa', media: 'Média', alta: 'Alta' } },
  screenMode: { label: () => t('settings.screen'), options: { janela: 'Janela', 'tela-cheia': 'Tela cheia' } },
};

const RANGES = {
  volume: { label: () => t('settings.volume'), min: 0, max: 100 },
  sensitivity: { label: () => t('settings.sensitivity'), min: 0, max: 100 },
};

const SWITCHES = {
  music: () => t('settings.music'),
  sfx: () => t('settings.sfx'),
  effects: () => t('settings.effects'),
  batterySaver: () => t('settings.battery'),
};

let current = null;
const persistRemote = debounce(async (s) => {
  if (!store.user) return;
  try {
    await api.saveSettings(s);
  } catch (err) {
    toast(`Não foi possível salvar na conta: ${err.message}`, 'error');
  }
}, 400);

export function renderSettings() {
  current = pickSettings(store.settings);
  setView(`
    <section class="screen">
      ${header(t('settings.title'))}
      <div class="settings">
        <fieldset class="card">
          <legend>Gráficos e idioma</legend>
          ${Object.entries(SELECTS).map(([k, def]) => selectRow(k, def)).join('')}
        </fieldset>
        <fieldset class="card">
          <legend>Som</legend>
          ${rangeRow('volume', RANGES.volume)}
          ${['music', 'sfx'].map((k) => switchRow(k)).join('')}
        </fieldset>
        <fieldset class="card">
          <legend>Controles e desempenho</legend>
          ${rangeRow('sensitivity', RANGES.sensitivity)}
          ${['effects', 'batterySaver'].map((k) => switchRow(k)).join('')}
        </fieldset>
      </div>
      <p class="muted small center" id="saved-note" aria-live="polite">As alterações são salvas automaticamente.</p>
    </section>`);

  bindGo(go);
  document.querySelectorAll('[data-setting]').forEach((el) => el.addEventListener('change', onChange));
  document.querySelectorAll('input[type=range][data-setting]').forEach((el) => el.addEventListener('input', onChange));
}

function selectRow(key, def) {
  const opts = Object.entries(def.options)
    .map(([v, l]) => `<option value="${esc(v)}" ${current[key] === v ? 'selected' : ''}>${esc(l)}</option>`).join('');
  return `<label class="setting-row"><span>${esc(def.label())}</span>
    <select data-setting="${key}">${opts}</select></label>`;
}

function rangeRow(key, def) {
  return `<label class="setting-row"><span>${esc(def.label())} <strong id="val-${key}">${current[key]}</strong></span>
    <input type="range" data-setting="${key}" min="${def.min}" max="${def.max}" value="${current[key]}"></label>`;
}

function switchRow(key) {
  return `<label class="setting-row switch-row"><span>${esc(SWITCHES[key]())}</span>
    <input type="checkbox" class="switch" data-setting="${key}" ${current[key] ? 'checked' : ''}></label>`;
}

function readValue(el) {
  if (el.type === 'checkbox') return el.checked;
  if (el.type === 'range') return Number(el.value);
  return el.value;
}

function onChange(e) {
  const key = e.target.dataset.setting;
  const value = readValue(e.target);
  const next = { ...current, [key]: value };
  if (key === 'volume' || key === 'sensitivity') {
    const label = $(`#val-${key}`);
    if (label) label.textContent = String(value);
  }
  current = pickSettings(next);
  applySettings(current);
  persistLocalSettings(current);
  persistRemote(current);
  if (key === 'screenMode') applyScreenMode(value);
  if (key === 'language') {
    renderSettings();
    return;
  }
  const note = $('#saved-note');
  if (note && e.type === 'change') {
    note.textContent = t('settings.saved');
  }
}

// Modo de tela: o navegador exige um clique para entrar em tela cheia.
function applyScreenMode(mode) {
  const wants = mode === 'tela-cheia';
  if (wants && !document.fullscreenElement && document.documentElement.requestFullscreen) {
    document.documentElement.requestFullscreen().catch(() => {
      toast('O navegador não permitiu a tela cheia. A preferência foi salva.', 'info');
    });
  } else if (!wants && document.fullscreenElement && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  }
}
