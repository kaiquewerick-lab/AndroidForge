// FÁBRICA DE MATERIAIS: santinhos, banners e placas, com prévia do design.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { shell, act, card, fmtInt, fmtMoney, readForm, requireCareer } from '../game.js';
import { SANTINHO, BANNER, PLACA } from '../../game/campaignData.js';

const designFields = (prefix, name, party, number) => `
  <fieldset class="design-fields">
    <legend>Design do material</legend>
    <label class="field"><span>Nome na propaganda</span><input name="name" maxlength="30" value="${esc(name)}"></label>
    <label class="field"><span>Partido (sigla)</span><input name="party" maxlength="30" value="${esc(party)}"></label>
    <label class="field"><span>Número</span><input name="number" inputmode="numeric" maxlength="5" value="${esc(number)}"></label>
    <label class="field"><span>Slogan (até 60 caracteres)</span><input name="slogan" maxlength="60"></label>
    <label class="field"><span>Cor principal</span><input name="primary" type="color" value="#1d4ed8"></label>
    <label class="field"><span>Cor secundária</span><input name="secondary" type="color" value="#ffffff"></label>
  </fieldset>`;

export function renderFabrica() {
  if (!requireCareer()) return;
  const c = store.career;
  const name = `${c.character.firstName || ''} ${c.character.lastName || ''}`.trim().slice(0, 30);
  const party = c.party ? c.party.acronym : 'Independente';
  const number = c.party ? String(c.party.number) : '00';

  const santinhos = card('Santinhos', `
    <form id="fab-santinho" class="stack">
      <label class="field"><span>Quantidade (${fmtInt(SANTINHO.pedidoMin)} a ${fmtInt(SANTINHO.pedidoMax)})</span>
        <input name="quantity" type="number" min="${SANTINHO.pedidoMin}" max="${SANTINHO.pedidoMax}" value="100" required></label>
      ${designFields('s', name, party, number)}
      <p class="small muted">Custo de fabricação: ${fmtMoney(SANTINHO.fabricacao)} por unidade, mais impressão em lotes de ${SANTINHO.lote}.</p>
      <button class="btn btn-primary" type="submit">Fabricar santinhos</button>
    </form>`);

  const banners = card('Banners', `
    <form id="fab-banner" class="stack">
      <label class="field"><span>Material</span>
        <select name="material">${Object.entries(BANNER.materiais).map(([k, m]) => `<option value="${k}">${esc(m.label)} (${fmtMoney(m.fabricacao)})</option>`).join('')}</select></label>
      <label class="field"><span>Tamanho</span>
        <select name="size">${Object.entries(BANNER.tamanhos).map(([k, t]) => `<option value="${k}">${esc(t.label)}</option>`).join('')}</select></label>
      ${designFields('b', name, party, number)}
      <p class="small muted">Impressão: ${fmtMoney(BANNER.impressao)}. Cada banner pode ser instalado em até ${BANNER.maxPorRegiao} pontos por região.</p>
      <button class="btn btn-primary" type="submit">Fabricar banner</button>
    </form>`);

  const placas = card('Placas', `
    <form id="fab-placa" class="stack">
      <label class="field"><span>Tamanho</span>
        <select name="size">${Object.entries(PLACA.tamanhos).map(([k, t]) => `<option value="${k}">${esc(t.label)} (${fmtMoney(t.fabricacao)}, manutenção ${fmtMoney(t.manutencaoDia)}/dia)</option>`).join('')}</select></label>
      ${designFields('p', name, party, number)}
      <p class="small muted">Impressão: ${fmtMoney(PLACA.impressao)}. Placas exigem manutenção diária e perdem conservação com o tempo.</p>
      <button class="btn btn-primary" type="submit">Fabricar placa</button>
    </form>`);

  const preview = card('Prévia', `
    <div class="design-preview" id="preview">
      <div class="preview-band" id="pv-band"><strong id="pv-name">${esc(name)}</strong></div>
      <div class="preview-number" id="pv-number">${esc(number)}</div>
      <div class="preview-party" id="pv-party">${esc(party)}</div>
      <div class="preview-slogan" id="pv-slogan"></div>
    </div>
    <p class="small muted">A prévia mostra cores e textos. O efeito de cada material depende da região e da audiência.</p>`);

  shell('fabrica', 'Fábrica de materiais', `
    <section class="two-col">${santinhos}${preview}</section>
    <section class="two-col">${banners}${placas}</section>`);

  bind();
}

function bind() {
  const form = document.querySelector('#fab-santinho');
  const sync = (f) => {
    const d = readForm(f);
    const band = document.getElementById('pv-band');
    if (band) band.style.background = d.primary || '#1d4ed8';
    if (band) band.style.color = d.secondary || '#ffffff';
    document.getElementById('pv-name').textContent = d.name || '';
    document.getElementById('pv-number').textContent = d.number || '';
    document.getElementById('pv-party').textContent = d.party || '';
    document.getElementById('pv-slogan').textContent = d.slogan || '';
  };
  const forms = ['#fab-santinho', '#fab-banner', '#fab-placa'].map((s) => document.querySelector(s));
  for (const f of forms) f.addEventListener('input', () => sync(f));
  sync(form);

  const design = (f) => {
    const d = readForm(f);
    return { name: d.name, party: d.party, number: String(d.number ?? ''), slogan: d.slogan || '', primary: d.primary, secondary: d.secondary };
  };
  forms[0].addEventListener('submit', async (e) => {
    e.preventDefault();
    const d = readForm(e.currentTarget);
    const res = await act('fabricarSantinhos', { quantity: Number(d.quantity), design: design(e.currentTarget) });
    if (res) { toast('Santinhos fabricados.', 'ok'); renderFabrica(); }
  });
  forms[1].addEventListener('submit', async (e) => {
    e.preventDefault();
    const d = readForm(e.currentTarget);
    const res = await act('fabricarBanner', { material: d.material, size: d.size, design: design(e.currentTarget) });
    if (res) { toast('Banner fabricado.', 'ok'); renderFabrica(); }
  });
  forms[2].addEventListener('submit', async (e) => {
    e.preventDefault();
    const d = readForm(e.currentTarget);
    const res = await act('fabricarPlaca', { size: d.size, design: design(e.currentTarget) });
    if (res) { toast('Placa fabricada.', 'ok'); renderFabrica(); }
  });
}
