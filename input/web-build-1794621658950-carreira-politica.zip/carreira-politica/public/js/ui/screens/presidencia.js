// PRESIDÊNCIA: candidatura, debates, pesquisas, propostas, painel do GOVERNO FEDERAL,
// ministérios, programas, decisões, Congresso (sanção e veto) e aprovação.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { STATES } from '../../world/cities.js';
import { lineChart } from '../charts.js';
import { shell, act, card, stat, table, fmtInt, fmtDec, fmtMoney, requireCareer } from '../game.js';
import { DEBATE_THEMES, DEPARTMENTS, DEPARTMENT_KEYS, NATIONAL_INDICATORS, NATIONAL_KEYS, NEGOTIATION, CAMARA_SEATS, SENADO_SEATS, PROGRAMS_ACTIVE_MAX } from '../../game/presidencyData.js';
import { EXISTING_PARTIES } from '../../game/offices.js';

const CHOICES = [['0', 'Resposta técnica'], ['1', 'Resposta popular'], ['2', 'Resposta agressiva']];
const THEME_KEYS = Object.keys(DEBATE_THEMES);

export function renderPresidencia() {
  if (!requireCareer()) return;
  const c = store.career;
  const p = c.presidential;
  const sum = c.summary?.presidency;
  if (!p || !sum) {
    return shell('presidencia', 'Presidência', card('Presidência', `
      <p>A Presidência aparece quando você se registra como candidato e entra na disputa nacional.</p>
      <p class="small muted">Requisitos: apoio popular de 15 milhões, dinheiro pessoal de R$ 50 mil, reserva de R$ 6 mil para campanha e um partido.</p>`));
  }
  const g = sum.government;
  const result = p.lastResult;
  const resultBanner = result ? (result.winnerPlayer
    ? `<section class="result-banner win" role="status"><h2>VOCÊ FOI ELEITO PRESIDENTE DA REPÚBLICA!</h2><p>Eleição de ${fmtInt(result.year)}. Veja o painel do governo abaixo.</p></section>`
    : (result.playerRan ? `<section class="result-banner lose" role="status"><h2>VOCÊ NÃO FOI ELEITO.</h2><p>Eleição de ${fmtInt(result.year)}: ${esc(result.winnerName)} venceu.</p></section>` : '')) : '';

  const pending = (sum.debates || []).filter((d) => d.playerNeeded);
  const debatesCard = card('Debates', sum.debates?.length ? table(
    ['Debate', 'Data', 'Emissora', 'Tempo', 'Temas', 'Situação'],
    sum.debates.map((d) => [esc(d.name), esc(d.date), esc(d.broadcaster), esc(d.timeLabel), esc(d.themes.join(', ')), esc(d.status)]),
  ) : '<p class="muted">Nenhum debate agendado.</p>', 'wide');

  const debateForms = pending.map((d) => {
    const debate = d;
    const fields = d.themes.map((label, i) => `
      <fieldset class="debate-theme"><legend>${esc(label)}</legend>
        <label class="field"><span>Estilo</span><select name="choice${i}">${CHOICES.map(([v, l]) => `<option value="${v}">${esc(l)}</option>`).join('')}</select></label>
        <label class="field"><span>Ou escreva sua resposta (opcional)</span><textarea name="text${i}" rows="2" maxlength="600"></textarea></label>
      </fieldset>`).join('');
    return card(`Responder: ${esc(debate.name)}`, `
      <form class="stack debate-form" data-debate="${esc(debate.id)}" data-count="${d.themes.length}">
        <p class="small muted">Tempo de cada resposta: ${esc(debate.timeLabel)}. Suas respostas são avaliadas pelo sistema em clareza, coerência, propostas, argumentação, viabilidade e outros critérios iguais para todos.</p>
        ${fields}
        <label class="field"><span>Discurso final (opcional)</span><textarea name="closing" rows="2" maxlength="300"></textarea></label>
        <button class="btn btn-primary" type="submit">Enviar respostas do debate</button>
      </form>`, 'wide');
  }).join('');

  const polls = sum.lastPoll ? card('Pesquisa mais recente', `
    <p class="small muted">${esc(sum.lastPoll.date)} · amostra de ${fmtInt(sum.lastPoll.sample)} entrevistados · margem de ±${fmtDec(sum.lastPoll.margin)} pontos</p>
    ${table(['Candidato', 'Intenção de voto'], (sum.lastPoll.ranking || []).map((r) => [esc(r.name), `${fmtDec(r.share)}%`]))}`) : card('Pesquisas', '<p class="muted">Ainda não há pesquisas.</p>');

  const travel = card('Viagens e propostas', `
    <form id="travel-form" class="inline-form">
      <label class="field"><span>Viajar para o estado</span>
        <select name="uf">${STATES.map((s) => `<option value="${s.uf}"${s.uf === sum.currentState ? ' selected' : ''}>${esc(s.name)}</option>`).join('')}</select></label>
      <button class="btn" type="submit">Viajar</button>
    </form>
    <form id="proposal-form" class="stack">
      <label class="field"><span>Tema da proposta</span>
        <select name="theme">${THEME_KEYS.map((k) => `<option value="${k}">${esc(DEBATE_THEMES[k].label)}</option>`).join('')}</select></label>
      <label class="field"><span>Texto da proposta (até 600 caracteres)</span><textarea name="text" rows="3" maxlength="600" required></textarea></label>
      <button class="btn" type="submit">Apresentar proposta</button>
    </form>
    <p class="small muted">Propostas apresentadas: ${fmtInt(sum.proposals)}. Propostas viram texto da campanha e pesam nas avaliações dos debates.</p>`);

  const governo = g ? governmentPanel(c, g) : card('Governo federal', '<p class="muted">O painel do governo é aberto após a posse.</p>', 'wide');

  shell('presidencia', 'Presidência', `
    ${resultBanner}
    <section class="two-col">${polls}${travel}</section>
    ${debatesCard}
    ${debateForms}
    ${governo}`);

  bind(sum, g);
}

function governmentPanel(c, g) {
  const ind = card('Painel do governo federal: indicadores nacionais', `
    <div class="stat-grid">${NATIONAL_INDICATORS.map((i) => {
      const cur = g.indicators[i.key];
      const prev = g.indicatorsPrev?.[i.key];
      const delta = prev === undefined ? '' : ` (${cur >= prev ? '+' : ''}${fmtDec(cur - prev)})`;
      return stat(i.label, `${fmtDec(cur)}${delta}`);
    }).join('')}</div>
    <p class="small">Aprovação do governo: <strong>${fmtDec(c.approval)}%</strong></p>
    ${lineChart({ series: [{ label: 'Aprovação (%)', color: '#f59e0b', points: (c.approvalHistory || []).map((p) => ({ x: p.day, y: p.value })) }], yMin: 0, yMax: 100, title: 'Aprovação do governo' })}`, 'wide');

  const ministers = card('Vice-presidência e ministérios', `
    <p>Vice-presidente: <strong>${esc(g.vice?.name || '—')}</strong></p>
    <form id="vice-form" class="inline-form">
      <select name="index">${g.vicePool.map((v, i) => `<option value="${i}">${esc(v.name)}</option>`).join('')}</select>
      <button class="btn btn-small" type="submit">Escolher vice</button></form>
    ${table(['Ministério', 'Ministro(a)', 'Competência', ''], DEPARTMENT_KEYS.map((k) => {
      const m = g.ministers[k];
      const options = (g.pool[k] || []).map((x, i) => `<option value="${i}">${esc(x.name)} (${esc(x.competence)})</option>`).join('');
      return [esc(DEPARTMENTS[k].label), esc(m?.name || '—'), esc(m?.competence || ''),
        `<form class="inline-form" data-minister="${k}"><select name="index" aria-label="Novo ministro">${options}</select><button class="btn btn-small" type="submit">Nomear</button></form>`];
    }))}`, 'wide');

  const programs = card('Programas ministeriais', `
    <p class="small muted">Programas custam dinheiro federal ao iniciar e entregam efeitos nos indicadores ao concluir. Máximo de ${PROGRAMS_ACTIVE_MAX} ativos.</p>
    ${DEPARTMENT_KEYS.map((k) => `<h4>${esc(DEPARTMENTS[k].label)}</h4>
      <div class="action-grid">${DEPARTMENTS[k].programs.map((pr) => `<button class="btn" type="button" data-prog-dept="${k}" data-prog="${pr.key}">${esc(pr.name)}
        <span class="muted small">${fmtMoney(pr.cost)} · ${pr.days} dias</span></button>`).join('')}</div>`).join('')}
    <h4>Em andamento e concluídos</h4>
    ${table(['Programa', 'Ministério', 'Situação', 'Custo'], (g.programs || []).slice(-12).reverse().map((pr) => [
      esc(pr.name), esc(DEPARTMENTS[pr.dept]?.label || pr.dept), esc(pr.status), fmtMoney(pr.cost)]))}`, 'wide');

  const events = card('Decisões do governo', (g.events || []).filter((e) => e.status === 'pendente').map((ev) => `
    <article class="event-card"><h4>${esc(ev.title)}</h4><p>${esc(ev.text)}</p>
      <div class="action-grid">${ev.options.map((o, i) => `<button class="btn" type="button" data-pevent="${esc(ev.id)}" data-option="${i}">${esc(o.label)}
        <span class="muted small">${o.cost ? `custo ${fmtMoney(o.cost)}` : 'sem custo'}${o.approval ? ` · aprovação ${o.approval > 0 ? '+' : ''}${o.approval}` : ''}</span></button>`).join('')}</div>
      <p class="small muted">Prazo: ${fmtInt(Math.max(0, ev.deadline - c.day))} dia(s). Sem decisão, a primeira opção é aplicada.</p></article>`).join('') || '<p class="muted">Nenhuma decisão pendente.</p>', 'wide');

  const bills = (g.bills || []).slice().reverse();
  const congress = card('Congresso Nacional', `
    <p>Câmara dos Deputados: ${fmtInt(CAMARA_SEATS)} cadeiras · Senado Federal: ${fmtInt(SENADO_SEATS)} cadeiras.</p>
    <p class="small muted">O presidente não vota. Ele sanciona ou veta as leis aprovadas. Negociar apoio custa ${fmtMoney(NEGOTIATION.cost)} e aumenta a força do partido aliado.</p>
    <div class="action-grid">${EXISTING_PARTIES.slice(0, 6).map((pt) => `<button class="btn" type="button" data-ally="${pt.id}">Negociar com ${esc(pt.acronym)}
      <span class="muted small">força atual ${fmtDec(g.allies?.[pt.id] || 0)}</span></button>`).join('')}</div>
    <form id="bill-form" class="inline-form">
      <label class="field"><span>Enviar projeto do Executivo</span>
        <select name="sector">${NATIONAL_KEYS.map((k) => `<option value="${k}">${esc(NATIONAL_INDICATORS.find((i) => i.key === k).label)}</option>`).join('')}</select></label>
      <button class="btn" type="submit">Enviar projeto</button></form>
    <h4>Pautas</h4>
    ${table(['Projeto', 'Situação', 'Prazo', ''], bills.map((b) => [
      esc(b.title), esc(b.status), `dia ${fmtInt(b.deadline)}`,
      b.status === 'sancao' ? `<button class="btn btn-small" type="button" data-sanction="${esc(b.id)}" data-decision="sancionar">Sancionar</button>
        <button class="btn btn-small btn-danger" type="button" data-sanction="${esc(b.id)}" data-decision="vetar">Vetar</button>` : '',
    ]))}`, 'wide');

  const approvalPolls = card('Pesquisas de aprovação', table(['Data', 'A favor', 'Contra', 'Indecisos'], (g.approvalPolls || []).map((p) => [esc(p.date), `${fmtDec(p.approve)}%`, `${fmtDec(p.disapprove)}%`, `${fmtDec(p.undecided)}%`])));

  const hist = g.history || [];
  const history = card('Evolução dos indicadores', lineChart({
    series: [
      { label: 'Economia', color: '#22c55e', points: hist.map((h) => ({ x: h.day, y: h.values.economia })) },
      { label: 'Saúde', color: '#ef4444', points: hist.map((h) => ({ x: h.day, y: h.values.saude })) },
      { label: 'Educação', color: '#3b82f6', points: hist.map((h) => ({ x: h.day, y: h.values.educacao })) },
    ],
    yMin: 0, yMax: 100, title: 'Indicadores nacionais',
  }), 'wide');

  return `<section class="government-panel" aria-label="Governo federal">
    <h2 class="panel-title">GOVERNO FEDERAL</h2>
    <section class="two-col">${ind}${ministers}</section>
    <section class="two-col">${programs}${events}</section>
    <section class="two-col">${congress}${approvalPolls}</section>
    ${history}
  </section>`;
}

function bind(sum, g) {
  document.querySelectorAll('.debate-form').forEach((f) => f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const el = e.currentTarget.elements;
    const count = Number(e.currentTarget.dataset.count);
    const answers = [];
    for (let i = 0; i < count; i += 1) {
      const text = (el[`text${i}`]?.value || '').trim();
      answers.push({ answer: text ? { text } : { choice: Number(el[`choice${i}`]?.value || 0) } });
    }
    const closingText = (el.closing?.value || '').trim();
    const res = await act('responderDebate', { debateId: e.currentTarget.dataset.debate, answers, closing: closingText ? { text: closingText } : null });
    if (res) { toast('Debate realizado.', 'ok'); renderPresidencia(); }
  }));
  document.getElementById('travel-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('viajarEstado', { uf: e.currentTarget.uf.value });
    if (res) { toast('Você chegou ao novo estado.', 'ok'); renderPresidencia(); }
  });
  document.getElementById('proposal-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('apresentarProposta', { theme: e.currentTarget.theme.value, text: e.currentTarget.text.value });
    if (res) { toast('Proposta apresentada.', 'ok'); e.currentTarget.reset(); renderPresidencia(); }
  });
  if (!g) return;
  document.getElementById('vice-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('escolherVice', { index: Number(e.currentTarget.index.value) });
    if (res) { toast('Vice escolhido(a).', 'ok'); renderPresidencia(); }
  });
  document.querySelectorAll('[data-minister]').forEach((f) => f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('nomearMinistro', { dept: f.dataset.minister, index: Number(f.index.value) });
    if (res) { toast('Ministro(a) nomeado(a).', 'ok'); renderPresidencia(); }
  }));
  document.querySelectorAll('[data-prog]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('iniciarPrograma', { dept: b.dataset.progDept, key: b.dataset.prog });
    if (res) { toast('Programa iniciado.', 'ok'); renderPresidencia(); }
  }));
  document.querySelectorAll('[data-pevent]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('decidirPresidencial', { eventId: b.dataset.pevent, option: Number(b.dataset.option) });
    if (res) { toast('Decisão registrada.', 'ok'); renderPresidencia(); }
  }));
  document.querySelectorAll('[data-ally]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('negociarApoio', { partyId: b.dataset.ally });
    if (res) { toast('Negociação concluída.', 'ok'); renderPresidencia(); }
  }));
  document.getElementById('bill-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('enviarProjetoLei', { sector: e.currentTarget.sector.value });
    if (res) { toast('Projeto enviado ao Congresso.', 'ok'); renderPresidencia(); }
  });
  document.querySelectorAll('[data-sanction]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('sancionarLei', { billId: b.dataset.sanction, decision: b.dataset.decision });
    if (res) { toast(b.dataset.decision === 'vetar' ? 'Lei vetada.' : 'Lei sancionada.', 'ok'); renderPresidencia(); }
  }));
}
