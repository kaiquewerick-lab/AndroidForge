// CONCORRER A UM CARGO: requisitos visíveis, candidatura, retirada e contribuições para a campanha.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { onLeave } from '../router.js';
import { stopClock } from '../../core/clock.js';
import { shell, act, card, fmtInt, fmtMoney, requireCareer, readForm } from '../game.js';

const SCOPE_LABEL = { municipal: 'Município', estadual: 'Estado', federal: 'União' };

export function renderConcorrer() {
  if (!requireCareer()) return;
  stopClock();
  onLeave(stopClock);
  const c = store.career;
  const s = c.summary || {};
  const inWindow = s.phase === 'pre-campanha' || s.phase === 'campanha' || s.phase === 'votacao';
  const registered = c.election?.registered || null;

  const offices = (s.offices || []).map((o) => {
    const items = o.items.map((i) => `<li class="${i.met ? 'met' : 'pending'}"><span aria-hidden="true">${i.met ? '✔' : '•'}</span> ${esc(i.label)}${i.current !== undefined ? ` <span class="muted small">(${fmtInt(i.current)} de ${fmtInt(i.target)})</span>` : ''}</li>`).join('');
    const status = o.held ? '<span class="badge ok">Você ocupa este cargo</span>'
      : o.registered ? '<span class="badge info">Candidatura registrada</span>'
        : o.offered ? '<span class="badge">Em disputa nesta eleição</span>'
          : '<span class="badge muted-badge">Sem disputa agora</span>';
    const canRegister = !o.held && !o.registered && o.eligible && inWindow && o.offered && !registered;
    const action = o.registered
      ? `<button class="btn btn-danger" type="button" data-act="retirarCandidatura" data-payload="{}">Retirar candidatura</button>`
      : canRegister
        ? `<button class="btn btn-primary" type="button" data-act="registrarCandidatura" data-payload='${esc(JSON.stringify({ officeId: o.officeId }))}'>Registrar candidatura</button>`
        : '';
    return `<article class="card office-card${o.eligible ? ' eligible' : ''}">
      <header class="office-head"><h3>${esc(o.name)}</h3>${status}</header>
      <p class="small muted">${esc(SCOPE_LABEL[o.scope] || o.scope)} · mandato de ${o.mandateYears} anos · salário ${fmtMoney(o.salary)}</p>
      <ul class="req-list" aria-label="Requisitos de ${esc(o.name)}">${items}</ul>
      <p class="small">${o.eligible ? 'Você cumpre todos os requisitos.' : 'Faltam requisitos para este cargo.'}</p>
      <div class="card-actions">${action}${o.officeId === 'presidente' ? '<button class="btn" type="button" data-go="presidencia">Ver painel presidencial</button>' : ''}</div>
    </article>`;
  }).join('');

  const body = `
    <p class="muted">${inWindow ? 'A janela eleitoral está aberta: você pode registrar candidatura.' : 'A janela eleitoral ainda não está aberta. Acompanhe o calendário no menu Mandato.'}
      ${s.nextElection ? ` Próxima eleição: ${esc(s.nextElection.date)}.` : ''}</p>
    <section class="office-grid">${offices}</section>
    <section class="two-col">
      ${card('Financiar a campanha', `
        <p class="small muted">Você pode transferir dinheiro pessoal ou do partido para a campanha. O dinheiro público nunca financia campanhas pessoais.</p>
        <form id="contrib-form" class="inline-form">
          <label class="field"><span>Valor (R$)</span><input name="amount" type="number" min="1" step="1" value="1000" required></label>
          <label class="field"><span>Origem</span>
            <select name="source">
              <option value="pessoal">Dinheiro pessoal (saldo ${fmtMoney(c.money)})</option>
              ${c.partyId ? `<option value="partido">Dinheiro do partido (saldo ${fmtMoney(c.partyFund)})</option>` : ''}
            </select>
          </label>
          <button class="btn btn-primary" type="submit">Transferir para a campanha</button>
        </form>
        <p class="small">Saldo de campanha: <strong>${fmtMoney(c.campaignFund)}</strong></p>`)}
      ${card('Situação atual', `
        <ul class="plain-list">
          <li>Cargo: ${esc(s.office?.name || 'nenhum')}</li>
          <li>Candidatura: ${registered ? esc(registered) : 'nenhuma registrada'}</li>
          <li>Apoio popular: ${fmtInt(c.support)}</li>
        </ul>`)}
    </section>`;

  shell('concorrer', 'Concorrer a um cargo', body);

  document.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', async () => {
    const payload = JSON.parse(b.dataset.payload || '{}');
    const res = await act(b.dataset.act, payload);
    if (res) { toast(b.dataset.act === 'registrarCandidatura' ? 'Candidatura registrada.' : 'Candidatura retirada.', 'ok'); renderConcorrer(); }
  }));

  document.getElementById('contrib-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = readForm(e.currentTarget);
    const res = await act('contribuir', { amount: data.amount, source: data.source });
    if (res) { toast('Valor transferido para a campanha.', 'ok'); renderConcorrer(); }
  });
}
