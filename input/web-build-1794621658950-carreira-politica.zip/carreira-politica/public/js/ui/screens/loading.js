// Tela de carregamento: imagens que trocam sozinhas, barra de progresso real, dicas e frases.
import { setView, $, toast } from '../../core/dom.js';
import { api, ApiError } from '../../core/api.js';
import { initFirebase } from '../../core/firebase.js';
import { store, applySettings, persistLocalSettings, loadLocalSettings } from '../../core/state.js';
import { pickSettings } from '../../core/validate.js';
import { sceneSvg, SCENES } from '../../world/scenes.js';
import { go } from '../router.js';

const TIPS = [
  'Dica: partidos com ideologia bem definida atraem eleitores que se identificam com suas ideias.',
  'Dica: cuide da saúde, da alimentação e da hidratação do seu personagem para manter a energia da campanha.',
  'Dica: você pode editar seu partido a qualquer momento pelo menu CRIAR PARTIDO.',
  'Dica: o dinheiro é limitado, então planeje cada gasto com cuidado.',
  'Dica: sua partida é salva automaticamente após cada decisão.',
];

const FACTS = [
  'O Congresso Nacional fica em Brasília e reúne a Câmara dos Deputados e o Senado Federal.',
  'Brasília foi inaugurada em 21 de abril de 1960 e é conhecida pelo projeto de Oscar Niemeyer.',
  'O Brasil tem 26 estados e o Distrito Federal, que abriga a capital do país.',
  'A democracia brasileira combina representação popular com eleições periódicas.',
];

const SCENE_MS = 3200;

export function renderLoading() {
  setView(`
    <section class="loading" aria-live="polite">
      <div class="scene-frame"><div class="scene" id="scene"></div></div>
      <div class="loading-panel">
        <h2 class="loading-title">Carregando</h2>
        <p class="loading-step" id="step">Iniciando...</p>
        <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" id="bar">
          <div class="bar-fill" id="bar-fill"></div>
        </div>
        <p class="pct" id="pct">0%</p>
        <p class="tip" id="tip"></p>
        <p class="fact" id="fact"></p>
        <div id="load-error" class="notice error" hidden></div>
      </div>
    </section>`);

  let sceneIndex = 0;
  let tipIndex = 0;
  const showScene = () => {
    const el = $('#scene');
    if (!el) return false;
    el.innerHTML = `<div class="scene-slide">${sceneSvg(sceneIndex)}</div>`;
    return true;
  };
  showScene();
  const sceneTimer = setInterval(() => {
    if (!showScene()) return clearInterval(sceneTimer);
    sceneIndex = (sceneIndex + 1) % SCENES.length;
  }, document.body.dataset.anim === 'off' ? SCENE_MS * 3 : SCENE_MS);
  const tipTimer = setInterval(() => {
    const tip = $('#tip');
    const fact = $('#fact');
    if (!tip) return clearInterval(tipTimer);
    tip.textContent = TIPS[tipIndex % TIPS.length];
    fact.textContent = FACTS[tipIndex % FACTS.length];
    tipIndex += 1;
  }, 4200);
  $('#tip').textContent = TIPS[0];
  $('#fact').textContent = FACTS[0];

  const setProgress = (done, total, label) => {
    const pct = Math.round((done / total) * 100);
    $('#bar-fill').style.width = `${pct}%`;
    $('#bar').setAttribute('aria-valuenow', String(pct));
    $('#pct').textContent = `${pct}%`;
    if (label) $('#step').textContent = label;
  };

  const stopTimers = () => {
    clearInterval(sceneTimer);
    clearInterval(tipTimer);
  };

  runBoot(setProgress)
    .then((result) => {
      stopTimers();
      setProgress(1, 1, 'Pronto!');
      setTimeout(() => {
        if (result.user) return go('home');
        if (result.needsProfile) return go('auth', { mode: 'profile' });
        return go('auth');
      }, 400);
    })
    .catch((err) => {
      stopTimers();
      const box = $('#load-error');
      box.hidden = false;
      box.innerHTML = `<p>${err.message}</p><button class="btn btn-primary" id="retry" type="button">Tentar novamente</button>`;
      $('#retry').addEventListener('click', () => renderLoading());
    });
}

// Etapas reais de inicialização. A barra avança a cada etapa concluída.
async function runBoot(setProgress) {
  const result = { user: null, needsProfile: false };
  const minDelay = new Promise((r) => setTimeout(r, document.body.dataset.anim === 'off' ? 600 : 2600));
  const steps = [
    ['Conectando ao servidor...', async () => {
      await initFirebase();
      store.server = await api.health();
    }],
    ['Verificando sua sessão...', async () => {
      let r;
      try {
        r = await api.me();
      } catch (err) {
        // Sem sessão no Firebase, o servidor responde 401: basta mostrar a tela de entrada.
        if (!(err instanceof ApiError && err.status === 401)) throw err;
        r = { user: null };
      }
      store.user = r.user;
      result.needsProfile = Boolean(r.needsProfile);
      if (r.user) {
        const local = loadLocalSettings();
        const merged = pickSettings(r.settings);
        // Se o servidor ainda tem configurações padrão, leva as preferências locais para a conta.
        const serverIsDefault = JSON.stringify(merged) === JSON.stringify(pickSettings(null));
        const finalSettings = serverIsDefault ? local : merged;
        applySettings(finalSettings);
        persistLocalSettings(finalSettings);
        if (serverIsDefault) api.saveSettings(finalSettings).catch(() => {});
      }
    }],
    ['Carregando seus partidos...', async () => {
      if (store.user) store.parties = (await api.listParties()).parties;
    }],
    ['Preparando a interface...', async () => {}],
  ];
  const total = steps.length;
  let done = 0;
  setProgress(0, total, steps[0][0]);
  for (const [label, fn] of steps) {
    setProgress(done, total, label);
    await fn();
    done += 1;
    setProgress(done, total, label);
  }
  await minDelay;
  result.user = store.user;
  return result;
}
