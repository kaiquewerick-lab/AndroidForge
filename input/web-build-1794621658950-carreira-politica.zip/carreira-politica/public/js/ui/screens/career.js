// MINHA CARREIRA: situação do personagem, apoio, fama, dinheiro, cargo, ações pessoais e partido.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { EXISTING_PARTIES } from '../../game/offices.js';
import { go } from '../router.js';
import { shell, act, card, stat, fmtInt, fmtDec, fmtMoney, requireCareer } from '../game.js';
import { onLeave } from '../router.js';
import { stopClock } from '../../core/clock.js';

const PERSONAL = [
  ['comer', 'Comer uma refeição', 'R$ 15'],
  ['beber', 'Beber água', 'R$ 3'],
  ['descansar', 'Descansar', 'grátis'],
  ['trabalhar', 'Trabalhar (recebe pagamento)', 'renda de R$ 1.200'],
  ['militancia', 'Fazer militância no bairro', '+300 de apoio'],
];

export function renderCareer(params = {}) {
  if (params.career) store.career = params.career;
  if (!requireCareer()) return;
  stopClock();
  onLeave(stopClock);
  const c = store.career;
  const s = c.summary || {};
  const camp = s.campaign || {};
  const office = s.office;
  const party = c.party ? `${esc(c.party.name)} (${esc(c.party.acronym)} · ${esc(c.party.number)})` : 'Independente';
  const cargo = office ? esc(office.name) : 'Cidadão(ã)';
  const mandate = office ? `${fmtInt(Math.ceil(office.mandateLeft / 30))} mês(es) de mandato` : 'Sem cargo';
  const next = s.nextElection ? `Próxima eleição: ${esc(s.nextElection.date)}` : '';

  const body = `
    <section class="hero-card">
      <div>
        <p class="eyebrow">${esc(s.date || '')}</p>
        <h2>${esc(c.character.firstName)} ${esc(c.character.lastName)}</h2>
        <p class="muted">${cargo} · ${party}</p>
        <p class="small">${esc(c.electoral?.stage || 'Fora de eleição')} · ${mandate}</p>
        <p class="small muted">${next}</p>
      </div>
    </section>

    <section class="stat-grid" aria-label="Indicadores principais">
      ${stat('Apoio popular', fmtInt(c.support), 'número de apoiadores (inteiro, nunca negativo)')}
      ${stat('Fama', fmtDec(c.fame), camp.nivelFama || '')}
      ${stat('Aprovação', fmtDec(c.approval) + '%', 'opinião sobre o seu trabalho')}
      ${stat('Dinheiro pessoal', fmtMoney(c.money), 'sua conta')}
      ${stat('Dinheiro de campanha', fmtMoney(c.campaignFund), 'só para campanhas')}
      ${stat('Dinheiro do partido', fmtMoney(c.partyFund), c.party ? 'do seu partido' : 'sem partido')}
    </section>

    <section class="two-col">
      ${card('Seu estado', `
        <ul class="meter-list">
          ${meter('Saúde', c.health)}${meter('Fome', 100 - c.hunger, 'menos fome é melhor')}${meter('Sede', c.thirst)}
        </ul>
        <p class="small muted">Os valores de saúde, fome e sede afetam sua energia para a campanha.</p>`)}
      ${card('Ações do dia a dia', `
        <div class="action-grid">
          ${PERSONAL.map(([key, label, cost]) => `<button class="btn" type="button" data-act="${key}" data-payload="{}">${esc(label)}<span class="muted small">${esc(cost)}</span></button>`).join('')}
        </div>
        <p class="small muted" id="personal-msg" role="status"></p>`)}
    </section>

    <section class="two-col">
      ${card('Partido', `
        <form id="party-form" class="inline-form">
          <label class="field"><span>Trocar de partido</span>
            <select name="partyId">${EXISTING_PARTIES.filter((p) => p.id !== c.partyId).map((p) => `<option value="${esc(p.id)}">${esc(p.name)} (${esc(p.acronym)})</option>`).join('')}</select>
          </label>
          <label class="check"><input type="checkbox" name="confirm"> Entendo que trocar de partido durante um mandato legislativo faz perder o cargo.</label>
          <button class="btn btn-primary" type="submit">Trocar de partido</button>
        </form>
        <p class="small muted">Você também pode criar um partido no menu principal.</p>`)}
      ${card('Encerrar carreira', `
        <p class="small muted">Encerrar é definitivo: a partida fica somente para consulta.</p>
        <form id="end-form" class="inline-form">
          <label class="check"><input type="checkbox" name="confirm" required> Confirmo que quero encerrar a carreira.</label>
          <button class="btn btn-danger" type="submit">Encerrar carreira</button>
        </form>`, 'danger-card')}
    </section>

    ${card('Histórico recente', `
      <ol class="timeline">
        ${(c.careerLog || []).slice(-15).reverse().map((l) => `<li><span class="muted small">${esc(l.date)}</span> ${esc(l.text)}</li>`).join('') || '<li class="muted">Sua história começa agora.</li>'}
      </ol>`)}`;

  shell('career', 'Minha carreira', body, c.narrative?.intro || '');

  document.querySelectorAll('[data-act]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act(b.dataset.act, {});
    if (res) renderCareer();
  }));

  document.getElementById('party-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.currentTarget;
    if (!f.elements.confirm.checked && c.office?.id && ['deputado_federal', 'deputado_estadual', 'vereador', 'senador'].includes(c.office.id)) {
      return toast('Marque a confirmação para trocar de partido durante o mandato.', 'error');
    }
    const res = await act('trocarPartido', { partyId: f.elements.partyId.value, confirm: f.elements.confirm.checked });
    if (res) { toast('Filiação alterada.', 'ok'); renderCareer(); }
  });

  document.getElementById('end-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!e.currentTarget.elements.confirm.checked) return toast('Confirme o encerramento.', 'error');
    const res = await act('encerrarCarreira', { confirm: true });
    if (res) { toast('Carreira encerrada.', 'info'); renderCareer(); }
  });
}

function meter(label, value, hint = '') {
  const v = Math.max(0, Math.min(100, Math.round(Number(value) || 0)));
  return `<li><span>${esc(label)}</span><div class="stat-bar" role="meter" aria-label="${esc(label)}" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${v}"><div class="stat-fill" style="width:${v}%"></div></div><span class="muted small">${v}${hint ? ` · ${esc(hint)}` : ''}</span></li>`;
}
