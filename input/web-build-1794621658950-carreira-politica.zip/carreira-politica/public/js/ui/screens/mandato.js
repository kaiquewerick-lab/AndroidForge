// MANDATO E CALENDÁRIO: velocidade do tempo, decisões pendentes, sessões legislativas,
// administração, finanças em contas separadas, aprovação e promessas de campanha.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { onLeave } from '../router.js';
import { SPEEDS, setSpeed, currentSpeed, stopClock, onClock, pendingCount } from '../../core/clock.js';
import { PROJECTS, INDICATOR_KEYS, INDICATOR_LABELS } from '../../game/offices.js';
import { lineChart } from '../charts.js';
import { shell, act, card, stat, table, fmtInt, fmtDec, fmtMoney, readForm, requireCareer } from '../game.js';

const CAT_LABEL = {
  receitas: 'Receitas', compras: 'Compras', fabricacao: 'Fabricação', impressao: 'Impressão',
  publicidade: 'Publicidade', manutencao: 'Manutenção', investimentos: 'Investimentos', outros: 'Outros',
};
const LEGISLATIVE = ['vereador', 'deputado_estadual', 'deputado_federal', 'senador'];
const EXECUTIVE = { prefeito: 'municipal', governador: 'estadual', presidente: 'federal' };

let lastPending = -1;

export function renderMandato() {
  if (!requireCareer()) return;
  const c = store.career;
  const s = c.summary || {};
  const office = c.office;
  const officeName = s.office?.name || null;
  const legislative = office && LEGISLATIVE.includes(office.id);
  const scope = office && EXECUTIVE[office.id];
  const left = s.office ? Math.max(0, Math.ceil(s.office.mandateLeft / 30)) : 0;
  const pending = pendingCount(c);
  lastPending = pending;

  const clock = `
    <section class="clock-card" aria-label="Calendário e velocidade do tempo">
      <div>
        <p class="eyebrow">Data no jogo</p>
        <h2 id="game-date">${esc(s.date || '—')}</h2>
        <p class="muted small">${officeName ? `Mandato de ${esc(officeName)}: cerca de ${fmtInt(left)} mês(es) restante(s)` : 'Você não ocupa cargo agora.'}</p>
        <p class="small muted">${esc(c.electoral?.stage || '')}${s.nextElection ? ` · Próxima eleição: ${esc(s.nextElection.date)}` : ''}</p>
      </div>
      <div class="speed-box">
        <div class="speed-buttons" role="group" aria-label="Velocidade">
          ${Object.entries(SPEEDS).map(([k, v]) => `<button type="button" class="btn speed-btn" data-speed="${k}" aria-pressed="${currentSpeed() === k}">${esc(v.label)}</button>`).join('')}
        </div>
        <p class="small" id="clock-status" role="status">${clockText(pending)}</p>
      </div>
    </section>`;

  const events = (c.events || []).filter((e) => e.status === 'pendente').map((ev) => card(
    ev.title,
    `<p>${esc(ev.text)}</p>
     <div class="action-grid">${ev.options.map((label, i) => `<button class="btn" type="button" data-event="${esc(ev.id)}" data-option="${i}">${esc(label)}</button>`).join('')}</div>
     <p class="small muted">Prazo: ${fmtInt(Math.max(0, ev.deadline - c.day))} dia(s). Sem decisão, a primeira opção é aplicada.</p>`,
    'event-card',
  )).join('');

  const bills = (c.bills || []).slice(-12).reverse().map((b) => {
    const open = b.status === 'aberto' && legislative;
    const vote = open ? `<div class="vote-row">
        <button class="btn" type="button" data-vote="favor" data-bill="${esc(b.id)}">A favor</button>
        <button class="btn" type="button" data-vote="contra" data-bill="${esc(b.id)}">Contra</button>
        <button class="btn" type="button" data-vote="abstencao" data-bill="${esc(b.id)}">Abstenção</button>
      </div>` : '';
    const tally = b.tally ? `<p class="small">Placar: ${fmtInt(b.tally.favor)} a favor, ${fmtInt(b.tally.contra)} contra, ${fmtInt(b.tally.abstencao)} abstenções.</p>` : '';
    return `<article class="bill ${esc(b.status)}">
      <header><strong>${esc(b.title)}</strong> <span class="badge">${esc(b.status)}</span></header>
      <p class="small muted">Setor: ${esc(INDICATOR_LABELS[b.sector] || b.sector)}${b.status === 'aberto' ? ` · vota até o dia ${fmtInt(b.deadline)}` : ''}${b.playerVote ? ` · seu voto: ${esc(b.playerVote)}` : ''}</p>
      ${tally}${vote}
    </article>`;
  }).join('');

  const sessions = card('Sessões legislativas', legislative
    ? `<p class="small muted">Vote antes do prazo. Sem voto, conta como abstenção.</p>
       <div class="bill-list">${bills || '<p class="muted">Nenhuma pauta ainda.</p>'}</div>
       ${office.id === 'deputado_federal' || office.id === 'deputado_estadual' ? `<form id="amend-form" class="inline-form">
         <label class="field"><span>Propor emenda para o setor</span><select name="sector">${INDICATOR_KEYS.map((k) => `<option value="${k}">${esc(INDICATOR_LABELS[k])}</option>`).join('')}</select></label>
         <button class="btn" type="submit">Propor emenda</button></form>` : ''}`
    : '<p class="muted">Você precisa de um mandato legislativo (vereador, deputado ou senador) para votar pautas.</p>', 'wide');

  const projects = scope ? PROJECTS[scope] : [];
  const admin = card('Administração', scope ? `
    <p class="small muted">Obras são pagas de uma vez e entregam efeitos ao concluir. Programas mensais custam todo mês e podem ser cancelados.</p>
    <div class="action-grid">${projects.map((p) => `<button class="btn" type="button" data-project="${esc(p.key)}">${esc(p.name)}<span class="muted small">${p.capital ? `obra: ${fmtMoney(p.capital)} · ${p.days} dias` : `mensal: ${fmtMoney(p.monthly)}`}</span></button>`).join('')}</div>
    <h4>Projetos</h4>
    ${table(['Projeto', 'Situação', ''], (c.projects || []).filter((p) => p.status !== 'cancelado').slice(-12).reverse().map((p) => [
      esc(p.name),
      esc(p.kind === 'capital' ? (p.status === 'andamento' ? `obra: faltam ${p.daysLeft} dia(s)` : 'concluída') : p.status),
      p.kind === 'monthly' ? `<button class="btn btn-small" type="button" data-cancel="${esc(p.id)}">Cancelar</button>` : '',
    ]))}
    ${office.id === 'presidente' ? '<p><button class="btn btn-primary" type="button" data-go="presidencia">Abrir o painel do governo federal</button></p>' : ''}`
    : '<p class="muted">Somente prefeito, governador e presidente administram projetos.</p>', 'wide');

  const balances = [
    ['Dinheiro pessoal', c.money], ['Dinheiro de campanha', c.campaignFund], ['Dinheiro do partido', c.partyFund],
    ['Orçamento municipal', c.publicBudgets.municipal], ['Orçamento estadual', c.publicBudgets.estadual], ['Orçamento federal', c.publicBudgets.federal],
  ];
  const ledgerRows = (c.ledger || []).slice(-40).reverse().map((l) => [
    `dia ${fmtInt(l.day)}`, esc(l.desc), esc(CAT_LABEL[l.category] || l.category),
    l.type === 'receita' ? `<span class="pos">+${fmtMoney(l.amount)}</span>` : `<span class="neg">−${fmtMoney(l.amount)}</span>`,
    esc(accountName(l.account)),
  ]);
  const finances = card('Finanças (contas separadas)', `
    <div class="stat-grid">${balances.map(([l, v]) => stat(l, fmtMoney(v))).join('')}</div>
    <p class="small muted">Cada conta é separada: dinheiro público não financia campanha pessoal. Saldos nunca ficam negativos.</p>
    <h4>Extrato (últimos 40 lançamentos)</h4>
    ${table(['Quando', 'Descrição', 'Categoria', 'Valor', 'Conta'], ledgerRows)}`, 'wide');

  const approval = card('Aprovação', `
    ${lineChart({ series: [{ label: 'Aprovação (%)', color: '#f59e0b', points: (c.approvalHistory || []).map((p) => ({ x: p.day, y: p.value })) }], yMin: 0, yMax: 100, title: 'Evolução da aprovação' })}
    <p class="small">Aprovação atual: <strong>${fmtDec(c.approval)}%</strong></p>`, 'wide');

  const promises = office ? card('Promessas de campanha', `
    <ul class="plain-list">${(office.promises || []).map((p) => {
      const cur = c.indicators[p.indicator] ?? 0;
      return `<li>${esc(INDICATOR_LABELS[p.indicator] || p.indicator)}: meta ${fmtInt(p.target)} · atual ${fmtDec(cur)} ${cur >= p.target ? '<span class="badge ok">cumprida</span>' : ''}</li>`;
    }).join('')}</ul>
    <p class="small muted">As promessas são cobradas ao fim do mandato e afetam a aprovação.</p>`) : '';

  const resign = office ? card('Renúncia', `
    <form id="resign-form" class="inline-form"><button class="btn btn-danger" type="submit">Renunciar ao cargo</button></form>`) : '';

  const log = card('Registro da carreira', `
    <ol class="timeline">${(c.careerLog || []).slice(-25).reverse().map((l) => `<li><span class="muted small">${esc(l.date)}</span> ${esc(l.text)}</li>`).join('') || '<li class="muted">Nenhum registro ainda.</li>'}</ol>`, 'wide');

  shell('mandato', 'Mandato e calendário', `
    ${clock}
    ${events ? `<section class="pending-block" aria-label="Decisões pendentes">${events}</section>` : ''}
    <section class="two-col">${sessions}${admin}</section>
    <section class="two-col">${finances}${approval}</section>
    <section class="two-col">${promises}${resign}</section>
    ${log}`);

  bindMandato();
  onLeave(stopClock);
  const offClock = onClock(() => {
    const cur = store.career;
    const el = document.getElementById('clock-status');
    if (el) el.textContent = clockText(pendingCount(cur));
    const dateEl = document.getElementById('game-date');
    if (dateEl && cur.summary?.date) dateEl.textContent = cur.summary.date;
    document.querySelectorAll('[data-speed]').forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.speed === currentSpeed())));
    // Decisões novas aparecem na tela: recarrega o conteúdo quando a contagem muda.
    if (pendingCount(cur) !== lastPending) renderMandato();
  });
  onLeave(offClock);
}

function clockText(pending) {
  if (pending) return `Tempo pausado: há ${pending} decisão(ões) pendente(s).`;
  const speed = currentSpeed();
  return speed === 'pausado' ? 'Tempo pausado.' : `Tempo em velocidade: ${SPEEDS[speed].label}.`;
}

function accountName(a) {
  if (a === 'pessoal') return 'pessoal';
  if (a === 'campanha') return 'campanha';
  if (a === 'partido') return 'partido';
  return `orçamento ${String(a).split(':')[1]}`;
}

function bindMandato() {
  document.querySelectorAll('[data-speed]').forEach((b) => b.addEventListener('click', () => setSpeed(b.dataset.speed)));
  document.querySelectorAll('[data-event]').forEach((b) => b.addEventListener('click', async () => {
    setSpeed('pausado');
    const res = await act('decidirEvento', { eventId: b.dataset.event, option: Number(b.dataset.option) });
    if (res) { toast('Decisão registrada.', 'ok'); renderMandato(); }
  }));
  document.querySelectorAll('[data-vote]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('votar', { billId: b.dataset.bill, vote: b.dataset.vote });
    if (res) { toast('Voto registrado.', 'ok'); renderMandato(); }
  }));
  document.querySelectorAll('[data-project]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('iniciarProjeto', { key: b.dataset.project });
    if (res) { toast('Projeto iniciado.', 'ok'); renderMandato(); }
  }));
  document.querySelectorAll('[data-cancel]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('cancelarProjeto', { projectId: b.dataset.cancel });
    if (res) { toast('Programa cancelado.', 'info'); renderMandato(); }
  }));
  document.getElementById('amend-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('proporEmenda', readForm(e.currentTarget));
    if (res) { toast('Emenda proposta.', 'ok'); renderMandato(); }
  });
  document.getElementById('resign-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!confirm('Tem certeza que quer renunciar ao cargo?')) return;
    const res = await act('renunciar', {});
    if (res) { toast('Você renunciou ao cargo.', 'info'); renderMandato(); }
  });
}
