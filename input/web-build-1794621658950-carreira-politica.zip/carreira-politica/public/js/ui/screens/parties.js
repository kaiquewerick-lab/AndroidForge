// Partidos: lista dos partidos do jogador e editor completo com prévia em tempo real.
import { setView, $, $$, esc, toast, readImageFile, formatDate, todayIso } from '../../core/dom.js';
import { api, ApiError } from '../../core/api.js';
import { store } from '../../core/state.js';
import { validateParty } from '../../core/validate.js';
import { PARTY_DEFAULT, SHAPE_LABELS, ICON_LABELS, FLAG_LABELS, PARTY_PALETTE, MAX_UPLOAD_CHARS } from '../../game/partyData.js';
import { logoSvg as partyLogo, flagSvg } from '../../game/partySvg.js';
import { header, bindGo } from '../components.js';
import { go } from '../router.js';

export async function renderParties() {
  if (!store.user) return go('auth');
  try {
    store.parties = (await api.listParties()).parties;
  } catch (err) {
    toast(err.message, 'error');
  }
  setView(`
    <section class="screen">
      ${header('Criar partido')}
      <div class="party-list-head">
        <p class="muted">Crie quantos partidos quiser e edite-os quando precisar.</p>
        <button class="btn btn-primary" type="button" id="new-party">Novo partido</button>
      </div>
      ${store.parties.length ? `<div class="party-grid">${store.parties.map(partyCard).join('')}</div>`
        : '<div class="card empty"><p>Você ainda não criou nenhum partido.</p></div>'}
    </section>`);
  bindGo(go);
  $('#new-party').addEventListener('click', () => go('party-editor', { id: null }));
  $$('[data-edit]').forEach((b) => b.addEventListener('click', () => go('party-editor', { id: b.dataset.edit })));
}

function partyCard(p) {
  return `<article class="card party-card">
    <div class="party-card-art">${flagSvg(p, { label: `Bandeira do ${p.name}` })}</div>
    <div class="party-card-body">
      <h3>${esc(p.name)} <span class="muted">(${esc(p.acronym)})</span></h3>
      <p class="small">Número ${esc(p.number)} · Fundado em ${formatDate(p.foundedAt)}</p>
      <p class="small muted">${p.members} filiado(s) · popularidade ${p.popularity}</p>
      <button class="btn btn-secondary" type="button" data-edit="${esc(p.id)}">Editar partido</button>
    </div>
  </article>`;
}

// ---------------- Editor ----------------
export async function renderPartyEditor({ id = null } = {}) {
  if (!store.user) return go('auth');
  let existing = null;
  if (id) {
    existing = store.parties.find((p) => p.id === id);
    if (!existing) {
      try {
        store.parties = (await api.listParties()).parties;
        existing = store.parties.find((p) => p.id === id);
      } catch (err) {
        toast(err.message, 'error');
      }
    }
    if (!existing) {
      toast('Partido não encontrado.', 'error');
      return go('parties');
    }
  }

  const draft = existing
    ? structuredClone(existing)
    : { ...structuredClone(PARTY_DEFAULT), name: '', acronym: '', number: '', motto: '', foundedAt: todayIso() };

  setView(`
    <section class="screen">
      ${header(existing ? `Editar ${existing.name}` : 'Novo partido', { back: 'parties' })}
      <div class="editor-layout">
        <aside class="preview card" aria-label="Prévia do partido">
          <h3>Prévia em tempo real</h3>
          <div id="preview-logo" class="preview-logo"></div>
          <div id="preview-flag" class="preview-flag"></div>
          <p class="small center" id="preview-name"></p>
        </aside>

        <form id="party-form" class="card editor-form" novalidate>
          <fieldset>
            <legend>Informações do partido</legend>
            ${textField('name', 'Nome do partido', draft.name, 'Exemplo: Partido Liberal', 60)}
            ${textField('acronym', 'Sigla', draft.acronym, 'Exemplo: PL', 8)}
            ${textField('number', 'Número eleitoral', draft.number, 'Exemplo: 22', 5, 'numeric')}
            <label class="field"><span>Lema histórico</span>
              <textarea name="motto" id="motto" maxlength="140" rows="2" placeholder='Exemplo: "Brasil acima de tudo, Deus acima de todos."'>${esc(draft.motto)}</textarea>
            </label>
            <label class="field"><span>Data de fundação</span>
              <input type="date" id="foundedAt" value="${esc(draft.foundedAt)}" ${existing ? 'disabled' : ''} max="${todayIso()}">
              ${existing ? '<small class="muted">A data de fundação não pode ser alterada.</small>' : ''}
            </label>
            <p class="field-error" id="err-party" role="alert"></p>
          </fieldset>

          <fieldset>
            <legend>Imagem do partido</legend>
            <div class="segmented" role="radiogroup" aria-label="Tipo de símbolo">
              ${[['shape', 'Símbolos'], ['icon', 'Ícones'], ['combo', 'Combinação'], ['upload', 'Imagem própria']]
                .map(([v, l]) => `<label><input type="radio" name="symtype" value="${v}" ${draft.symbol.type === v ? 'checked' : ''}><span>${l}</span></label>`).join('')}
            </div>
            <div id="sym-shape" class="choice-grid" ${['shape', 'combo'].includes(draft.symbol.type) ? '' : 'hidden'}>
              ${Object.entries(SHAPE_LABELS).map(([k, l]) => choiceBtn('shape', k, l, draft.symbol.shape)).join('')}
            </div>
            <div id="sym-icon" class="choice-grid" ${['icon', 'combo'].includes(draft.symbol.type) ? '' : 'hidden'}>
              ${Object.entries(ICON_LABELS).map(([k, l]) => choiceBtn('icon', k, l, draft.symbol.icon)).join('')}
            </div>
            <div id="sym-upload" class="upload-row" ${draft.symbol.type === 'upload' ? '' : 'hidden'}>
              <label class="btn btn-secondary">Escolher imagem
                <input type="file" id="upload" accept="image/png,image/jpeg,image/webp" hidden>
              </label>
              <small class="muted">PNG, JPEG ou WEBP de até 250 KB.</small>
            </div>
          </fieldset>

          <fieldset>
            <legend>Cores e bandeira</legend>
            <div class="color-row">
              <label class="field inline"><span>Cor primária</span><input type="color" id="primary" value="${esc(draft.primary)}"></label>
              <label class="field inline"><span>Cor secundária</span><input type="color" id="secondary" value="${esc(draft.secondary)}"></label>
            </div>
            <div class="swatches" aria-label="Paleta sugerida">
              ${PARTY_PALETTE.map((c) => `<button type="button" class="swatch" data-swatch="${c}" style="background:${c}" aria-label="Usar cor ${c}"></button>`).join('')}
            </div>
            <label class="field"><span>Padrão da bandeira</span>
              <select id="flagPattern">${Object.entries(FLAG_LABELS).map(([k, l]) => `<option value="${k}" ${draft.flagPattern === k ? 'selected' : ''}>${l}</option>`).join('')}</select>
            </label>
          </fieldset>

          <fieldset>
            <legend>Ideologia</legend>
            ${slider('economic', 'Economia', 'Estatal', 'Livre mercado', draft.ideology.economic)}
            ${slider('social', 'Costumes', 'Tradicional', 'Progressista', draft.ideology.social)}
          </fieldset>

          <div class="form-actions">
            <button class="btn btn-ghost" type="button" data-go="parties">Cancelar</button>
            <button class="btn btn-primary" type="submit" id="save-party">${existing ? 'Salvar alterações' : 'Criar partido'}</button>
          </div>
        </form>
      </div>
    </section>`);

  bindGo(go);
  bindEditor(draft, existing);
}

function textField(id, label, value, placeholder, max, mode = 'text') {
  return `<label class="field"><span>${label}</span>
    <input id="${id}" name="${id}" value="${esc(value)}" placeholder="${esc(placeholder)}" maxlength="${max}" inputmode="${mode}" autocomplete="off"></label>`;
}

function choiceBtn(kind, key, label, selected) {
  return `<button type="button" class="choice ${selected === key ? 'selected' : ''}" data-kind="${kind}" data-value="${key}" aria-pressed="${selected === key}">${label}</button>`;
}

function slider(key, label, left, right, value) {
  return `<label class="field"><span>${label}: <em>${left}</em> ↔ <em>${right}</em></span>
    <input type="range" min="0" max="100" value="${value}" id="ideo-${key}"></label>`;
}

function bindEditor(draft, existing) {
  const form = $('#party-form');
  const errBox = $('#err-party');

  const refresh = () => {
    $('#preview-logo').innerHTML = partyLogo(draft, { label: 'Logotipo do partido' });
    $('#preview-flag').innerHTML = flagSvg(draft, { label: 'Bandeira do partido' });
    $('#preview-name').textContent = draft.name ? `${draft.name} (${draft.acronym || '—'}) · ${draft.number || '—'}` : 'Seu partido aparecerá aqui';
  };

  const sync = () => {
    draft.name = $('#name').value;
    draft.acronym = $('#acronym').value.toUpperCase();
    draft.number = $('#number').value.replace(/\D/g, '');
    draft.motto = $('#motto').value;
    draft.primary = $('#primary').value;
    draft.secondary = $('#secondary').value;
    draft.flagPattern = $('#flagPattern').value;
    draft.ideology = { economic: Number($('#ideo-economic').value), social: Number($('#ideo-social').value) };
    refresh();
  };
  form.addEventListener('input', sync);
  form.addEventListener('change', sync);

  $('#number').addEventListener('input', (e) => { e.target.value = e.target.value.replace(/\D/g, ''); });
  $('#acronym').addEventListener('input', (e) => { e.target.value = e.target.value.toUpperCase(); });

  // Tipo de símbolo
  document.querySelectorAll('input[name=symtype]').forEach((r) => r.addEventListener('change', () => {
    draft.symbol.type = r.value;
    $('#sym-shape').hidden = !['shape', 'combo'].includes(r.value);
    $('#sym-icon').hidden = !['icon', 'combo'].includes(r.value);
    $('#sym-upload').hidden = r.value !== 'upload';
    if (r.value !== 'upload') delete draft.symbol.dataUrl;
    refresh();
  }));

  // Escolha de forma e ícone
  $$('.choice').forEach((btn) => btn.addEventListener('click', () => {
    const kind = btn.dataset.kind;
    draft.symbol[kind] = btn.dataset.value;
    $$(`.choice[data-kind="${kind}"]`).forEach((b) => {
      const on = b === btn;
      b.classList.toggle('selected', on);
      b.setAttribute('aria-pressed', String(on));
    });
    refresh();
  }));

  // Imagem própria
  $('#upload').addEventListener('change', async (e) => {
    try {
      draft.symbol = { type: 'upload', dataUrl: await readImageFile(e.target.files[0], MAX_UPLOAD_CHARS) };
      toast('Imagem carregada.', 'ok');
      refresh();
    } catch (err) {
      toast(err.message, 'error');
    }
  });

  // Paleta: aplica a cor à última cor selecionada (primária por padrão).
  let activeColor = 'primary';
  $('#primary').addEventListener('focus', () => { activeColor = 'primary'; });
  $('#secondary').addEventListener('focus', () => { activeColor = 'secondary'; });
  $$('[data-swatch]').forEach((b) => b.addEventListener('click', () => {
    $(`#${activeColor}`).value = b.dataset.swatch;
    draft[activeColor] = b.dataset.swatch;
    refresh();
  }));

  // Salvar
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    sync();
    const payload = {
      name: draft.name,
      acronym: draft.acronym,
      number: draft.number,
      motto: draft.motto,
      foundedAt: existing ? existing.foundedAt : draft.foundedAt,
      symbol: draft.symbol,
      primary: draft.primary,
      secondary: draft.secondary,
      flagPattern: draft.flagPattern,
      ideology: draft.ideology,
    };
    const errors = validateParty(payload);
    errBox.textContent = errors[0] || '';
    if (errors.length) return;
    const btn = $('#save-party');
    btn.disabled = true;
    try {
      if (existing) await api.updateParty(existing.id, payload);
      else await api.createParty(payload);
      store.parties = (await api.listParties()).parties;
      toast(existing ? 'Partido atualizado.' : 'Partido criado e salvo na sua conta.', 'ok');
      go('parties');
    } catch (err) {
      errBox.textContent = err instanceof ApiError ? err.message : 'Erro inesperado ao salvar.';
    } finally {
      btn.disabled = false;
    }
  });

  refresh();
}
