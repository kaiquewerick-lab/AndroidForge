// MINHA CAMPANHA: apoio, fama, dinheiro de campanha, campanhas digitais e atividades públicas.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { lineChart } from '../charts.js';
import { shell, act, card, stat, table, fmtInt, fmtDec, fmtMoney, readForm, requireCareer } from '../game.js';
import { DIGITAL, ATIVIDADES } from '../../game/campaignData.js';

const CAT = {
  compras: 'Compras', fabricacao: 'Fabricação', impressao: 'Impressão', publicidade: 'Publicidade',
  manutencao: 'Manutenção', investimentos: 'Investimentos', receitas: 'Receitas', outros: 'Outros',
};

export function renderCampanha() {
  if (!requireCareer()) return;
  const c = store.career;
  const cp = c.summary?.campaign || {};
  const phone = c.inventory.find((i) => i.id === c.equippedPhone);
  const digital = (c.digital || []).slice().reverse();
  const activeDigital = digital.filter((d) => d.status === 'ativa').length;
  const byCat = Object.entries(cp.gastosPorCategoria || {}).map(([k, v]) => [CAT[k] || k, fmtMoney(v)]);

  const overview = card('Resumo da campanha', `
    <div class="stat-grid">
      ${stat('Apoio popular', fmtInt(cp.apoio ?? c.support))}
      ${stat('Fama', `${fmtDec(cp.fama ?? c.fame)} (${esc(cp.nivelFama || '')})`)}
      ${stat('Dinheiro de campanha', fmtMoney(cp.dinheiroCampanha ?? c.campaignFund))}
      ${stat('Gasto de campanha', fmtMoney(cp.gastosCampanha ?? 0))}
      ${stat('Santinhos distribuídos', fmtInt(cp.santinhosDistribuidos ?? 0))}
      ${stat('Banners instalados', fmtInt(cp.bannersInstalados ?? 0))}
    </div>
    <p class="small muted">O dinheiro de campanha é separado do seu dinheiro pessoal. Use a aba Fábrica para produzir materiais.</p>
    <h4>Gastos por categoria</h4>
    ${byCat.length ? table(['Categoria', 'Total'], byCat) : '<p class="muted">Nenhum gasto de campanha ainda.</p>'}`, 'wide');

  const charts = card('Evolução', `
    ${lineChart({ series: [{ label: 'Apoio', color: '#22c55e', points: (c.supportHistory || []).map((p) => ({ x: p.day, y: p.value })) }], yMin: 0, title: 'Apoio popular' })}
    ${lineChart({ series: [{ label: 'Fama', color: '#a855f7', points: (c.fameHistory || []).map((p) => ({ x: p.day, y: p.value })) }], yMin: 0, yMax: 100, title: 'Fama' })}`, 'wide');

  const digitalForm = `
    <form id="digital-form" class="inline-form">
      <label class="field"><span>Orçamento diário (R$ ${fmtInt(DIGITAL.orcamentoMin)} a R$ ${fmtInt(DIGITAL.orcamentoMax)})</span>
        <input name="budget" type="number" min="${DIGITAL.orcamentoMin}" max="${DIGITAL.orcamentoMax}" value="500" required></label>
      <label class="field"><span>Duração</span>
        <select name="days">${DIGITAL.duracoesDias.map((d) => `<option value="${d}">${d} dias</option>`).join('')}</select></label>
      <button class="btn btn-primary" type="submit" ${phone ? '' : 'disabled'}>Iniciar campanha digital</button>
    </form>
    ${phone ? '' : '<p class="notice warn">Equipe um celular no Inventário para administrar campanhas digitais.</p>'}
    <p class="small muted">Campanhas digitais têm limite de ${DIGITAL.maxAtivas} ao mesmo tempo. Ativas agora: ${activeDigital}.</p>`;

  const digitalList = table(['Início', 'Orçamento/dia', 'Duração', 'Situação', 'Gasto', 'Apoio gerado', ''], digital.slice(0, 8).map((d) => [
    `dia ${fmtInt(d.startDay)}`, fmtMoney(d.budget), `${d.days} dias`, esc(d.status), fmtMoney(d.spent), fmtInt(d.gained),
    d.status === 'ativa' ? `<button class="btn btn-small" type="button" data-stop="${esc(d.id)}">Encerrar</button>` : '',
  ]));

  const digitalCard = card('Campanha digital', `${digitalForm}<h4>Histórico</h4>${digitalList}`, 'wide');

  const activities = card('Atividades públicas', `
    <p class="small muted">Até ${fmtInt(3)} atividades por dia. Cada atividade pode gerar fama e apoio, e algumas custam dinheiro de campanha.</p>
    <div class="action-grid">
      ${Object.entries(ATIVIDADES).map(([k, a]) => `<button class="btn" type="button" data-activity="${k}">${esc(a.label)}
        <span class="muted small">${a.custo ? `custo ${fmtMoney(a.custo)}` : 'sem custo'}${a.janela ? ' · só na janela eleitoral' : ''}${a.cargo ? ' · exige cargo' : ''}</span></button>`).join('')}
    </div>`, 'wide');

  const recent = card('Últimas atividades e conversas', `
    ${table(['Dia', 'Pessoa', 'Tema', 'Reação', 'Ganho'], (c.conversations || []).slice(-10).reverse().map((v) => [
      `dia ${fmtInt(v.day)}`, esc(v.citizen), esc(v.topic), esc(v.reaction), `+${fmtInt(v.gain)}`,
    ]))}`, 'wide');

  shell('campanha', 'Minha campanha', `
    <section class="two-col">${overview}${charts}</section>
    <section class="two-col">${digitalCard}${activities}</section>
    ${recent}`);

  bindCampanha();
}

function bindCampanha() {
  document.getElementById('digital-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await act('campanhaDigital', readForm(e.currentTarget));
    if (res) { toast('Campanha digital iniciada.', 'ok'); renderCampanha(); }
  });
  document.querySelectorAll('[data-stop]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('pararCampanhaDigital', { digitalId: b.dataset.stop });
    if (res) { toast('Campanha encerrada.', 'info'); renderCampanha(); }
  }));
  document.querySelectorAll('[data-activity]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('atividade', { kind: b.dataset.activity });
    if (res) { toast('Atividade realizada.', 'ok'); renderCampanha(); }
  }));
}

