// LOJA DE CELULARES: compra com dinheiro pessoal. O celular equipado define a eficiência digital.
import { esc, toast } from '../../core/dom.js';
import { store as appStore } from '../../core/state.js';
import { shell, act, card, table, fmtInt, fmtMoney, requireCareer } from '../game.js';
import { PHONES } from '../../game/campaignData.js';

export function renderStore() {
  if (!requireCareer()) return;
  const c = appStore.career;
  const equipped = c.inventory.find((i) => i.id === c.equippedPhone);
  const rows = PHONES.map((p) => [
    `<strong>${esc(p.brand)} ${esc(p.model)}</strong>`,
    fmtMoney(p.price),
    `${p.camera}/10`,
    `${p.performance}/10`,
    `${fmtInt(p.storage)} GB`,
    `${p.connection}/10`,
    `${Math.round(p.efficiency * 100)}%`,
    `<button class="btn btn-small" type="button" data-buy="${esc(p.id)}" ${c.money < p.price ? 'disabled' : ''}>Comprar</button>`,
  ]);
  shell('loja', 'Loja de celulares', `
    <section class="two-col">
      ${card('Seu dinheiro pessoal', `<p class="stat-big">${fmtMoney(c.money)}</p>
        <p class="small muted">${equipped ? `Equipado: ${esc(equipped.name)}` : 'Nenhum celular equipado. A eficiência de campanha fica reduzida.'}</p>
        <p class="small muted">Celulares são comprados com dinheiro pessoal e equipados no Inventário. O preço não define sozinho a eficiência.</p>`)}
      ${card('Aparelhos', table(['Modelo', 'Preço', 'Câmera', 'Desempenho', 'Armazenamento', 'Conexão', 'Eficiência', ''], rows), 'wide')}
    </section>`);

  document.querySelectorAll('[data-buy]').forEach((b) => b.addEventListener('click', async () => {
    const res = await act('comprarCelular', { phoneId: b.dataset.buy });
    if (res) { toast('Celular comprado. Equipe no Inventário.', 'ok'); renderStore(); }
  }));
}
