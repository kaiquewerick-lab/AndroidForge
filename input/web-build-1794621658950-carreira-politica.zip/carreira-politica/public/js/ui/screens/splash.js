// Tela de apresentação da empresa (SATURNGAMES).
import { setView, $ } from '../../core/dom.js';
import { logoSvg } from '../../world/scenes.js';
import { go } from '../router.js';

export function renderSplash() {
  setView(`
    <section class="splash" id="splash" aria-label="Apresentação SaturnGames">
      <div class="splash-logo">${logoSvg({ cls: 'logo logo-big' })}</div>
      <h1 class="splash-name">SATURNGAMES</h1>
      <p class="splash-hint">toque para continuar</p>
    </section>`);

  const reduced = document.body.dataset.anim === 'off';
  let done = false;
  const finish = () => {
    if (done) return;
    done = true;
    go('loading');
  };
  const timer = setTimeout(finish, reduced ? 900 : 3800);
  const splash = $('#splash');
  splash.addEventListener('click', () => {
    clearTimeout(timer);
    finish();
  });
}
