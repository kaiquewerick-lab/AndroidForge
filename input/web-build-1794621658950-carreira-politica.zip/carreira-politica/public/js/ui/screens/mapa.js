// MAPA E CONVERSAS: regiões, pessoas por região, conversas com o eleitorado e deslocamento.
import { esc, toast } from '../../core/dom.js';
import { store } from '../../core/state.js';
import { shell, act, card, table, fmtInt, requireCareer, readForm } from '../game.js';
import { REGIONS, CITIZEN_TYPES, TOPICS, CONVERSATION } from '../../game/campaignData.js';
import { INDICATOR_KEYS, INDICATOR_LABELS } from '../../game/offices.js';

let selectedCitizen = null;

export function renderMapa() {
  if (!requireCareer()) return;
  const c = store.career;
  const here = c.regions.find((r) => r.id === c.currentRegion);

  const svg = `<svg class="campaign-map" viewBox="0 0 100 60" role="img" aria-label="Mapa da cidade dividido em regiões">
    ${REGIONS.map((r) => {
      const [x, y, w, h] = r.box;
      const cur = r.id === c.currentRegion;
      return `<g>
        <rect x="${x}" y="${y}" width="${w}" height="${h}" class="region${cur ? ' is-here' : ''}" data-region="${r.id}" tabindex="0" role="button" aria-label="Ir para ${esc(r.name)}"></rect>
        <text x="${x + w / 2}" y="${y + 4}" text-anchor="middle" class="region-label">${esc(r.name)}</text>
      </g>`;
    }).join('')}
    ${c.citizens.filter((p) => p.regionId === c.currentRegion).map((p) => `
      <circle cx="${p.x}" cy="${p.y}" r="1.6" class="citizen${selectedCitizen === p.id ? ' is-selected' : ''}" data-citizen="${esc(p.id)}" tabindex="0" role="button" aria-label="${esc(p.name)}"></circle>`).join('')}
  </svg>`;

  const regionButtons = REGIONS.map((r) => {
    const reg = c.regions.find((x) => x.id === r.id);
    return `<button class="btn${r.id === c.currentRegion ? ' is-on' : ''}" type="button" data-move="${r.id}" ${r.id === c.currentRegion ? 'disabled' : ''}>${esc(r.name)}<span class="muted small">${fmtInt(reg?.reached ?? 0)} alcançados de ${fmtInt(r.population)}</span></button>`;
  }).join('');

  const people = c.citizens.filter((p) => p.regionId === c.currentRegion);
  const today = c.day;
  const peopleRows = people.map((p) => {
    const cooling = p.lastTalkDay !== null && today - p.lastTalkDay < CONVERSATION.cooldownDias;
    return [
      `<button class="link" type="button" data-pick="${esc(p.id)}">${esc(p.name)}</button>`,
      esc(CITIZEN_TYPES[p.type].label),
      esc(INDICATOR_LABELS[CITIZEN_TYPES[p.type].interest] || CITIZEN_TYPES[p.type].interest),
      cooling ? `aguarde ${fmtInt(CONVERSATION.cooldownDias - (today - p.lastTalkDay))} dia(s)` : 'disponível',
    ];
  });

  const target = people.find((p) => p.id === selectedCitizen);
  const talkForm = target ? `
    <form id="talk-form" class="stack">
      <p><strong>${esc(target.name)}</strong> · ${esc(CITIZEN_TYPES[target.type].label)}</p>
      <label class="field"><span>Tema</span>
        <select name="topic">${Object.entries(TOPICS).map(([k, t]) => `<option value="${k}">${esc(t.label)}</option>`).join('')}</select></label>
      <label class="field"><span>Assunto de interesse</span>
        <select name="indicator">${INDICATOR_KEYS.map((k) => `<option value="${k}">${esc(INDICATOR_LABELS[k])}</option>`).join('')}</select></label>
      <label class="field"><span>O que você diz (opcional, até ${CONVERSATION.textoMax} caracteres)</span>
        <textarea name="reply" maxlength="${CONVERSATION.textoMax}" rows="3"></textarea></label>
      <input type="hidden" name="citizenId" value="${esc(target.id)}">
      <button class="btn btn-primary" type="submit" ${target.lastTalkDay !== null && today - target.lastTalkDay < CONVERSATION.cooldownDias ? 'disabled' : ''}>Conversar</button>
    </form>` : '<p class="muted">Escolha uma pessoa na região para conversar.</p>';

  const log = (c.conversations || []).slice(-12).reverse().map((v) => [
    `dia ${fmtInt(v.day)}`, esc(v.citizen), esc(v.topic), esc(v.reaction), v.reply ? esc(v.reply) : '—', `+${fmtInt(v.gain)}`,
  ]);

  shell('mapa', 'Mapa e conversas', `
    <section class="two-col">
      ${card(`Você está em: ${esc(here?.name || '')}`, `${svg}<p class="small muted">Clique numa região para caminhar até ela. Clique numa pessoa para conversar. Cada conversa leva ${CONVERSATION.cooldownDias} dias para ser repetida com a mesma pessoa.</p>`, 'wide')}
      ${card('Regiões', `<div class="action-grid">${regionButtons}</div>`)}
    </section>
    <section class="two-col">
      ${card('Pessoas nesta região', table(['Pessoa', 'Perfil', 'Interesse', 'Situação'], peopleRows))}
      ${card('Conversar', talkForm)}
    </section>
    ${card('Conversas recentes', table(['Dia', 'Pessoa', 'Tema', 'Reação', 'Resposta', 'Ganho'], log), 'wide')}`);

  bind();
}

function bind() {
  document.querySelectorAll('[data-move]').forEach((b) => b.addEventListener('click', async () => {
    selectedCitizen = null;
    const res = await act('mudarRegiao', { regionId: b.dataset.move });
    if (res) renderMapa();
  }));
  document.querySelectorAll('[data-region]').forEach((el) => el.addEventListener('click', () => {
    const id = el.dataset.region;
    if (id !== store.career.currentRegion) document.querySelector(`[data-move="${id}"]`)?.click();
  }));
  document.querySelectorAll('[data-citizen], [data-pick]').forEach((el) => el.addEventListener('click', () => {
    selectedCitizen = el.dataset.citizen || el.dataset.pick;
    renderMapa();
  }));
  document.getElementById('talk-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = readForm(e.currentTarget);
    const res = await act('conversar', data);
    if (res) {
      toast('Conversa registrada.', 'ok');
      renderMapa();
    }
  });
}
