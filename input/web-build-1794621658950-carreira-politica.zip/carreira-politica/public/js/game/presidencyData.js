// Dados da Parte 4 (Presidência, eleição nacional, governo federal e Congresso).
// Valores fictícios e configuráveis. Todo número usado pelo motor fica aqui.

// ---------------- Requisitos (ver também offices.js: presidente) ----------------
export const PRESIDENCY = {
  requirements: {
    support: 15000000, // apoio popular mínimo
    money: 50000, // dinheiro pessoal mínimo (R$)
    campaignReserve: 6000, // dinheiro reservado para campanha (R$)
  },
  candidatesMin: 5,
  candidatesMax: 12,
  electorate: 150000000, // eleitores fictícios no país (escala configurável)
  sampleSize: 2000, // entrevistados simulados por pesquisa
  marginOfError: 2.2, // pontos percentuais, para 2.000 entrevistados (95%)
  majorityRule: 0.5, // mais de 50% dos votos válidos no primeiro turno
  turnoutRound2Factor: 0.97, // participação do segundo turno em relação ao primeiro
  blankShare: [0.015, 0.035], // faixa de votos em branco por estado
  nullShare: [0.02, 0.04], // faixa de votos nulos por estado
  votingPlaceSize: 2500, // eleitores por local de votação fictício
  mandateYears: 4,
  reelectionMax: 1,
  // Pesos do cálculo do voto (somam 1). Mesmos pesos para todos os candidatos.
  weights: { support: 0.4, fame: 0.15, debate: 0.15, campaign: 0.1, proposals: 0.1, approval: 0.1 },
  noise: 0.03, // variação aleatória controlada (± no peso final)
};

// Faixas de apoio dos candidatos (valor mínimo, máximo e probabilidade). Acima de 100 milhões é raro.
export const SUPPORT_TIERS = [
  { min: 15000000, max: 20000000, p: 0.3 },
  { min: 20000000, max: 35000000, p: 0.25 },
  { min: 35000000, max: 50000000, p: 0.18 },
  { min: 50000000, max: 80000000, p: 0.14 },
  { min: 80000000, max: 100000000, p: 0.1 },
  { min: 100000000, max: 150000000, p: 0.02 },
  { min: 150000000, max: 300000000, p: 0.007 },
  { min: 300000000, max: 500000000, p: 0.002 },
  { min: 500000000, max: 1000000000, p: 0.001 },
];

// Perfis: apenas diferenciam personagens e estilos de jogo. Não determinam vitória.
export const PERSONALITIES = {
  tecnico: { label: 'Candidato técnico', econ: 50, social: 50, fame: [30, 60], skill: 75, campaign: 0.5, style: 'tecnico' },
  popular: { label: 'Candidato popular', econ: 40, social: 40, fame: [55, 90], skill: 55, campaign: 0.8, style: 'popular' },
  experiente: { label: 'Candidato experiente', econ: 60, social: 55, fame: [60, 85], skill: 70, campaign: 0.6, style: 'tecnico' },
  jovem: { label: 'Candidato jovem', econ: 45, social: 30, fame: [30, 60], skill: 60, campaign: 0.7, style: 'popular' },
  conservador: { label: 'Candidato conservador', econ: 75, social: 75, fame: [40, 75], skill: 60, campaign: 0.5, style: 'agressivo' },
  progressista: { label: 'Candidato progressista', econ: 30, social: 25, fame: [40, 75], skill: 62, campaign: 0.6, style: 'popular' },
  independente: { label: 'Candidato independente', econ: 50, social: 50, fame: [35, 70], skill: 58, campaign: 0.55, style: 'agressivo' },
};

export const HISTORY_SLOGANS = [
  'Juntos para avançar', 'O Brasil que queremos', 'Trabalho e futuro', 'Gente em primeiro lugar',
  'Mudança com responsabilidade', 'Governar é ouvir', 'Progresso com justiça',
];

// ---------------- Temas dos debates ----------------
// keywords: palavras que mostram que a resposta trata do tema (sem acento, minúsculas).
export const DEBATE_THEMES = {
  economia: { label: 'Economia', keywords: ['economia', 'inflacao', 'renda', 'preco', 'orcamento', 'arrecadacao', 'divida'] },
  saude: { label: 'Saúde', keywords: ['saude', 'hospital', 'medicamento', 'atendimento', 'posto'] },
  educacao: { label: 'Educação', keywords: ['educacao', 'escola', 'universidade', 'professor', 'merenda'] },
  seguranca: { label: 'Segurança pública', keywords: ['seguranca', 'policia', 'violencia', 'prevencao', 'crime'] },
  infraestrutura: { label: 'Infraestrutura', keywords: ['infraestrutura', 'estrada', 'ponte', 'saneamento', 'energia'] },
  cultura: { label: 'Cultura', keywords: ['cultura', 'museu', 'biblioteca', 'patrimonio', 'evento'] },
  tecnologia: { label: 'Tecnologia', keywords: ['tecnologia', 'internet', 'digital', 'inovacao', 'conectividade'] },
  meio_ambiente: { label: 'Meio ambiente', keywords: ['meio ambiente', 'ambiental', 'floresta', 'clima', 'agua', 'reciclagem'] },
  emprego: { label: 'Emprego', keywords: ['emprego', 'trabalho', 'vaga', 'desemprego', 'renda'] },
  agricultura: { label: 'Agricultura', keywords: ['agricultura', 'agricultor', 'safra', 'irrigacao', 'campo'] },
  transporte: { label: 'Transporte', keywords: ['transporte', 'onibus', 'ferrovia', 'metro', 'mobilidade'] },
  relacoes_internacionais: { label: 'Relações internacionais', keywords: ['internacional', 'exterior', 'acordo', 'diplomacia', 'comercio exterior'] },
};
export const THEME_KEYS = Object.keys(DEBATE_THEMES);

// Tempo de fala (segundos) -> palavras permitidas na resposta.
export const DEBATE_TIME = {
  30: { label: '30 segundos', words: 40 },
  60: { label: '1 minuto', words: 90 },
  120: { label: '2 minutos', words: 180 },
  180: { label: '3 minutos', words: 270 },
};
export const DEBATE_DEFAULT_TIME = 60;
export const DEBATE_DAYS_BEFORE = [30, 15, 5]; // dias antes da eleição
export const DEBATE_BROADCASTERS = ['Rede Horizonte', 'TV Cidade Central', 'Canal Brasil Novo', 'Rádio Nacional Aurora'];
export const DEBATE_VENUES = ['Auditório do Congresso Aurora', 'Centro de Convenções Ipê', 'Teatro Nacional Vale Verde'];

// Estilos de resposta (texto de escolha). Cada um tem forças e fraquezas diferentes; a nota vem do texto.
export const ANSWER_STYLES = {
  tecnico: (t) => `Para ${t}, o plano tem metas numéricas, prazo de 24 meses e fonte de recurso definida, porque o diagnóstico técnico aponta essa prioridade.`,
  popular: (t) => `Vou falar direto com você sobre ${t}: vamos ouvir as comunidades e trabalhar com quem está na ponta.`,
  agressivo: (t) => `Quem governa hoje falhou em ${t}. Isso é um problema grave e a população sabe disso, mas não vou aceitar mais desculpas.`,
};
export const ANSWER_CHOICE_ORDER = ['tecnico', 'popular', 'agressivo'];
export const REPLICA_TEMPLATES = [
  (who, t) => `${who}: falar de ${t} é fácil. Qual é a fonte do dinheiro?`,
  (who, t) => `${who}: em ${t} o problema é a falta de execução, não de promessas.`,
  (who, t) => `${who}: a proposta sobre ${t} não tem prazo nem custo claro.`,
];
export const CLOSING_TEMPLATES = [
  'Agradeço a oportunidade e peço o seu voto com responsabilidade.',
  'O país precisa de resultados, e é isso que vou entregar.',
  'Conto com cada brasileiro nesta caminhada.',
];

// ---------------- Governo federal ----------------
// Indicadores nacionais: base de exemplo do briefing; variam entre partidas.
export const NATIONAL_INDICATORS = [
  { key: 'saude', label: 'Saúde', base: 50 },
  { key: 'educacao', label: 'Educação', base: 67 },
  { key: 'seguranca', label: 'Segurança', base: 86 },
  { key: 'economia', label: 'Economia', base: 46 },
  { key: 'cultura', label: 'Cultura', base: 36 },
  { key: 'infraestrutura', label: 'Infraestrutura', base: 55 },
  { key: 'emprego', label: 'Emprego', base: 60 },
  { key: 'meio_ambiente', label: 'Meio ambiente', base: 50 },
  { key: 'tecnologia', label: 'Tecnologia', base: 45 },
  { key: 'transporte', label: 'Transporte', base: 58 },
];
export const NATIONAL_KEYS = NATIONAL_INDICATORS.map((i) => i.key);

// Departamentos (ministérios). Cada um tem programas com custo, prazo e efeitos.
// efeitos: indicadores nacionais; approval: aprovação do governo ao concluir.
export const DEPARTMENTS = {
  saude: { label: 'Saúde', programs: [
    { key: 'hospitais', name: 'Hospitais regionais', cost: 40000000, days: 60, effects: { saude: 6 }, approval: 2 },
    { key: 'medicamentos', name: 'Distribuição de medicamentos', cost: 12000000, days: 30, effects: { saude: 3 }, approval: 1 },
    { key: 'atendimento', name: 'Atendimento básico ampliado', cost: 18000000, days: 45, effects: { saude: 4 }, approval: 1 },
  ] },
  educacao: { label: 'Educação', programs: [
    { key: 'escolas', name: 'Reforma de escolas', cost: 35000000, days: 60, effects: { educacao: 6 }, approval: 2 },
    { key: 'merenda', name: 'Programa de merenda escolar', cost: 10000000, days: 30, effects: { educacao: 3 }, approval: 1 },
    { key: 'formacao', name: 'Formação profissional', cost: 15000000, days: 45, effects: { educacao: 3, emprego: 2 }, approval: 1 },
  ] },
  seguranca: { label: 'Segurança', programs: [
    { key: 'integracao', name: 'Integração entre instituições', cost: 20000000, days: 45, effects: { seguranca: 5 }, approval: 1 },
    { key: 'prevencao', name: 'Prevenção à violência', cost: 14000000, days: 45, effects: { seguranca: 3 }, approval: 1 },
    { key: 'modernizacao', name: 'Modernização policial', cost: 25000000, days: 60, effects: { seguranca: 5, tecnologia: 1 }, approval: 1 },
  ] },
  economia: { label: 'Economia', programs: [
    { key: 'credito', name: 'Crédito para pequenos negócios', cost: 22000000, days: 45, effects: { economia: 4, emprego: 2 }, approval: 1 },
    { key: 'estabilidade', name: 'Plano de estabilidade fiscal', cost: 5000000, days: 30, effects: { economia: 4 }, approval: -1 },
    { key: 'arrecadacao', name: 'Modernização da arrecadação', cost: 8000000, days: 40, effects: { economia: 3 }, approval: 0 },
  ] },
  cultura: { label: 'Cultura', programs: [
    { key: 'museus', name: 'Restauração de museus', cost: 9000000, days: 45, effects: { cultura: 5 }, approval: 1 },
    { key: 'bibliotecas', name: 'Bibliotecas comunitárias', cost: 6000000, days: 30, effects: { cultura: 3, educacao: 1 }, approval: 1 },
    { key: 'incentivos', name: 'Incentivos culturais', cost: 7000000, days: 30, effects: { cultura: 4 }, approval: 1 },
  ] },
  infraestrutura: { label: 'Infraestrutura', programs: [
    { key: 'rodovias', name: 'Duplicação de rodovias', cost: 60000000, days: 90, effects: { infraestrutura: 6, transporte: 2 }, approval: 2 },
    { key: 'saneamento', name: 'Saneamento básico', cost: 30000000, days: 60, effects: { infraestrutura: 4, saude: 2 }, approval: 1 },
    { key: 'energia', name: 'Expansão da energia', cost: 35000000, days: 75, effects: { infraestrutura: 4, economia: 2 }, approval: 1 },
  ] },
  emprego: { label: 'Emprego', programs: [
    { key: 'qualificacao', name: 'Qualificação de trabalhadores', cost: 12000000, days: 40, effects: { emprego: 5 }, approval: 1 },
    { key: 'primeiro', name: 'Primeiro emprego', cost: 9000000, days: 30, effects: { emprego: 3 }, approval: 1 },
    { key: 'apoio_empresas', name: 'Apoio a empresas empregadoras', cost: 16000000, days: 45, effects: { emprego: 4, economia: 1 }, approval: 0 },
  ] },
  meio_ambiente: { label: 'Meio ambiente', programs: [
    { key: 'florestas', name: 'Proteção de florestas', cost: 15000000, days: 60, effects: { meio_ambiente: 6 }, approval: 1 },
    { key: 'reciclagem', name: 'Coleta seletiva nacional', cost: 8000000, days: 30, effects: { meio_ambiente: 3 }, approval: 1 },
    { key: 'agua', name: 'Recursos hídricos', cost: 11000000, days: 45, effects: { meio_ambiente: 3, infraestrutura: 1 }, approval: 1 },
  ] },
  tecnologia: { label: 'Tecnologia', programs: [
    { key: 'conectividade', name: 'Conectividade em escolas e postos', cost: 18000000, days: 45, effects: { tecnologia: 5, educacao: 1 }, approval: 1 },
    { key: 'inovacao', name: 'Fundo de inovação', cost: 14000000, days: 45, effects: { tecnologia: 4, economia: 1 }, approval: 0 },
    { key: 'governo_digital', name: 'Governo digital', cost: 7000000, days: 30, effects: { tecnologia: 3 }, approval: 1 },
  ] },
  transporte: { label: 'Transporte', programs: [
    { key: 'onibus', name: 'Renovação da frota de ônibus', cost: 25000000, days: 60, effects: { transporte: 5 }, approval: 1 },
    { key: 'ferrovias', name: 'Ferrovias', cost: 45000000, days: 90, effects: { transporte: 4, infraestrutura: 3 }, approval: 1 },
    { key: 'portos', name: 'Modernização de portos', cost: 30000000, days: 75, effects: { transporte: 3, economia: 2 }, approval: 1 },
  ] },
};
export const DEPARTMENT_KEYS = Object.keys(DEPARTMENTS);

export const MINISTER_POOL_SIZE = 3;
export const PROGRAMS_ACTIVE_MAX = 6;
// Eficiência do ministro: 0,7 + competência / 250 (faixa aproximada de 0,86 a 1,06).
export const ministerEfficiency = (competence) => 0.7 + competence / 250;

// Negociação com partidos (emendas parlamentares).
export const NEGOTIATION = { cost: 2000000, strengthStep: 0.2, strengthMax: 1, cooldownDays: 15 };

// ---------------- Congresso ----------------
export const CAMARA_SEATS = 513;
export const SENADO_SEATS = 81;
export const PARTY_WEIGHTS = [22, 18, 16, 14, 12, 10]; // distribuição fictícia de cadeiras por partido
export const CONGRESS = {
  billEveryDays: 30,
  camaraDays: 5, // prazo de votação na Câmara
  senadoDays: 5, // prazo de votação no Senado
  sancaoDays: 15, // prazo para sancionar ou vetar (sanção tácita depois)
  allyStrengthStart: 0.5,
  allyBonus: 0.15,
  approvalEffect: 400, // (aprovação - 50) / 400 entra na probabilidade de voto
  noise: 0.03,
  presidentialSectors: NATIONAL_KEYS,
  billEffect: 4,
  sanctionApproval: 1,
  vetoApproval: -1,
};
export const PRESIDENTIAL_BILLS = [
  { title: 'Plano nacional de saúde preventiva', sector: 'saude', econ: 45, social: 70 },
  { title: 'Lei de incentivo à educação técnica', sector: 'educacao', econ: 50, social: 65 },
  { title: 'Marco da segurança integrada', sector: 'seguranca', econ: 60, social: 45 },
  { title: 'Regras para estímulo ao crédito', sector: 'economia', econ: 30, social: 40 },
  { title: 'Lei de proteção do patrimônio cultural', sector: 'cultura', econ: 40, social: 75 },
  { title: 'Concessão de rodovias e portos', sector: 'infraestrutura', econ: 70, social: 35 },
  { title: 'Programa de qualificação profissional', sector: 'emprego', econ: 40, social: 60 },
  { title: 'Código nacional de meio ambiente', sector: 'meio_ambiente', econ: 35, social: 80 },
];

// ---------------- Eventos presidenciais ----------------
// options: label, cost (R$ do orçamento federal), approval, indicators. Mostrados com custo e consequência.
export const PRESIDENTIAL_EVENTS = {
  crise_economica: { title: 'Crise econômica', text: 'Queda na arrecadação e alta da dívida pública exigem medidas.', options: [
    { label: 'Pacote de estabilização', cost: 20000000, approval: -2, indicators: { economia: 5 } },
    { label: 'Corte de gastos', cost: 0, approval: -5, indicators: { economia: 2, educacao: -2 } },
    { label: 'Aguardar o mercado', cost: 0, approval: -3, indicators: { economia: -3 } },
  ] },
  enchente: { title: 'Enchente em um estado', text: 'Chuvas fortes deixam famílias desabrigadas. Um estado pede socorro federal.', options: [
    { label: 'Socorro emergencial completo', cost: 15000000, approval: 4, indicators: { infraestrutura: 2 } },
    { label: 'Ajuda parcial', cost: 5000000, approval: 0, indicators: { infraestrutura: 1 } },
    { label: 'Encaminhar para análise', cost: 0, approval: -4, indicators: {} },
  ] },
  hospital_regiao: { title: 'Região pede hospital', text: 'Uma região sem atendimento de alta complexidade pede investimentos.', options: [
    { label: 'Financiar o hospital', cost: 25000000, approval: 2, indicators: { saude: 4 } },
    { label: 'Ampliar uma unidade existente', cost: 8000000, approval: 1, indicators: { saude: 2 } },
    { label: 'Negar o pedido', cost: 0, approval: -3, indicators: { saude: -2 } },
  ] },
  obra_importante: { title: 'Obra importante precisa de aprovação', text: 'Uma ponte estratégica depende de aprovação do governo federal.', options: [
    { label: 'Aprovar a obra', cost: 30000000, approval: 1, indicators: { infraestrutura: 4, transporte: 2 } },
    { label: 'Adiar para o próximo ano', cost: 0, approval: -1, indicators: { infraestrutura: -1 } },
  ] },
  crise_ambiental: { title: 'Crise ambiental', text: 'Queimadas e desmatamento crescem em áreas protegidas.', options: [
    { label: 'Operação de fiscalização', cost: 12000000, approval: 2, indicators: { meio_ambiente: 4 } },
    { label: 'Acordos com estados', cost: 4000000, approval: 1, indicators: { meio_ambiente: 2 } },
    { label: 'Não intervir agora', cost: 0, approval: -4, indicators: { meio_ambiente: -4 } },
  ] },
  negociacao_internacional: { title: 'Negociação internacional', text: 'Um país parceiro propõe um acordo comercial.', options: [
    { label: 'Assinar o acordo', cost: 0, approval: 2, indicators: { economia: 3, emprego: 1 } },
    { label: 'Negociar condições melhores', cost: 2000000, approval: 1, indicators: { economia: 2 } },
    { label: 'Recusar', cost: 0, approval: -1, indicators: {} },
  ] },
  reivindicacao_popular: { title: 'Reivindicação popular', text: 'Movimentos organizados pedem mais investimentos em cultura e educação.', options: [
    { label: 'Atender parcialmente', cost: 6000000, approval: 2, indicators: { cultura: 2, educacao: 2 } },
    { label: 'Diálogo sem recursos', cost: 0, approval: 0, indicators: {} },
    { label: 'Ignorar', cost: 0, approval: -3, indicators: { cultura: -1 } },
  ] },
};
export const PRESIDENTIAL_EVENT_KEYS = Object.keys(PRESIDENTIAL_EVENTS);
export const PRESIDENTIAL_EVENT_CHANCE = 1 / 45;
export const PRESIDENTIAL_EVENT_DEADLINE = 7;
export const PRESIDENTIAL_EVENT_NO_REPEAT = 5;

// Pesos de eleitorado por UF (escala relativa e fictícia; a soma é distribuída até PRESIDENCY.electorate).
export const STATE_ELECTORATE_WEIGHTS = {
  AC: 1, AL: 2, AP: 1, AM: 3, BA: 8, CE: 5, DF: 2, ES: 2, GO: 3, MA: 4, MT: 2, MS: 2, MG: 11,
  PA: 5, PB: 3, PR: 6, PE: 6, PI: 2, RJ: 9, RN: 2, RS: 6, RO: 1, RR: 1, SC: 4, SP: 22, SE: 2, TO: 1,
};

export const PARTY_IDEOLOGY_FALLBACK = { economic: 50, social: 50 };
