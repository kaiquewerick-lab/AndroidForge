// Motor da Parte 3: apoio popular por campanha, santinhos, banners, placas, celulares,
// publicidade digital, atividades públicas, conversas com cidadãos, regiões e fama.
// Roda somente no servidor. Ganhos de apoio sempre passam por consumeReach(), que aplica os tetos:
//   - diário por região (DAILY_REACH_SHARE) e de audiência total (REACH_SHARE);
// assim não existe apoio infinito, mesmo com placas que o briefing descreve como muito potentes.
import {
  REGIONS, CITIZENS_PER_REGION, REACH_SHARE, DAILY_REACH_SHARE, CITIZEN_TYPES, TOPICS, CONVERSATION,
  SANTINHO, BANNER, PLACA, PHONES, EFFICIENCY_WITHOUT_PHONE, DIGITAL, ATIVIDADES, ATIVIDADE_DIARIA_MAX,
  FAME_LEVELS,
} from './campaignData.js';
import { CANDIDATE_FIRST, CANDIDATE_LAST, INDICATOR_KEYS } from './offices.js';
import { GameError, logEvent, credit, debit, canAfford, balanceOf, round2 } from './ledger.js';

export const CAMPAIGN_ACTION_NAMES = [
  'comprarCelular', 'equiparCelular', 'descartarItem', 'fabricarSantinhos', 'fabricarBanner', 'fabricarPlaca',
  'distribuirSantinhos', 'instalarItem', 'removerInstalacao', 'repararPlaca', 'campanhaDigital',
  'pararCampanhaDigital', 'atividade', 'conversar', 'mudarRegiao',
];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const round1 = (v) => Math.round(v * 10) / 10;
const isObj = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);
const pick = (arr, rng) => arr[Math.floor(rng.next() * arr.length)];
const between = (min, max, rng) => min + Math.floor(rng.next() * (max - min + 1));
const fmtId = (rng, prefix) => `${prefix}-${Math.floor(rng.next() * 1e9).toString(36)}`;

function intIn(value, min, max, msg) {
  const n = Math.floor(Number(value));
  if (!Number.isFinite(n) || n < min || n > max) throw new GameError(msg);
  return n;
}

function strOf(value, max) {
  return typeof value === 'string' ? value.trim().replace(/\s+/g, ' ').slice(0, max) : '';
}

const hexOr = (value, fallback) => (typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value) ? value : fallback);

// ---------------- Estado inicial ----------------
export const emptyStats = () => ({
  santinhosFabricados: 0,
  santinhosDistribuidos: 0,
  bannersProduzidos: 0,
  bannersInstalados: 0,
  placasProduzidas: 0,
  placasInstaladas: 0,
  campanhasDigitais: 0,
  pessoasAlcancadas: 0,
  conversas: 0,
  conversasPositivas: 0,
  apoioDeCampanha: 0,
  santinhoDay: { day: -1, count: 0 },
  conversaDay: { day: -1, count: 0 },
  atividadeDay: { day: -1, count: 0 },
});

// Cria regiões e cidadãos. rng: objeto com next() (mesmo gerador da partida).
export function createCampaignState(rng) {
  const regions = REGIONS.map((r) => ({
    id: r.id, name: r.name, population: r.population, reached: 0, dayKey: -1, dayUsed: 0,
  }));
  const citizens = [];
  for (const r of REGIONS) {
    const pool = [];
    for (const [type, weight] of Object.entries(r.mix)) for (let i = 0; i < weight; i += 1) pool.push(type);
    const [bx, by, bw, bh] = r.box;
    for (let i = 0; i < CITIZENS_PER_REGION; i += 1) {
      const type = pick(pool, rng);
      const base = CITIZEN_TYPES[type];
      citizens.push({
        id: `c-${r.id}-${i}`,
        regionId: r.id,
        name: `${pick(CANDIDATE_FIRST, rng)} ${pick(CANDIDATE_LAST, rng)}`,
        type,
        econ: clamp(base.econ + between(-15, 15, rng), 0, 100),
        social: clamp(base.social + between(-15, 15, rng), 0, 100),
        x: round1(bx + 6 + rng.next() * (bw - 12)),
        y: round1(by + 6 + rng.next() * (bh - 12)),
        lastTalkDay: null,
      });
    }
  }
  return {
    regions,
    citizens,
    digital: [],
    installs: [],
    inventory: [],
    equippedPhone: null,
    currentRegion: 'centro',
    conversations: [],
    supportHistory: [],
    fameHistory: [],
    stats: emptyStats(),
  };
}

// ---------------- Consultas ----------------
export const fameLevel = (fame) => {
  let level = FAME_LEVELS[0];
  for (const l of FAME_LEVELS) if (fame >= l.min) level = l;
  return level.label;
};

export const phoneDef = (id) => PHONES.find((p) => p.id === id) || null;

export function equippedPhone(s) {
  const item = s.inventory.find((i) => i.id === s.equippedPhone && i.kind === 'celular');
  return item ? phoneDef(item.phoneId) : null;
}

export const efficiencyOf = (s) => (equippedPhone(s) ? equippedPhone(s).efficiency : EFFICIENCY_WITHOUT_PHONE);

// Áreas de alcance: as 4 regiões do mapa municipal e, na campanha presidencial, os 27 estados.
function regionOf(s, id) {
  const r = s.regions.find((x) => x.id === id) || s.presidential?.states?.[id];
  if (!r) throw new GameError('Região desconhecida.');
  return r;
}

// Onde a campanha acontece agora: o estado escolhido durante a campanha presidencial, ou a região do mapa.
export function activeArea(s) {
  return s.election?.registered === 'presidente' && s.presidential?.currentState
    ? s.presidential.currentState
    : s.currentRegion;
}

// Receptividade: quanto da audiência ainda não foi alcançada (1 = toda, perto de 0 = saturada).
export function receptivity(s, regionId) {
  const r = regionOf(s, regionId);
  const total = Math.floor(r.population * REACH_SHARE);
  return clamp((total - r.reached) / total, 0.1, 1);
}

// ---------------- Teto de audiência: todo ganho de apoio de campanha passa por aqui ----------------
export function consumeReach(s, regionId, amount) {
  const r = regionOf(s, regionId);
  if (r.dayKey !== s.day) {
    r.dayKey = s.day;
    r.dayUsed = 0;
  }
  const dailyLeft = Math.max(0, Math.floor(r.population * DAILY_REACH_SHARE) - r.dayUsed);
  const lifeLeft = Math.max(0, Math.floor(r.population * REACH_SHARE) - r.reached);
  const gained = Math.max(0, Math.min(Math.floor(amount), dailyLeft, lifeLeft));
  r.dayUsed += gained;
  r.reached += gained;
  s.support += gained;
  s.stats.apoioDeCampanha += gained;
  return gained;
}

function addFame(s, amount) {
  s.fame = round1(clamp(s.fame + amount, 0, 100));
}

function windowOpen(s) {
  return Boolean(s.election) && s.day < s.election.electionDay;
}

function ensureRegion(s, payloadRegion) {
  if (payloadRegion && payloadRegion !== s.currentRegion) {
    throw new GameError('Você precisa estar nesta região para isso. Mude de região no mapa primeiro.');
  }
  return s.currentRegion;
}

// Design comum (santinho, banner, placa). Valores padrão vêm do personagem e do partido.
function designFrom(s, raw) {
  const d = isObj(raw) ? raw : {};
  const name = strOf(d.name, 30) || `${s.character.firstName} ${s.character.lastName}`.slice(0, 30);
  if (!/^[\p{L}\d .'-]+$/u.test(name)) throw new GameError('Nome do candidato inválido no design.');
  const number = /^\d{2,5}$/.test(String(d.number ?? '')) ? String(d.number) : (s.party ? String(s.party.number) : '00');
  return {
    name,
    party: strOf(d.party, 30) || (s.party ? s.party.acronym : 'Independente'),
    number,
    slogan: strOf(d.slogan, 60),
    primary: hexOr(d.primary, '#1d4ed8'),
    secondary: hexOr(d.secondary, '#ffffff'),
    imagem: 'personagem',
  };
}

function stackKey(item) {
  return JSON.stringify([item.kind, item.design, item.size || null, item.material || null]);
}

function addItem(s, item) {
  const same = s.inventory.find((i) => i.kind === item.kind && stackKey(i) === stackKey(item));
  if (same && item.kind === 'santinho') {
    same.quantity += item.quantity;
    return same;
  }
  s.inventory.push(item);
  return item;
}

function takeItem(s, itemId) {
  const item = s.inventory.find((i) => i.id === itemId);
  if (!item) throw new GameError('Item não encontrado no inventário.');
  return item;
}

function removeOne(s, item, qty = 1) {
  item.quantity -= qty;
  if (item.quantity <= 0) s.inventory.splice(s.inventory.indexOf(item), 1);
}

// ---------------- Compras e fabricação ----------------
function buyPhone(s, rng, { phoneId }) {
  const phone = phoneDef(phoneId);
  if (!phone) throw new GameError('Aparelho não encontrado na loja.');
  debit(s, 'pessoal', phone.price, `Compra: ${phone.brand} ${phone.model}`, 'compras');
  const item = { id: fmtId(rng, 'cel'), kind: 'celular', name: `${phone.brand} ${phone.model}`, phoneId: phone.id, quantity: 1, condition: 100 };
  s.inventory.push(item);
  logEvent(s, 'compra', `Comprou um ${phone.brand} ${phone.model}.`);
  if (!s.equippedPhone) s.equippedPhone = item.id;
}

function equipPhone(s, { itemId }) {
  const item = takeItem(s, itemId);
  if (item.kind !== 'celular') throw new GameError('Só celulares podem ser equipados.');
  s.equippedPhone = item.id;
  logEvent(s, 'celular', `Equipou o celular ${item.name}.`);
}

function discardItem(s, { itemId, quantity }) {
  const item = takeItem(s, itemId);
  const qty = item.kind === 'santinho' ? intIn(quantity || item.quantity, 1, item.quantity, 'Quantidade inválida.') : 1;
  if (item.kind === 'celular' && s.equippedPhone === item.id) s.equippedPhone = null;
  removeOne(s, item, qty);
  logEvent(s, 'inventario', `Descartou ${qty} unidade(s) de ${item.name}.`);
}

function printCost(q) {
  return Math.ceil(q / SANTINHO.lote) * SANTINHO.impressaoPorLote;
}

function produceSantinhos(s, rng, payload) {
  const q = intIn(payload.quantity, SANTINHO.pedidoMin, SANTINHO.pedidoMax, `Pedido entre ${SANTINHO.pedidoMin} e ${SANTINHO.pedidoMax} santinhos.`);
  const fab = SANTINHO.fabricacao;
  const impr = printCost(q);
  if (!canAfford(s, 'campanha', fab + impr)) {
    throw new GameError(`Dinheiro de campanha insuficiente: o pedido custa R$ ${fab + impr}.`);
  }
  debit(s, 'campanha', fab, 'Fabricação de santinhos', 'fabricacao');
  debit(s, 'campanha', impr, `Impressão de ${q} santinhos`, 'impressao');
  addItem(s, { id: fmtId(rng, 'san'), kind: 'santinho', name: 'Santinho', design: designFrom(s, payload.design), quantity: q, condition: 100 });
  s.stats.santinhosFabricados += q;
  logEvent(s, 'producao', `Fabricou e imprimiu ${q} santinhos.`);
}

function produceBanner(s, rng, payload) {
  const mat = BANNER.materiais[payload.material];
  const size = BANNER.tamanhos[payload.size];
  if (!mat || !size) throw new GameError('Escolha material e tamanho válidos.');
  const total = mat.fabricacao + BANNER.impressao;
  if (!canAfford(s, 'campanha', total)) throw new GameError(`Dinheiro de campanha insuficiente: o banner custa R$ ${total}.`);
  debit(s, 'campanha', mat.fabricacao, `Fabricação de banner (${mat.label})`, 'fabricacao');
  debit(s, 'campanha', BANNER.impressao, 'Impressão de banner', 'impressao');
  const design = designFrom(s, payload.design);
  design.primary = hexOr(payload.design?.primary, design.primary);
  s.inventory.push({
    id: fmtId(rng, 'ban'), kind: 'banner', name: `Banner ${design.name}`, quantity: 1,
    size: payload.size, material: payload.material, design, cost: total, condition: 100,
  });
  s.stats.bannersProduzidos += 1;
  logEvent(s, 'producao', `Produziu um banner ${size.label.toLowerCase()} (${mat.label.toLowerCase()}).`);
}

function producePlaca(s, rng, payload) {
  const size = PLACA.tamanhos[payload.size];
  if (!size) throw new GameError('Escolha um tamanho de placa válido.');
  const total = size.fabricacao + PLACA.impressao;
  if (!canAfford(s, 'campanha', total)) throw new GameError(`Dinheiro de campanha insuficiente: a placa custa R$ ${total}.`);
  debit(s, 'campanha', size.fabricacao, `Fabricação de placa ${size.label.toLowerCase()}`, 'fabricacao');
  debit(s, 'campanha', PLACA.impressao, 'Impressão de placa', 'impressao');
  s.inventory.push({
    id: fmtId(rng, 'pla'), kind: 'placa', name: `Placa ${size.label}`, quantity: 1,
    size: payload.size, design: designFrom(s, payload.design), cost: total, condition: 100,
  });
  s.stats.placasProduzidas += 1;
  logEvent(s, 'producao', `Produziu uma placa ${size.label.toLowerCase()}.`);
}

// ---------------- Distribuição e instalação ----------------
function distribute(s, rng, { itemId, quantity, regionId }) {
  const region = ensureRegion(s, regionId);
  const item = takeItem(s, itemId);
  if (item.kind !== 'santinho') throw new GameError('Só santinhos podem ser distribuídos assim.');
  const qty = intIn(quantity, 1, item.quantity, 'Quantidade maior que a disponível no inventário.');
  const used = s.stats.santinhoDay.day === s.day ? s.stats.santinhoDay.count : 0;
  if (used + qty > SANTINHO.limiteDiario) {
    throw new GameError(`Limite diário: você pode entregar mais ${Math.max(0, SANTINHO.limiteDiario - used)} santinhos hoje.`);
  }
  const eff = efficiencyOf(s);
  let raw = 0;
  for (let i = 0; i < qty; i += 1) {
    const points = between(SANTINHO.pontosMin, SANTINHO.pontosMax, rng);
    raw += points * eff * receptivity(s, region);
  }
  const gained = consumeReach(s, region, raw);
  removeOne(s, item, qty);
  s.stats.santinhoDay = { day: s.day, count: used + qty };
  s.stats.santinhosDistribuidos += qty;
  s.stats.pessoasAlcancadas += qty;
  logEvent(s, 'distribuicao', `Distribuiu ${qty} santinhos em ${regionOf(s, region).name}: +${gained} de apoio.`);
  return gained;
}

function installItem(s, rng, { itemId, regionId }) {
  const region = ensureRegion(s, regionId);
  const item = takeItem(s, itemId);
  if (item.kind !== 'banner' && item.kind !== 'placa') throw new GameError('Só banners e placas podem ser instalados.');
  const max = item.kind === 'banner' ? BANNER.maxPorRegiao : PLACA.maxPorRegiao;
  const count = s.installs.filter((i) => i.regionId === region && i.kind === item.kind).length;
  if (count >= max) throw new GameError(`Limite de ${max} ${item.kind === 'banner' ? 'banners' : 'placas'} nesta região.`);
  const visibility = round1(0.5 + rng.next() * 0.5);
  let daily;
  let days;
  if (item.kind === 'banner') {
    const fator = BANNER.tamanhos[item.size].fator;
    const total = between(BANNER.pontosMin, BANNER.pontosMax, rng) * fator * visibility;
    days = BANNER.duracaoDias;
    daily = total / days;
    s.stats.bannersInstalados += 1;
  } else {
    const fator = PLACA.tamanhos[item.size].fator;
    days = PLACA.duracaoDias;
    daily = between(PLACA.potencialPorHoraMin, PLACA.potencialPorHoraMax, rng) * fator * 24 * visibility;
    s.stats.placasInstaladas += 1;
  }
  removeOne(s, item, 1);
  s.installs.push({
    id: fmtId(rng, 'ins'), kind: item.kind, name: item.name, size: item.size, regionId: region,
    installedDay: s.day, expiresDay: s.day + days, visibility, condition: 100,
    dailyPotential: Math.round(daily), design: item.design,
  });
  logEvent(s, 'instalacao', `Instalou ${item.name} em ${regionOf(s, region).name}.`);
}

function removeInstall(s, { installId }) {
  const idx = s.installs.findIndex((i) => i.id === installId);
  if (idx < 0) throw new GameError('Instalação não encontrada.');
  const [inst] = s.installs.splice(idx, 1);
  logEvent(s, 'instalacao', `Retirou ${inst.name} de ${regionOf(s, inst.regionId).name}.`);
}

function repairPlaca(s, { installId }) {
  const inst = s.installs.find((i) => i.id === installId);
  if (!inst || inst.kind !== 'placa') throw new GameError('Placa não encontrada.');
  if (inst.condition >= 100) throw new GameError('Esta placa já está em bom estado.');
  const cost = Math.round(PLACA.tamanhos[inst.size].fabricacao * PLACA.reparoFracao);
  debit(s, 'campanha', cost, `Reparo de placa (${inst.name})`, 'manutencao');
  inst.condition = 100;
  logEvent(s, 'manutencao', `Reparou ${inst.name}.`);
}

// ---------------- Publicidade digital ----------------
function startDigital(s, rng, { budget, days }) {
  if (!equippedPhone(s)) throw new GameError('Equipe um celular para administrar campanhas digitais.');
  const b = intIn(budget, DIGITAL.orcamentoMin, DIGITAL.orcamentoMax, `Orçamento diário entre R$ ${DIGITAL.orcamentoMin} e R$ ${DIGITAL.orcamentoMax}.`);
  if (!DIGITAL.duracoesDias.includes(Number(days))) throw new GameError('Escolha 7, 14 ou 30 dias.');
  const active = s.digital.filter((d) => d.status === 'ativa').length;
  if (active >= DIGITAL.maxAtivas) throw new GameError(`Limite de ${DIGITAL.maxAtivas} campanhas digitais ativas.`);
  if (!canAfford(s, 'campanha', b)) throw new GameError('Dinheiro de campanha insuficiente para o primeiro dia.');
  s.digital.push({
    id: fmtId(rng, 'dig'), budget: b, days: Number(days), startDay: s.day, endDay: s.day + Number(days),
    status: 'ativa', spent: 0, gained: 0, views: 0, interactions: 0, shares: 0,
  });
  s.stats.campanhasDigitais += 1;
  logEvent(s, 'publicidade', `Campanha digital iniciada: R$ ${b} por dia durante ${days} dias.`);
}

function stopDigital(s, { digitalId }) {
  const d = s.digital.find((x) => x.id === digitalId);
  if (!d || d.status !== 'ativa') throw new GameError('Campanha digital não está ativa.');
  d.status = 'encerrada';
  d.endDay = s.day;
  logEvent(s, 'publicidade', 'Campanha digital encerrada pelo candidato.');
}

// ---------------- Atividades públicas (fama e apoio) ----------------
function doActivity(s, rng, { kind }) {
  const def = ATIVIDADES[kind];
  if (!def) throw new GameError('Atividade desconhecida.');
  if (def.janela && !windowOpen(s)) throw new GameError('Este evento só acontece durante a janela eleitoral.');
  if (def.cargo && !s.office) throw new GameError('Esta atividade exige um cargo público.');
  const used = s.stats.atividadeDay.day === s.day ? s.stats.atividadeDay.count : 0;
  if (used >= ATIVIDADE_DIARIA_MAX) throw new GameError(`Você já fez ${ATIVIDADE_DIARIA_MAX} atividades hoje.`);
  if (def.custo) debit(s, 'campanha', def.custo, `${def.label}`, 'publicidade');
  let gained = 0;
  if (def.apoio[1] > 0) gained = consumeReach(s, activeArea(s), between(def.apoio[0], def.apoio[1], rng));
  addFame(s, def.fama);
  s.stats.atividadeDay = { day: s.day, count: used + 1 };
  s.stats.pessoasAlcancadas += gained;
  logEvent(s, 'atividade', `${def.label}: +${def.fama} de fama${gained ? `, +${gained} de apoio` : ''}.`);
}

// ---------------- Conversas com cidadãos ----------------
function alignmentOf(s, c) {
  const pe = s.party?.ideology?.economic ?? 50;
  const ps = s.party?.ideology?.social ?? 50;
  return 1 - (Math.abs(c.econ - pe) + Math.abs(c.social - ps)) / 200;
}

function chanceOf(s, c, topicKey, indicator) {
  const topic = TOPICS[topicKey];
  let bonus = topic.bonus;
  if (topicKey === 'proposta' && indicator === CITIZEN_TYPES[c.type].interest) bonus += 0.1;
  if (topicKey === 'problemas' && indicator === CITIZEN_TYPES[c.type].interest) bonus += 0.05;
  return clamp(0.2 + 0.5 * alignmentOf(s, c) + bonus + Math.min(s.fame, 100) / 400, 0.05, 0.95);
}

// Chance estimada de simpatia, exibida antes da conversa (para o indicador visual).
export function conversationOdds(s, citizenId, topicKey, indicator) {
  const c = s.citizens.find((x) => x.id === citizenId);
  if (!c || !TOPICS[topicKey]) throw new GameError('Pessoa ou tema inválido.');
  return Math.round(chanceOf(s, c, topicKey, indicator) * 100);
}

function talk(s, rng, { citizenId, topic, indicator, reply }) {
  const c = s.citizens.find((x) => x.id === citizenId);
  if (!c) throw new GameError('Pessoa não encontrada.');
  if (c.regionId !== s.currentRegion) throw new GameError('Esta pessoa não está na sua região atual.');
  if (c.lastTalkDay !== null && s.day - c.lastTalkDay < CONVERSATION.cooldownDias) {
    throw new GameError(`Você já conversou com ${c.name} recentemente. Volte em ${CONVERSATION.cooldownDias - (s.day - c.lastTalkDay)} dia(s).`);
  }
  const used = s.stats.conversaDay.day === s.day ? s.stats.conversaDay.count : 0;
  if (used >= CONVERSATION.limiteDiario) throw new GameError('Você já teve muitas conversas hoje. Descanse e volte amanhã.');
  const def = TOPICS[topic];
  if (!def) throw new GameError('Tema de conversa inválido.');
  if (def.precisaPartido && !s.party) throw new GameError('Você precisa de um partido para apresentá-lo.');
  if (def.precisaProposta && !INDICATOR_KEYS.includes(indicator)) throw new GameError('Escolha o tema da proposta.');

  const chance = chanceOf(s, c, topic, indicator);
  const roll = rng.next();
  let reaction = 'negativa';
  let gained = 0;
  if (roll < chance) {
    reaction = 'positiva';
    gained = consumeReach(s, c.regionId, between(CONVERSATION.pontosMin, CONVERSATION.pontosMax, rng));
    addFame(s, 0.05);
    s.stats.conversasPositivas += 1;
  } else if (roll < chance + 0.15) {
    reaction = 'neutra';
  }
  c.lastTalkDay = s.day;
  s.stats.conversas += 1;
  s.stats.conversaDay = { day: s.day, count: used + 1 };
  s.stats.pessoasAlcancadas += 1;
  const text = typeof reply === 'string' ? reply.replace(/[\u0000-\u001F]/g, '').trim().slice(0, CONVERSATION.textoMax) : null;
  s.conversations.push({
    day: s.day, citizen: c.name, type: CITIZEN_TYPES[c.type].label, topic: def.label,
    reaction, gain: gained, chance: Math.round(chance * 100), reply: text || null,
  });
  if (s.conversations.length > 40) s.conversations.splice(0, s.conversations.length - 40);
  logEvent(s, 'conversa', `${c.name} (${CITIZEN_TYPES[c.type].label}): ${reaction}${gained ? `, +${gained} de apoio` : ''}.`);
}

function moveTo(s, { regionId }) {
  regionOf(s, regionId);
  if (regionId === s.currentRegion) throw new GameError('Você já está nesta região.');
  s.currentRegion = regionId;
  logEvent(s, 'mapa', `Caminhou até ${regionOf(s, regionId).name}.`);
}

// Ponto de entrada das ações de campanha. Retorna false se a ação não for desta parte.
export function handleCampaignAction(s, rng, action, payload) {
  switch (action) {
    case 'comprarCelular': buyPhone(s, rng, payload); break;
    case 'equiparCelular': equipPhone(s, payload); break;
    case 'descartarItem': discardItem(s, payload); break;
    case 'fabricarSantinhos': produceSantinhos(s, rng, payload); break;
    case 'fabricarBanner': produceBanner(s, rng, payload); break;
    case 'fabricarPlaca': producePlaca(s, rng, payload); break;
    case 'distribuirSantinhos': distribute(s, rng, payload); break;
    case 'instalarItem': installItem(s, rng, payload); break;
    case 'removerInstalacao': removeInstall(s, payload); break;
    case 'repararPlaca': repairPlaca(s, payload); break;
    case 'campanhaDigital': startDigital(s, rng, payload); break;
    case 'pararCampanhaDigital': stopDigital(s, payload); break;
    case 'atividade': doActivity(s, rng, payload); break;
    case 'conversar': talk(s, rng, payload); break;
    case 'mudarRegiao': moveTo(s, payload); break;
    default: return false;
  }
  return true;
}

// ---------------- Dia a dia: publicidade, instalações, histórico ----------------
export function campaignDaily(s, rng) {
  for (const d of s.digital) {
    if (d.status !== 'ativa') continue;
    if (s.day > d.endDay) {
      d.status = 'encerrada';
      logEvent(s, 'publicidade', 'Campanha digital concluída.');
      continue;
    }
    if (!canAfford(s, 'campanha', d.budget)) {
      d.status = 'pausada';
      logEvent(s, 'publicidade', 'Campanha digital pausada: falta dinheiro de campanha.');
      continue;
    }
    debit(s, 'campanha', d.budget, 'Publicidade digital (diária)', 'publicidade');
    d.spent = round2(d.spent + d.budget);
    const potential = Math.floor(s.fame * DIGITAL.pontosPorFamaPorHora * DIGITAL.horasPorDia * efficiencyOf(s));
    const cap = Math.min(potential, d.budget * DIGITAL.apoioPorReal, DIGITAL.limiteDiarioPorCampanha);
    let gained = 0;
    // Distribui o alcance entre as regiões, da mais populosa para a menos.
    for (const r of [...s.regions].sort((a, b) => b.population - a.population)) {
      if (gained >= cap) break;
      gained += consumeReach(s, r.id, cap - gained);
    }
    d.gained += gained;
    const views = Math.round(gained * 2.5);
    d.views += views;
    d.interactions += Math.round(gained * 0.3);
    d.shares += Math.round(gained * 0.08);
    s.stats.pessoasAlcancadas += views;
    addFame(s, d.budget >= 500 ? DIGITAL.fama : 0.01);
  }

  for (const inst of [...s.installs]) {
    if (s.day >= inst.expiresDay) {
      s.installs.splice(s.installs.indexOf(inst), 1);
      logEvent(s, 'instalacao', `${inst.name} saiu de ${regionOf(s, inst.regionId).name} (fim do prazo).`);
      continue;
    }
    const manut = inst.kind === 'banner' ? BANNER.manutencaoDia : PLACA.tamanhos[inst.size].manutencaoDia;
    if (!canAfford(s, 'campanha', manut)) {
      logEvent(s, 'manutencao', `Sem verba para manter ${inst.name}: não gerou apoio hoje.`);
      continue;
    }
    debit(s, 'campanha', manut, `Manutenção: ${inst.name}`, 'manutencao');
    if (inst.kind === 'placa') {
      inst.condition = round1(Math.max(0, inst.condition - PLACA.desgastePorDia));
      if (inst.condition < PLACA.condicaoMinima) continue;
    }
    const gained = consumeReach(s, inst.regionId, inst.dailyPotential);
    s.stats.pessoasAlcancadas += Math.round(gained * 1.5);
  }

  if (s.day % 7 === 0) {
    s.supportHistory.push({ day: s.day, value: s.support });
    s.fameHistory.push({ day: s.day, value: round1(s.fame) });
    if (s.supportHistory.length > 400) s.supportHistory.splice(0, s.supportHistory.length - 400);
    if (s.fameHistory.length > 400) s.fameHistory.splice(0, s.fameHistory.length - 400);
  }
}

// ---------------- Resumo para MINHA CAMPANHA ----------------
export function campaignReport(s) {
  const campaignSpent = s.ledger
    .filter((l) => l.account === 'campanha' && l.type === 'despesa')
    .reduce((a, l) => a + l.amount, 0);
  const byCategory = {};
  for (const l of s.ledger) {
    if (l.account !== 'campanha' || l.type !== 'despesa') continue;
    byCategory[l.category] = round2((byCategory[l.category] || 0) + l.amount);
  }
  const phone = equippedPhone(s);
  return {
    apoio: s.support,
    fama: round1(s.fame),
    nivelFama: fameLevel(s.fame),
    dinheiroCampanha: balanceOf(s, 'campanha'),
    dinheiroPessoal: balanceOf(s, 'pessoal'),
    dinheiroPartido: balanceOf(s, 'partido'),
    gastosCampanha: round2(campaignSpent),
    gastosPorCategoria: byCategory,
    santinhosDistribuidos: s.stats.santinhosDistribuidos,
    santinhosFabricados: s.stats.santinhosFabricados,
    bannersProduzidos: s.stats.bannersProduzidos,
    bannersInstalados: s.stats.bannersInstalados,
    placasProduzidas: s.stats.placasProduzidas,
    placasInstaladas: s.stats.placasInstaladas,
    placasAtivas: s.installs.filter((i) => i.kind === 'placa').length,
    campanhasDigitais: s.digital.length,
    campanhasDigitaisAtivas: s.digital.filter((d) => d.status === 'ativa').length,
    pessoasAlcancadas: s.stats.pessoasAlcancadas,
    conversas: s.stats.conversas,
    conversasPositivas: s.stats.conversasPositivas,
    celularEquipado: phone ? `${phone.brand} ${phone.model}` : null,
    historicoApoio: s.supportHistory,
    historicoFama: s.fameHistory,
    regioes: s.regions.map((r) => ({ id: r.id, name: r.name, population: r.population, alcancado: r.reached, teto: Math.floor(r.population * REACH_SHARE) })),
  };
}
