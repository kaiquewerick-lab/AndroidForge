// Desenho 2D do personagem em SVG a partir dos dados salvos. Função pura: não altera o estado.
const HEX = /^#[0-9a-fA-F]{6}$/;
const col = (v, fallback = '#000000') => (typeof v === 'string' && HEX.test(v) ? v : fallback);

// Posições das mãos para cada pose: [ombro x,y, mão x,y].
const POSE_ARMS = {
  parado: { l: [66, 150, 52, 250], r: [134, 150, 148, 250] },
  acenando: { l: [66, 150, 52, 250], r: [134, 150, 166, 70] },
  discursando: { l: [66, 150, 76, 208], r: [134, 150, 124, 208] },
  apontando: { l: [66, 150, 52, 250], r: [134, 150, 190, 150] },
};

function hairBack(style, c) {
  if (style === 'medio') return `<rect x="58" y="60" width="84" height="40" rx="16" fill="${c}"/>`;
  if (style === 'longo') return `<rect x="54" y="60" width="92" height="92" rx="26" fill="${c}"/>`;
  return '';
}

function hairTop(style, c) {
  switch (style) {
    case 'curto': return `<path d="M64,74 Q62,34 100,32 Q138,34 136,74 Q124,56 100,56 Q76,56 64,74 Z" fill="${c}"/>`;
    case 'medio':
    case 'longo': return `<path d="M62,78 Q58,30 100,30 Q142,30 138,78 Q130,52 100,52 Q70,52 62,78 Z" fill="${c}"/>`;
    case 'cacheado': return `<g fill="${c}"><circle cx="72" cy="56" r="14"/><circle cx="88" cy="40" r="14"/><circle cx="106" cy="36" r="14"/><circle cx="124" cy="44" r="14"/><circle cx="132" cy="62" r="12"/><circle cx="68" cy="70" r="10"/></g>`;
    case 'raspado': return `<path d="M68,70 Q100,50 132,70 Q100,62 68,70 Z" fill="${c}" opacity="0.45"/>`;
    default: return '';
  }
}

function headShape(face, skin) {
  switch (face) {
    case 'quadrado': return `<rect x="66" y="44" width="68" height="80" rx="18" fill="${skin}"/>`;
    case 'redondo': return `<circle cx="100" cy="84" r="40" fill="${skin}"/>`;
    case 'fino': return `<ellipse cx="100" cy="84" rx="30" ry="44" fill="${skin}"/>`;
    default: return `<ellipse cx="100" cy="84" rx="34" ry="42" fill="${skin}"/>`;
  }
}

function eyeShape(style, x, y, iris) {
  const white = '#ffffff';
  let shape;
  if (style === 'amendoados') {
    shape = `<path d="M${x - 8},${y} Q${x},${y - 7} ${x + 8},${y} Q${x},${y + 4} ${x - 8},${y} Z" fill="${white}"/>`;
  } else {
    const rx = style === 'grandes' ? 8 : 6;
    const ry = style === 'grandes' ? 6 : 4;
    shape = `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${white}"/>`;
  }
  return `${shape}<circle cx="${x}" cy="${y}" r="3.2" fill="${iris}"/>`;
}

function beard(style, c) {
  switch (style) {
    case 'curta': return `<path d="M70,98 Q72,128 100,128 Q128,128 130,98 Q120,118 100,118 Q80,118 70,98 Z" fill="${c}" opacity="0.9"/>`;
    case 'cheia': return `<path d="M66,92 Q62,136 100,140 Q138,136 134,92 Q126,124 100,126 Q74,124 66,92 Z" fill="${c}" opacity="0.92"/>`;
    case 'cavanhaque': return `<path d="M90,116 Q100,132 110,116 Q104,126 100,127 Q96,126 90,116 Z" fill="${c}"/>`;
    default: return '';
  }
}

function mustache(style, c) {
  if (style === 'fino') return `<path d="M88,104 Q100,98 112,104 Q100,103 88,104 Z" fill="${c}" stroke="${c}" stroke-width="2"/>`;
  if (style === 'cheio') return `<path d="M86,105 Q100,94 114,105 Q100,108 86,105 Z" fill="${c}"/>`;
  return '';
}

function glasses(style, c) {
  if (style === 'redondo') {
    return `<g fill="rgba(255,255,255,0.15)" stroke="${c}" stroke-width="3"><circle cx="86" cy="80" r="11"/><circle cx="114" cy="80" r="11"/><line x1="97" y1="80" x2="103" y2="80"/></g>`;
  }
  if (style === 'quadrado') {
    return `<g fill="rgba(255,255,255,0.15)" stroke="${c}" stroke-width="3"><rect x="75" y="72" width="22" height="16" rx="3"/><rect x="103" y="72" width="22" height="16" rx="3"/><line x1="97" y1="79" x2="103" y2="79"/></g>`;
  }
  return '';
}

function cap(style, c) {
  if (style !== 'bone') return '';
  return `<g fill="${c}"><path d="M62,58 Q100,18 138,58 Z"/><path d="M128,58 Q156,60 160,68 Q140,68 124,62 Z"/></g>`;
}

function hat(style, c) {
  if (style !== 'fedora') return '';
  return `<g fill="${c}"><ellipse cx="100" cy="50" rx="60" ry="10"/><rect x="70" y="18" width="60" height="34" rx="6"/></g><rect x="70" y="42" width="60" height="5" fill="#00000055"/>`;
}

function shoes(style, c) {
  if (style === 'botas') return `<g fill="${c}"><rect x="70" y="318" width="30" height="52" rx="8"/><rect x="100" y="318" width="30" height="52" rx="8"/></g>`;
  if (style === 'tenis') {
    return `<g fill="${c}"><ellipse cx="84" cy="360" rx="18" ry="9"/><ellipse cx="116" cy="360" rx="18" ry="9"/></g><rect x="66" y="366" width="36" height="5" rx="2" fill="#ffffff"/><rect x="98" y="366" width="36" height="5" rx="2" fill="#ffffff"/>`;
  }
  return `<g fill="${c}"><rect x="70" y="354" width="32" height="14" rx="6"/><rect x="98" y="354" width="32" height="14" rx="6"/></g>`;
}

function pants(style, c) {
  if (style === 'shorts') {
    return `<rect x="72" y="250" width="26" height="46" rx="6" fill="${c}"/><rect x="102" y="250" width="26" height="46" rx="6" fill="${c}"/>` +
      `<rect x="74" y="294" width="22" height="60" rx="6" fill="#e8b48a"/><rect x="104" y="294" width="22" height="60" rx="6" fill="#e8b48a"/>`;
  }
  return `<rect x="72" y="250" width="26" height="112" rx="6" fill="${c}"/><rect x="102" y="250" width="26" height="112" rx="6" fill="${c}"/>`;
}

// Monta o SVG. `mirror` (-1..1) simula o personagem girando (arrastar no preview).
export function renderCharacter(c, { mirror = 1, title = 'Personagem' } = {}) {
  const ap = c.appearance;
  const cl = c.clothing;
  const ac = c.accessories;
  const pose = POSE_ARMS[c.pose] ? c.pose : 'parado';
  const arms = POSE_ARMS[pose];
  const skin = col(ap.skinTone, '#e8b48a');
  const hairC = col(ap.hairColor, '#1b1b1b');
  const eyeC = col(ap.eyeColor, '#3b2a1a');

  const shirt = cl.shirt, tshirt = cl.tshirt, suit = cl.suit, jacket = cl.jacket;
  const hasShirt = shirt.style !== 'nenhuma';
  const hasTee = tshirt.style !== 'nenhuma';
  const hasSuit = suit.style !== 'nenhum';
  const hasJacket = jacket.style !== 'nenhuma';

  const torsoColor = hasTee ? col(tshirt.color) : hasShirt ? col(shirt.color) : skin;
  const sleeveColor = hasJacket ? col(jacket.color) : hasSuit ? col(suit.color) : torsoColor;

  let torsoOuter = '';
  if (hasSuit) {
    const d = suit.style === 'slim'
      ? 'M64,138 L136,138 L132,258 L68,258 Z'
      : 'M60,138 L140,138 L136,258 L64,258 Z';
    torsoOuter = `<path d="${d}" fill="${col(suit.color)}"/><path d="M92,140 L100,178 L108,140" stroke="#00000055" stroke-width="2" fill="none"/>`;
  } else if (hasJacket) {
    const d = jacket.style === 'bomber' ? 'M58,140 L142,140 L138,236 L62,236 Z' : 'M58,140 L142,140 L138,246 L62,246 Z';
    torsoOuter = `<path d="${d}" fill="${col(jacket.color)}"/>` +
      (jacket.style === 'couro' ? '<line x1="100" y1="150" x2="100" y2="240" stroke="#00000044" stroke-width="2"/>' : '<path d="M62,236 L138,236" stroke="#00000044" stroke-width="3"/>');
  }

  const collar = hasShirt && shirt.style === 'polo'
    ? `<path d="M92,140 L100,152 L108,140" stroke="#00000055" stroke-width="2" fill="none"/>`
    : hasShirt && shirt.style === 'social'
      ? `<path d="M90,140 L100,162 L110,140" fill="#ffffff" stroke="#00000033" stroke-width="1"/>`
      : '';
  const print = hasTee && tshirt.style === 'estampada'
    ? `<rect x="90" y="176" width="20" height="18" rx="2" fill="#ffffff" opacity="0.85"/>`
    : '';

  let tie = '';
  if (cl.tie.style !== 'nenhuma') {
    const w = cl.tie.style === 'larga' ? 1 : 0.6;
    tie = `<path d="M${100 - 6 * w},150 L${100 + 6 * w},150 L104,198 L100,208 L96,198 Z" fill="${col(cl.tie.color)}"/>`;
  }

  const armLine = (pts) => `<line x1="${pts[0]}" y1="${pts[1]}" x2="${pts[2]}" y2="${pts[3]}" stroke="${sleeveColor}" stroke-width="20" stroke-linecap="round"/>`;
  const handDot = (x, y) => `<circle cx="${x}" cy="${y}" r="10" fill="${skin}"/>`;
  const L = arms.l, R = arms.r;
  const wrist = { x: L[0] + (L[2] - L[0]) * 0.82, y: L[1] + (L[3] - L[1]) * 0.82 };
  const watchItem = ac.watch.style !== 'nenhum'
    ? `<circle cx="${wrist.x.toFixed(1)}" cy="${wrist.y.toFixed(1)}" r="6" fill="${col(ac.watch.color, '#c0c0c0')}" stroke="#333" stroke-width="1"/>`
    : '';
  const pin = ac.pin.style === 'broche'
    ? `<circle cx="122" cy="170" r="4" fill="${col(ac.pin.color, '#f1c40f')}"/>`
    : ac.pin.style === 'bandeira'
      ? `<rect x="116" y="166" width="10" height="7" fill="#1e8449"/><rect x="116" y="166" width="10" height="3" fill="#f1c40f"/>`
      : '';

  const hairStyle = ap.hair;
  const eyesStyle = ap.eyes;
  const glassesColor = col(ac.glasses.color, '#222222');
  const bodyParts = [
    hairBack(hairStyle, hairC),
    `<rect x="90" y="120" width="20" height="24" fill="${skin}"/>`,
    pants(cl.pants.style, col(cl.pants.color)),
    shoes(cl.shoes.style, col(cl.shoes.color)),
    `<path d="M64,140 L136,140 L132,252 L68,252 Z" fill="${torsoColor}"/>`,
    collar,
    print,
    tie,
    torsoOuter,
    pin,
    armLine(L),
    armLine(R),
    handDot(L[2], L[3]),
    handDot(R[2], R[3]),
    watchItem,
    headShape(ap.face, skin),
    `<ellipse cx="66" cy="88" rx="7" ry="10" fill="${skin}"/><ellipse cx="134" cy="88" rx="7" ry="10" fill="${skin}"/>`,
    hairTop(hairStyle, hairC),
    `<path d="M78,70 Q86,66 94,70 M106,70 Q114,66 122,70" stroke="${hairC}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    eyeShape(eyesStyle, 86, 80, eyeC),
    eyeShape(eyesStyle, 114, 80, eyeC),
    `<path d="M100,86 L97,100 Q100,103 103,100" stroke="#00000044" stroke-width="2" fill="none"/>`,
    `<path d="M90,112 Q100,118 110,112" stroke="#7a3b2e" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    beard(ap.beard, hairC),
    mustache(ap.mustache, hairC),
    glasses(ac.glasses.style, glassesColor),
    cap(ac.cap.style, col(ac.cap.color, '#222222')),
    hat(ac.hat.style, col(ac.hat.color, '#222222')),
  ].join('');

  const flip = mirror < 0 ? -Math.min(1, Math.abs(mirror)) : Math.min(1, mirror);
  const scaleX = flip === 0 ? 0.08 : flip;
  return `<svg class="char-svg" viewBox="0 0 200 380" role="img" aria-label="${title}" xmlns="http://www.w3.org/2000/svg">` +
    `<g transform="translate(100 0) scale(${scaleX.toFixed(3)} 1) translate(-100 0)">${bodyParts}</g></svg>`;
}
