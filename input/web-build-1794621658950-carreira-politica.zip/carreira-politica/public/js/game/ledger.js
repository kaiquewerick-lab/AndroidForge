// Contas e registros do jogo. Todo movimento de dinheiro passa por aqui.
// Contas separadas: pessoal, campanha, partido e orçamentos públicos (municipal, estadual, federal).
// Não existe função que transfira dinheiro entre pessoal e público. A única saída pública para o
// personagem é o salário do cargo (feito pelo motor político) e fica registrada nos dois lados.
import { formatDay as formatDayLabel } from './calendar.js';

export class GameError extends Error {}

const LEDGER_LIMIT = 1500;
const LOG_LIMIT = 500;

export const round2 = (v) => Math.round(v * 100) / 100;
const fmtMoney = (v) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);

export const accountLabel = (account) => {
  if (account === 'pessoal') return 'dinheiro pessoal';
  if (account === 'campanha') return 'dinheiro de campanha';
  if (account === 'partido') return 'dinheiro do partido';
  return `orçamento ${account.split(':')[1]}`;
};

export function balanceOf(s, account) {
  if (account === 'pessoal') return s.money;
  if (account === 'campanha') return s.campaignFund;
  if (account === 'partido') return s.partyFund;
  return s.publicBudgets[account.split(':')[1]];
}

function setBalance(s, account, value) {
  const v = round2(value);
  if (account === 'pessoal') s.money = v;
  else if (account === 'campanha') s.campaignFund = v;
  else if (account === 'partido') s.partyFund = v;
  else s.publicBudgets[account.split(':')[1]] = v;
}

export function logEvent(s, type, text, office = null) {
  s.careerLog.push({ day: s.day, date: formatDayLabel(s.day), type, office, text });
  if (s.careerLog.length > LOG_LIMIT) s.careerLog.splice(0, s.careerLog.length - LOG_LIMIT);
}

function post(s, account, type, amount, desc, category) {
  s.ledger.push({
    day: s.day, account, type, amount: round2(amount), desc: String(desc).slice(0, 120),
    category: category || (type === 'receita' ? 'receitas' : 'outros'),
  });
  if (s.ledger.length > LEDGER_LIMIT) s.ledger.splice(0, s.ledger.length - LEDGER_LIMIT);
}

export function credit(s, account, amount, desc, category) {
  if (!(amount >= 0) || !Number.isFinite(amount)) throw new GameError('Valor inválido.');
  setBalance(s, account, balanceOf(s, account) + amount);
  post(s, account, 'receita', amount, desc, category || 'receitas');
}

// Débito: nunca deixa saldo negativo (salvo allowNegative, que não é usado pelo jogo).
export function debit(s, account, amount, desc, category = 'outros') {
  if (!(amount >= 0) || !Number.isFinite(amount)) throw new GameError('Valor inválido.');
  if (balanceOf(s, account) < amount) {
    throw new GameError(`Saldo insuficiente (${accountLabel(account)}): faltam ${fmtMoney(amount - balanceOf(s, account))}.`);
  }
  setBalance(s, account, balanceOf(s, account) - amount);
  post(s, account, 'despesa', amount, desc, category);
}

// Verifica se há saldo para um débito sem executá-lo.
export function canAfford(s, account, amount) {
  return balanceOf(s, account) >= amount;
}
