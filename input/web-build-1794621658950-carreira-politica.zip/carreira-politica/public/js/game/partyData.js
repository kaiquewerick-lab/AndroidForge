// Dados do editor de partidos: formas, ícones, padrões de bandeira e valores padrão.
export const SHAPE_LABELS = {
  circulo: 'Círculo', triangulo: 'Triângulo', quadrado: 'Quadrado',
  losango: 'Losango', estrela: 'Estrela', hexagono: 'Hexágono',
};

export const ICON_LABELS = {
  folha: 'Folha', sol: 'Sol', escudo: 'Escudo', tocha: 'Tocha', mao: 'Mão',
  coracao: 'Coração', arvore: 'Árvore', onda: 'Onda', roda: 'Engrenagem', livro: 'Livro',
};

export const FLAG_LABELS = {
  solida: 'Cor sólida', horizontal: 'Faixas horizontais', vertical: 'Faixas verticais',
  diagonal: 'Diagonal', circulo: 'Círculo central',
};

export const SHAPE_KEYS = Object.keys(SHAPE_LABELS);
export const ICON_KEYS = Object.keys(ICON_LABELS);
export const FLAG_KEYS = Object.keys(FLAG_LABELS);
export const SYMBOL_TYPES = ['shape', 'icon', 'combo', 'upload'];

export const PARTY_PALETTE = [
  '#1f4e79', '#c0392b', '#1e8449', '#f4c542', '#ffffff', '#1b1b1b',
  '#8e44ad', '#e67e22', '#17a2b8', '#6c757d', '#2d6cdf', '#b03a2e',
];

export const PARTY_DEFAULT = {
  name: '',
  acronym: '',
  number: '',
  motto: '',
  symbol: { type: 'shape', shape: 'circulo', icon: 'sol' },
  primary: '#1f4e79',
  secondary: '#f4c542',
  flagPattern: 'solida',
  ideology: { economic: 50, social: 50 },
};

// Tamanho máximo da imagem enviada pelo jogador (caracteres da data URL).
export const MAX_UPLOAD_CHARS = 350000;
