// Dados e limites de balanceamento da Parte 3 (campanha, apoio popular, publicidade e fama).
// Valores em R$ são fictícios. Todos os limites ficam aqui para ajuste fácil.

// ---------------- Regiões e cidadãos ----------------
// box = [x, y, largura, altura] no mapa 0-100 x 0-60. mix = pesos de tipos de cidadão.
export const REGIONS = [
  { id: 'centro', name: 'Centro', population: 140000, box: [0, 0, 50, 30], mix: { comerciante: 3, empresario: 2, trabalhador: 2, professor: 1 } },
  { id: 'norte', name: 'Zona Norte', population: 120000, box: [50, 0, 50, 30], mix: { estudante: 3, trabalhador: 3, comerciante: 1 } },
  { id: 'sul', name: 'Zona Sul', population: 110000, box: [0, 30, 50, 30], mix: { aposentado: 3, professor: 2, morador: 2 } },
  { id: 'leste', name: 'Zona Leste', population: 150000, box: [50, 30, 50, 30], mix: { trabalhador: 3, agricultor: 1, morador: 2, estudante: 2 } },
];
export const CITIZENS_PER_REGION = 8;

// Parcela da população que pode ser alcançada por campanhas no total (teto de audiência).
export const REACH_SHARE = 0.8;
// Parcela da população que pode ser alcançada em um único dia por região (ritmo de crescimento).
export const DAILY_REACH_SHARE = 0.05;

// Tipos de cidadão: opinião típica (econômica/social, 0-100) e tema de interesse (indicador).
export const CITIZEN_TYPES = {
  trabalhador: { label: 'Trabalhador(a)', econ: 35, social: 55, interest: 'economia' },
  estudante: { label: 'Estudante', econ: 60, social: 75, interest: 'educacao' },
  comerciante: { label: 'Comerciante', econ: 25, social: 40, interest: 'economia' },
  professor: { label: 'Professor(a)', econ: 45, social: 70, interest: 'educacao' },
  agricultor: { label: 'Agricultor(a)', econ: 40, social: 35, interest: 'infraestrutura' },
  aposentado: { label: 'Aposentado(a)', econ: 50, social: 30, interest: 'saude' },
  empresario: { label: 'Empresário(a)', econ: 15, social: 35, interest: 'economia' },
  morador: { label: 'Morador(a)', econ: 50, social: 50, interest: 'seguranca' },
};

// Temas de conversa. bonus = acréscimo na chance de simpatia; precisaPartido/precisaProposta exigem dados.
export const TOPICS = {
  cumprimentar: { label: 'Cumprimentar', bonus: 0.04 },
  proposta: { label: 'Apresentar uma proposta', bonus: 0.08, precisaProposta: true },
  cidade: { label: 'Falar sobre a cidade', bonus: 0.06 },
  problemas: { label: 'Perguntar sobre problemas locais', bonus: 0.1 },
  partido: { label: 'Apresentar o partido', bonus: 0.08, precisaPartido: true },
  livre: { label: 'Conversa livre (IA)', bonus: 0.07 },
};
export const CONVERSATION = {
  pontosMin: 25,
  pontosMax: 30,
  cooldownDias: 30, // o mesmo cidadão só pode ser abordado de novo depois deste prazo
  limiteDiario: 12,
  textoMax: 300,
};

// ---------------- Santinhos ----------------
export const SANTINHO = {
  fabricacao: 20, // R$ por pedido de fabricação
  impressaoPorLote: 5, // R$ por lote de impressão
  lote: 20, // unidades por lote
  pontosMin: 200,
  pontosMax: 1000,
  limiteDiario: 60, // santinhos entregues por dia
  pedidoMin: 20,
  pedidoMax: 2000,
};

// ---------------- Banners ----------------
export const BANNER = {
  materiais: {
    simples: { label: 'Material simples', fabricacao: 500 },
    intermediario: { label: 'Material intermediário', fabricacao: 750 },
    premium: { label: 'Material premium', fabricacao: 1000 },
  },
  impressao: 100,
  tamanhos: {
    pequeno: { label: 'Pequeno', fator: 0.8 },
    medio: { label: 'Médio', fator: 1 },
    grande: { label: 'Grande', fator: 1.2 },
  },
  pontosMin: 3000, // apoio total gerado durante a exibição, antes do fator de tamanho e visibilidade
  pontosMax: 5000,
  maxPorRegiao: 3,
  manutencaoDia: 8,
  duracaoDias: 60,
};

// ---------------- Placas ----------------
// "potencialPorHora" segue o briefing (1 a 2 milhões por hora de jogo em cenário de audiência alta).
// O teto diário e o teto de audiência da região impedem apoio infinito.
export const PLACA = {
  tamanhos: {
    pequena: { label: 'Pequena', fabricacao: 4600, fator: 0.1, manutencaoDia: 40 },
    media: { label: 'Média', fabricacao: 4800, fator: 0.4, manutencaoDia: 120 },
    grande: { label: 'Grande', fabricacao: 5000, fator: 1, manutencaoDia: 300 },
  },
  impressao: 1000,
  potencialPorHoraMin: 1000000,
  potencialPorHoraMax: 2000000,
  maxPorRegiao: 2,
  duracaoDias: 90,
  desgastePorDia: 0.2, // pontos de conservação perdidos por dia
  condicaoMinima: 20, // abaixo disso a placa não gera apoio até ser reparada
  reparoFracao: 0.1, // reparo custa 10% do valor de fabricação
};

// ---------------- Celulares ----------------
// efficiency: multiplicador (0,85 a 1,15) para campanhas digitais e produção de conteúdo.
// O preço não define a eficiência: aparelhos baratos podem ser eficientes e vice-versa.
export const PHONES = [
  { id: 'samsung-nova', brand: 'Samsung', model: 'Nova S8', price: 1800, camera: 6, performance: 6, storage: 128, connection: 6, efficiency: 0.95 },
  { id: 'samsung-ultra', brand: 'Samsung', model: 'Nova Ultra 15', price: 6200, camera: 9, performance: 9, storage: 512, connection: 9, efficiency: 1.1 },
  { id: 'apple-pear', brand: 'Apple', model: 'Pear 13', price: 4800, camera: 8, performance: 8, storage: 256, connection: 8, efficiency: 1 },
  { id: 'apple-pear-pro', brand: 'Apple', model: 'Pear 16 Pro', price: 9800, camera: 10, performance: 10, storage: 512, connection: 10, efficiency: 1.15 },
  { id: 'motorola-acao', brand: 'Motorola', model: 'Moto Ação 5', price: 1100, camera: 4, performance: 5, storage: 64, connection: 5, efficiency: 0.85 },
  { id: 'xiaomi-vivo', brand: 'Xiaomi', model: 'Mi Vivo 12', price: 2400, camera: 7, performance: 7, storage: 256, connection: 7, efficiency: 1 },
  { id: 'realme-real', brand: 'Realme', model: 'Real 11 Pro', price: 2000, camera: 6, performance: 7, storage: 256, connection: 6, efficiency: 1.02 },
  { id: 'pixel-gama', brand: 'Google', model: 'Pixel Gama 9', price: 3900, camera: 9, performance: 8, storage: 128, connection: 8, efficiency: 1.05 },
];
export const EFFICIENCY_WITHOUT_PHONE = 0.8;

// ---------------- Publicidade digital ----------------
export const DIGITAL = {
  duracoesDias: [7, 14, 30],
  orcamentoMin: 50, // R$ por dia
  orcamentoMax: 5000,
  apoioPorReal: 5, // apoio potencial por R$ investido (limitado pela audiência)
  pontosPorFamaPorHora: 10, // cada ponto de fama gera 10 apoios por hora de jogo
  horasPorDia: 24,
  limiteDiarioPorCampanha: 40000,
  maxAtivas: 2,
  fama: 0.05, // ganho de fama por dia de campanha com orçamento de pelo menos R$ 500
};

// ---------------- Atividades públicas ----------------
export const ATIVIDADES = {
  evento: { label: 'Evento público', custo: 800, fama: 0.8, apoio: [300, 600], janela: false },
  entrevista: { label: 'Entrevista na rádio local', custo: 0, fama: 0.5, apoio: [50, 150], janela: false },
  discurso: { label: 'Discurso na praça', custo: 200, fama: 0.6, apoio: [200, 400], janela: false },
  debate: { label: 'Debate entre candidatos', custo: 0, fama: 1.5, apoio: [400, 800], janela: true },
  divulgarProjeto: { label: 'Divulgar projeto relevante', custo: 0, fama: 0.4, apoio: [0, 0], cargo: true },
};
export const ATIVIDADE_DIARIA_MAX = 3;

// ---------------- Fama: níveis de reconhecimento ----------------
export const FAME_LEVELS = [
  { min: 0, label: 'Desconhecido' },
  { min: 10, label: 'Conhecido localmente' },
  { min: 25, label: 'Conhecido regionalmente' },
  { min: 45, label: 'Conhecido nacionalmente' },
  { min: 65, label: 'Muito famoso' },
  { min: 85, label: 'Figura pública de grande reconhecimento' },
];

export const CAMPAIGN_LEDGER_CATEGORIES = [
  'compras', 'fabricacao', 'impressao', 'publicidade', 'manutencao', 'investimentos', 'receitas', 'outros',
];
