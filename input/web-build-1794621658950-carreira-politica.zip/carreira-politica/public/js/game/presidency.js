// Motor da Parte 4: candidatura à Presidência, candidatos adversários, debates, pesquisas,
// eleição nacional em dois turnos, governo federal, ministérios, programas, eventos e Congresso.
// Roda SOMENTE no servidor. Os adversários são controlados pelo sistema (lógica determinística
// com semente), e as notas dos debates usam os MESMOS critérios para todos os candidatos.
// Nenhum voto vem de sorteio puro: o total de votos é sempre fechado por estado (ver allocate).
import {
  PRESIDENCY, SUPPORT_TIERS, PERSONALITIES, HISTORY_SLOGANS, DEBATE_THEMES, THEME_KEYS, DEBATE_TIME,
  DEBATE_DEFAULT_TIME, DEBATE_DAYS_BEFORE, DEBATE_BROADCASTERS, DEBATE_VENUES, ANSWER_STYLES,
  ANSWER_CHOICE_ORDER, REPLICA_TEMPLATES, CLOSING_TEMPLATES, NATIONAL_INDICATORS, NATIONAL_KEYS,
  DEPARTMENTS, DEPARTMENT_KEYS, MINISTER_POOL_SIZE, PROGRAMS_ACTIVE_MAX, ministerEfficiency, NEGOTIATION,
  CAMARA_SEATS, SENADO_SEATS, PARTY_WEIGHTS, CONGRESS, PRESIDENTIAL_BILLS, PRESIDENTIAL_EVENTS,
  PRESIDENTIAL_EVENT_KEYS, PRESIDENTIAL_EVENT_CHANCE, PRESIDENTIAL_EVENT_DEADLINE,
  PRESIDENTIAL_EVENT_NO_REPEAT, STATE_ELECTORATE_WEIGHTS,
} from './presidencyData.js';
import { EXISTING_PARTIES, CANDIDATE_FIRST, CANDIDATE_LAST } from './offices.js';
import { STATES } from '../world/cities.js';
import { GameError, logEvent, debit, canAfford } from './ledger.js';
import { consumeReach, activeArea } from './campaign.js';
import { electionDay, campaignStart, formatDay } from './calendar.js';

export const PRESIDENCY_ACTION_NAMES = [
  'responderDebate', 'viajarEstado', 'apresentarProposta', 'escolherVice', 'nomearMinistro',
  'iniciarPrograma', 'decidirPresidencial', 'sancionarLei', 'negociarApoio', 'enviarProjetoLei',
];

export const CRITERIA = [
  { key: 'clareza', label: 'Clareza' },
  { key: 'coerencia', label: 'Coerência' },
  { key: 'resposta', label: 'Capacidade de responder à pergunta' },
  { key: 'propostas', label: 'Qualidade das propostas' },
  { key: 'argumentacao', label: 'Argumentação' },
  { key: 'consistencia', label: 'Consistência entre propostas' },
  { key: 'problemas', label: 'Reconhecimento de problemas' },
  { key: 'viabilidade', label: 'Viabilidade das soluções' },
];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const round1 = (v) => Math.round(v * 10) / 10;
const round3 = (v) => Math.round(v * 1e6) / 1e6;
const pick = (arr, rng) => arr[Math.floor(rng.next() * arr.length)];
const between = (min, max, rng) => min + Math.floor(rng.next() * (max - min + 1));
const norm = (t) => String(t).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const sum = (arr) => arr.reduce((a, b) => a + b, 0);
const isObj = (v) => Boolean(v) && typeof v === 'object' && !Array.isArray(v);

// ---------------- Distribuição inteira (maior resto): a soma é sempre igual ao total ----------------
export function allocate(total, weights) {
  if (total <= 0 || weights.length === 0) return weights.map(() => 0);
  const wsum = sum(weights);
  if (wsum <= 0) {
    const base = Math.floor(total / weights.length);
    const out = weights.map(() => base);
    for (let i = 0; i < total - base * weights.length; i += 1) out[i] += 1;
    return out;
  }
  const raw = weights.map((w) => (total * w) / wsum);
  const out = raw.map(Math.floor);
  const rest = total - sum(out);
  const order = raw.map((r, i) => [r - Math.floor(r), i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
  for (let k = 0; k < rest; k += 1) out[order[k % order.length][1]] += 1;
  return out;
}

// Eleitorado por UF (soma exatamente PRESIDENCY.electorate).
export function electorateByState() {
  const counts = allocate(PRESIDENCY.electorate, STATES.map((s) => STATE_ELECTORATE_WEIGHTS[s.uf] || 1));
  return Object.fromEntries(STATES.map((s, i) => [s.uf, counts[i]]));
}

// ---------------- Estado presidencial (fica em s.presidential) ----------------
export function ensurePresidential(s) {
  if (!s.presidential) {
    s.presidential = {
      states: null, currentState: 'DF', electorate: PRESIDENCY.electorate, election: null,
      debateStats: {}, proposals: [], government: null, archive: [], lastResult: null,
    };
  }
  const p = s.presidential;
  if (!p.states) {
    const counts = electorateByState();
    p.states = Object.fromEntries(STATES.map((st) => [st.uf, {
      uf: st.uf, name: st.name, population: counts[st.uf], reached: 0, dayKey: -1, dayUsed: 0,
    }]));
  }
  return p;
}

export function stateRecognition(st) {
  return clamp(0.1 + st.reached / (st.population * 0.05), 0, 1);
}

// Chance de a pessoa do estado conhecer o candidato: mesmo critério para todos (adversários têm mapa próprio).
const recognitionFor = (c, st) => (c.player ? stateRecognition(st) : (c.recognition?.[st.uf] ?? 0.3));

// ---------------- Respostas e avaliação (mesmos critérios para todos) ----------------
const PROPOSAL_RE = /\b(vou|vamos|propor|proposta|criar|implantar|investir|construir|ampliar|plano)\b/g;
const NUMBER_RE = /(\d|\bmeta\b|\bmetas\b|\bprazo\b|\bmeses\b|\banos\b)/g;
const FONTE_RE = /\b(fonte|recurso|recursos|orcamento|financiamento|custo)\b/g;
const ARG_RE = /\b(porque|pois|dados|estudo|pesquisa|exemplo|por isso|diagnostico)\b/g;
const PROBLEM_RE = /\b(problema|desafio|dificuldade|falta|crise|demanda|falhou)\b/g;
const VIAB_RE = /\b(prazo|fonte|orcamento|custo|etapa|cronograma|recurso|meta|metas)\b/g;

const countOf = (text, re) => (text.match(re) || []).length;

// Avalia uma resposta com os mesmos critérios (0 a 100). themeKey = null para discursos finais.
export function evaluateAnswer(text, themeKey = null) {
  const t = norm(text || '').trim();
  const words = t.match(/[\p{L}\d]+/gu) || [];
  const wc = words.length;
  if (wc === 0) {
    const zero = Object.fromEntries(CRITERIA.map((c) => [c.key, 0]));
    return { ...zero, overall: 0 };
  }
  const sentences = t.split(/[.!?]+/).map((x) => x.trim()).filter(Boolean);
  const avgLen = wc / Math.max(1, sentences.length);
  const uniq = new Set(words).size / wc;
  const theme = themeKey ? DEBATE_THEMES[themeKey] : null;
  const hits = theme ? theme.keywords.map(norm).filter((k) => t.includes(k)).length : 0;
  const scores = {
    clareza: clamp(Math.round(100 - Math.abs(avgLen - 16) * 4), 20, 100),
    coerencia: wc < 5 ? 30 : clamp(Math.round(uniq * 140), 20, 100),
    resposta: theme ? (hits ? clamp(80 + 10 * hits, 0, 100) : 35) : 60,
    propostas: clamp(
      20 + 30 * Math.min(1, countOf(t, PROPOSAL_RE)) + 20 * (countOf(t, NUMBER_RE) > 0 ? 1 : 0)
      + 20 * (countOf(t, FONTE_RE) > 0 ? 1 : 0), 0, 100,
    ),
    argumentacao: clamp(wc < 5 ? 20 : 30 + 25 * Math.min(2, countOf(t, ARG_RE)), 0, 100),
    consistencia: /\bnao vou\b/.test(t) && /\bvou\b/.test(t) ? 40 : 75,
    problemas: clamp(35 + 30 * Math.min(2, countOf(t, PROBLEM_RE)), 0, 100),
    viabilidade: clamp(30 + 30 * Math.min(2, countOf(t, VIAB_RE)), 0, 100),
  };
  const overall = Math.round(sum(CRITERIA.map((c) => scores[c.key])) / CRITERIA.length);
  return { ...scores, overall };
}

// Corta o texto no limite de palavras do tempo de fala.
const wordLimit = (sec) => (DEBATE_TIME[sec] || DEBATE_TIME[DEBATE_DEFAULT_TIME]).words;
const truncateWords = (text, n) => text.split(' ').slice(0, n).join(' ');

// Resposta do jogador: escolha de um dos três estilos OU texto livre (limitado pelo tempo de fala).
export function answerText(answer, themeKey, timeSeconds) {
  const limit = wordLimit(timeSeconds);
  if (!isObj(answer)) throw new GameError('Resposta inválida.');
  if (Number.isInteger(answer.choice)) {
    const style = ANSWER_CHOICE_ORDER[answer.choice];
    if (!style) throw new GameError('Escolha de resposta inválida.');
    return truncateWords(ANSWER_STYLES[style](DEBATE_THEMES[themeKey].label), limit);
  }
  if (typeof answer.text === 'string') {
    const clean = answer.text.replace(/[\u0000-\u001F]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 600);
    if (!clean) throw new GameError('Escreva uma resposta ou escolha uma opção.');
    return truncateWords(clean, limit);
  }
  throw new GameError('Escreva uma resposta ou escolha uma opção.');
}

// Resposta de adversário controlado pelo sistema: o estilo depende da personalidade e da habilidade.
function aiAnswer(c, themeKey, rng, timeSeconds) {
  const skillHit = rng.next() < c.skill / 100;
  let style;
  if (skillHit) style = c.mainStyle === 'agressivo' ? 'tecnico' : c.mainStyle;
  else style = c.mainStyle === 'agressivo' ? 'popular' : 'agressivo';
  return truncateWords(ANSWER_STYLES[style](DEBATE_THEMES[themeKey].label), wordLimit(timeSeconds));
}

// ---------------- Candidatos adversários ----------------
const PHRASES = [
  'Ex-governador(a) de estado', 'Ex-ministro(a) de planejamento', 'Empresário(a) do setor produtivo',
  'Ex-senador(a) da república', 'Professor(a) universitário(a)', 'Líder sindical nacional',
  'Ex-prefeito(a) de capital', 'Médico(a) sanitarista',
];

function tierSupport(rng) {
  let r = rng.next();
  for (const t of SUPPORT_TIERS) {
    if (r < t.p) return between(t.min, t.max, rng);
    r -= t.p;
  }
  const last = SUPPORT_TIERS[SUPPORT_TIERS.length - 1];
  return between(last.min, last.max, rng);
}

function makeOpponent(idx, rng, year, playerPartyId) {
  const keys = Object.keys(PERSONALITIES);
  const kind = pick(keys, rng);
  const p = PERSONALITIES[kind];
  const independent = kind === 'independente';
  const pool = EXISTING_PARTIES.filter((x) => x.id !== playerPartyId);
  const party = independent ? null : pick(pool, rng);
  const recognition = {};
  for (const st of STATES) recognition[st.uf] = round3(0.15 + rng.next() * 0.5);
  const home = pick(STATES, rng).uf;
  recognition[home] = round3(Math.min(1, recognition[home] + 0.35));
  const topics = [...THEME_KEYS];
  const proposals = [];
  for (let i = 0; i < 3; i += 1) {
    const k = Math.floor(rng.next() * topics.length);
    const [theme] = topics.splice(k, 1);
    proposals.push({ theme, text: ANSWER_STYLES.tecnico(DEBATE_THEMES[theme].label) });
  }
  return {
    id: `pres-${year}-${idx}`,
    name: `${pick(CANDIDATE_FIRST, rng)} ${pick(CANDIDATE_LAST, rng)}`,
    age: between(35, 75, rng),
    personality: kind,
    personalityLabel: p.label,
    partyId: party ? party.id : null,
    party: party ? party.name : 'Independente',
    acronym: party ? party.acronym : '—',
    number: party ? party.number : '—',
    slogan: pick(HISTORY_SLOGANS, rng),
    history: pick(PHRASES, rng),
    ideology: {
      economic: clamp(p.econ + between(-10, 10, rng), 0, 100),
      social: clamp(p.social + between(-10, 10, rng), 0, 100),
    },
    proposals,
    fame: between(p.fame[0], p.fame[1], rng),
    support: tierSupport(rng),
    money: between(50000, 3000000, rng),
    approval: between(40, 60, rng),
    campaignIndex: p.campaign,
    skill: clamp(p.skill + between(-10, 10, rng), 30, 95),
    mainStyle: p.style,
    recognition,
    dinheiroCampanha: 0,
  };
}

// Abre a eleição presidencial: 5 a 12 candidatos, eleitorado por UF e debates agendados.
export function openPresidentialElection(s, year, rng) {
  const p = ensurePresidential(s);
  const count = between(PRESIDENCY.candidatesMin, PRESIDENCY.candidatesMax, rng);
  const opponents = Array.from({ length: count }, (_, i) => makeOpponent(i, rng, year, s.partyId));
  const params = Object.fromEntries(STATES.map((st) => [st.uf, {
    turnout: round3(0.72 + rng.next() * 0.1),
    blank: round3(PRESIDENCY.blankShare[0] + rng.next() * (PRESIDENCY.blankShare[1] - PRESIDENCY.blankShare[0])),
    nul: round3(PRESIDENCY.nullShare[0] + rng.next() * (PRESIDENCY.nullShare[1] - PRESIDENCY.nullShare[0])),
  }]));
  const debateDays = DEBATE_DAYS_BEFORE.map((before) => electionDay(year) - before);
  const debates = debateDays.map((day, i) => ({
    id: `deb-${year}-${i + 1}`,
    name: `Debate presidencial ${i + 1}`,
    broadcaster: DEBATE_BROADCASTERS[i % DEBATE_BROADCASTERS.length],
    venue: DEBATE_VENUES[i % DEBATE_VENUES.length],
    mediator: `${pick(CANDIDATE_FIRST, rng)} ${pick(CANDIDATE_LAST, rng)}`,
    day,
    date: formatDay(day),
    timeSeconds: DEBATE_DEFAULT_TIME,
    themes: (() => { const t = [...THEME_KEYS]; const out = []; for (let k = 0; k < 3; k += 1) out.push(t.splice(Math.floor(rng.next() * t.length), 1)[0]); return out; })(),
    status: 'agendado',
    participants: null,
    report: null,
  }));
  p.election = { year, opponents: opponents.map((o) => o.id), debates, polls: [], params, electionDay: electionDay(year) };
  return opponents;
}

// Candidatos do boletim: adversários + jogador (somente se registrado para a Presidência).
export function presidentialCandidates(s, p) {
  const list = (s.election?.opponents?.presidente || []).map((o) => ({ ...o, player: false }));
  if (s.election?.registered === 'presidente') {
    list.push({
      id: 'player', player: true, name: `${s.character.firstName} ${s.character.lastName}`,
      party: s.party ? s.party.name : 'Independente', acronym: s.party ? s.party.acronym : '—',
      number: s.party ? s.party.number : '—', support: s.support, fame: s.fame, approval: s.approval,
      campaignIndex: clamp(Math.log10(1 + s.stats.pessoasAlcancadas) / 7, 0, 1),
      proposals: p.proposals, skill: 0, recognition: null,
    });
  }
  return list;
}

const debateAvgOf = (p, id, fallback) => {
  const st = p.debateStats[id];
  return st && st.count ? st.sum / st.count : fallback;
};

// Peso de um candidato no voto nacional. Mesma fórmula para todos; ruído controlado pela semente.
function weightOf(s, p, c, totalSupport, noise) {
  const W = PRESIDENCY.weights;
  const pop = totalSupport > 0 ? c.support / totalSupport : 0;
  const debate = debateAvgOf(p, c.player ? 'player' : c.id, c.skill || 50);
  const proposalsN = Math.min(1, new Set((c.proposals || []).map((x) => (typeof x === 'string' ? x : x.theme))).size / 6);
  const raw = W.support * pop + W.fame * (c.fame / 100) + W.debate * (debate / 100)
    + W.campaign * (c.campaignIndex ?? 0.5) + W.proposals * proposalsN + W.approval * (c.approval / 100);
  return Math.max(0.001, raw + noise);
}

// Uma rodada: votos por estado com totais fechados. Retorna números inteiros que somam o eleitorado.
function runRound(p, cands, round) {
  const totals = Object.fromEntries(cands.map((c) => [c.id, 0]));
  const states = [];
  const acc = { electorate: 0, present: 0, valid: 0, blank: 0, nul: 0, abstencao: 0 };
  for (const st0 of STATES) {
    const st = p.states[st0.uf];
    const prm = p.election.params[st.uf];
    const E = st.population;
    const turnout = round === 2 ? prm.turnout * PRESIDENCY.turnoutRound2Factor : prm.turnout;
    const P = Math.round(E * turnout);
    const B = Math.round(P * prm.blank);
    const N = Math.round(P * prm.nul);
    const V = P - B - N;
    const scores = cands.map((c) => c.weight * (0.75 + 0.5 * recognitionFor(c, st)));
    const votes = allocate(V, scores);
    const per = {};
    cands.forEach((c, i) => { per[c.id] = votes[i]; totals[c.id] += votes[i]; });
    states.push({ uf: st.uf, name: st.name, electorate: E, present: P, valid: V, blank: B, nul: N, abstencao: E - P, votes: per });
    acc.electorate += E; acc.present += P; acc.valid += V; acc.blank += B; acc.nul += N; acc.abstencao += E - P;
  }
  return { round, totals, states, ...acc };
}

const percentOf = (totals, valid) => Object.fromEntries(
  Object.entries(totals).map(([id, v]) => [id, valid > 0 ? Math.round((v / valid) * 10000) / 100 : 0]),
);

function verifyVote(r1, r2, percents, winnerId) {
  const checks = [];
  const stateSumOk = r1.states.every((st) => st.present === st.valid + st.blank + st.nul
    && st.electorate === st.present + st.abstencao
    && sum(Object.values(st.votes)) === st.valid);
  checks.push({ name: 'Soma dos votos por estado', ok: stateSumOk });
  checks.push({ name: 'Total de votos válidos consistente', ok: sum(Object.values(r1.totals)) === r1.valid });
  checks.push({ name: 'Eleitorado total correto', ok: r1.electorate === PRESIDENCY.electorate });
  checks.push({ name: 'Percentuais somam 100%', ok: Math.abs(sum(Object.values(percents)) - 100) <= 0.1 });
  // Sem segundo turno, o vencedor precisa de mais da metade dos votos válidos do 1º turno.
  // Com segundo turno, o vencedor é o mais votado entre os dois finalistas do 2º turno.
  checks.push({
    name: 'Regra de maioria absoluta respeitada',
    ok: r2 ? r2.totals[winnerId] * 2 > r2.valid : r1.totals[winnerId] * 2 > r1.valid,
  });
  if (r2) checks.push({ name: 'Segundo turno entre os dois mais votados', ok: Object.keys(r2.totals).length === 2 });
  return { ok: checks.every((c) => c.ok), checks };
}

// Apuração completa da eleição presidencial (dia da eleição).
export function runPresidentialVote(s, rng) {
  const p = ensurePresidential(s);
  const cands = presidentialCandidates(s, p);
  const totalSupport = sum(cands.map((c) => c.support));
  for (const c of cands) {
    const noise = (rng.next() * 2 - 1) * PRESIDENCY.noise;
    c.weight = round3(weightOf(s, p, c, totalSupport, noise));
  }
  const r1 = runRound(p, cands, 1);
  const rank = (list, totals) => [...list].sort((a, b) => totals[b.id] - totals[a.id] || b.weight - a.weight || (a.id < b.id ? -1 : 1));
  const ranking = rank(cands, r1.totals);
  let winner = ranking[0];
  let r2 = null;
  if (!(r1.totals[winner.id] * 2 > r1.valid)) {
    const two = ranking.slice(0, 2);
    r2 = runRound(p, two, 2);
    winner = rank(two, r2.totals)[0];
  }
  const percents1 = percentOf(r1.totals, r1.valid);
  const percents2 = r2 ? percentOf(r2.totals, r2.valid) : null;
  const verification = verifyVote(r1, r2, percents1, winner.id);
  const rankingOut = ranking.map((c) => ({
    id: c.id, name: c.name, party: c.party, acronym: c.acronym, number: c.number, player: Boolean(c.player),
    votes: r1.totals[c.id], share: percents1[c.id], votesRound2: r2 ? (r2.totals[c.id] ?? null) : null,
    won: c.id === winner.id, support: c.support, fame: round1(c.fame), debate: round1(debateAvgOf(p, c.player ? 'player' : c.id, c.skill || 50)),
    weight: c.weight,
  }));
  const result = {
    year: s.election.year,
    electorate: r1.electorate,
    present: r1.present,
    turnout: Math.round((r1.present / r1.electorate) * 10000) / 100,
    valid: r1.valid, blank: r1.blank, nul: r1.nul, abstencao: r1.abstencao,
    round1: { totals: r1.totals, percent: percents1, states: r1.states },
    round2: r2 ? { totals: r2.totals, percent: percents2, states: r2.states, candidates: Object.keys(r2.totals) } : null,
    winnerId: winner.id,
    winnerName: winner.name,
    ranking: rankingOut,
    verification,
    votingPlaces: Object.fromEntries(STATES.map((st) => [st.uf, Math.ceil(p.states[st.uf].population / PRESIDENCY.votingPlaceSize)])),
  };
  p.lastResult = { year: result.year, winnerName: winner.name, winnerPlayer: Boolean(winner.player), round2: Boolean(r2), verificationOk: verification.ok, playerRan: s.election.registered === 'presidente' };
  return {
    ranking: rankingOut.map((c) => ({ name: c.name, party: c.party, acronym: c.acronym, number: c.number, share: c.share, player: c.player, won: c.won, votes: c.votes })),
    winners: [winner.name],
    playerRegistered: s.election.registered === 'presidente',
    playerWon: Boolean(winner.player),
    presidential: result,
  };
}

// Pesquisa eleitoral simulada: intenção de voto, indecisos, rejeição, margem e amostra.
export function presidentialPoll(s, rng) {
  const p = ensurePresidential(s);
  if (!p.election) return null;
  const cands = presidentialCandidates(s, p);
  if (!cands.length) return null;
  const totalSupport = sum(cands.map((c) => c.support));
  const w = cands.map((c) => weightOf(s, p, c, totalSupport, 0));
  const wsum = sum(w);
  const avgCampaign = sum(cands.map((c) => c.campaignIndex ?? 0.5)) / cands.length;
  const undecided = round1(clamp(20 - 10 * avgCampaign, 4, 25));
  const raw = w.map((x) => Math.max(0.05, (x / wsum) * (100 - undecided) + (rng.next() * 2 - 1)));
  const rsum = sum(raw);
  const intention = raw.map((x) => round1((x / rsum) * (100 - undecided)));
  const diff = round1(100 - undecided - sum(intention));
  const top = intention.indexOf(Math.max(...intention));
  intention[top] = round1(intention[top] + diff);
  const poll = {
    day: s.day,
    date: formatDay(s.day),
    sample: PRESIDENCY.sampleSize,
    margin: PRESIDENCY.marginOfError,
    undecided,
    intention: Object.fromEntries(cands.map((c, i) => [c.id, intention[i]])),
    rejection: Object.fromEntries(cands.map((c) => {
      const debate = debateAvgOf(p, c.player ? 'player' : c.id, c.skill || 50);
      const value = 10 + 20 * (1 - debate / 100) + 20 * (1 - c.approval / 100) + (rng.next() * 4 - 2);
      return [c.id, round1(clamp(value, 1, 90))];
    })),
    names: Object.fromEntries(cands.map((c) => [c.id, c.name])),
  };
  p.election.polls.push(poll);
  if (p.election.polls.length > 12) p.election.polls.splice(0, p.election.polls.length - 12);
  return poll;
}

// ---------------- Debates ----------------
function nowDebateCandidates(s, p) {
  const cands = presidentialCandidates(s, p);
  const ai = cands.filter((c) => !c.player).sort((a, b) => b.support - a.support || (a.id < b.id ? -1 : 1)).slice(0, 4);
  return [...ai, ...cands.filter((c) => c.player)];
}

// Debate na data marcada. Se o jogador estiver registrado, o debate espera a resposta dele (ver pendingPlayerDebate).
export function runDebate(s, pres, debate, rng, input = null) {
  if (debate.status !== 'agendado') throw new GameError('Este debate já foi realizado.');
  const participants = nowDebateCandidates(s, pres);
  const limit = debate.timeSeconds;
  const evals = new Map(participants.map((c) => [c.id, []]));
  const answers = new Map(participants.map((c) => [c.id, []]));
  const replicas = [];
  const proposalsAdded = [];

  debate.themes.forEach((theme, i) => {
    const item = input?.answers?.[i] || {};
    for (const c of participants) {
      if (c.player) {
        const auto = !item.answer;
        const text = answerText(auto ? { choice: 1 } : item.answer, theme, limit);
        const ev = evaluateAnswer(text, theme);
        evals.get(c.id).push(ev);
        answers.get(c.id).push({ theme, text, auto, kind: 'resposta', scores: ev });
        if (!auto && ev.propostas >= 60) proposalsAdded.push({ theme, text, day: debate.day, source: 'debate' });
        if (item.treplica) {
          const t2 = answerText(item.treplica, theme, limit);
          const ev2 = evaluateAnswer(t2, theme);
          evals.get(c.id).push(ev2);
          answers.get(c.id).push({ theme, text: t2, auto: false, kind: 'treplica', scores: ev2 });
        }
      } else {
        const text = aiAnswer(c, theme, rng, limit);
        const ev = evaluateAnswer(text, theme);
        evals.get(c.id).push(ev);
        answers.get(c.id).push({ theme, text, auto: false, kind: 'resposta', scores: ev });
      }
    }
    const aiOnly = participants.filter((c) => !c.player);
    if (aiOnly.length > 1) {
      const attacker = pick(aiOnly, rng);
      const k = Math.floor(rng.next() * REPLICA_TEMPLATES.length);
      replicas.push({ theme, from: attacker.name, text: REPLICA_TEMPLATES[k](attacker.name, DEBATE_THEMES[theme].label) });
    }
  });

  // Discursos finais: o jogador pode escrever o seu; os adversários usam modelos fixos.
  for (const c of participants) {
    let text;
    if (c.player) text = (input?.closing && typeof input.closing.text === 'string' && input.closing.text.trim())
      ? input.closing.text.replace(/[\u0000-\u001F]/g, ' ').trim().slice(0, 300)
      : CLOSING_TEMPLATES[0];
    else text = CLOSING_TEMPLATES[Math.floor(rng.next() * CLOSING_TEMPLATES.length)];
    const ev = evaluateAnswer(text, null);
    evals.get(c.id).push(ev);
    answers.get(c.id).push({ theme: null, text, auto: c.player && !input?.closing, kind: 'discurso final', scores: ev });
  }

  const ranking = participants.map((c) => {
    const list = evals.get(c.id);
    const crit = Object.fromEntries(CRITERIA.map((k) => [k.key, Math.round(sum(list.map((e) => e[k.key])) / list.length)]));
    const overall = Math.round(sum(list.map((e) => e.overall)) / list.length);
    return { id: c.id, name: c.name, party: c.acronym, player: Boolean(c.player), overall, criteria: crit, answers: answers.get(c.id) };
  }).sort((a, b) => b.overall - a.overall || (a.id < b.id ? -1 : 1));

  for (const r of ranking) {
    const key = r.player ? 'player' : r.id;
    const st = pres.debateStats[key] || { sum: 0, count: 0 };
    pres.debateStats[key] = { sum: st.sum + r.overall, count: st.count + 1 };
  }

  const player = ranking.find((r) => r.player);
  if (player) applyDebateEffects(s, player.overall);
  if (proposalsAdded.length) {
    pres.proposals.push(...proposalsAdded);
    if (pres.proposals.length > 40) pres.proposals.splice(0, pres.proposals.length - 40);
  }

  const report = {
    id: debate.id, name: debate.name, broadcaster: debate.broadcaster, venue: debate.venue, mediator: debate.mediator,
    date: debate.date, day: debate.day, timeSeconds: limit, timeLabel: (DEBATE_TIME[limit] || DEBATE_TIME[DEBATE_DEFAULT_TIME]).label,
    themes: debate.themes.map((k) => DEBATE_THEMES[k].label),
    criteria: CRITERIA,
    ranking: ranking.map(({ answers: _a, ...r }) => r),
    answers: Object.fromEntries(ranking.map((r) => [r.id, r.answers])),
    replicas,
    winner: ranking[0].name,
    playerScore: player ? player.overall : null,
    playerRank: player ? ranking.indexOf(player) + 1 : null,
  };
  debate.status = 'realizado';
  debate.participants = participants.map((c) => c.id);
  debate.report = report;
  logEvent(s, 'debate', `${debate.name} realizado. Melhor avaliação: ${ranking[0].name}.`, 'presidente');
  return report;
}

function applyDebateEffects(s, score) {
  const delta = clamp((score - 50) / 50, -1, 1) * 1.5;
  s.fame = round1(clamp(s.fame + delta, 0, 100));
  if (score > 50) consumeReach(s, activeArea(s), Math.round((score - 50) * 10));
  else if (score < 40) s.support = Math.max(0, s.support - Math.round((40 - score) * 5));
}

// Debate que espera o jogador: bloqueia o avanço do tempo até ser respondido.
export function pendingPlayerDebate(s) {
  const p = s.presidential;
  if (!p?.election || s.election?.registered !== 'presidente') return null;
  return p.election.debates.find((d) => d.status === 'agendado' && d.day === s.day) || null;
}

// Eventos da eleição por dia: pesquisas na campanha oficial e debates só de adversários.
export function presidentialElectionDaily(s, rng, phase) {
  const p = s.presidential;
  if (!p?.election || !s.election) return;
  const e = p.election;
  if (phase === 'campanha' && (s.day - campaignStart(e.year)) % 10 === 0) presidentialPoll(s, rng);
  for (const d of e.debates) {
    if (d.status === 'agendado' && d.day === s.day && s.election.registered !== 'presidente') {
      runDebate(s, p, d, rng, null);
    }
  }
}

// ---------------- Governo federal ----------------
function makeMinister(rng) {
  return {
    name: `${pick(CANDIDATE_FIRST, rng)} ${pick(CANDIDATE_LAST, rng)}`,
    competence: between(40, 90, rng),
    partyId: rng.next() < 0.5 ? pick(EXISTING_PARTIES, rng).id : null,
  };
}

// Posse: gabinete, indicadores nacionais, Congresso e aliados. Chamado ao vencer a eleição.
export function startPresidency(s, rng) {
  const p = ensurePresidential(s);
  const indicators = Object.fromEntries(NATIONAL_INDICATORS.map((i) => [i.key, clamp(round1(i.base + between(-8, 8, rng)), 0, 100)]));
  const pool = {};
  const ministers = {};
  for (const dk of DEPARTMENT_KEYS) {
    pool[dk] = Array.from({ length: MINISTER_POOL_SIZE }, () => makeMinister(rng)).sort((a, b) => b.competence - a.competence);
    ministers[dk] = pool[dk][0];
  }
  const vicePool = Array.from({ length: 3 }, () => makeMinister(rng));
  const seatsFor = (total) => {
    const alloc = allocate(total, PARTY_WEIGHTS.slice(0, EXISTING_PARTIES.length));
    return Object.fromEntries(EXISTING_PARTIES.map((x, i) => [x.id, alloc[i]]));
  };
  const allies = Object.fromEntries(EXISTING_PARTIES.map((x, i) => [x.id, i < 2 ? CONGRESS.allyStrengthStart : 0]));
  p.government = {
    startDay: s.day,
    vice: vicePool[0],
    vicePool,
    pool,
    ministers,
    indicators,
    lastMark: { day: s.day, values: { ...indicators } },
    indicatorsPrev: { ...indicators },
    history: [{ day: s.day, values: { ...indicators } }],
    programs: [],
    events: [],
    lastEventKeys: [],
    congress: {
      seats: { camara: seatsFor(CAMARA_SEATS), senado: seatsFor(SENADO_SEATS) },
      allies,
      bills: [],
      lastNegotiationDay: -999,
      lastProposalDay: -999,
    },
    approvalPolls: [],
  };
  s.approval = Math.max(s.approval, 55);
  logEvent(s, 'governo', `Posse na Presidência. Vice-presidente: ${p.government.vice.name}. Gabinete formado.`, 'presidente');
}

// Encerramento do mandato presidencial: arquiva o resumo.
export function endPresidency(s, reason) {
  const p = s.presidential;
  if (!p?.government) return;
  const g = p.government;
  p.archive.push({
    startDay: g.startDay, endDay: s.day, reason,
    indicators: g.indicators, programsDone: g.programs.filter((x) => x.status === 'concluido').length,
    approval: s.approval,
  });
  if (p.archive.length > 10) p.archive.splice(0, p.archive.length - 10);
  p.government = null;
}

const programCost = (dept, key) => {
  const prog = DEPARTMENTS[dept]?.programs.find((x) => x.key === key);
  return prog || null;
};

function completeProgram(s, g, prog) {
  const minister = g.ministers[prog.dept];
  const eff = ministerEfficiency(minister.competence);
  for (const [k, v] of Object.entries(prog.effects)) {
    if (k in g.indicators) g.indicators[k] = round1(clamp(g.indicators[k] + v * eff, 0, 100));
  }
  s.approval = round1(clamp(s.approval + prog.approval * eff, 0, 100));
  prog.status = 'concluido';
  logEvent(s, 'programa', `Programa concluído: ${prog.name} (eficiência ${eff.toFixed(2)}).`, 'presidente');
}

function spawnPresidentialEvent(s, g, rng) {
  const pool = PRESIDENTIAL_EVENT_KEYS.filter((k) => !g.lastEventKeys.includes(k));
  const key = pick(pool.length ? pool : PRESIDENTIAL_EVENT_KEYS, rng);
  const data = PRESIDENTIAL_EVENTS[key];
  g.events.push({
    id: `pev-${s.day}-${key}`, key, title: data.title, text: data.text,
    options: data.options.map((o) => ({ ...o, indicators: { ...o.indicators } })),
    createdDay: s.day, deadline: s.day + PRESIDENTIAL_EVENT_DEADLINE, status: 'pendente', chosen: null, auto: false,
  });
  g.lastEventKeys.push(key);
  if (g.lastEventKeys.length > PRESIDENTIAL_EVENT_NO_REPEAT) g.lastEventKeys.splice(0, g.lastEventKeys.length - PRESIDENTIAL_EVENT_NO_REPEAT);
  if (g.events.length > 60) g.events.splice(0, g.events.length - 60);
}

// Aplica uma alternativa de evento. Custo sai do orçamento federal; sem saldo, só o automático segue sem custo.
function resolvePresidentialEvent(s, g, ev, index, auto) {
  const opt = ev.options[index];
  if (!opt) throw new GameError('Opção inválida.');
  if (opt.cost > 0) {
    if (canAfford(s, 'publico:federal', opt.cost)) {
      debit(s, 'publico:federal', opt.cost, `Evento presidencial: ${ev.title}`, 'investimentos');
    } else if (!auto) {
      throw new GameError('Orçamento federal insuficiente para esta alternativa.');
    } else {
      logEvent(s, 'evento', `Orçamento federal insuficiente: ${ev.title} seguiu sem custo.`, 'presidente');
    }
  }
  s.approval = round1(clamp(s.approval + opt.approval, 0, 100));
  for (const [k, v] of Object.entries(opt.indicators)) {
    if (k in g.indicators) g.indicators[k] = round1(clamp(g.indicators[k] + v, 0, 100));
  }
  ev.status = 'resolvido';
  ev.chosen = index;
  ev.auto = auto;
  logEvent(s, 'decisao', `${ev.title}: ${auto ? 'decisão automática' : 'decisão presidencial'} — ${opt.label}.`, 'presidente');
}

// Votação em uma casa. Retorna contagens inteiras que somam o total de cadeiras.
function chamberVote(s, g, chamber, bill, rng) {
  const seats = g.congress.seats[chamber];
  const tally = { favor: 0, contra: 0, abstencao: 0 };
  let total = 0;
  for (const party of EXISTING_PARTIES) {
    const seat = seats[party.id] || 0;
    total += seat;
    const aff = 1 - (Math.abs(party.ideology.economic - bill.econ) + Math.abs(party.ideology.social - bill.social)) / 200;
    const pf = clamp(
      0.5 + 0.35 * (aff - 0.5) + (g.congress.allies[party.id] || 0) * CONGRESS.allyBonus
        + (s.approval - 50) / CONGRESS.approvalEffect + (rng.next() * 2 - 1) * CONGRESS.noise,
      0.02, 0.98,
    );
    const abst = Math.round(seat * 0.03);
    const favor = Math.min(seat - abst, Math.round(seat * pf));
    tally.favor += favor;
    tally.abstencao += abst;
    tally.contra += seat - favor - abst;
  }
  return { ...tally, total };
}

const majorityPasses = (t) => t.favor * 2 > t.total;
const supermajorityPasses = (t) => t.favor * 3 >= t.total * 2;

function applySanction(s, g, bill, tacit) {
  bill.status = 'sancionada';
  g.indicators[bill.sector] = round1(clamp(g.indicators[bill.sector] + CONGRESS.billEffect, 0, 100));
  s.approval = round1(clamp(s.approval + CONGRESS.sanctionApproval, 0, 100));
  logEvent(s, 'lei', `Lei sancionada${tacit ? ' tacitamente' : ''}: ${bill.title}.`, 'presidente');
}

function createBill(s, g, rng, origin, sector, title, econ, social) {
  // Contador sequencial: IDs não se repetem mesmo quando a lista é aparada.
  g.congress.seq = (g.congress.seq || 0) + 1;
  g.congress.bills.push({
    id: `lei-${g.congress.seq}-${s.day}-${origin}`, title, sector, econ, social, origem: origin,
    status: 'camara', deadline: s.day + CONGRESS.camaraDays, votes: {}, decidedDay: null,
  });
  if (g.congress.bills.length > 60) g.congress.bills.splice(0, g.congress.bills.length - 60);
}

function congressDaily(s, rng, g) {
  const c = g.congress;
  if (s.day % CONGRESS.billEveryDays === 0) {
    const n = rng.next() < 0.5 ? 1 : 2;
    for (let i = 0; i < n; i += 1) {
      const t = pick(PRESIDENTIAL_BILLS, rng);
      createBill(s, g, rng, 'congresso', t.sector, t.title, t.econ, t.social);
    }
  }
  for (const bill of c.bills) {
    if (bill.status === 'camara' && s.day >= bill.deadline) {
      const t = chamberVote(s, g, 'camara', bill, rng);
      bill.votes.camara = t;
      if (majorityPasses(t)) { bill.status = 'senado'; bill.deadline = s.day + CONGRESS.senadoDays; }
      else { bill.status = 'rejeitada'; bill.decidedDay = s.day; }
    } else if (bill.status === 'senado' && s.day >= bill.deadline) {
      const t = chamberVote(s, g, 'senado', bill, rng);
      bill.votes.senado = t;
      if (majorityPasses(t)) { bill.status = 'sancao'; bill.deadline = s.day + CONGRESS.sancaoDays; }
      else { bill.status = 'rejeitada'; bill.decidedDay = s.day; }
    } else if (bill.status === 'sancao' && s.day >= bill.deadline) {
      applySanction(s, g, bill, true);
      bill.decidedDay = s.day;
    }
  }
}

// Dia a dia do governo: programas, indicadores, aprovação, eventos, Congresso e relatórios.
export function presidencyDaily(s, rng) {
  if (!s.office || s.office.id !== 'presidente') return;
  const g = s.presidential?.government;
  if (!g) return;
  for (const prog of g.programs) {
    if (prog.status !== 'andamento') continue;
    prog.daysLeft -= 1;
    if (prog.daysLeft <= 0) completeProgram(s, g, prog);
  }
  for (const k of NATIONAL_KEYS) {
    g.indicators[k] = round1(clamp(g.indicators[k] + (50 - g.indicators[k]) * 0.0008 + (rng.next() - 0.5) * 0.2, 0, 100));
  }
  const avg = sum(NATIONAL_KEYS.map((k) => g.indicators[k])) / NATIONAL_KEYS.length;
  s.approval = round1(clamp(s.approval + (25 + avg * 0.5 - s.approval) * 0.01, 0, 100));

  for (const ev of g.events) {
    if (ev.status === 'pendente' && s.day >= ev.deadline) resolvePresidentialEvent(s, g, ev, 0, true);
  }
  if (!g.events.some((e) => e.status === 'pendente') && rng.next() < PRESIDENTIAL_EVENT_CHANCE) spawnPresidentialEvent(s, g, rng);

  congressDaily(s, rng, g);

  if (s.day % 30 === 0) {
    g.indicatorsPrev = g.lastMark.values;
    g.lastMark = { day: s.day, values: { ...g.indicators } };
    g.history.push({ day: s.day, values: { ...g.indicators } });
    if (g.history.length > 120) g.history.splice(0, g.history.length - 120);
    const approve = clamp(Math.round(s.approval + (rng.next() * 4 - 2)), 0, 95);
    const undecided = between(5, 12, rng);
    const disapprove = Math.max(0, 100 - approve - undecided);
    g.approvalPolls.push({ day: s.day, date: formatDay(s.day), approve, disapprove, undecided: 100 - approve - disapprove });
    if (g.approvalPolls.length > 24) g.approvalPolls.splice(0, g.approvalPolls.length - 24);
    logEvent(s, 'relatorio', `Relatório mensal: aprovação do governo em ${s.approval.toFixed(1)}%.`, 'presidente');
  }
}

// ---------------- Ações da Presidência ----------------
export function handlePresidentialAction(s, rng, action, payload) {
  const p = ensurePresidential(s);
  const g = p.government;
  const needGov = () => { if (!g) throw new GameError('Você ainda não ocupa a Presidência.'); };
  switch (action) {
    case 'responderDebate': {
      const debate = p.election?.debates.find((d) => d.id === payload.debateId);
      if (!debate) throw new GameError('Debate não encontrado.');
      if (debate.status !== 'agendado') throw new GameError('Este debate já foi realizado.');
      if (s.election?.registered !== 'presidente') throw new GameError('Você precisa estar registrado como candidato à Presidência.');
      if (debate.day !== s.day) throw new GameError(`Este debate acontece em ${debate.date}.`);
      runDebate(s, p, debate, rng, { answers: Array.isArray(payload.answers) ? payload.answers : [], closing: payload.closing || null });
      break;
    }
    case 'viajarEstado': {
      const st = p.states[payload.uf];
      if (!st) throw new GameError('Estado inválido.');
      if (p.currentState === payload.uf) throw new GameError('Você já está neste estado.');
      p.currentState = payload.uf;
      logEvent(s, 'viagem', `Viajou para ${st.name}.`, s.election ? 'presidente' : null);
      break;
    }
    case 'apresentarProposta': {
      if (s.election?.registered !== 'presidente') throw new GameError('Registre-se como candidato para apresentar propostas.');
      if (!DEBATE_THEMES[payload.theme]) throw new GameError('Tema inválido.');
      const text = answerText({ text: payload.text }, payload.theme, DEBATE_DEFAULT_TIME);
      const ev = evaluateAnswer(text, payload.theme);
      if (ev.propostas < 60) throw new GameError('A proposta precisa de mais detalhes: informe o que será feito e como (metas, prazo ou fonte de recurso).');
      p.proposals.push({ theme: payload.theme, text, day: s.day, source: 'proposta' });
      if (p.proposals.length > 40) p.proposals.splice(0, p.proposals.length - 40);
      logEvent(s, 'proposta', `Proposta apresentada: ${DEBATE_THEMES[payload.theme].label}.`, 'presidente');
      break;
    }
    case 'escolherVice': {
      needGov();
      const v = g.vicePool[Number(payload.index)];
      if (!v) throw new GameError('Escolha um vice da lista.');
      g.vice = v;
      logEvent(s, 'governo', `Vice-presidente: ${v.name}.`, 'presidente');
      break;
    }
    case 'nomearMinistro': {
      needGov();
      if (!DEPARTMENTS[payload.dept]) throw new GameError('Departamento inválido.');
      const m = g.pool[payload.dept][Number(payload.index)];
      if (!m) throw new GameError('Escolha um nome da lista.');
      g.ministers[payload.dept] = m;
      logEvent(s, 'governo', `Novo(a) ministro(a) de ${DEPARTMENTS[payload.dept].label}: ${m.name}.`, 'presidente');
      break;
    }
    case 'iniciarPrograma': {
      needGov();
      const prog = programCost(payload.dept, payload.key);
      if (!prog) throw new GameError('Programa inexistente.');
      const active = g.programs.filter((x) => x.status === 'andamento').length;
      if (active >= PROGRAMS_ACTIVE_MAX) throw new GameError(`Limite de ${PROGRAMS_ACTIVE_MAX} programas em andamento.`);
      debit(s, 'publico:federal', prog.cost, `Programa: ${prog.name}`, 'investimentos');
      g.programs.push({
        id: `prog-${s.day}-${g.programs.length}`, dept: payload.dept, key: prog.key, name: prog.name,
        cost: prog.cost, daysLeft: prog.days, days: prog.days, effects: prog.effects, approval: prog.approval,
        status: 'andamento', startDay: s.day,
      });
      logEvent(s, 'programa', `Programa iniciado: ${prog.name}.`, 'presidente');
      break;
    }
    case 'decidirPresidencial': {
      needGov();
      const ev = g.events.find((x) => x.id === payload.eventId);
      if (!ev || ev.status !== 'pendente') throw new GameError('Evento não está pendente.');
      resolvePresidentialEvent(s, g, ev, Number(payload.option), false);
      break;
    }
    case 'sancionarLei': {
      needGov();
      const bill = g.congress.bills.find((b) => b.id === payload.billId);
      if (!bill || bill.status !== 'sancao') throw new GameError('Esta lei não está aguardando sanção.');
      if (payload.decision === 'sancionar') {
        applySanction(s, g, bill, false);
        bill.decidedDay = s.day;
      } else if (payload.decision === 'vetar') {
        // Veto: a derrubada exige dois terços em cada casa (votação simulada imediata).
        const ca = chamberVote(s, g, 'camara', bill, rng);
        const se = chamberVote(s, g, 'senado', bill, rng);
        if (supermajorityPasses(ca) && supermajorityPasses(se)) {
          bill.status = 'promulgada';
          applySanction(s, g, bill, false);
          bill.status = 'promulgada';
          logEvent(s, 'lei', `Veto derrubado pelo Congresso: ${bill.title}.`, 'presidente');
        } else {
          bill.status = 'vetada';
          s.approval = round1(clamp(s.approval + CONGRESS.vetoApproval, 0, 100));
          logEvent(s, 'lei', `Lei vetada: ${bill.title}. O veto não foi derrubado.`, 'presidente');
        }
        bill.votes.derrubada = { camara: ca, senado: se };
        bill.decidedDay = s.day;
      } else {
        throw new GameError('Escolha sancionar ou vetar.');
      }
      break;
    }
    case 'negociarApoio': {
      needGov();
      if (!EXISTING_PARTIES.some((x) => x.id === payload.partyId)) throw new GameError('Partido inválido.');
      if (s.day - g.congress.lastNegotiationDay < NEGOTIATION.cooldownDays) throw new GameError('Aguarde antes de nova negociação.');
      debit(s, 'publico:federal', NEGOTIATION.cost, 'Negociação com partido (emendas)', 'outros');
      const cur = g.congress.allies[payload.partyId] || 0;
      g.congress.allies[payload.partyId] = round1(Math.min(NEGOTIATION.strengthMax, cur + NEGOTIATION.strengthStep));
      g.congress.lastNegotiationDay = s.day;
      logEvent(s, 'congresso', 'Negociação de apoio parlamentar concluída.', 'presidente');
      break;
    }
    case 'enviarProjetoLei': {
      needGov();
      if (!NATIONAL_KEYS.includes(payload.sector)) throw new GameError('Setor inválido.');
      if (s.day - g.congress.lastProposalDay < CONGRESS.billEveryDays) throw new GameError('Você já enviou um projeto recentemente.');
      createBill(s, g, rng, 'presidente', payload.sector, `Projeto do Executivo: ${NATIONAL_INDICATORS.find((i) => i.key === payload.sector).label}`, 50, 50);
      g.congress.lastProposalDay = s.day;
      logEvent(s, 'congresso', 'Projeto de lei enviado ao Congresso.', 'presidente');
      break;
    }
    default:
      return false;
  }
  return true;
}


// Resumo leve para a tela de Presidência e para MINHA CARREIRA.
export function presidencySummary(s) {
  const p = s.presidential;
  if (!p) return null;
  const e = p.election;
  const g = p.government;
  const lastPoll = e?.polls?.length ? e.polls[e.polls.length - 1] : null;
  return {
    currentState: p.currentState,
    electorate: PRESIDENCY.electorate,
    debates: e ? e.debates.map((d) => ({
      id: d.id, name: d.name, broadcaster: d.broadcaster, venue: d.venue, mediator: d.mediator,
      date: d.date, day: d.day, status: d.status, themes: d.themes.map((k) => DEBATE_THEMES[k].label),
      timeLabel: (DEBATE_TIME[d.timeSeconds] || DEBATE_TIME[DEBATE_DEFAULT_TIME]).label,
      playerNeeded: d.status === 'agendado' && s.election?.registered === 'presidente' && d.day === s.day,
    })) : [],
    lastPoll,
    proposals: p.proposals.length,
    lastResult: p.lastResult,
    government: g ? {
      vice: g.vice,
      ministers: Object.fromEntries(DEPARTMENT_KEYS.map((k) => [k, { name: g.ministers[k].name, competence: g.ministers[k].competence, label: DEPARTMENTS[k].label }])),
      indicators: g.indicators,
      indicatorsPrev: g.indicatorsPrev,
      programs: g.programs,
      events: g.events.slice(-12),
      bills: g.congress.bills.slice(-12),
      allies: g.congress.allies,
      pool: g.pool,
      vicePool: g.vicePool,
      seats: g.congress.seats,
      approvalPolls: g.approvalPolls.slice(-6),
      history: g.history.slice(-24),
    } : null,
    archive: p.archive,
  };
}
