// Dados dos cargos, partidos fictícios, projetos administrativos, eventos e pautas.
// Todos os números são configuráveis aqui. Salários são fictícios.
// Premissas assumidas (não definidas no briefing): mandato de 4 anos para Presidente,
// requisitos do Presidente (apoio 15.000.000 e dinheiro 50.000; ver presidencyData.js), e eleições simultâneas a cada 4 anos
// (Senado: 8 anos de mandato, eleito a cada 8 anos).

export const OFFICE_ORDER = [
  'vereador', 'prefeito', 'deputado_estadual', 'governador',
  'deputado_federal', 'senador', 'presidente',
];

export const OFFICES = {
  vereador: {
    id: 'vereador', name: 'Vereador', scope: 'municipal', arena: 'Câmara Municipal',
    legislative: true, council: 21, seats: 9, cycle: 4, mandateYears: 4, salary: 8000,
    reelection: { allowed: true, max: 3 }, canResign: true,
    requirements: { support: 1000, money: 2000, party: true, campaign: false },
    area: 'Município (bairros, serviços e leis locais)',
    responsibilities: ['Criar e votar leis municipais', 'Fiscalizar a prefeitura', 'Representar moradores'],
    powers: ['Criar projetos de lei municipais', 'Votar propostas na Câmara', 'Propor melhorias para bairros'],
    limits: ['Não administra diretamente a prefeitura', 'Não legisla sobre temas estaduais ou federais'],
    exclusiveEvents: ['denuncia_vereador', 'enchente_bairro'],
  },
  prefeito: {
    id: 'prefeito', name: 'Prefeito', scope: 'municipal', arena: 'Prefeitura Municipal',
    executive: true, seats: 1, cycle: 4, mandateYears: 4, salary: 22000,
    reelection: { allowed: true, max: 1 }, canResign: true,
    requirements: { support: 20000, money: 15000, party: true, campaign: true },
    area: 'Administração municipal',
    responsibilities: ['Administrar saúde, educação e obras', 'Executar o orçamento municipal', 'Prestar contas à Câmara'],
    powers: ['Construir hospitais e escolas', 'Contratar servidores dentro do orçamento', 'Criar programas sociais'],
    limits: ['Não pode gastar além do orçamento municipal', 'Segurança limitada às competências municipais'],
    exclusiveEvents: ['enchente_cidade', 'greve_servidores'],
  },
  deputado_estadual: {
    id: 'deputado_estadual', name: 'Deputado Estadual', scope: 'estadual', arena: 'Assembleia Legislativa',
    legislative: true, council: 24, seats: 10, cycle: 4, mandateYears: 4, salary: 25000,
    reelection: { allowed: true, max: 3 }, canResign: true,
    requirements: { support: 50000, money: 20000, party: true, campaign: true },
    area: 'Estado',
    responsibilities: ['Criar leis estaduais', 'Fiscalizar o governador', 'Participar de comissões'],
    powers: ['Propor projetos de lei estaduais', 'Votar o orçamento estadual', 'Propor investimentos regionais'],
    limits: ['Não administra diretamente o estado', 'Não legisla sobre temas federais'],
    exclusiveEvents: ['comissao_especial', 'operacao_policial'],
  },
  governador: {
    id: 'governador', name: 'Governador', scope: 'estadual', arena: 'Governo do Estado',
    executive: true, seats: 1, cycle: 4, mandateYears: 4, salary: 40000,
    reelection: { allowed: true, max: 1 }, canResign: true,
    requirements: { support: 300000, money: 35000, party: true, campaign: true },
    area: 'Administração estadual',
    responsibilities: ['Administrar saúde, educação e segurança estaduais', 'Executar o orçamento do estado'],
    powers: ['Criar programas estaduais', 'Investir em infraestrutura', 'Enviar propostas à Assembleia'],
    limits: ['Não pode gastar além do orçamento estadual', 'Não controla a política monetária federal'],
    exclusiveEvents: ['greve_policia', 'seca_regional'],
  },
  deputado_federal: {
    id: 'deputado_federal', name: 'Deputado Federal', scope: 'federal', arena: 'Câmara dos Deputados',
    legislative: true, council: 30, seats: 15, cycle: 4, mandateYears: 4, salary: 35000,
    reelection: { allowed: true, max: 3 }, canResign: true,
    requirements: { support: 500000, money: 40000, party: true, campaign: true },
    area: 'Nação',
    responsibilities: ['Criar leis federais', 'Votar o orçamento da União', 'Fiscalizar o Poder Executivo'],
    powers: ['Apresentar projetos de lei federais', 'Propor emendas orçamentárias', 'Participar de comissões'],
    limits: ['Não administra diretamente o governo', 'Emendas seguem as regras do orçamento'],
    exclusiveEvents: ['comissao_cpi', 'reforma_tributaria'],
  },
  senador: {
    id: 'senador', name: 'Senador', scope: 'federal', arena: 'Senado Federal',
    legislative: true, council: 27, seats: 1, cycle: 8, mandateYears: 8, salary: 45000,
    reelection: { allowed: true, max: 2 }, canResign: true,
    requirements: { support: 800000, money: 45000, party: true, campaign: true },
    area: 'Nação (representação do estado)',
    responsibilities: ['Votar projetos federais', 'Analisar indicações', 'Fiscalizar o governo'],
    powers: ['Apresentar projetos de lei', 'Participar de sabatinas', 'Decidir temas nacionais importantes'],
    limits: ['Mandato de 8 anos', 'Não administra o orçamento diretamente'],
    exclusiveEvents: ['sabatina_ministro', 'debate_nacional'],
  },
  presidente: {
    id: 'presidente', name: 'Presidente da República', scope: 'federal', arena: 'Governo Federal',
    executive: true, seats: 1, cycle: 4, mandateYears: 4, salary: 60000,
    reelection: { allowed: true, max: 1 }, canResign: false,
    requirements: { support: 15000000, money: 50000, party: true, campaign: true },
    area: 'Administração federal',
    responsibilities: ['Administrar o governo federal', 'Executar o orçamento da União', 'Representar o país'],
    powers: ['Propor projetos ao Congresso', 'Criar programas nacionais', 'Investir em infraestrutura nacional'],
    limits: ['Não pode gastar além do orçamento federal', 'Mandato não pode ser abandonado'],
    exclusiveEvents: ['crise_internacional', 'pandemia_nacional'],
  },
};

// Receita mensal (repasse) de cada orçamento público. Fictícia e configurável.
export const MONTHLY_REVENUE = { municipal: 900000, estadual: 4000000, federal: 25000000 };

// Quantidade de vagas de cada cargo na eleição (ranking dos mais votados).
export const SESSION_EVERY_DAYS = 15;
export const VOTE_WINDOW_DAYS = 5;

// Partidos fictícios que podem ser escolhidos para filiação ou usados pelos adversários.
export const EXISTING_PARTIES = [
  { id: 'ext-ppg', name: 'Partido do Progresso', acronym: 'PPG', number: '71', ideology: { economic: 60, social: 55 } },
  { id: 'ext-mc', name: 'Movimento Cidadão', acronym: 'MC', number: '72', ideology: { economic: 40, social: 70 } },
  { id: 'ext-fv', name: 'Frente Verde', acronym: 'FV', number: '73', ideology: { economic: 30, social: 80 } },
  { id: 'ext-un', name: 'União Nacional', acronym: 'UN', number: '74', ideology: { economic: 75, social: 30 } },
  { id: 'ext-pp', name: 'Partido Popular', acronym: 'PP', number: '75', ideology: { economic: 25, social: 45 } },
  { id: 'ext-cd', name: 'Centro Democrático', acronym: 'CD', number: '76', ideology: { economic: 55, social: 50 } },
];

export const PARTY_BY_ID = Object.fromEntries(EXISTING_PARTIES.map((p) => [p.id, p]));

// Pautas que aparecem nas sessões legislativas, por escopo.
export const BILL_TEMPLATES = {
  municipal: [
    { title: 'Criação de ciclovias nos bairros', sector: 'infraestrutura', econ: 40, social: 70 },
    { title: 'Programa de creche de bairro', sector: 'educacao', econ: 35, social: 75 },
    { title: 'Revisão do IPTU residencial', sector: 'economia', econ: 70, social: 40 },
    { title: 'Feira de agricultores urbanos', sector: 'economia', econ: 45, social: 60 },
    { title: 'Fiscalização de obras públicas', sector: 'seguranca', econ: 50, social: 50 },
  ],
  estadual: [
    { title: 'Programa estadual de bolsas escolares', sector: 'educacao', econ: 35, social: 75 },
    { title: 'Reforma do sistema de segurança estadual', sector: 'seguranca', econ: 55, social: 35 },
    { title: 'Incentivo a startups regionais', sector: 'economia', econ: 75, social: 55 },
    { title: 'Ampliação de leitos regionais', sector: 'saude', econ: 40, social: 80 },
  ],
  federal: [
    { title: 'Reforma tributária simplificada', sector: 'economia', econ: 80, social: 40 },
    { title: 'Marco do saneamento nacional', sector: 'infraestrutura', econ: 50, social: 65 },
    { title: 'Piso salarial para professores', sector: 'educacao', econ: 30, social: 80 },
    { title: 'Ampliação do atendimento de saúde', sector: 'saude', econ: 35, social: 85 },
    { title: 'Lei de transparência orçamentária', sector: 'seguranca', econ: 60, social: 60 },
  ],
};

// Projetos administrativos por escopo. "capital" é pago uma vez; "monthly" é pago todo mês.
// "effects" aumenta indicadores ao concluir (capital) ou a cada mês (monthly).
export const PROJECTS = {
  municipal: [
    { key: 'hospital', name: 'Construir hospital', capital: 900000, days: 120, effects: { saude: 8 } },
    { key: 'escola', name: 'Construir escola', capital: 600000, days: 90, effects: { educacao: 8 } },
    { key: 'reforma_rua', name: 'Reformar ruas', capital: 220000, days: 45, effects: { infraestrutura: 5 } },
    { key: 'pavimentacao', name: 'Pavimentação de bairros', capital: 360000, days: 60, effects: { infraestrutura: 6 } },
    { key: 'iluminacao', name: 'Iluminação pública', capital: 160000, days: 30, effects: { seguranca: 4 } },
    { key: 'programa_social', name: 'Programa social mensal', monthly: 70000, effects: { saude: 2, educacao: 2 } },
    { key: 'servidores', name: 'Contratar servidores (agentes e guardas)', monthly: 90000, effects: { seguranca: 3 } },
    { key: 'limpeza', name: 'Reforço da limpeza urbana', monthly: 40000, effects: { saude: 1 } },
  ],
  estadual: [
    { key: 'hospital_regional', name: 'Hospital regional', capital: 6000000, days: 180, effects: { saude: 8 } },
    { key: 'escola_tecnica', name: 'Escola técnica estadual', capital: 4000000, days: 150, effects: { educacao: 8 } },
    { key: 'rodovia', name: 'Rodovias estaduais', capital: 7000000, days: 180, effects: { infraestrutura: 6 } },
    { key: 'seguranca_publica', name: 'Programa de segurança pública', monthly: 500000, effects: { seguranca: 5 } },
    { key: 'desenvolvimento', name: 'Desenvolvimento econômico', monthly: 300000, effects: { economia: 5 } },
  ],
  federal: [
    { key: 'saude_nacional', name: 'Programa nacional de saúde', monthly: 2000000, effects: { saude: 5 } },
    { key: 'educacao_nacional', name: 'Plano nacional de educação', monthly: 1800000, effects: { educacao: 5 } },
    { key: 'obras_federais', name: 'Obras federais de infraestrutura', capital: 40000000, days: 240, effects: { infraestrutura: 8 } },
    { key: 'seguranca_nacional', name: 'Reforço da segurança nacional', monthly: 1500000, effects: { seguranca: 5 } },
    { key: 'estimulo_economia', name: 'Estímulo à economia', monthly: 1200000, effects: { economia: 5 } },
  ],
};

export const INDICATOR_KEYS = ['saude', 'educacao', 'infraestrutura', 'seguranca', 'economia'];
export const INDICATOR_LABELS = {
  saude: 'Saúde', educacao: 'Educação', infraestrutura: 'Infraestrutura', seguranca: 'Segurança', economia: 'Economia',
};

// Eventos gerais e exclusivos. Cada opção aplica efeitos imediatos.
// effects: approval (aprovação), indicators (variação), cost (custo do orçamento do escopo).
export const EVENTS = {
  crise_economica: {
    title: 'Crise econômica', text: 'A queda na arrecadação ameaça o orçamento.',
    options: [
      { label: 'Cortar gastos', effects: { approval: -2, indicators: { economia: 3 } } },
      { label: 'Ampliar crédito', effects: { approval: 2, indicators: { economia: -2 }, cost: 0 } },
    ],
  },
  surto_saude: {
    title: 'Surto de doença', text: 'Casos aumentam nos bairros. Há pressão por ação imediata.',
    options: [
      { label: 'Mutirão de vacinação (custo de R$ 150 mil)', effects: { approval: 2, indicators: { saude: 3 }, cost: 150000 } },
      { label: 'Aguardar', effects: { approval: -3, indicators: { saude: -5 } } },
    ],
  },
  boa_safra: {
    title: 'Boa safra', text: 'Produtores locais pedem parceria para escoar a produção.',
    options: [
      { label: 'Aceitar parceria', effects: { approval: 1, indicators: { economia: 4 } } },
      { label: 'Ignorar', effects: {} },
    ],
  },
  protesto: {
    title: 'Protesto em frente ao prédio público', text: 'Manifestantes pedem diálogo e respostas.',
    options: [
      { label: 'Dialogar', effects: { approval: 1, indicators: { seguranca: -1 } } },
      { label: 'Reprimir', effects: { approval: -6, indicators: { seguranca: 2 } } },
    ],
  },
  denuncia_vereador: {
    title: 'Denúncia de irregularidade', text: 'Um morador denuncia gastos suspeitos em seu gabinete.',
    options: [
      { label: 'Abrir investigação pública', effects: { approval: 3 } },
      { label: 'Negar e arquivar', effects: { approval: -5 } },
    ],
  },
  enchente_bairro: {
    title: 'Enchente no bairro', text: 'Chuva forte alaga ruas e casas do bairro.',
    options: [
      { label: 'Plano de emergência (R$ 80 mil)', effects: { approval: 3, indicators: { infraestrutura: 2 }, cost: 80000 } },
      { label: 'Aguardar a vazante', effects: { approval: -4, indicators: { infraestrutura: -4 } } },
    ],
  },
  enchente_cidade: {
    title: 'Enchente na cidade', text: 'O alagamento atinge vários bairros. A prefeitura precisa decidir.',
    options: [
      { label: 'Plano de emergência (R$ 250 mil)', effects: { approval: 4, indicators: { infraestrutura: 3 }, cost: 250000 } },
      { label: 'Esperar o fim das chuvas', effects: { approval: -6, indicators: { infraestrutura: -6 } } },
    ],
  },
  greve_servidores: {
    title: 'Greve dos servidores municipais', text: 'Professores e agentes param por reajuste.',
    options: [
      { label: 'Negociar reajuste (R$ 120 mil)', effects: { approval: 2, indicators: { educacao: 2 }, cost: 120000 } },
      { label: 'Manter a proposta', effects: { approval: -4, indicators: { educacao: -3 } } },
    ],
  },
  comissao_especial: {
    title: 'Comissão especial', text: 'Uma comissão pede relatório sobre o orçamento estadual.',
    options: [
      { label: 'Participar e propor melhorias', effects: { approval: 2, indicators: { economia: 2 } } },
      { label: 'Recusar participação', effects: { approval: -2 } },
    ],
  },
  operacao_policial: {
    title: 'Operação policial controversa', text: 'Moradores questionam a ação da polícia no bairro.',
    options: [
      { label: 'Pedir apuração', effects: { approval: 2, indicators: { seguranca: -1 } } },
      { label: 'Apoiar a operação', effects: { approval: -3, indicators: { seguranca: 2 } } },
    ],
  },
  greve_policia: {
    title: 'Greve da polícia estadual', text: 'Policiais paralisam por salários atrasados.',
    options: [
      { label: 'Pagar reajuste (R$ 1,5 mi)', effects: { approval: 3, indicators: { seguranca: 2 }, cost: 1500000 } },
      { label: 'Recusar negociação', effects: { approval: -8, indicators: { seguranca: -6 } } },
    ],
  },
  seca_regional: {
    title: 'Seca regional', text: 'Produtores pedem auxílio emergencial.',
    options: [
      { label: 'Liberar auxílio (R$ 2 mi)', effects: { approval: 3, indicators: { economia: 2 }, cost: 2000000 } },
      { label: 'Orientar produtores', effects: { approval: -2, indicators: { economia: -2 } } },
    ],
  },
  comissao_cpi: {
    title: 'Pedido de CPI', text: 'Parlamentares pedem investigação sobre contratos públicos.',
    options: [
      { label: 'Apoiar a CPI', effects: { approval: 3 } },
      { label: 'Votar contra', effects: { approval: -4 } },
    ],
  },
  reforma_tributaria: {
    title: 'Pressão por reforma tributária', text: 'Setores econômicos pedem mudanças imediatas.',
    options: [
      { label: 'Apoiar mudanças', effects: { approval: -1, indicators: { economia: 3 } } },
      { label: 'Manter o sistema', effects: { approval: 1, indicators: { economia: -2 } } },
    ],
  },
  sabatina_ministro: {
    title: 'Sabatina de indicado ministerial', text: 'O Senado precisa aprovar um nome indicado pelo governo.',
    options: [
      { label: 'Aprovar após sabatina', effects: { approval: 1 } },
      { label: 'Rejeitar a indicação', effects: { approval: 2 } },
    ],
  },
  debate_nacional: {
    title: 'Debate nacional', text: 'Uma emissora convida para um debate sobre o país.',
    options: [
      { label: 'Aceitar o debate', effects: { approval: 2 } },
      { label: 'Recusar', effects: { approval: -2 } },
    ],
  },
  crise_internacional: {
    title: 'Crise internacional', text: 'Tensões externas afetam preços e exportações.',
    options: [
      { label: 'Diplomacia e reservas (R$ 5 mi)', effects: { approval: 2, indicators: { economia: 2 }, cost: 5000000 } },
      { label: 'Adotar postura firme', effects: { approval: -3, indicators: { economia: -4 } } },
    ],
  },
  pandemia_nacional: {
    title: 'Ameaça de pandemia nacional', text: 'Autoridades pedem plano federal de saúde.',
    options: [
      { label: 'Plano federal (R$ 6 mi)', effects: { approval: 4, indicators: { saude: 5 }, cost: 6000000 } },
      { label: 'Deixar para os estados', effects: { approval: -5, indicators: { saude: -6 } } },
    ],
  },
};

export const GENERAL_EVENTS = ['crise_economica', 'surto_saude', 'boa_safra', 'protesto'];

// Apoio popular é uma contagem de apoiadores (não uma escala de 0 a 100).
export const CAMPAIGN_ACTIONS = {
  comicio: { label: 'Fazer comício', cost: 2000, support: 4000, fame: 1 },
  panfletagem: { label: 'Panfletagem nos bairros', cost: 800, support: 1500, fame: 0 },
  midia: { label: 'Campanha na mídia', cost: 5000, support: 2500, fame: 3 },
};

export const CANDIDATE_FIRST = ['Marina', 'Carlos', 'Joana', 'Rafael', 'Helena', 'Bruno', 'Patrícia', 'Eduardo', 'Renata', 'Luiz', 'Camila', 'Felipe'];
export const CANDIDATE_LAST = ['Almeida', 'Ribeiro', 'Costa', 'Nascimento', 'Pereira', 'Lima', 'Teixeira', 'Barbosa', 'Moura', 'Araújo', 'Castro', 'Vieira'];
