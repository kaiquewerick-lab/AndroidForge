// Desenhos do partido: logotipo, símbolo e bandeira em SVG. Não executa scripts.
const HEX = /^#[0-9a-fA-F]{6}$/;
const col = (v, fb) => (HEX.test(v) ? v : fb);

const SHAPES = {
  circulo: '<circle cx="50" cy="50" r="40"/>',
  triangulo: '<polygon points="50,10 90,85 10,85"/>',
  quadrado: '<rect x="15" y="15" width="70" height="70"/>',
  losango: '<polygon points="50,8 92,50 50,92 8,50"/>',
  estrela: '<polygon points="50,6 61,36 93,36 67,55 77,88 50,68 23,88 33,55 7,36 39,36"/>',
  hexagono: '<polygon points="50,8 88,30 88,70 50,92 12,70 12,30"/>',
};

const ICONS = {
  folha: '<path d="M20,80 C20,30 60,15 85,15 C85,60 65,85 20,80 Z"/>',
  sol: '<circle cx="50" cy="50" r="18"/><path d="M50,8 L55,28 L45,28 Z M50,92 L55,72 L45,72 Z M8,50 L28,55 L28,45 Z M92,50 L72,55 L72,45 Z M20,20 L36,34 L30,40 Z M80,80 L64,66 L70,60 Z M80,20 L66,36 L60,30 Z M20,80 L34,64 L40,70 Z"/>',
  escudo: '<path d="M50,8 L88,20 L84,60 Q78,82 50,92 Q22,82 16,60 L12,20 Z"/>',
  tocha: '<path d="M50,8 Q64,28 60,40 Q72,46 68,64 Q62,84 50,88 Q38,84 32,64 Q28,46 40,40 Q36,28 50,8 Z"/>',
  mao: '<path d="M30,90 L30,50 L24,38 L30,34 L36,44 L36,20 L42,18 L46,40 L46,14 L52,12 L54,40 L56,18 L62,18 L62,42 L66,30 L72,32 L70,60 L72,90 Z"/>',
  coracao: '<path d="M50,88 C10,60 6,36 22,22 C34,12 46,20 50,30 C54,20 66,12 78,22 C94,36 90,60 50,88 Z"/>',
  arvore: '<rect x="44" y="60" width="12" height="30"/><circle cx="50" cy="40" r="30"/>',
  onda: '<path d="M6,40 Q20,24 34,40 T62,40 T90,40 L90,60 Q76,44 62,60 T34,60 T6,60 Z"/>',
  roda: '<circle cx="50" cy="50" r="38"/><circle cx="50" cy="50" r="14" fill="#00000000"/>',
  livro: '<path d="M10,24 Q30,16 50,28 Q70,16 90,24 L90,80 Q70,72 50,84 Q30,72 10,80 Z"/>',
};

// Conteúdo interno do logotipo (fundo + símbolo), dentro de uma área 200x200.
function logoInner(party) {
  const primary = col(party.primary, '#1f4e79');
  const secondary = col(party.secondary, '#f4c542');
  const sym = party.symbol || { type: 'shape', shape: 'circulo' };
  let symbol = '';
  if (sym.type === 'upload' && typeof sym.dataUrl === 'string') {
    symbol = `<image href="${sym.dataUrl}" x="22" y="22" width="156" height="156" preserveAspectRatio="xMidYMid meet"/>`;
  } else if (sym.type === 'shape' || sym.type === 'combo') {
    symbol += `<g fill="${secondary}" transform="translate(30 30) scale(0.8)">${SHAPES[sym.shape] || SHAPES.circulo}</g>`;
    if (sym.type === 'combo') {
      symbol += `<g fill="${primary}" transform="translate(60 60) scale(0.4)">${ICONS[sym.icon] || ''}</g>`;
    }
  } else if (sym.type === 'icon') {
    symbol = `<g fill="${secondary}" transform="translate(40 40) scale(0.6)">${ICONS[sym.icon] || ICONS.sol}</g>`;
  }
  return `<circle cx="100" cy="100" r="94" fill="${primary}" stroke="${secondary}" stroke-width="8"/>${symbol}`;
}

export function logoSvg(party, { label = 'Logotipo do partido' } = {}) {
  return `<svg class="party-logo" viewBox="0 0 200 200" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg">${logoInner(party)}</svg>`;
}

export function flagSvg(party, { label = 'Bandeira do partido' } = {}) {
  const p = col(party.primary, '#1f4e79');
  const s = col(party.secondary, '#f4c542');
  let bg;
  switch (party.flagPattern) {
    case 'horizontal': bg = `<rect width="300" height="100" fill="${p}"/><rect y="100" width="300" height="100" fill="${s}"/>`; break;
    case 'vertical': bg = `<rect width="150" height="200" fill="${p}"/><rect x="150" width="150" height="200" fill="${s}"/>`; break;
    case 'diagonal': bg = `<rect width="300" height="200" fill="${s}"/><polygon points="0,0 300,0 0,200" fill="${p}"/>`; break;
    case 'circulo': bg = `<rect width="300" height="200" fill="${p}"/><circle cx="150" cy="100" r="72" fill="${s}"/>`; break;
    default: bg = `<rect width="300" height="200" fill="${p}"/>`;
  }
  return `<svg class="party-flag" viewBox="0 0 300 200" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg">` +
    `${bg}<svg x="85" y="20" width="130" height="160" viewBox="0 0 200 200" overflow="hidden">${logoInner(party)}</svg></svg>`;
}
