// Regras de início de carreira. Toda a matemática fica no servidor (e a IA nunca altera números).
// Dinheiro pessoal, de campanha, do partido e orçamentos públicos são contas separadas.
import { INDICATOR_KEYS } from './offices.js';
import { newSeed, formatDay, createRng } from './calendar.js';
import { createCampaignState } from './campaign.js';

export const START_MONEY = 10000; // R$ — dinheiro pessoal inicial definido pelo sistema (fictício).
// Saldo inicial dos orçamentos públicos (fictício): a arrecadação mensal sustenta o resto.
export const START_PUBLIC_BUDGETS = { municipal: 3000000, estadual: 20000000, federal: 150000000 };

export const randInt = (min, max, rng = Math.random) => Math.floor(rng() * (max - min + 1)) + min;

// Estado inicial de uma partida. O dia 0 é 1º de janeiro de 2027 (ver calendar.js).
export function initialCareer({ character, partyId = null, party = null, location }, rng = Math.random) {
  return {
    status: 'ativa',
    character,
    partyId: party ? party.id : partyId,
    party: party ? { id: party.id, name: party.name, acronym: party.acronym, number: party.number } : null,
    location: { state: location.state, city: location.city },
    money: START_MONEY,
    campaignFund: 0,
    partyFund: 0,
    publicBudgets: { ...START_PUBLIC_BUDGETS },
    support: 0, // contagem absoluta de apoiadores
    fame: 0, // 0 a 100
    approval: 50, // 0 a 100
    indicators: Object.fromEntries(INDICATOR_KEYS.map((k) => [k, 50])),
    health: randInt(70, 100, rng),
    hunger: randInt(50, 100, rng),
    thirst: randInt(50, 100, rng),
    day: 0,
    position: 'Cidadão(ã)',
    office: null,
    lastOffice: null,
    pastOffices: [],
    election: null,
    electionHistory: [],
    lastElectionYear: 0,
    bills: [],
    events: [],
    projects: [],
    ledger: [],
    careerLog: [{ day: 0, date: formatDay(0), type: 'carreira', office: null, text: 'Sua carreira política começou.' }],
    approvalHistory: [{ day: 0, value: 50 }],
    history: [{ day: 0, text: 'Sua carreira política começou.' }],
    decisions: [],
    electoral: { stage: 'Fora de eleição' },
    // Parte 3: regiões, cidadãos, inventário, celulares, campanhas digitais e estatísticas.
    ...createCampaignState(createRng(newSeed(rng))),
    rng: newSeed(rng),
  };
}

// Texto de contingência usado quando a IA não está configurada ou está indisponível.
export function localIntro(character, party, location) {
  const origem = `${location.city}, ${location.state}`;
  const partido = party ? `pelo ${party.name}` : 'como independente';
  return `${character.firstName} ${character.lastName} nasceu em ${origem} e decide entrar na vida pública ${partido}. Sua trajetória começa agora.`;
}
