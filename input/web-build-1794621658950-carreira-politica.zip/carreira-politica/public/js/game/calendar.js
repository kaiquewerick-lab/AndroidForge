// Calendário do jogo e gerador de números pseudoaleatórios com semente (determinístico).
// O dia 0 é 1º de janeiro de START_YEAR. Eleições acontecem em 4 de outubro dos anos
// de eleição; a posse ocorre em 1º de janeiro do ano seguinte.
export const START_YEAR = 2027;
export const FIRST_ELECTION_YEAR = 2028;
export const ELECTION_MONTH = 9; // outubro (0 = janeiro)
export const ELECTION_DAY_OF_MONTH = 4;
export const PRE_CAMPAIGN_DAYS = 180;
export const CAMPAIGN_DAYS = 45;

const MS_DAY = 864e5;
const base = Date.UTC(START_YEAR, 0, 1);

export const dayOf = (year, month, day) => Math.round((Date.UTC(year, month, day) - base) / MS_DAY);
export const dateOf = (day) => new Date(base + day * MS_DAY);
export const yearOf = (day) => dateOf(day).getUTCFullYear();

export function formatDay(day) {
  const d = dateOf(day);
  return d.toLocaleDateString('pt-BR', { timeZone: 'UTC' });
}

export const electionDay = (year) => dayOf(year, ELECTION_MONTH, ELECTION_DAY_OF_MONTH);
export const posseDay = (year) => dayOf(year + 1, 0, 1);
export const preCampaignStart = (year) => electionDay(year) - PRE_CAMPAIGN_DAYS;
export const campaignStart = (year) => electionDay(year) - CAMPAIGN_DAYS;

// Ano de eleição em que um cargo é renovado (cargos de 8 anos só entram em 2028, 2036...).
export function officeIsElectedIn(office, year) {
  if (year < FIRST_ELECTION_YEAR) return false;
  return (year - FIRST_ELECTION_YEAR) % office.cycle === 0;
}

// Mulberry32 com estado salvável: a partida guarda o inteiro "rng" e continua do mesmo ponto.
export function createRng(seed) {
  let s = seed >>> 0;
  const next = () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return { next, get state() { return s; } };
}

// Cria uma semente a partir de um número aleatório (usado apenas na criação da partida).
export const newSeed = (rand = Math.random) => Math.floor(rand() * 2 ** 32) >>> 0;
