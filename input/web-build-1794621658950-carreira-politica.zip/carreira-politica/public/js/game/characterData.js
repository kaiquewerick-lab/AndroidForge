// Opções do criador de personagem. Cada chave aqui é um valor válido salvo na partida.
export const OPTIONS = {
  hair: { curto: 'Curto', medio: 'Médio', longo: 'Longo', cacheado: 'Cacheado', raspado: 'Raspado', careca: 'Careca' },
  face: { oval: 'Oval', quadrado: 'Quadrado', redondo: 'Redondo', fino: 'Fino' },
  eyes: { normais: 'Normais', amendoados: 'Amendoados', grandes: 'Grandes' },
  beard: { nenhuma: 'Sem barba', curta: 'Curta', cheia: 'Cheia', cavanhaque: 'Cavanhaque' },
  mustache: { nenhum: 'Sem bigode', fino: 'Fino', cheio: 'Cheio' },
  shirt: { nenhuma: 'Sem camisa', social: 'Social', polo: 'Polo' },
  tshirt: { nenhuma: 'Sem camiseta', basica: 'Básica', estampada: 'Estampada' },
  suit: { nenhum: 'Sem terno', classico: 'Clássico', slim: 'Slim' },
  jacket: { nenhuma: 'Sem jaqueta', couro: 'Couro', bomber: 'Bomber' },
  pants: { jeans: 'Jeans', social: 'Social', shorts: 'Shorts' },
  shoes: { social: 'Social', tenis: 'Tênis', botas: 'Botas' },
  tie: { nenhuma: 'Sem gravata', larga: 'Larga', fina: 'Fina' },
  glasses: { nenhum: 'Sem óculos', redondo: 'Redondos', quadrado: 'Quadrados' },
  watch: { nenhum: 'Sem relógio', prata: 'Prata', dourado: 'Dourado' },
  cap: { nenhum: 'Sem boné', bone: 'Boné' },
  hat: { nenhum: 'Sem chapéu', fedora: 'Fedora' },
  pin: { nenhum: 'Sem broche', broche: 'Broche', bandeira: 'Mini bandeira' },
  pose: { parado: 'Parado', acenando: 'Acenando', discursando: 'Discursando', apontando: 'Apontando' },
};

export const SKIN_TONES = ['#f5d0b0', '#e8b48a', '#d19a6b', '#a86f47', '#7a4a2c', '#4d2e1b'];
export const HAIR_COLORS = ['#1b1b1b', '#4a2c17', '#8b5a2b', '#d9b26f', '#b5b5b5', '#c0392b'];
export const EYE_COLORS = ['#3b2a1a', '#5b3c1e', '#2f6f8f', '#3c7a4a', '#6b6b6b'];
export const CLOTHING_COLORS = [
  '#ffffff', '#1b1b1b', '#2d6cdf', '#c0392b', '#1e8449', '#f1c40f',
  '#8e44ad', '#7f8c8d', '#1f2a44', '#8b5a2b', '#e67e22', '#ecf0f1',
];

export const CLOTHING_KEYS = ['shirt', 'tshirt', 'suit', 'jacket', 'pants', 'shoes', 'tie'];
export const ACCESSORY_KEYS = ['glasses', 'watch', 'cap', 'hat', 'pin'];
export const APPEARANCE_KEYS = ['hair', 'hairColor', 'face', 'skinTone', 'eyes', 'eyeColor', 'beard', 'mustache'];

export const CLOTHING_LABELS = {
  shirt: 'Camisa', tshirt: 'Camiseta', suit: 'Terno', jacket: 'Jaqueta',
  pants: 'Calça', shoes: 'Sapato', tie: 'Gravata',
};
export const ACCESSORY_LABELS = { glasses: 'Óculos', watch: 'Relógio', cap: 'Boné', hat: 'Chapéu', pin: 'Outros acessórios' };

export const POSES = Object.keys(OPTIONS.pose);

export const DEFAULT_CHARACTER = {
  firstName: '',
  lastName: '',
  age: 35,
  birthState: 'DF',
  birthCity: 'Brasília',
  appearance: {
    hair: 'curto', hairColor: '#1b1b1b', face: 'oval', skinTone: '#e8b48a',
    eyes: 'normais', eyeColor: '#3b2a1a', beard: 'nenhuma', mustache: 'nenhum',
  },
  clothing: {
    shirt: { style: 'social', color: '#ffffff' },
    tshirt: { style: 'nenhuma', color: '#2d6cdf' },
    suit: { style: 'classico', color: '#1f2a44' },
    jacket: { style: 'nenhuma', color: '#333333' },
    pants: { style: 'social', color: '#2b2b2b' },
    shoes: { style: 'social', color: '#1a1a1a' },
    tie: { style: 'larga', color: '#c0392b' },
  },
  accessories: {
    glasses: { style: 'nenhum', color: '#222222' },
    watch: { style: 'prata', color: '#c0c0c0' },
    cap: { style: 'nenhum', color: '#222222' },
    hat: { style: 'nenhum', color: '#222222' },
    pin: { style: 'nenhum', color: '#f1c40f' },
  },
  pose: 'parado',
};
