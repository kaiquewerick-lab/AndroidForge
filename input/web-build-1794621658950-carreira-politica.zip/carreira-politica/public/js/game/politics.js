// Motor político: cargos, requisitos, eleições, mandatos, salários, votações, administração,
// eventos e passagem de tempo. Função pura sobre uma cópia do estado. Roda SOMENTE no servidor
// (que é a autoridade do jogo). A IA não passa por aqui: não altera valores econômicos.
import {
  OFFICES, OFFICE_ORDER, MONTHLY_REVENUE, SESSION_EVERY_DAYS, VOTE_WINDOW_DAYS,
  EXISTING_PARTIES, BILL_TEMPLATES, PROJECTS, INDICATOR_KEYS, INDICATOR_LABELS,
  EVENTS, GENERAL_EVENTS, CAMPAIGN_ACTIONS, CANDIDATE_FIRST, CANDIDATE_LAST,
} from './offices.js';
import {
  FIRST_ELECTION_YEAR, electionDay, posseDay, preCampaignStart, campaignStart,
  officeIsElectedIn, yearOf, dayOf, formatDay, createRng,
} from './calendar.js';
import {
  GameError, logEvent, credit, debit, canAfford, balanceOf, round2, accountLabel,
} from './ledger.js';
import {
  handleCampaignAction, campaignDaily, campaignReport, consumeReach, activeArea,
} from './campaign.js';
import {
  openPresidentialElection, runPresidentialVote, startPresidency, endPresidency, presidentialElectionDaily,
  presidencyDaily, handlePresidentialAction, pendingPlayerDebate, presidencySummary,
} from './presidency.js';
import { PRESIDENCY } from './presidencyData.js';

export { GameError, logEvent, accountLabel };

const APPROVAL_HISTORY_LIMIT = 400;
const PROMISE_TARGET = 60;
const EVENT_CHANCE = 1 / 40;
const EVENT_DEADLINE_DAYS = 7;
const OPERATING_COST_RATE = 0.85; // fração da receita mensal consumida pelo funcionamento do Estado
export const SCOPES = ['municipal', 'estadual', 'federal'];

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const round1 = (v) => Math.round(v * 10) / 10;
const fmtMoney = (v) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v);
const fmtNum = (v) => new Intl.NumberFormat('pt-BR').format(v);
const pick = (arr, rng) => arr[Math.floor(rng.next() * arr.length)];
const scopeOfOffice = (id) => OFFICES[id].scope;
const isExecutive = (id) => Boolean(OFFICES[id].executive);
const isLegislative = (id) => Boolean(OFFICES[id].legislative);
const WINDOW_PHASES = ['pre-campanha', 'campanha'];

// ---------------- Contas separadas ----------------
// Dinheiro pessoal, de campanha, do partido e orçamentos públicos nunca se misturam (ver ledger.js).
// Não existe transferência entre pessoal e público. A única saída pública para o personagem é o
// salário do cargo (paySalary), registrado nos dois lados.

// Salário público: a única ligação entre orçamento público e dinheiro pessoal.
// Se o orçamento do escopo não cobrir a folha, o salário não é pago (sem saldo negativo).
function paySalary(s, officeId) {
  const salary = OFFICES[officeId].salary;
  const scope = scopeOfOffice(officeId);
  const name = OFFICES[officeId].name;
  if (s.publicBudgets[scope] < salary) {
    logEvent(s, 'salario', `Salário de ${name} não pago: orçamento ${scope} insuficiente.`, officeId);
    return;
  }
  debit(s, `publico:${scope}`, salary, `Folha: salário de ${name}`);
  credit(s, 'pessoal', salary, `Salário público (${name})`);
}

// ---------------- Requisitos ----------------
// A janela eleitoral (pré-campanha ou campanha aberta) é exigida para registrar candidatura.
// Depende do calendário, não de já ser candidato, então não é circular.
export function electionWindowOpen(s) {
  return Boolean(s.election && WINDOW_PHASES.includes(electionPhase(s.election, s.day)));
}

export function officeStatus(s, officeId) {
  const o = OFFICES[officeId];
  if (!o) throw new GameError('Cargo desconhecido.');
  const r = o.requirements;
  const items = [
    { key: 'personagem', label: 'Possuir personagem', met: true },
    { key: 'apoio', label: `Apoio popular mínimo: ${fmtNum(r.support)} apoiadores`, current: s.support, target: r.support, met: s.support >= r.support },
    { key: 'dinheiro', label: `Dinheiro mínimo: ${fmtMoney(r.money)}`, current: s.money, target: r.money, met: s.money >= r.money },
  ];
  if (r.party) items.push({ key: 'partido', label: 'Possuir ou participar de um partido político', met: Boolean(s.partyId) });
  if (r.campaign) {
    items.push({
      key: 'campanha', label: 'Janela eleitoral aberta (pré-campanha ou campanha)',
      met: electionWindowOpen(s) && s.election.offices.includes(officeId),
    });
  }
  if (officeId === 'presidente') {
    const reserve = PRESIDENCY.requirements.campaignReserve;
    items.push({ key: 'reserva', label: `Reserva para campanha: ${fmtMoney(reserve)}`, current: s.campaignFund, target: reserve, met: s.campaignFund >= reserve });
  }
  const held = s.office?.id === officeId;
  const used = held ? s.office.reelections : (s.lastOffice?.id === officeId ? s.lastOffice.reelections : 0);
  if (held) items.push({ key: 'reeleicao', label: `Reeleições: ${used} de ${o.reelection.max}`, met: used < o.reelection.max });
  return {
    officeId, name: o.name, scope: o.scope, mandateYears: o.mandateYears, salary: o.salary,
    eligible: items.every((i) => i.met), items,
    held, registered: s.election?.registered === officeId,
    offered: Boolean(s.election && s.election.offices.includes(officeId)),
  };
}

// ---------------- Eleições ----------------
export function electionPhase(e, day) {
  if (!e) return null;
  if (day >= posseDay(e.year)) return 'posse';
  if (day > e.electionDay) return 'resultado';
  if (day === e.electionDay) return 'votacao';
  if (day >= campaignStart(e.year)) return 'campanha';
  return 'pre-campanha';
}

const PHASE_LABEL = {
  'pre-campanha': 'Pré-campanha', campanha: 'Campanha oficial', votacao: 'Dia da votação',
  resultado: 'Apuração e resultado', posse: 'Posse',
};
export const phaseLabel = (p) => PHASE_LABEL[p] || '—';

const HISTORY_PHRASES = [
  'Ex-secretário(a) municipal', 'Empresário(a) do comércio local', 'Professor(a) da rede pública',
  'Ex-deputado(a) estadual', 'Advogado(a) sindical', 'Líder comunitário(a)', 'Médico(a) de posto de saúde',
];

function genOpponent(s, officeId, idx, rng) {
  const req = OFFICES[officeId].requirements;
  const pool = EXISTING_PARTIES.filter((p) => p.id !== s.partyId);
  const p = pick(pool, rng);
  return {
    id: `op-${officeId}-${s.lastElectionYear}-${idx}`,
    name: `${pick(CANDIDATE_FIRST, rng)} ${pick(CANDIDATE_LAST, rng)}`,
    age: 30 + Math.floor(rng.next() * 40),
    partyId: p.id, party: p.name, acronym: p.acronym, number: p.number,
    fame: Math.floor(rng.next() * 70),
    support: Math.floor(req.support * (0.4 + rng.next() * 1.2)),
    money: Math.floor(req.money * (0.5 + rng.next())),
    ideas: { economic: Math.floor(rng.next() * 100), social: Math.floor(rng.next() * 100) },
    history: pick(HISTORY_PHRASES, rng),
  };
}

function openElection(s, year, rng) {
  const offices = OFFICE_ORDER.filter((id) => officeIsElectedIn(OFFICES[id], year));
  const opponents = {};
  for (const id of offices) {
    if (id === 'presidente') {
      opponents[id] = openPresidentialElection(s, year, rng);
      continue;
    }
    // Disputas de um lugar: 3 adversários. Disputas de várias vagas: o dobro das vagas (máx. 30).
    const seats = OFFICES[id].seats;
    const count = seats === 1 ? 3 : Math.min(seats * 2, 30);
    opponents[id] = Array.from({ length: count }, (_, i) => genOpponent(s, id, i, rng));
  }
  s.election = {
    year, electionDay: electionDay(year), posse: posseDay(year), offices, opponents,
    registered: null, polls: [], results: null,
  };
  s.lastElectionYear = year;
  const names = offices.map((id) => OFFICES[id].name).join(', ');
  logEvent(s, 'eleicao', `Pré-campanha de ${year} aberta. Cargos em disputa: ${names}.`);
}

function candidatesFor(s, officeId) {
  const e = s.election;
  const list = e.opponents[officeId].map((o) => ({ ...o, player: false, incumbent: false }));
  if (e.registered === officeId) {
    list.push({
      id: 'player',
      name: `${s.character.firstName} ${s.character.lastName}`,
      partyId: s.partyId,
      party: s.party ? s.party.name : 'Independente',
      acronym: s.party ? s.party.acronym : '—',
      number: s.party ? s.party.number : '—',
      fame: s.fame, support: s.support, money: s.campaignFund,
      player: true, incumbent: s.office?.id === officeId, approval: s.approval,
    });
  }
  return list;
}

// Pontuação: apoio (peso maior), fama, dinheiro de campanha, incumbência e (com rng) sorte.
function scoreCandidates(s, officeId, rng) {
  const list = candidatesFor(s, officeId);
  const maxS = Math.max(1, ...list.map((c) => c.support));
  const maxM = Math.max(1, ...list.map((c) => c.money));
  for (const c of list) {
    const raw = 0.55 * (c.support / maxS) + 0.2 * (c.fame / 100) + 0.15 * (c.money / maxM)
      + (c.incumbent ? 0.05 : 0) + (c.player && c.incumbent ? (c.approval - 50) / 500 : 0);
    c.score = Math.max(0.01, raw + (rng ? (rng.next() - 0.5) * 0.12 : 0));
  }
  const total = list.reduce((a, c) => a + c.score, 0);
  for (const c of list) c.share = round1((c.score / total) * 100);
  return list.sort((a, b) => b.score - a.score);
}

function pollRecord(s, e) {
  if (!e.registered) return;
  const ranking = scoreCandidates(s, e.registered, null);
  e.polls.push({ day: s.day, office: e.registered, shares: ranking.map((c) => ({ name: c.name, share: c.share })) });
  if (e.polls.length > 12) e.polls.splice(0, e.polls.length - 12);
}

function runElection(s, rng) {
  const e = s.election;
  const results = {};
  for (const id of e.offices) {
    if (id === 'presidente') {
      results[id] = runPresidentialVote(s, rng);
      continue;
    }
    const ranking = scoreCandidates(s, id, rng);
    const seats = OFFICES[id].seats;
    ranking.forEach((c, i) => { c.won = i < seats; });
    results[id] = {
      ranking: ranking.map((c) => ({
        name: c.name, party: c.party, acronym: c.acronym, number: c.number,
        share: c.share, player: Boolean(c.player), won: Boolean(c.won),
      })),
      winners: ranking.filter((c) => c.won).map((c) => c.name),
      playerRegistered: e.registered === id,
      playerWon: ranking.some((c) => c.player && c.won),
    };
  }
  e.results = results;
  if (e.registered) {
    const r = results[e.registered];
    const name = OFFICES[e.registered].name;
    if (r.playerWon) logEvent(s, 'eleicao', `Você foi eleito(a) para ${name} (${e.year}).`, e.registered);
    else logEvent(s, 'derrota', `Você não foi eleito(a) para ${name} em ${e.year}.`, e.registered);
  }
  logEvent(s, 'eleicao', `Apuração de ${e.year} concluída.`);
}

// Posse: começa o mandato. Promessas de campanha: três indicadores diferentes, meta fixa,
// avaliadas quando o mandato termina.
function takeOffice(s, officeId, year, rng) {
  const o = OFFICES[officeId];
  const start = posseDay(year);
  const reelections = s.lastOffice && s.lastOffice.id === officeId && s.lastOffice.endDay === start
    ? s.lastOffice.reelections + 1 : 0;
  const offset = year % INDICATOR_KEYS.length;
  const keys = [...INDICATOR_KEYS.slice(offset), ...INDICATOR_KEYS.slice(0, offset)];
  s.office = {
    id: officeId,
    startDay: start,
    endDay: dayOf(year + 1 + o.mandateYears, 0, 1),
    reelections,
    promises: keys.slice(0, 3).map((indicator) => ({ indicator, target: PROMISE_TARGET })),
  };
  s.approval = Math.max(s.approval, 55);
  s.position = o.name;
  logEvent(s, 'posse', `Posse como ${o.name}. Mandato até ${formatDay(s.office.endDay)}.`, officeId);
  if (officeId === 'presidente') startPresidency(s, rng);
}

function endOffice(s, reason) {
  const o = s.office;
  if (!o) return;
  const name = OFFICES[o.id].name;
  const promises = o.promises.map((p) => ({ ...p, fulfilled: s.indicators[p.indicator] >= p.target }));
  const fulfilled = promises.filter((p) => p.fulfilled).length;
  s.approval = clamp(round1(s.approval + promises.reduce((a, p) => a + (p.fulfilled ? 3 : -2), 0)), 0, 100);
  s.pastOffices.push({
    id: o.id, name, startDay: o.startDay, endDay: s.day, reason, reelections: o.reelections, promises,
    startDate: formatDay(o.startDay), endDate: formatDay(s.day),
  });
  if (o.id === 'presidente') endPresidency(s, reason);
  s.lastOffice = { id: o.id, reelections: o.reelections, endDay: s.day };
  s.office = null;
  s.position = 'Cidadão(ã)';
  for (const p of s.projects) if (p.status === 'ativo' || p.status === 'suspenso') p.status = 'cancelado';
  logEvent(s, 'cargo_fim', `Fim do cargo de ${name}: ${reason}. Promessas cumpridas: ${fulfilled} de ${promises.length}.`, o.id);
}

function closeElection(s, rng) {
  const e = s.election;
  if (e.registered && e.results?.[e.registered]?.playerWon) takeOffice(s, e.registered, e.year, rng);
  s.electionHistory.push({
    year: e.year, offices: e.offices, registered: e.registered,
    playerWon: Boolean(e.registered && e.results?.[e.registered]?.playerWon),
    winners: e.results ? Object.fromEntries(Object.entries(e.results).map(([k, v]) => [k, v.winners])) : {},
  });
  if (s.electionHistory.length > 50) s.electionHistory.splice(0, s.electionHistory.length - 50);
  s.election = null;
}

function opponentsMove(s, e, rng) {
  for (const id of e.offices) {
    for (const op of e.opponents[id]) {
      op.support = Math.max(0, Math.round(op.support + (rng.next() * 2 - 1) * op.support * 0.01));
      op.money = Math.max(0, Math.round(op.money - rng.next() * 400));
    }
  }
}

function electionDaily(s, rng) {
  const e = s.election;
  const day = s.day;
  const phase = electionPhase(e, day);
  if (phase === 'pre-campanha' || phase === 'campanha') opponentsMove(s, e, rng);
  presidentialElectionDaily(s, rng, phase);
  if (phase === 'campanha' && day === campaignStart(e.year)) logEvent(s, 'eleicao', 'Campanha oficial aberta.');
  if (phase === 'campanha' && (day - campaignStart(e.year)) % 10 === 0) pollRecord(s, e);
  if (day === e.electionDay - 20) logEvent(s, 'eleicao', 'Primeiro debate entre candidatos.');
  if (day === e.electionDay - 7) logEvent(s, 'eleicao', 'Segundo debate entre candidatos.');
  if (day === e.electionDay) runElection(s, rng);
}

function maybeOpenElection(s, rng) {
  const day = s.day;
  for (let y = FIRST_ELECTION_YEAR; y <= yearOf(day) + 5; y += 4) {
    if (y > s.lastElectionYear && electionDay(y) > day && day >= preCampaignStart(y)) {
      openElection(s, y, rng);
      return;
    }
  }
}

// ---------------- Mensal: repasses, salário, partido, projetos ----------------
function monthly(s) {
  for (const scope of SCOPES) {
    credit(s, `publico:${scope}`, MONTHLY_REVENUE[scope], 'Repasse mensal');
    // Custo de funcionamento da máquina pública (folha administrativa, serviços). Se não couber, é registrado.
    const operating = Math.round(MONTHLY_REVENUE[scope] * OPERATING_COST_RATE);
    if (s.publicBudgets[scope] >= operating) debit(s, `publico:${scope}`, operating, 'Custo de funcionamento');
    else logEvent(s, 'orcamento', `Custo de funcionamento de ${scope} não coberto neste mês.`);
  }
  if (s.office) paySalary(s, s.office.id);
  if (s.partyId) credit(s, 'partido', 1000, 'Contribuição mensal de filiados');
  for (const p of s.projects) {
    if (p.kind !== 'monthly' || (p.status !== 'ativo' && p.status !== 'suspenso')) continue;
    if (s.publicBudgets[p.scope] >= p.monthly) {
      debit(s, `publico:${p.scope}`, p.monthly, `Projeto mensal: ${p.name}`);
      p.status = 'ativo';
      applyEffects(s, p.effects);
    } else {
      p.status = 'suspenso';
      logEvent(s, 'projeto', `Projeto suspenso por falta de orçamento: ${p.name}.`);
    }
  }
}

function applyEffects(s, effects) {
  for (const [k, v] of Object.entries(effects || {})) {
    if (k in s.indicators) s.indicators[k] = round1(clamp(s.indicators[k] + v, 0, 100));
  }
}

function projectsDaily(s) {
  for (const p of s.projects) {
    if (p.kind !== 'capital' || p.status !== 'andamento') continue;
    p.daysLeft -= 1;
    if (p.daysLeft <= 0) {
      p.status = 'concluido';
      applyEffects(s, p.effects);
      logEvent(s, 'projeto', `Obra concluída: ${p.name}.`);
    }
  }
}

// ---------------- Indicadores, aprovação e apoio ----------------
function indicatorsDaily(s) {
  for (const k of INDICATOR_KEYS) s.indicators[k] = round1(s.indicators[k] + (50 - s.indicators[k]) * 0.0015);
}

// Aprovação tende ao equilíbrio entre indicadores e ao fato de ocupar cargo.
function approvalDaily(s) {
  const avg = INDICATOR_KEYS.reduce((a, k) => a + s.indicators[k], 0) / INDICATOR_KEYS.length;
  const target = s.office ? 25 + avg * 0.7 : 40 + (avg - 50) * 0.2;
  s.approval = round1(clamp(s.approval + (target - s.approval) * 0.01, 0, 100));
}

// Apoio cresce devagar com fama e aprovação (mais com cargo ocupado); cai se a aprovação for baixa.
function supportDaily(s) {
  s.support += Math.floor(s.fame * 0.2 + Math.max(0, s.approval - 50) * 0.1 + (s.office ? 150 : 0));
  if (s.approval < 30 && s.office) s.support = Math.max(0, s.support - Math.floor((30 - s.approval) * 2));
  s.fame = round1(clamp(s.fame + (s.office ? 0.02 : -0.01), 0, 100));
}

// ---------------- Sessões legislativas ----------------
function localDebate(bill, rng) {
  const names = [0, 1, 2].map(() => `${pick(CANDIDATE_FIRST, rng)} ${pick(CANDIDATE_LAST, rng)}`);
  const stance = (b) => (b.popularity >= 55 ? 'Apoio, a população pede isso.'
    : b.popularity <= 45 ? 'Não podemos aprovar sem estudo de impacto.' : 'Precisamos de ajustes no texto.');
  return names.map((n, i) => ({
    speaker: n,
    text: i === 0 ? stance(bill) : (bill.econ > 60 ? 'Isso pesa no orçamento e precisa de fonte de recurso.' : 'Essa pauta toca diretamente no dia a dia dos moradores.'),
  }));
}

function createBills(s, rng) {
  const scope = scopeOfOffice(s.office.id);
  const pool = BILL_TEMPLATES[scope] || [];
  const n = rng.next() < 0.5 ? 1 : 2;
  for (let i = 0; i < n && pool.length; i += 1) {
    const t = pick(pool, rng);
    s.bills.push({
      id: `bill-${s.day}-${i}`, title: t.title, sector: t.sector, econ: t.econ, social: t.social,
      kind: 'lei', scope,
      popularity: 35 + Math.floor(rng.next() * 40),
      deadline: s.day + VOTE_WINDOW_DAYS, status: 'aberto', playerVote: null, tally: null,
      debate: localDebate(t, rng),
    });
  }
  if (s.bills.length > 60) s.bills.splice(0, s.bills.length - 60);
}

function resolveBills(s, rng) {
  for (const bill of s.bills) {
    if (bill.status !== 'aberto' || s.day < bill.deadline) continue;
    const council = s.office && isLegislative(s.office.id) ? OFFICES[s.office.id].council : 21;
    const tally = { favor: 0, contra: 0, abstencao: 0 };
    for (let i = 0; i < council - 1; i += 1) {
      const econ = rng.next() * 100;
      const social = rng.next() * 100;
      const affinity = 1 - (Math.abs(econ - bill.econ) + Math.abs(social - bill.social)) / 200;
      const p = clamp(0.25 + affinity * 0.5 + (bill.popularity - 50) / 200, 0.05, 0.95);
      const r = rng.next();
      if (r < p) tally.favor += 1;
      else if (r < p + 0.1) tally.abstencao += 1;
      else tally.contra += 1;
    }
    if (bill.playerVote === 'favor' || bill.playerVote === 'contra' || bill.playerVote === 'abstencao') {
      tally[bill.playerVote] += 1;
    } else {
      bill.playerVote = 'sem voto';
      tally.abstencao += 1;
    }
    bill.tally = tally;
    const approved = tally.favor > tally.contra;
    bill.status = approved ? 'aprovado' : 'rejeitado';
    if (approved) {
      applyEffects(s, { [bill.sector]: bill.kind === 'emenda' ? 6 : 4 });
    }
    logEvent(s, 'votacao', `${approved ? 'Aprovado' : 'Rejeitado'}: ${bill.title} (${tally.favor} a favor, ${tally.contra} contra, ${tally.abstencao} abstenções).`, s.office?.id || null);
    if ((bill.playerVote === 'favor' || bill.playerVote === 'contra') && s.office && isLegislative(s.office.id)) {
      const aligned = (bill.playerVote === 'favor') === (bill.popularity >= 50);
      s.approval = round1(clamp(s.approval + (aligned ? 0.8 : -0.8), 0, 100));
    }
  }
}

// ---------------- Eventos ----------------
function spawnEvent(s, rng) {
  const exclusive = s.office ? OFFICES[s.office.id].exclusiveEvents : [];
  const pool = [...GENERAL_EVENTS, ...exclusive];
  const key = pick(pool, rng);
  s.events.push({
    id: `ev-${s.day}-${key}`, key, title: EVENTS[key].title, text: EVENTS[key].text,
    options: EVENTS[key].options.map((o) => o.label),
    createdDay: s.day, deadline: s.day + EVENT_DEADLINE_DAYS, status: 'pendente', chosen: null, auto: false,
  });
  if (s.events.length > 80) s.events.splice(0, s.events.length - 80);
}

function applyEventOption(s, ev, index, auto) {
  const opt = EVENTS[ev.key].options[index];
  const effects = opt.effects;
  const cost = effects.cost || 0;
  if (cost > 0) {
    if (!s.office) {
      if (!auto) throw new GameError('Esta opção exige um cargo público.');
    } else {
      const scope = scopeOfOffice(s.office.id);
      if (s.publicBudgets[scope] < cost) {
        if (!auto) throw new GameError(`Orçamento ${scope} insuficiente para esta opção.`);
        logEvent(s, 'evento', `Orçamento insuficiente: ${ev.title} seguiu sem custo.`);
      } else {
        debit(s, `publico:${scope}`, cost, `Evento: ${ev.title}`);
      }
    }
  }
  s.approval = round1(clamp(s.approval + (effects.approval || 0), 0, 100));
  applyEffects(s, effects.indicators);
  ev.status = 'resolvido';
  ev.chosen = index;
  ev.auto = auto;
  logEvent(s, 'evento', `${ev.title}: ${auto ? 'decisão automática' : 'decisão'} — ${opt.label}.`, s.office?.id || null);
}

function eventsDaily(s, rng) {
  for (const ev of s.events) {
    if (ev.status === 'pendente' && s.day >= ev.deadline) {
      try { applyEventOption(s, ev, 0, true); } catch { ev.status = 'resolvido'; ev.chosen = 0; ev.auto = true; }
    }
  }
  if (!s.events.some((e) => e.status === 'pendente') && rng.next() < EVENT_CHANCE) spawnEvent(s, rng);
}

// ---------------- Dia a dia ----------------
function tickDay(s, rng) {
  s.day += 1;
  const day = s.day;
  if (s.office && day >= s.office.endDay) endOffice(s, 'fim do mandato');
  if (!s.election) maybeOpenElection(s, rng);
  if (s.election) {
    electionDaily(s, rng);
    if (day >= s.election.posse) closeElection(s, rng);
  }
  if (day % 30 === 0) monthly(s);
  projectsDaily(s);
  indicatorsDaily(s);
  approvalDaily(s);
  supportDaily(s);
  campaignDaily(s, rng);
  presidencyDaily(s, rng);
  if (s.office && isLegislative(s.office.id) && day % SESSION_EVERY_DAYS === 0) createBills(s, rng);
  resolveBills(s, rng);
  eventsDaily(s, rng);
  if (day % 7 === 0) {
    s.approvalHistory.push({ day, value: s.approval });
    if (s.approvalHistory.length > APPROVAL_HISTORY_LIMIT) s.approvalHistory.splice(0, s.approvalHistory.length - APPROVAL_HISTORY_LIMIT);
  }
  s.electoral.stage = stageText(s);
}

function stageText(s) {
  if (s.election) {
    const ph = electionPhase(s.election, s.day);
    return `${phaseLabel(ph)} · eleição de ${s.election.year}`;
  }
  return s.office ? `Exercendo: ${OFFICES[s.office.id].name}` : 'Fora de eleição';
}

// Avança N dias (limite de segurança por chamada). Retorna uma nova partida.
export function advance(career, days) {
  if (career.status === 'encerrada') throw new GameError('Sua carreira foi encerrada.');
  const n = Math.floor(days);
  if (!(n >= 1 && n <= 60)) throw new GameError('Avance entre 1 e 60 dias por vez.');
  const s = structuredClone(career);
  const rng = createRng(s.rng);
  for (let i = 0; i < n; i += 1) {
    // O tempo para no dia de um debate presidencial até o jogador responder.
    if (pendingPlayerDebate(s)) break;
    tickDay(s, rng);
  }
  s.rng = rng.state;
  return s;
}

// ---------------- Ações do jogador ----------------
function requireActive(s) {
  if (s.status === 'encerrada') throw new GameError('Sua carreira foi encerrada.');
}

function requireElectionWindow(s) {
  if (!s.election) throw new GameError('Não há eleição aberta no momento.');
}

export const PERSONAL_ACTIONS = {
  comer: { label: 'Comeu uma refeição', cost: 15, hunger: 35 },
  beber: { label: 'Bebeu água', cost: 3, thirst: 30 },
  descansar: { label: 'Descansou', cost: 0, health: 12, hunger: -4, thirst: -4 },
  trabalhar: { label: 'Trabalhou e recebeu o pagamento', cost: 0, income: 1200, hunger: -8, thirst: -6, health: -4 },
  militancia: { label: 'Fez militância no bairro', cost: 0, health: -3, support: 300, fame: 0.2 },
};

function applyPersonal(s, action) {
  const def = PERSONAL_ACTIONS[action];
  if (def.income) credit(s, 'pessoal', def.income, 'Renda do trabalho');
  if (def.cost) debit(s, 'pessoal', def.cost, def.label);
  if (def.health) s.health = clamp(s.health + def.health, 0, 100);
  if (def.hunger) s.hunger = clamp(s.hunger + def.hunger, 0, 100);
  if (def.thirst) s.thirst = clamp(s.thirst + def.thirst, 0, 100);
  if (def.support) consumeReach(s, s.currentRegion, def.support);
  if (def.fame) s.fame = round1(clamp(s.fame + def.fame, 0, 100));
  s.decisions.push({ day: s.day, action, at: new Date().toISOString() });
  s.history.push({ day: s.day, text: def.label });
}

export function performAction(career, action, payload = {}) {
  const s = structuredClone(career);
  requireActive(s);
  const rng = createRng(s.rng);
  if (PERSONAL_ACTIONS[action]) {
    if (s.health <= 5 && action === 'trabalhar') throw new GameError('Saúde muito baixa para trabalhar. Descanse primeiro.');
    applyPersonal(s, action);
    s.rng = rng.state;
    return s;
  }
  switch (action) {
    case 'registrarCandidatura': {
      const id = payload.officeId;
      if (!OFFICES[id]) throw new GameError('Cargo inválido.');
      if (!s.election || !s.election.offices.includes(id)) throw new GameError(`${OFFICES[id].name} não está em disputa nesta eleição.`);
      if (!electionWindowOpen(s)) throw new GameError('A janela de registro de candidaturas está fechada.');
      if (s.election.registered) throw new GameError(`Você já tem candidatura registrada para ${OFFICES[s.election.registered].name}. Retire-a antes.`);
      if (s.office && s.office.id !== id) {
        throw new GameError(`Você ocupa ${OFFICES[s.office.id].name}. Renuncie (quando permitido) ou aguarde o fim do mandato para concorrer a outro cargo.`);
      }
      const missing = officeStatus(s, id).items.filter((i) => !i.met);
      if (missing.length) throw new GameError(`Requisitos pendentes: ${missing.map((m) => m.label).join('; ')}.`);
      s.election.registered = id;
      logEvent(s, 'candidatura', `Candidatura registrada para ${OFFICES[id].name} (${s.election.year}).`, id);
      break;
    }
    case 'retirarCandidatura': {
      requireElectionWindow(s);
      if (!s.election.registered) throw new GameError('Você não tem candidatura registrada.');
      if (s.day >= s.election.electionDay - 45) throw new GameError('Não é possível retirar a candidatura durante a campanha oficial.');
      logEvent(s, 'candidatura', `Candidatura retirada: ${OFFICES[s.election.registered].name}.`);
      s.election.registered = null;
      break;
    }
    case 'contribuir': {
      const amount = Math.floor(Number(payload.amount));
      if (!(amount > 0)) throw new GameError('Informe um valor positivo.');
      if (payload.source === 'pessoal') {
        debit(s, 'pessoal', amount, 'Contribuição à própria campanha');
        credit(s, 'campanha', amount, 'Contribuição pessoal');
      } else if (payload.source === 'partido') {
        if (!s.partyId) throw new GameError('Você não tem partido.');
        debit(s, 'partido', amount, 'Repasse à campanha');
        credit(s, 'campanha', amount, 'Repasse do partido');
      } else {
        throw new GameError('Origem de recurso inválida.');
      }
      break;
    }
    case 'campanha': {
      const def = CAMPAIGN_ACTIONS[payload.type];
      if (!def) throw new GameError('Ação de campanha inválida.');
      if (!s.election?.registered) throw new GameError('Registre uma candidatura para fazer campanha.');
      if (electionPhase(s.election, s.day) !== 'campanha') throw new GameError('A campanha oficial ainda não começou.');
      debit(s, 'campanha', def.cost, `Campanha: ${def.label}`);
      consumeReach(s, activeArea(s), def.support);
      s.fame = round1(clamp(s.fame + def.fame, 0, 100));
      logEvent(s, 'campanha', `${def.label} concluído(a).`);
      break;
    }
    case 'trocarPartido': {
      // payload.party é validado pelo servidor (partido fictício existente).
      const target = payload.party;
      if (!target || !target.id) throw new GameError('Escolha um partido válido.');
      if (target.id === s.partyId) throw new GameError('Você já está neste partido.');
      if (s.election?.registered) throw new GameError('Retire a candidatura antes de trocar de partido.');
      if (s.office && isLegislative(s.office.id) && !payload.confirm) {
        throw new GameError('Trocar de partido durante um mandato legislativo faz você perder o cargo (fidelidade partidária). Confirme para continuar.');
      }
      const wasHolding = s.office && isLegislative(s.office.id) ? s.office.id : null;
      s.partyId = target.id;
      s.party = { id: target.id, name: target.name, acronym: target.acronym, number: target.number };
      logEvent(s, 'partido', `Filiação alterada para ${target.name} (${target.acronym}).`, wasHolding);
      if (wasHolding) {
        endOffice(s, 'perda de mandato por troca de partido (fidelidade partidária)');
      }
      break;
    }
    case 'renunciar': {
      if (!s.office) throw new GameError('Você não ocupa cargo.');
      if (!OFFICES[s.office.id].canResign) throw new GameError('Este cargo não permite renúncia.');
      endOffice(s, 'renúncia');
      break;
    }
    case 'encerrarCarreira': {
      if (!payload.confirm) throw new GameError('Confirme o encerramento da carreira.');
      endOffice(s, 'encerramento da carreira');
      s.status = 'encerrada';
      logEvent(s, 'carreira', 'Carreira política encerrada pelo jogador.');
      break;
    }
    case 'votar': {
      if (s.office?.id === 'presidente') throw new GameError('O presidente não vota nas sessões do Congresso: ele sanciona ou veta as leis.');
      const bill = s.bills.find((b) => b.id === payload.billId);
      if (!bill) throw new GameError('Pauta não encontrada.');
      if (!s.office || !isLegislative(s.office.id)) throw new GameError('Você precisa de um mandato legislativo para votar.');
      if (bill.status !== 'aberto') throw new GameError('Esta votação já foi encerrada.');
      if (!['favor', 'contra', 'abstencao'].includes(payload.vote)) throw new GameError('Voto inválido.');
      bill.playerVote = payload.vote;
      break;
    }
    case 'proporEmenda': {
      if (!s.office || !isLegislative(s.office.id) || !['deputado_federal', 'deputado_estadual'].includes(s.office.id)) {
        throw new GameError('Apenas deputados podem propor emendas.');
      }
      if (!Object.keys(INDICATOR_LABELS).includes(payload.sector)) throw new GameError('Setor inválido.');
      s.bills.push({
        id: `emenda-${s.day}-${s.bills.length}`, title: `Emenda: ${INDICATOR_LABELS[payload.sector]}`,
        sector: payload.sector, econ: 50, social: 50, kind: 'emenda', scope: scopeOfOffice(s.office.id),
        popularity: 60, deadline: s.day + VOTE_WINDOW_DAYS, status: 'aberto', playerVote: null, tally: null,
        debate: [],
      });
      logEvent(s, 'votacao', `Emenda proposta para ${INDICATOR_LABELS[payload.sector]}.`, s.office.id);
      break;
    }
    case 'iniciarProjeto': {
      if (!s.office || !isExecutive(s.office.id)) throw new GameError('Somente o Executivo administra projetos.');
      const scope = scopeOfOffice(s.office.id);
      const def = PROJECTS[scope].find((p) => p.key === payload.key);
      if (!def) throw new GameError('Projeto inexistente para este cargo.');
      const base = { id: `pj-${s.day}-${s.projects.length}`, key: def.key, name: def.name, scope, effects: def.effects, startDay: s.day };
      if (def.capital) {
        debit(s, `publico:${scope}`, def.capital, `Projeto: ${def.name}`);
        s.projects.push({ ...base, kind: 'capital', cost: def.capital, daysLeft: def.days, status: 'andamento' });
      } else {
        s.projects.push({ ...base, kind: 'monthly', monthly: def.monthly, status: 'ativo' });
        applyEffects(s, def.effects);
      }
      logEvent(s, 'projeto', `Projeto iniciado: ${def.name}.`, s.office.id);
      break;
    }
    case 'cancelarProjeto': {
      const p = s.projects.find((x) => x.id === payload.projectId);
      if (!p) throw new GameError('Projeto não encontrado.');
      if (p.kind !== 'monthly' || (p.status !== 'ativo' && p.status !== 'suspenso')) throw new GameError('Só programas mensais podem ser cancelados.');
      p.status = 'cancelado';
      logEvent(s, 'projeto', `Programa cancelado: ${p.name}.`);
      break;
    }
    case 'decidirEvento': {
      const ev = s.events.find((e) => e.id === payload.eventId);
      if (!ev || ev.status !== 'pendente') throw new GameError('Evento não está pendente.');
      const index = Number(payload.option);
      if (!Number.isInteger(index) || index < 0 || index >= EVENTS[ev.key].options.length) throw new GameError('Opção inválida.');
      applyEventOption(s, ev, index, false);
      break;
    }
    case 'avancarDia': {
      // Ação da Parte 1: passa um dia completo do mundo.
      s.rng = rng.state;
      return advance(s, 1);
    }
    default:
      // Ações da Parte 3 (celulares, santinhos, banners, placas, digital, conversas, regiões).
      if (!handleCampaignAction(s, rng, action, payload) && !handlePresidentialAction(s, rng, action, payload)) {
        throw new GameError('Ação desconhecida.');
      }
  }
  s.rng = rng.state;
  s.electoral.stage = stageText(s);
  return s;
}

// Resumo financeiro: saldos por conta e movimentos dos últimos N dias.
export function financialReport(s, days = 30) {
  const from = s.day - days;
  const recent = s.ledger.filter((l) => l.day > from);
  const sum = (filter, type) => round2(recent.filter((l) => filter(l) && l.type === type).reduce((a, l) => a + l.amount, 0));
  const accounts = ['pessoal', 'campanha', 'partido', ...SCOPES.map((x) => `publico:${x}`)];
  return {
    days,
    balances: Object.fromEntries(accounts.map((a) => [a, balanceOf(s, a)])),
    accounts: accounts.map((a) => ({
      account: a,
      label: a.startsWith('publico') ? `Orçamento ${a.split(':')[1]}` : { pessoal: 'Dinheiro pessoal', campanha: 'Dinheiro de campanha', partido: 'Dinheiro do partido' }[a],
      balance: balanceOf(s, a),
      receitas: sum((l) => l.account === a, 'receita'),
      despesas: sum((l) => l.account === a, 'despesa'),
    })),
    totals: {
      receitas: sum(() => true, 'receita'),
      despesas: sum(() => true, 'despesa'),
    },
    recent: recent.slice(-40).reverse(),
    categoriasCampanha: campaignReport(s).gastosPorCategoria,
  };
}

// Resumo de progressão para a tela MINHA CARREIRA.
export function careerSummary(s) {
  const office = s.office ? { ...s.office, name: OFFICES[s.office.id].name, mandateLeft: Math.max(0, s.office.endDay - s.day) } : null;
  return {
    office,
    phase: s.election ? electionPhase(s.election, s.day) : null,
    nextElection: s.election ? { year: s.election.year, day: s.election.electionDay, date: formatDay(s.election.electionDay) }
      : { year: nextElectionYear(s.day), date: formatDay(electionDay(nextElectionYear(s.day))) },
    offices: OFFICE_ORDER.map((id) => officeStatus(s, id)),
    campaign: campaignReport(s),
    presidency: presidencySummary(s),
    date: formatDay(s.day),
  };
}

export function nextElectionYear(day) {
  for (let y = FIRST_ELECTION_YEAR; ; y += 4) if (electionDay(y) > day) return y;
}

