// Ponto de entrada do cliente: registra as telas e inicia a apresentação.
import { defineScreen, go } from './ui/router.js';
import { audio } from './core/audio.js';
import { applySettings, loadLocalSettings } from './core/state.js';
import { toast } from './core/dom.js';
import { renderSplash } from './ui/screens/splash.js';
import { renderLoading } from './ui/screens/loading.js';
import { renderAuth } from './ui/screens/auth.js';
import { renderHome } from './ui/screens/home.js';
import { renderStart } from './ui/screens/start.js';
import { renderCareer } from './ui/screens/career.js';
import { renderStore } from './ui/screens/store.js';
import { renderSettings } from './ui/screens/settings.js';
import { renderParties, renderPartyEditor } from './ui/screens/parties.js';
import { renderCreator } from './ui/screens/characterCreator.js';
import { renderPreparing } from './ui/screens/preparing.js';
import { renderConcorrer } from './ui/screens/concorrer.js';
import { renderMandato } from './ui/screens/mandato.js';
import { renderCampanha } from './ui/screens/campanha.js';
import { renderMapa } from './ui/screens/mapa.js';
import { renderFabrica } from './ui/screens/fabrica.js';
import { renderInventario } from './ui/screens/inventario.js';
import { renderPresidencia } from './ui/screens/presidencia.js';

defineScreen('splash', renderSplash);
defineScreen('loading', renderLoading);
defineScreen('auth', (p) => renderAuth(p));
defineScreen('home', renderHome);
defineScreen('start', renderStart);
defineScreen('career', (p) => renderCareer(p));
defineScreen('concorrer', renderConcorrer);
defineScreen('mandato', renderMandato);
defineScreen('campanha', renderCampanha);
defineScreen('mapa', renderMapa);
defineScreen('fabrica', renderFabrica);
defineScreen('inventario', renderInventario);
defineScreen('presidencia', renderPresidencia);
defineScreen('store', renderStore);
defineScreen('loja', renderStore);
defineScreen('settings', renderSettings);
defineScreen('parties', renderParties);
defineScreen('party-editor', (p) => renderPartyEditor(p));
defineScreen('creator', renderCreator);
defineScreen('preparing', (p) => renderPreparing(p));

// Som de clique em botões (respeita a configuração de efeitos sonoros).
document.addEventListener('click', (e) => {
  if (e.target.closest('button, a[href], .swatch, .choice, .chip')) audio.click();
});

window.addEventListener('unhandledrejection', (e) => {
  console.error(e.reason);
  toast('Algo inesperado aconteceu. Tente novamente.', 'error');
});

// Aplica as preferências deste dispositivo antes de qualquer tela.
applySettings(loadLocalSettings());

go('splash').catch((err) => {
  console.error(err);
  document.body.insertAdjacentHTML('beforeend', `<p class="fatal">Erro ao iniciar o jogo: ${err.message}</p>`);
});
