// Testes da API: login via Firebase (tokens assinados de verdade, sem rede), perfis, configurações,
// partidos, partidas, ações, avanço de tempo, isolamento entre contas e salvamento.
// Rodar com: npm test
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// Banco de testes isolado (o db.js lê DATA_DIR ao ser carregado).
const DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'cp-test-'));
process.env.DATA_DIR = DATA_DIR;

const { createServer } = await import('../server/server.js');
const { setVerifier } = await import('../server/auth.js');
const { verifyIdTokenWith } = await import('../server/firebase.js');
const { DEFAULT_CHARACTER } = await import('../public/js/game/characterData.js');
const { SHAPE_KEYS, FLAG_KEYS } = await import('../public/js/game/partyData.js');

const PROJECT = 'politica-fb74a';
const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
const PEM = publicKey.export({ type: 'spki', format: 'pem' });
const b64url = (buf) => Buffer.from(buf).toString('base64url');

// Cria um ID token com a mesma estrutura do Firebase, assinado com a chave de teste.
function makeToken(uid, overrides = {}) {
  const nowS = Math.floor(Date.now() / 1000);
  const header = { alg: 'RS256', kid: 'test-key', typ: 'JWT' };
  const payload = {
    aud: PROJECT,
    iss: `https://securetoken.google.com/${PROJECT}`,
    sub: uid,
    iat: nowS,
    exp: nowS + 3600,
    email: `${uid}@teste.com`,
    email_verified: true,
    firebase: { sign_in_provider: 'password' },
    ...overrides,
  };
  const data = `${b64url(JSON.stringify(header))}.${b64url(JSON.stringify(payload))}`;
  const sig = crypto.sign('sha256', Buffer.from(data), privateKey);
  return `${data}.${b64url(sig)}`;
}

let server;
let base;
const uniq = () => crypto.randomUUID().slice(0, 8);

async function call(method, route, { token, body } = {}) {
  const headers = {};
  if (token) headers.authorization = `Bearer ${token}`;
  let payload;
  if (body !== undefined) {
    headers['content-type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  const res = await fetch(base + route, { method, headers, body: payload });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data, headers: res.headers };
}

// Cria um jogador com perfil pronto e devolve o token e o nome de usuário.
async function newPlayer(prefix = 'jogador') {
  const uid = `${prefix}-${uniq()}`;
  const token = makeToken(uid);
  const username = `${prefix.replace(/[^a-z]/gi, '').slice(0, 6)}${uniq().slice(0, 6)}`;
  const r = await call('POST', '/api/auth/profile', { token, body: { username } });
  assert.equal(r.status, 201, `perfil criado: ${JSON.stringify(r.data)}`);
  return { uid, token, username };
}

const characterBody = () => ({ character: { ...structuredClone(DEFAULT_CHARACTER), firstName: 'Ana', lastName: 'Souza' } });

function partyBody(name = 'Partido Teste') {
  return {
    party: {
      name, acronym: 'PTS', number: '4321', motto: 'Teste',
      foundedAt: '2020-01-10',
      symbol: { type: 'shape', shape: SHAPE_KEYS[0] },
      primary: '#112233', secondary: '#445566', flagPattern: FLAG_KEYS[0],
      ideology: { economic: 50, social: 50 },
    },
  };
}

before(async () => {
  setVerifier(async (t) => verifyIdTokenWith(t, { 'test-key': PEM }, PROJECT));
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});

after(() => {
  server.close();
  fs.rmSync(DATA_DIR, { recursive: true, force: true });
});

// ---------------- Login e perfil ----------------
test('saúde: responde ok e informa o projeto Firebase', async () => {
  const r = await call('GET', '/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.data.ok, true);
  assert.equal(r.data.firebaseProject, PROJECT);
});

test('login: sem token, /api/auth/me devolve usuário nulo', async () => {
  const r = await call('GET', '/api/auth/me');
  assert.equal(r.status, 200);
  assert.equal(r.data.user, null);
});

test('login: token inválido é recusado com 401', async () => {
  const r = await call('GET', '/api/auth/me', { token: 'abc.def.ghi' });
  assert.equal(r.status, 401);
});

test('login: token de outro projeto é recusado', async () => {
  const bad = makeToken('intruso', { aud: 'outro-projeto', iss: 'https://securetoken.google.com/outro-projeto' });
  const r = await call('GET', '/api/auth/me', { token: bad });
  assert.equal(r.status, 401);
});

test('login: token expirado é recusado', async () => {
  const old = Math.floor(Date.now() / 1000) - 7200;
  const r = await call('GET', '/api/auth/me', { token: makeToken('velho', { iat: old, exp: old + 60 }) });
  assert.equal(r.status, 401);
});

test('login: token com payload adulterado é recusado (assinatura não confere)', async () => {
  const good = makeToken('adulterado');
  const [h, , s] = good.split('.');
  const forged = `${h}.${b64url(JSON.stringify({ sub: 'outro', aud: PROJECT, iss: `https://securetoken.google.com/${PROJECT}`, exp: 9999999999, iat: 1 }))}.${s}`;
  const r = await call('GET', '/api/auth/me', { token: forged });
  assert.equal(r.status, 401);
});

test('perfil: conta nova sem nome de usuário precisa escolher um', async () => {
  const token = makeToken(`novo-${uniq()}`);
  const me = await call('GET', '/api/auth/me', { token });
  assert.equal(me.data.user, null);
  assert.equal(me.data.needsProfile, true);
  const blocked = await call('GET', '/api/settings', { token });
  assert.equal(blocked.status, 403);
  assert.equal(blocked.data.needsProfile, true);
});

test('perfil: nome de usuário inválido e repetido são recusados', async () => {
  const token = makeToken(`perfil-${uniq()}`);
  const inv = await call('POST', '/api/auth/profile', { token, body: { username: 'a b' } });
  assert.equal(inv.status, 400);
  assert.ok(inv.data.fields.username);
  const nome = `Repetido${uniq()}`;
  const ok = await call('POST', '/api/auth/profile', { token, body: { username: nome } });
  assert.equal(ok.status, 201);
  const again = await call('POST', '/api/auth/profile', { token, body: { username: 'Outro_nome' } });
  assert.equal(again.status, 409);
  const otherUid = makeToken(`outro-${uniq()}`);
  const dup = await call('POST', '/api/auth/profile', { token: otherUid, body: { username: nome } });
  assert.equal(dup.status, 400);
  assert.ok(dup.data.fields.username);
});

test('perfil: após criar o perfil, /api/auth/me devolve o usuário e as configurações', async () => {
  const p = await newPlayer('me');
  const r = await call('GET', '/api/auth/me', { token: p.token });
  assert.equal(r.data.user.username, p.username);
  assert.equal(r.data.user.provider, 'e-mail');
  assert.equal(r.data.settings.language, 'pt');
});

// ---------------- Configurações ----------------
test('configurações: sem login são recusadas', async () => {
  const r = await call('GET', '/api/settings');
  assert.equal(r.status, 401);
});

test('configurações: salvam e são lidas de volta', async () => {
  const p = await newPlayer('cfg');
  const body = { language: 'en', graphics: 'alto', volume: 40, music: false, sfx: true, animations: 'media', screenMode: 'janela', sensitivity: 70, batterySaver: false, effects: true };
  const put = await call('PUT', '/api/settings', { token: p.token, body });
  assert.equal(put.status, 200);
  const get = await call('GET', '/api/settings', { token: p.token });
  assert.equal(get.data.settings.volume, 40);
  assert.equal(get.data.settings.language, 'en');
});

test('configurações: valores inválidos são recusados', async () => {
  const p = await newPlayer('cfgbad');
  const r = await call('PUT', '/api/settings', { token: p.token, body: { volume: 500 } });
  assert.equal(r.status, 400);
});

// ---------------- Partidos ----------------
test('partidos: criar, listar e editar; campos de jogo não são alterados', async () => {
  const p = await newPlayer('party');
  const created = await call('POST', '/api/parties', { token: p.token, body: partyBody('Partido Alfa') });
  assert.equal(created.status, 201);
  const id = created.data.party.id;
  const list = await call('GET', '/api/parties', { token: p.token });
  assert.equal(list.data.parties.length, 1);
  const edit = await call('PUT', `/api/parties/${id}`, { token: p.token, body: partyBody('Partido Beta') });
  assert.equal(edit.status, 200);
  assert.equal(edit.data.party.name, 'Partido Beta');
  assert.equal(edit.data.party.members, 1);
});

test('partidos: dados inválidos são recusados e outra conta não edita o partido', async () => {
  const dono = await newPlayer('dono');
  const outra = await newPlayer('outra');
  const bad = await call('POST', '/api/parties', { token: dono.token, body: { party: { name: 'x' } } });
  assert.equal(bad.status, 400);
  const created = await call('POST', '/api/parties', { token: dono.token, body: partyBody('Partido Dono') });
  const steal = await call('PUT', `/api/parties/${created.data.party.id}`, { token: outra.token, body: partyBody('Roubado') });
  assert.equal(steal.status, 404);
});

// ---------------- Partidas ----------------
test('partida: criar a partir do personagem, com resumo de cargos', async () => {
  const p = await newPlayer('carreira');
  const r = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  assert.equal(r.status, 201);
  assert.equal(r.data.career.status, 'ativa');
  assert.equal(r.data.career.day, 0);
  assert.equal(r.data.career.summary.offices.length, 7);
  assert.equal(r.data.career.money, 10000);
  assert.equal(r.data.career.support, 0);
  assert.equal(r.data.career.userId, undefined, 'o id da conta não é devolvido');
});

test('partida: última partida é recuperada após salvar', async () => {
  const p = await newPlayer('reload');
  const created = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const id = created.data.career.id;
  await call('POST', `/api/career/${id}/action`, { token: p.token, body: { action: 'comer' } });
  const latest = await call('GET', '/api/career/latest', { token: p.token });
  assert.equal(latest.data.career.id, id);
  assert.equal(latest.data.career.money, 10000 - 15);
});

test('partida: ações pessoais alteram dinheiro e atributos pelo servidor', async () => {
  const p = await newPlayer('acoes');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const id = data.career.id;
  const trab = await call('POST', `/api/career/${id}/action`, { token: p.token, body: { action: 'trabalhar' } });
  assert.equal(trab.status, 200);
  assert.equal(trab.data.career.money, 10000 + 1200);
  const desc = await call('POST', `/api/career/${id}/action`, { token: p.token, body: { action: 'descansar' } });
  assert.equal(desc.status, 200);
});

test('partida: ação desconhecida é recusada antes do motor', async () => {
  const p = await newPlayer('invalida');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const r = await call('POST', `/api/career/${data.career.id}/action`, { token: p.token, body: { action: 'ficarRico' } });
  assert.equal(r.status, 400);
});

test('campanha: compra de celular e fabricação de santinhos pela API, com saldo de campanha', async () => {
  const p = await newPlayer('campanha');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const id = data.career.id;
  const phone = await call('POST', `/api/career/${id}/action`, { token: p.token, body: { action: 'comprarCelular', payload: { phoneId: 'samsung-nova' } } });
  assert.equal(phone.status, 200);
  assert.equal(phone.data.career.money, 10000 - 1800);
  const sem = await call('POST', `/api/career/${id}/action`, { token: p.token, body: { action: 'fabricarSantinhos', payload: { quantity: 20 } } });
  assert.equal(sem.status, 400, 'sem dinheiro de campanha o pedido é recusado');
});

test('campanha: conversa devolve fala do cidadão (texto local sem chave de IA) e não altera o dinheiro', async () => {
  const p = await newPlayer('conversa');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const id = data.career.id;
  const citizen = data.career.citizens.find((c) => c.regionId === 'centro');
  const r = await call('POST', `/api/career/${id}/action`, { token: p.token, body: { action: 'conversar', payload: { citizenId: citizen.id, topic: 'cumprimentar', reply: 'texto do cliente' } } });
  assert.equal(r.status, 200);
  const last = r.data.career.conversations.at(-1);
  assert.ok(last.reply && last.reply !== 'texto do cliente', 'a fala deve vir do servidor');
  assert.equal(r.data.career.money, 10000);
});

test('presidência: ações presidenciais exigem a eleição e são recusadas pelo motor com mensagem', async () => {
  const p = await newPlayer('presidente');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const r = await call('POST', `/api/career/${data.career.id}/action`, { token: p.token, body: { action: 'responderDebate', payload: { debateId: 'x', answers: [] } } });
  assert.equal(r.status, 400);
  assert.ok(r.data.error || r.data.message, 'a recusa traz uma mensagem');
});

test('tempo: avança dias e grava o novo dia; limites são respeitados', async () => {
  const p = await newPlayer('tempo');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const id = data.career.id;
  const r = await call('POST', `/api/career/${id}/time`, { token: p.token, body: { days: 30 } });
  assert.equal(r.status, 200);
  assert.equal(r.data.career.day, 30);
  const zero = await call('POST', `/api/career/${id}/time`, { token: p.token, body: { days: 0 } });
  assert.equal(zero.status, 400);
  const big = await call('POST', `/api/career/${id}/time`, { token: p.token, body: { days: 61 } });
  assert.equal(big.status, 400);
  const notInt = await call('POST', `/api/career/${id}/time`, { token: p.token, body: { days: 2.5 } });
  assert.equal(notInt.status, 400);
});

test('eleição: candidatura fora da janela eleitoral é recusada pelo servidor', async () => {
  const p = await newPlayer('elei');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const r = await call('POST', `/api/career/${data.career.id}/action`, { token: p.token, body: { action: 'registrarCandidatura', payload: { officeId: 'vereador' } } });
  assert.equal(r.status, 400);
  assert.match(r.data.error, /disputa|janela/);
});

test('partido: trocar de partido usa o partido resolvido pelo servidor', async () => {
  const p = await newPlayer('troca');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const r = await call('POST', `/api/career/${data.career.id}/action`, { token: p.token, body: { action: 'trocarPartido', payload: { partyId: 'ext-mc' } } });
  assert.equal(r.status, 200);
  assert.equal(r.data.career.partyId, 'ext-mc');
  assert.equal(r.data.career.party.acronym, 'MC');
  const fake = await call('POST', `/api/career/${data.career.id}/action`, { token: p.token, body: { action: 'trocarPartido', payload: { partyId: 'nao-existe' } } });
  assert.equal(fake.status, 400);
});

test('contas: uma conta não age sobre a partida de outra', async () => {
  const dono = await newPlayer('dono-c');
  const intruso = await newPlayer('intruso-c');
  const { data } = await call('POST', '/api/career/prepare', { token: dono.token, body: characterBody() });
  const r = await call('POST', `/api/career/${data.career.id}/action`, { token: intruso.token, body: { action: 'comer' } });
  assert.equal(r.status, 404);
  const t = await call('POST', `/api/career/${data.career.id}/time`, { token: intruso.token, body: { days: 1 } });
  assert.equal(t.status, 404);
});

test('importação: restaura uma partida quando a conta não tem nenhuma; a segunda é recusada', async () => {
  const p = await newPlayer('import');
  const { data } = await call('POST', '/api/career/prepare', { token: p.token, body: characterBody() });
  const state = structuredClone(data.career);
  delete state.summary;
  const q = await newPlayer('import2');
  const ok = await call('POST', '/api/career/import', { token: q.token, body: { state } });
  assert.equal(ok.status, 201);
  const again = await call('POST', '/api/career/import', { token: q.token, body: { state } });
  assert.equal(again.status, 409);
});

test('importação: cópia local inválida é recusada', async () => {
  const q = await newPlayer('import3');
  const r = await call('POST', '/api/career/import', { token: q.token, body: { state: { money: 'muito' } } });
  assert.equal(r.status, 400);
});

// ---------------- Arquivos e segurança ----------------
test('segurança: a página recebe a Content Security Policy com os domínios do Firebase', async () => {
  const r = await fetch(`${base}/`);
  assert.equal(r.status, 200);
  const csp = r.headers.get('content-security-policy');
  assert.match(csp, /script-src 'self' https:\/\/www\.gstatic\.com/);
  assert.match(csp, /identitytoolkit\.googleapis\.com/);
  assert.match(csp, /object-src 'none'/);
});

test('arquivos: caminhos fora da pasta pública são bloqueados', async () => {
  const r = await fetch(`${base}/..%2F..%2Fpackage.json`);
  assert.notEqual(r.status, 200);
});
