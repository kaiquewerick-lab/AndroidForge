// Testes das regras da Parte 2: requisitos, progressão, eleições, mandatos, salários,
// separação de dinheiro, aprovação, votações, eventos, projetos, partidos, salvamento.
// Rodar com: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_CHARACTER } from '../public/js/game/characterData.js';
import { EXISTING_PARTIES, OFFICES, EVENTS } from '../public/js/game/offices.js';
import { initialCareer, START_MONEY } from '../public/js/game/careerRules.js';
import {
  advance, performAction, officeStatus, electionWindowOpen, electionPhase, financialReport, careerSummary,
  GameError,
} from '../public/js/game/politics.js';
import { validateCareerState, pickCareer } from '../public/js/core/validate.js';
import { preCampaignStart, electionDay, posseDay, dayOf } from '../public/js/game/calendar.js';

const PARTY = EXISTING_PARTIES[0];
const CHARACTER = () => ({ ...structuredClone(DEFAULT_CHARACTER), firstName: 'Ana', lastName: 'Souza' });
const LOCATION = { state: DEFAULT_CHARACTER.birthState, city: DEFAULT_CHARACTER.birthCity };

function newCareer({ party = null, seed = 0.42 } = {}) {
  const r = mulberry(seed);
  return initialCareer({ character: CHARACTER(), party, location: LOCATION }, r);
}

// Gerador determinístico só para os testes (valores fixos de partida).
function mulberry(seed) {
  let a = Math.floor(seed * 4294967295) >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Avança até a janela eleitoral (pré-campanha) abrir, sem passar do dia de eleição.
function advanceUntil(s, pred, limitDays = 4000) {
  let cur = s;
  for (let i = 0; i < limitDays; i += 1) {
    if (pred(cur)) return cur;
    cur = advance(cur, 1);
  }
  throw new Error('condição não atingida');
}

// Dá ao jogador recursos suficientes para o cargo pedido (apenas nos testes).
function makeEligible(s, { support = 2_000_000, money = 1_000_000, withParty = true } = {}) {
  const next = structuredClone(s);
  next.support = support;
  next.money = money;
  if (withParty) {
    next.partyId = PARTY.id;
    next.party = { id: PARTY.id, name: PARTY.name, acronym: PARTY.acronym, number: PARTY.number };
  }
  return next;
}

test('requisitos: vereador exige partido, apoio e dinheiro', () => {
  let s = newCareer();
  s.support = 5000;
  s.money = 5000;
  assert.equal(officeStatus(s, 'vereador').eligible, false, 'sem partido não é elegível');
  s = makeEligible(s, { support: 5000, money: 5000 });
  assert.equal(officeStatus(s, 'vereador').eligible, true);
  s.support = 500;
  const st = officeStatus(s, 'vereador');
  assert.equal(st.items.find((i) => i.key === 'apoio').met, false, 'apoio abaixo do mínimo aparece pendente');
  assert.equal(st.eligible, false);
});

test('requisitos: prefeito exige janela eleitoral aberta e partido', () => {
  const s = makeEligible(newCareer(), { support: 50000, money: 50000 });
  const st = officeStatus(s, 'prefeito');
  assert.equal(st.items.find((i) => i.key === 'campanha').met, false, 'sem eleição aberta, campanha pendente');
  assert.equal(st.eligible, false);
});

test('requisitos: valores do briefing estão configurados', () => {
  assert.equal(OFFICES.vereador.requirements.support, 1000);
  assert.equal(OFFICES.vereador.requirements.money, 2000);
  assert.equal(OFFICES.prefeito.requirements.support, 20000);
  assert.equal(OFFICES.prefeito.requirements.money, 15000);
  assert.equal(OFFICES.deputado_estadual.requirements.support, 50000);
  assert.equal(OFFICES.governador.requirements.support, 300000);
  assert.equal(OFFICES.deputado_federal.requirements.support, 500000);
  assert.equal(OFFICES.senador.requirements.support, 800000);
  assert.equal(OFFICES.senador.mandateYears, 8);
  assert.equal(OFFICES.vereador.mandateYears, 4);
});

test('progressão: candidatura é recusada fora da janela eleitoral', () => {
  const s = makeEligible(newCareer());
  assert.throws(() => performAction(s, 'registrarCandidatura', { officeId: 'vereador' }), GameError);
});

test('progressão: candidatura é aceita com requisitos cumpridos e recusada sem eles', () => {
  let s = advanceUntil(newCareer(), (c) => electionWindowOpen(c));
  const rich = makeEligible(s, { support: 10 });
  assert.throws(() => performAction(rich, 'registrarCandidatura', { officeId: 'vereador' }), /Requisitos pendentes/);
  const ok = makeEligible(s);
  const next = performAction(ok, 'registrarCandidatura', { officeId: 'vereador' });
  assert.equal(next.election.registered, 'vereador');
});

test('progressão: não se candidata a outro cargo enquanto ocupa um', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c));
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  s = advanceUntil(s, (c) => c.office !== null, 800);
  assert.equal(s.office.id, 'vereador', 'o jogador tomou posse de vereador');
  // A eleição de 2032 ainda ocorre durante o mandato de vereador (que termina em 2033).
  s = advanceUntil(s, (c) => electionWindowOpen(c) && c.election.year === 2032, 2000);
  assert.throws(() => performAction(s, 'registrarCandidatura', { officeId: 'prefeito' }), /Renuncie|aguarde/i);
});

test('eleição: o candidato com mais apoio vence e toma posse com mandato de 4 anos', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c));
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  s = advanceUntil(s, (c) => c.office !== null, 800);
  assert.equal(s.office.id, 'vereador');
  assert.equal(s.office.endDay, dayOf(2028 + 1 + 4, 0, 1), 'mandato termina em 1º de janeiro após os 4 anos');
  assert.equal(s.position, 'Vereador');
  assert.equal(s.electionHistory.at(-1).playerWon, true);
  assert.ok(s.electionHistory.at(-1).winners.vereador.length === OFFICES.vereador.seats);
});

test('eleição: fases do calendário seguem a ordem correta', () => {
  const s = newCareer();
  const e = { year: 2028, electionDay: electionDay(2028) };
  assert.equal(electionPhase(e, preCampaignStart(2028)), 'pre-campanha');
  assert.equal(electionPhase(e, electionDay(2028)), 'votacao');
  assert.equal(electionPhase(e, electionDay(2028) + 1), 'resultado');
  assert.equal(electionPhase(e, posseDay(2028)), 'posse');
  assert.ok(s);
});

test('eleição: derrota não concede cargo', () => {
  // Prefeito tem uma vaga. Os adversários são fixados bem acima do jogador (somente no teste).
  let s = advanceUntil(makeEligible(newCareer(), { support: 25000, money: 20000 }), (c) => electionWindowOpen(c));
  for (const o of s.election.opponents.prefeito) {
    o.support = 5_000_000;
    o.fame = 100;
  }
  s = performAction(s, 'registrarCandidatura', { officeId: 'prefeito' });
  s = advanceUntil(s, (c) => c.electionHistory.length > 0, 800);
  assert.equal(s.office, null);
  assert.equal(s.electionHistory.at(-1).playerWon, false);
  assert.ok(s.careerLog.some((l) => l.type === 'derrota'), 'derrota registrada no histórico');
});

test('mandato: ao terminar, o cargo é registrado no histórico e o cargo volta a cidadão', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c));
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  s = advanceUntil(s, (c) => c.office !== null, 800);
  s = advanceUntil(s, (c) => c.office === null && c.pastOffices.length > 0, 1500);
  assert.equal(s.pastOffices.at(-1).id, 'vereador');
  assert.equal(s.position, 'Cidadão(ã)');
  assert.equal(s.pastOffices.at(-1).promises.length, 3, 'três promessas de campanha');
});

test('salários: são pagos na conta pessoal, saindo do orçamento público do mesmo escopo', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c));
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  s = advanceUntil(s, (c) => c.office !== null, 800);
  const before = { pessoal: s.money, municipal: s.publicBudgets.municipal, campanha: s.campaignFund };
  s = advance(s, 31); // 31 dias seguidos sempre incluem um dia múltiplo de 30 (pagamento mensal)
  const salaryEntries = s.ledger.filter((l) => l.desc.startsWith('Salário público') && l.account === 'pessoal');
  const folhaEntries = s.ledger.filter((l) => l.desc.startsWith('Folha') && l.account === 'publico:municipal');
  assert.ok(salaryEntries.length >= 1, 'salário registrado na conta pessoal');
  assert.ok(folhaEntries.length >= 1, 'despesa registrada no orçamento municipal');
  assert.equal(s.campaignFund, before.campanha, 'dinheiro de campanha não é usado para salário');
  assert.ok(s.money >= before.pessoal, 'o saldo pessoal cresce com o salário');
});

test('separação: dinheiro pessoal não paga despesas de campanha diretamente', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c));
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  s = advanceUntil(s, (c) => electionPhase(c.election, c.day) === 'campanha', 400);
  const pessoalAntes = s.money;
  // Campanha usa só o dinheiro de campanha: sem fundo, a ação é recusada.
  assert.throws(() => performAction(s, 'campanha', { type: 'comicio' }), /Saldo insuficiente/);
  assert.equal(s.money, pessoalAntes, 'o dinheiro pessoal não foi tocado');
  // Depois de contribuir voluntariamente, a campanha pode gastar.
  s = performAction(s, 'contribuir', { source: 'pessoal', amount: 5000 });
  assert.equal(s.money, pessoalAntes - 5000);
  assert.equal(s.campaignFund, 5000);
  s = performAction(s, 'campanha', { type: 'comicio' });
  assert.equal(s.campaignFund, 3000);
  assert.equal(s.money, pessoalAntes - 5000, 'a campanha não debita o dinheiro pessoal');
});

test('separação: contribuição do partido só sai do caixa do partido', () => {
  const s = makeEligible(newCareer());
  s.partyFund = 1000;
  const next = performAction(s, 'contribuir', { source: 'partido', amount: 400 });
  assert.equal(next.partyFund, 600);
  assert.equal(next.campaignFund, 400);
  assert.equal(next.money, s.money, 'o pessoal não muda');
  assert.throws(() => performAction(next, 'contribuir', { source: 'partido', amount: 9999 }), /Saldo insuficiente/);
});

test('relatório financeiro mostra contas separadas', () => {
  const s = newCareer();
  const rep = financialReport(s, 30);
  assert.deepEqual(Object.keys(rep.balances).sort(), ['campanha', 'partido', 'pessoal', 'publico:estadual', 'publico:federal', 'publico:municipal'].sort());
  assert.equal(rep.balances.pessoal, START_MONEY);
});

test('aprovação: decisões de evento alteram a aprovação', () => {
  let s = makeEligible(newCareer(), { support: 1, money: 1 });
  s.events.push({
    id: 'ev-teste', key: 'protesto', title: EVENTS.protesto.title, text: EVENTS.protesto.text,
    options: EVENTS.protesto.options.map((o) => o.label), createdDay: s.day, deadline: s.day + 7,
    status: 'pendente', chosen: null, auto: false,
  });
  const antes = s.approval;
  const reprimir = performAction(s, 'decidirEvento', { eventId: 'ev-teste', option: 1 });
  assert.ok(reprimir.approval < antes, 'reprimir protesto reduz aprovação');
  const dialogar = performAction(s, 'decidirEvento', { eventId: 'ev-teste', option: 0 });
  assert.ok(dialogar.approval > reprimir.approval, 'dialogar é melhor para a aprovação');
});

test('aprovação: é um valor entre 0 e 100 e aparece no histórico semanal', () => {
  let s = newCareer();
  s = advance(s, 60);
  assert.ok(s.approval >= 0 && s.approval <= 100);
  assert.ok(s.approvalHistory.length >= 8, 'histórico semanal de aprovação');
});

test('votação: vereador vota e a pauta é encerrada com contagem', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c));
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  s = advanceUntil(s, (c) => c.office !== null, 800);
  s = advanceUntil(s, (c) => c.bills.some((b) => b.status === 'aberto'), 60);
  const bill = s.bills.find((b) => b.status === 'aberto');
  s = performAction(s, 'votar', { billId: bill.id, vote: 'favor' });
  assert.equal(s.bills.find((b) => b.id === bill.id).playerVote, 'favor');
  s = advanceUntil(s, (c) => c.bills.find((b) => b.id === bill.id).status !== 'aberto', 20);
  const closed = s.bills.find((b) => b.id === bill.id);
  assert.ok(['aprovado', 'rejeitado'].includes(closed.status));
  const t = closed.tally;
  assert.equal(t.favor + t.contra + t.abstencao, OFFICES.vereador.council, 'a contagem soma o tamanho da Câmara');
  assert.equal(t.favor > t.contra, closed.status === 'aprovado', 'a decisão segue a contagem');
});

test('votação: sem mandato legislativo não é possível votar', () => {
  let s = advanceUntil(newCareer(), (c) => c.day > 40);
  s.bills.push({ id: 'b1', title: 'x', sector: 'saude', econ: 50, social: 50, kind: 'lei', scope: 'municipal', popularity: 50, deadline: s.day + 5, status: 'aberto', playerVote: null, tally: null, debate: [] });
  assert.throws(() => performAction(s, 'votar', { billId: 'b1', vote: 'favor' }), /mandato legislativo/);
});

test('votação: abstenção é um voto válido', () => {
  const s = newCareer();
  s.office = { id: 'vereador', startDay: 0, endDay: 9999, reelections: 0, promises: [] };
  s.bills.push({ id: 'b2', title: 'x', sector: 'saude', econ: 50, social: 50, kind: 'lei', scope: 'municipal', popularity: 50, deadline: 999, status: 'aberto', playerVote: null, tally: null, debate: [] });
  const next = performAction(s, 'votar', { billId: 'b2', vote: 'abstencao' });
  assert.equal(next.bills[0].playerVote, 'abstencao');
});

test('administração: somente o Executivo inicia projetos', () => {
  const s = newCareer();
  s.office = { id: 'vereador', startDay: 0, endDay: 9999, reelections: 0, promises: [] };
  assert.throws(() => performAction(s, 'iniciarProjeto', { key: 'hospital' }), /Executivo/);
});

test('administração: obra consome orçamento e concede efeito ao concluir', () => {
  const s = newCareer();
  s.office = { id: 'prefeito', startDay: 0, endDay: 9999, reelections: 0, promises: [] };
  const orcamento = s.publicBudgets.municipal;
  const started = performAction(s, 'iniciarProjeto', { key: 'hospital' });
  assert.equal(started.publicBudgets.municipal, orcamento - 900000);
  let cur = started;
  const saudeAntes = cur.indicators.saude;
  for (let i = 0; i < 130; i += 1) cur = advance(cur, 1);
  assert.equal(cur.projects[0].status, 'concluido');
  assert.ok(cur.indicators.saude > saudeAntes, 'o indicador de saúde sobe ao concluir o hospital');
});

test('administração: programa mensal é suspenso quando o orçamento não cobre', () => {
  // A receita mensal do município cobre cerca de R$ 135 mil após o custo de funcionamento.
  // Três programas (R$ 200 mil no total) não cabem: pelo menos um deve ser suspenso.
  const s = newCareer();
  s.office = { id: 'prefeito', startDay: 0, endDay: 9999, reelections: 0, promises: [] };
  s.publicBudgets.municipal = 0;
  let cur = s;
  for (const key of ['programa_social', 'servidores', 'limpeza']) cur = performAction(cur, 'iniciarProjeto', { key });
  for (let i = 0; i < 31; i += 1) cur = advance(cur, 1);
  assert.ok(cur.projects.some((p) => p.status === 'suspenso'), 'programa suspenso por falta de orçamento');
  assert.ok(cur.publicBudgets.municipal >= 0, 'o orçamento público nunca fica negativo');
});

test('troca de partido: mandato legislativo exige confirmação e é perdido', () => {
  const s = newCareer({ party: { id: PARTY.id, name: PARTY.name, acronym: PARTY.acronym, number: PARTY.number } });
  s.office = { id: 'deputado_estadual', startDay: 0, endDay: 9999, reelections: 0, promises: [] };
  const outro = EXISTING_PARTIES[1];
  assert.throws(() => performAction(s, 'trocarPartido', { party: outro }), /fidelidade/);
  const next = performAction(s, 'trocarPartido', { party: outro, confirm: true });
  assert.equal(next.partyId, outro.id);
  assert.equal(next.office, null, 'perdeu o mandato');
  assert.equal(next.pastOffices.at(-1).reason.includes('fidelidade'), true);
});

test('renúncia: presidente não pode renunciar', () => {
  const s = newCareer();
  s.office = { id: 'presidente', startDay: 0, endDay: 9999, reelections: 0, promises: [] };
  assert.throws(() => performAction(s, 'renunciar'), /não permite/);
});

test('encerramento: a carreira fica encerrada e não aceita mais ações', () => {
  const s = newCareer();
  assert.throws(() => performAction(s, 'encerrarCarreira', {}), /Confirme/);
  const fim = performAction(s, 'encerrarCarreira', { confirm: true });
  assert.equal(fim.status, 'encerrada');
  assert.throws(() => performAction(fim, 'comer'), /encerrada/);
  assert.throws(() => advance(fim, 1), /encerrada/);
});

test('tempo: avanço aceita apenas de 1 a 60 dias por chamada', () => {
  const s = newCareer();
  assert.throws(() => advance(s, 0), GameError);
  assert.throws(() => advance(s, 61), GameError);
  assert.equal(advance(s, 60).day, 60);
});

test('salvamento: partida salva e recarregada continua idêntica (determinismo)', () => {
  let s = advanceUntil(makeEligible(newCareer()), (c) => electionWindowOpen(c), 500);
  s = performAction(s, 'registrarCandidatura', { officeId: 'vereador' });
  const saved = JSON.parse(JSON.stringify(pickCareer(s)));
  assert.deepEqual(validateCareerState(saved), []);
  const many = (c) => { let x = c; for (let i = 0; i < 4; i += 1) x = advance(x, 50); return x; };
  const a = many(s);
  const b = many(saved);
  assert.deepEqual(a.election, b.election, 'mesmo resultado depois de salvar e carregar');
  assert.equal(a.money, b.money);
  assert.equal(a.approval, b.approval);
  assert.equal(a.rng, b.rng);
});

test('validação: partida com cargo inválido é recusada', () => {
  const s = newCareer();
  s.office = { id: 'rei', startDay: 0, endDay: 1, reelections: 0, promises: [] };
  assert.ok(validateCareerState(s).some((e) => /Cargo ocupado/.test(e)));
});

test('resumo de carreira lista todos os cargos com situação', () => {
  const sum = careerSummary(newCareer());
  assert.equal(sum.offices.length, 7);
  assert.ok(sum.offices.every((o) => Array.isArray(o.items)));
});
