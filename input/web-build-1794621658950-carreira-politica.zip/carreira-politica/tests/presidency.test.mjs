// Testes da Parte 4: candidatura presidencial, adversários, debates, avaliação, pesquisas,
// eleição em dois turnos, posse, governo, programas, eventos, Congresso e salvamento.
// Rodar com: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_CHARACTER } from '../public/js/game/characterData.js';
import { EXISTING_PARTIES } from '../public/js/game/offices.js';
import { initialCareer } from '../public/js/game/careerRules.js';
import {
  advance, performAction, officeStatus, electionWindowOpen, GameError,
} from '../public/js/game/politics.js';
import {
  allocate, electorateByState, evaluateAnswer, openPresidentialElection, runPresidentialVote, presidentialPoll,
} from '../public/js/game/presidency.js';
import { PRESIDENCY, PRESIDENTIAL_EVENTS, DEPARTMENTS, CAMARA_SEATS, SENADO_SEATS } from '../public/js/game/presidencyData.js';
import { electionDay, campaignStart } from '../public/js/game/calendar.js';
import { validateCareerState, pickCareer } from '../public/js/core/validate.js';

const PARTY = EXISTING_PARTIES[0];
const CHARACTER = () => ({ ...structuredClone(DEFAULT_CHARACTER), firstName: 'Ana', lastName: 'Souza' });
const LOCATION = { state: DEFAULT_CHARACTER.birthState, city: DEFAULT_CHARACTER.birthCity };

function mulberry(seed) {
  let a = Math.floor(seed * 4294967295) >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Gerador com a forma esperada pelo motor (objeto com next()).
const rngOf = (seed) => ({ next: mulberry(seed) });

function newCareer({ seed = 0.42, support = 0, money = 0, campaignFund = 0, fame = 0, withParty = true } = {}) {
  const s = initialCareer({ character: CHARACTER(), location: LOCATION }, mulberry(seed));
  s.support = support;
  s.money = money;
  s.campaignFund = campaignFund;
  s.fame = fame;
  if (withParty) {
    s.partyId = PARTY.id;
    s.party = { id: PARTY.id, name: PARTY.name, acronym: PARTY.acronym, number: PARTY.number };
  }
  return s;
}

// Avança até a eleição presidencial abrir (primeira eleição, 2028).
function untilElectionOpen(s) {
  let cur = s;
  for (let i = 0; i < 2000 && !cur.election; i += 1) cur = advance(cur, 1);
  return cur;
}

// Roda um ciclo completo: o jogador se registra à Presidência, responde os debates e chega à apuração.
// answerFn(debate) devolve o payload de resposta do jogador.
function runCycle(s0, { register = true, answerFn = () => ({ answers: [{ answer: { choice: 1 } }, { answer: { choice: 0 } }, { answer: { choice: 2 } }] }) } = {}) {
  let s = untilElectionOpen(s0);
  if (register) s.election.registered = 'presidente';
  for (let steps = 0; steps < 5000 && s.election; steps += 1) {
    const due = s.presidential?.election?.debates.find((d) => d.status === 'agendado' && d.day === s.day);
    if (due && register) {
      s = performAction(s, 'responderDebate', { debateId: due.id, ...answerFn(due) });
      continue;
    }
    s = advance(s, 1);
  }
  return s;
}

// ---------------- Funções puras ----------------
test('distribuição de votos: totais inteiros que somam exatamente o total', () => {
  for (const total of [0, 1, 7, 1000, 150000003]) {
    const out = allocate(total, [3, 1, 0, 2, 5.5]);
    assert.equal(out.reduce((a, b) => a + b, 0), total);
    assert.ok(out.every((x) => Number.isInteger(x) && x >= 0));
  }
  assert.deepEqual(allocate(10, [1, 1]), [5, 5]);
});

test('eleitorado: os 27 estados somam exatamente o eleitorado do país', () => {
  const e = electorateByState();
  assert.equal(Object.keys(e).length, 27);
  assert.equal(Object.values(e).reduce((a, b) => a + b, 0), PRESIDENCY.electorate);
  assert.ok(Object.values(e).every((x) => x > 0));
});

test('avaliação: mesmos critérios e notas entre 0 e 100; texto vazio tem nota zero', () => {
  assert.equal(evaluateAnswer('').overall, 0);
  const a = evaluateAnswer('Vou propor um plano de saúde com metas e prazo, porque o diagnóstico mostra a fonte de recurso.', 'saude');
  const b = evaluateAnswer('Vou propor um plano de saúde com metas e prazo, porque o diagnóstico mostra a fonte de recurso.', 'saude');
  assert.deepEqual(a, b);
  for (const v of Object.values(a)) assert.ok(v >= 0 && v <= 100);
});

test('avaliação: estilos diferentes têm pontos fortes e fracos diferentes (sem resposta sempre melhor)', () => {
  const tec = evaluateAnswer('Para saúde, o plano tem metas numéricas, prazo de 24 meses e fonte de recurso definida, porque o diagnóstico técnico aponta essa prioridade.', 'saude');
  const pop = evaluateAnswer('Vou falar direto com você sobre saúde: vamos ouvir as comunidades e trabalhar com quem está na ponta.', 'saude');
  const agr = evaluateAnswer('Quem governa hoje falhou em saúde. Isso é um problema grave e a população sabe disso, mas não vou aceitar mais desculpas.', 'saude');
  assert.ok(tec.viabilidade > agr.viabilidade);
  assert.ok(agr.problemas > tec.problemas);
  assert.ok(new Set([tec.overall, pop.overall, agr.overall]).size >= 2);
});

test('adversários: entre 5 e 12 candidatos, todos com apoio mínimo de 15 milhões', () => {
  for (let seed = 1; seed <= 40; seed += 1) {
    const s = newCareer({ seed: seed / 41 });
    const opps = openPresidentialElection(s, 2028, rngOf(seed / 41));
    assert.ok(opps.length >= PRESIDENCY.candidatesMin && opps.length <= PRESIDENCY.candidatesMax);
    for (const o of opps) assert.ok(o.support >= PRESIDENCY.requirements.support, `apoio ${o.support}`);
  }
});

test('adversários: apoio muito alto é raro (acima de 100 milhões em poucos casos)', () => {
  let total = 0;
  let above = 0;
  for (let seed = 1; seed <= 300; seed += 1) {
    const s = newCareer();
    for (const o of openPresidentialElection(s, 2028, rngOf(seed / 301))) {
      total += 1;
      if (o.support > 100000000) above += 1;
    }
  }
  const share = above / total;
  assert.ok(share > 0 && share < 0.06, `fração acima de 100 milhões: ${share}`);
});

test('adversários: partidos distintos do jogador e personalidades diferentes', () => {
  const s = newCareer();
  const opps = openPresidentialElection(s, 2028, rngOf(0.9));
  const kinds = new Set(opps.map((o) => o.personality));
  assert.ok(kinds.size >= 2, 'personalidades devem variar');
  assert.ok(opps.every((o) => o.partyId !== PARTY.id));
});

// ---------------- Requisitos e candidatura ----------------
test('requisitos: a Presidência lista apoio, dinheiro, reserva de campanha e partido', () => {
  const s = newCareer();
  const st = officeStatus(s, 'presidente');
  const keys = st.items.map((i) => i.key);
  for (const k of ['apoio', 'dinheiro', 'partido', 'campanha', 'reserva']) assert.ok(keys.includes(k), `falta ${k}`);
  assert.equal(st.items.find((i) => i.key === 'apoio').target, PRESIDENCY.requirements.support);
  assert.equal(st.items.find((i) => i.key === 'reserva').target, PRESIDENCY.requirements.campaignReserve);
  assert.equal(st.eligible, false);
});

test('candidatura presidencial: recusada sem a reserva de campanha de R$ 6.000', () => {
  let s = newCareer({ support: 20000000, money: 60000, campaignFund: 1000 });
  s = untilElectionOpen(s);
  assert.throws(() => performAction(s, 'registrarCandidatura', { officeId: 'presidente' }), /Requisitos pendentes/);
});

test('candidatura presidencial: aceita quando todos os requisitos são cumpridos', () => {
  let s = newCareer({ support: 20000000, money: 60000, campaignFund: 6000 });
  s = untilElectionOpen(s);
  while (!electionWindowOpen(s)) s = advance(s, 1);
  s = performAction(s, 'registrarCandidatura', { officeId: 'presidente' });
  assert.equal(s.election.registered, 'presidente');
});

// ---------------- Debates ----------------
test('debates: três debates agendados em 30, 15 e 5 dias antes da eleição', () => {
  let s = untilElectionOpen(newCareer());
  const e = electionDay(s.election.year);
  assert.deepEqual(s.presidential.election.debates.map((d) => d.day), [e - 30, e - 15, e - 5]);
  assert.ok(s.presidential.election.debates.every((d) => d.status === 'agendado'));
});

test('debates: a resposta só é aceita no dia do debate', () => {
  let s = newCareer({ support: 20000000, money: 60000, campaignFund: 6000 });
  s = untilElectionOpen(s);
  s.election.registered = 'presidente';
  const debate = s.presidential.election.debates[0];
  assert.throws(() => performAction(s, 'responderDebate', { debateId: debate.id, answers: [] }), /acontece em/);
});

test('debates: o tempo para no dia do debate até o jogador responder', () => {
  let s = untilElectionOpen(newCareer());
  s.election.registered = 'presidente';
  const debate = s.presidential.election.debates[0];
  while (s.day < debate.day) s = advance(s, 1);
  const stuck = advance(s, 5);
  assert.equal(stuck.day, debate.day, 'o tempo deveria parar no debate');
  const done = performAction(stuck, 'responderDebate', { debateId: debate.id, answers: [] });
  assert.equal(done.presidential.election.debates[0].status, 'realizado');
  assert.ok(advance(done, 1).day > debate.day);
});

test('debates: relatório com a mesma avaliação para todos os participantes', () => {
  const s = runCycle(newCareer({ support: 20000000, money: 60000, campaignFund: 6000 }));
  const debate = s.electionHistory.length ? null : null;
  void debate;
  // O resultado de cada debate fica no histórico do ciclo (campo report).
  const report = s.presidential.election.debates[0].report;
  assert.ok(report, 'debate sem relatório');
  const keys = report.criteria.map((c) => c.key);
  for (const r of report.ranking) {
    for (const k of keys) assert.ok(r.criteria[k] >= 0 && r.criteria[k] <= 100, `${r.name} ${k}`);
    assert.ok(r.overall >= 0 && r.overall <= 100);
  }
  assert.equal(report.ranking[0].overall >= report.ranking.at(-1).overall, true);
});

test('debates: tempo de fala limita as palavras da resposta do jogador', () => {
  let s = untilElectionOpen(newCareer({ support: 20000000, money: 60000, campaignFund: 6000 }));
  s.election.registered = 'presidente';
  const debate = s.presidential.election.debates[0];
  debate.timeSeconds = 30;
  while (s.day < debate.day) s = advance(s, 1);
  const long = Array.from({ length: 200 }, (_, i) => `palavra${i}`).join(' ');
  s = performAction(s, 'responderDebate', { debateId: debate.id, answers: [{ answer: { text: long } }] });
  const first = s.presidential.election.debates[0].report.answers;
  const playerEntry = Object.values(first).flat().find((a) => a.kind === 'resposta' && !a.auto);
  assert.ok(playerEntry.text.split(' ').length <= 40);
});

// ---------------- Eleição nacional ----------------
test('apuração: soma de votos, eleitorado e percentuais são consistentes em várias partidas', () => {
  for (const seed of [0.11, 0.37, 0.73]) {
    const s = runCycle(newCareer({ seed, support: 20000000, money: 60000, campaignFund: 6000 }));
    const res = s.electionHistory.at(-1);
    assert.ok(res, 'eleição não encerrada');
    assert.ok(s.presidential.lastResult.verificationOk, 'verificação falhou');
  }
});

test('apuração: a mesma semente produz o mesmo resultado (reprodutível)', () => {
  const a = runCycle(newCareer({ seed: 0.5, support: 20000000, money: 60000, campaignFund: 6000 }));
  const b = runCycle(newCareer({ seed: 0.5, support: 20000000, money: 60000, campaignFund: 6000 }));
  assert.deepEqual(a.electionHistory.at(-1), b.electionHistory.at(-1));
  assert.deepEqual(a.presidential.lastResult, b.presidential.lastResult);
});

test('apuração: segundo turno entre os dois mais votados, sempre verificado', () => {
  let withRound2 = 0;
  for (let seed = 1; seed <= 12; seed += 1) {
    const s = runCycle(newCareer({ seed: seed / 13, support: 20000000, money: 60000, campaignFund: 6000 }));
    const r = s.presidential.lastResult;
    assert.ok(r.verificationOk, `verificação falhou na semente ${seed}`);
    if (r.round2) withRound2 += 1;
  }
  assert.ok(withRound2 > 0, 'nenhuma partida chegou ao segundo turno');
});

test('apuração direta: pesquisas e votação somam 100% e respeitam a maioria absoluta', () => {
  let s = untilElectionOpen(newCareer({ support: 20000000, money: 60000, campaignFund: 6000 }));
  s.election.registered = 'presidente';
  const rng = rngOf(0.3);
  s.presidential.election.debates.forEach((d) => { d.status = 'realizado'; });
  const poll = presidentialPoll(s, rng);
  assert.equal(poll.sample, PRESIDENCY.sampleSize);
  assert.equal(poll.margin, PRESIDENCY.marginOfError);
  const total = Object.values(poll.intention).reduce((a, b) => a + b, 0) + poll.undecided;
  assert.ok(Math.abs(total - 100) <= 0.2, `intenções + indecisos = ${total}`);
  for (const r of Object.values(poll.rejection)) assert.ok(r >= 1 && r <= 90);
  const res = runPresidentialVote(s, rngOf(0.3));
  assert.equal(res.presidential.verification.ok, true);
  const winner = res.presidential.ranking.find((c) => c.won);
  assert.ok(res.presidential.round2 !== null || winner.votes * 2 > res.presidential.valid);
});

test('apuração: placas e debates contam (apoio cresce com o desempenho nos debates)', () => {
  const weak = runCycle(newCareer({ seed: 0.61, support: 20000000, money: 60000, campaignFund: 6000 }),
    { answerFn: () => ({ answers: [{ answer: { text: 'Sim.' } }, { answer: { text: 'Não.' } }, { answer: { text: 'Talvez.' } }] }) });
  const strong = runCycle(newCareer({ seed: 0.61, support: 20000000, money: 60000, campaignFund: 6000 }));
  const sumScores = (st) => st.presidential.election.debates.reduce((a, d) => a + (d.report?.playerScore || 0), 0);
  assert.ok(sumScores(strong) > sumScores(weak));
});

// ---------------- Vitória, derrota e posse ----------------
test('vitória: posse, gabinete com dez ministérios, vice e Congresso com 513 e 81 cadeiras', () => {
  let s = runCycle(newCareer({ seed: 0.2, support: 400000000, money: 60000, campaignFund: 6000, fame: 80 }));
  assert.equal(s.electionHistory.at(-1).playerWon, true);
  assert.equal(s.office?.id, 'presidente');
  const g = s.presidential.government;
  assert.ok(g.vice.name);
  assert.equal(Object.keys(g.ministers).length, Object.keys(DEPARTMENTS).length);
  assert.equal(Object.values(g.congress.seats.camara).reduce((a, b) => a + b, 0), CAMARA_SEATS);
  assert.equal(Object.values(g.congress.seats.senado).reduce((a, b) => a + b, 0), SENADO_SEATS);
});

test('derrota: sem cargo e sem governo; a carreira continua', () => {
  let s = runCycle(newCareer({ seed: 0.9, support: 15000000, money: 60000, campaignFund: 6000 }));
  if (s.electionHistory.at(-1).playerWon) return; // improvável; a derrota é verificada nas outras partidas
  assert.equal(s.office, null);
  assert.equal(s.presidential.government, null);
  assert.equal(s.status, 'ativa');
});

// ---------------- Governo ----------------
function inOffice() {
  return runCycle(newCareer({ seed: 0.2, support: 400000000, money: 60000, campaignFund: 6000, fame: 80 }));
}

test('gabinete: trocar ministro usa a lista de candidatos e recusa índice inválido', () => {
  let s = inOffice();
  s = performAction(s, 'nomearMinistro', { dept: 'saude', index: 2 });
  assert.equal(s.presidential.government.ministers.saude.name, s.presidential.government.pool.saude[2].name);
  assert.throws(() => performAction(s, 'nomearMinistro', { dept: 'saude', index: 9 }), GameError);
});

test('programas: custo sai do orçamento federal e o programa conclui após o prazo', () => {
  let s = inOffice();
  const before = s.publicBudgets.federal;
  s = performAction(s, 'iniciarPrograma', { dept: 'saude', key: 'medicamentos' });
  assert.equal(before - s.publicBudgets.federal, DEPARTMENTS.saude.programs.find((p) => p.key === 'medicamentos').cost);
  const days = DEPARTMENTS.saude.programs.find((p) => p.key === 'medicamentos').days;
  s = advance(s, days + 1);
  assert.equal(s.presidential.government.programs[0].status, 'concluido');
});

test('programas: sem orçamento federal, o programa é recusado (sem saldo negativo)', () => {
  let s = inOffice();
  s.publicBudgets.federal = 100;
  assert.throws(() => performAction(s, 'iniciarPrograma', { dept: 'infraestrutura', key: 'rodovias' }), GameError);
  assert.equal(s.publicBudgets.federal, 100);
});

test('presidente não vota em sessões: o voto é recusado', () => {
  const s = inOffice();
  const bill = s.presidential.government.congress.bills[0];
  assert.throws(() => performAction(s, 'votar', { billId: bill ? bill.id : 'x', vote: 'favor' }), /não vota/);
});

test('leis: sanção e veto só valem para leis aguardando sanção', () => {
  let s = inOffice();
  assert.throws(() => performAction(s, 'sancionarLei', { billId: 'inexistente', decision: 'sancionar' }), GameError);
  for (let i = 0; i < 400; i += 1) {
    const bill = s.presidential.government.congress.bills.find((b) => b.status === 'sancao');
    if (bill) {
      const after = performAction(s, 'sancionarLei', { billId: bill.id, decision: 'vetar' });
      const status = after.presidential.government.congress.bills.find((b) => b.id === bill.id).status;
      assert.ok(['vetada', 'promulgada'].includes(status));
      return;
    }
    s = advance(s, 1);
    if (!s.office) break;
  }
});

test('eventos presidenciais: a alternativa mostra custo e consequência e cobra do orçamento federal', () => {
  let s = inOffice();
  for (let i = 0; i < 2000; i += 1) {
    const ev = s.presidential.government.events.find((e) => e.status === 'pendente');
    if (ev) {
      const opt = ev.options.find((o) => o.cost > 0);
      if (!opt) { s = advance(s, 1); continue; }
      const idx = ev.options.indexOf(opt);
      const before = s.publicBudgets.federal;
      const after = performAction(s, 'decidirPresidencial', { eventId: ev.id, option: idx });
      assert.equal(before - after.publicBudgets.federal, opt.cost);
      assert.ok(Object.keys(PRESIDENTIAL_EVENTS).includes(ev.key));
      return;
    }
    s = advance(s, 1);
    if (!s.office) break;
  }
});

test('negociação com partido: custo do orçamento federal e intervalo entre negociações', () => {
  let s = inOffice();
  const before = s.publicBudgets.federal;
  s = performAction(s, 'negociarApoio', { partyId: EXISTING_PARTIES[2].id });
  assert.ok(before > s.publicBudgets.federal);
  assert.throws(() => performAction(s, 'negociarApoio', { partyId: EXISTING_PARTIES[2].id }), /Aguarde/);
});

test('governo: aprovação e indicadores nacionais ficam entre 0 e 100', () => {
  let s = inOffice();
  for (let i = 0; i < 2; i += 1) s = advance(s, 60);
  if (!s.office) return;
  assert.ok(s.approval >= 0 && s.approval <= 100);
  for (const v of Object.values(s.presidential.government.indicators)) assert.ok(v >= 0 && v <= 100);
  for (const poll of s.presidential.government.approvalPolls) {
    assert.equal(poll.approve + poll.disapprove + poll.undecided, 100);
  }
});

// ---------------- Campanha presidencial (integração com a Parte 3) ----------------
test('campanha presidencial: viajar para outro estado leva apoio para aquele estado', () => {
  let s = untilElectionOpen(newCareer({ support: 20000000, money: 60000, campaignFund: 100000 }));
  while (!electionWindowOpen(s)) s = advance(s, 1);
  s = performAction(s, 'registrarCandidatura', { officeId: 'presidente' });
  s = performAction(s, 'viajarEstado', { uf: 'SP' });
  s = performAction(s, 'atividade', { kind: 'entrevista' });
  assert.ok(s.presidential.states.SP.reached > 0);
});

test('apresentar proposta exige detalhes (metas, prazo ou fonte)', () => {
  let s = untilElectionOpen(newCareer({ support: 20000000, money: 60000, campaignFund: 6000 }));
  s.election.registered = 'presidente';
  assert.throws(() => performAction(s, 'apresentarProposta', { theme: 'saude', text: 'Vamos cuidar melhor.' }), /mais detalhes/);
  s = performAction(s, 'apresentarProposta', { theme: 'saude', text: 'Vou propor um plano de saúde com metas e prazo de 24 meses, porque a fonte de recurso já está definida.' });
  assert.equal(s.presidential.proposals.length, 1);
});

// ---------------- Salvamento ----------------
test('salvamento: partida presidencial salva, valida e recarrega com o mesmo resultado', () => {
  const s = inOffice();
  const saved = JSON.parse(JSON.stringify(pickCareer(s)));
  assert.deepEqual(validateCareerState(saved), []);
  const a = advance(s, 30);
  const b = advance(saved, 30);
  assert.deepEqual(a.presidential.government.indicators, b.presidential.government.indicators);
  assert.equal(a.approval, b.approval);
  assert.equal(a.publicBudgets.federal, b.publicBudgets.federal);
});
