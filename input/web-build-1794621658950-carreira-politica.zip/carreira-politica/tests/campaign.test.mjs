// Testes da Parte 3: apoio popular, conversas, santinhos, banners, placas, celulares,
// inventário, publicidade digital, fama, dinheiro de campanha e salvamento.
// Rodar com: npm test
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { DEFAULT_CHARACTER } from '../public/js/game/characterData.js';
import { initialCareer } from '../public/js/game/careerRules.js';
import { advance, performAction, careerSummary, GameError } from '../public/js/game/politics.js';
import { fameLevel, consumeReach, receptivity } from '../public/js/game/campaign.js';
import { SANTINHO, BANNER, PLACA, PHONES, REGIONS, REACH_SHARE, DAILY_REACH_SHARE, CITIZENS_PER_REGION } from '../public/js/game/campaignData.js';
import { validateCareerState, pickCareer } from '../public/js/core/validate.js';

const CHARACTER = () => ({ ...structuredClone(DEFAULT_CHARACTER), firstName: 'Ana', lastName: 'Souza' });
const LOCATION = { state: DEFAULT_CHARACTER.birthState, city: DEFAULT_CHARACTER.birthCity };

function mulberry(seed) {
  let a = Math.floor(seed * 4294967295) >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function newCareer({ seed = 0.42, money = 10000, campaignFund = 0 } = {}) {
  const s = initialCareer({ character: CHARACTER(), location: LOCATION }, mulberry(seed));
  s.money = money;
  s.campaignFund = campaignFund;
  return s;
}

// Compra um celular e equipa (pré-requisito da publicidade digital).
const withPhone = (s) => performAction(s, 'comprarCelular', { phoneId: PHONES[0].id });

const cityCitizen = (s, regionId = 'centro') => s.citizens.find((c) => c.regionId === regionId);

// ---------------- Dinheiro e santinhos ----------------
test('santinhos: fabricação de R$ 20 e impressão de R$ 5 a cada 20 unidades', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 40 });
  assert.equal(s.campaignFund, 1000 - SANTINHO.fabricacao - 10);
  assert.equal(s.inventory.find((i) => i.kind === 'santinho').quantity, 40);
  assert.equal(s.stats.santinhosFabricados, 40);
});

test('santinhos: 21 unidades pagam impressão de dois lotes', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 21 });
  assert.equal(s.campaignFund, 1000 - 20 - 10);
});

test('santinhos: sem saldo de campanha, o pedido é recusado (saldo nunca fica negativo)', () => {
  const s = newCareer({ campaignFund: 10 });
  assert.throws(() => performAction(s, 'fabricarSantinhos', { quantity: 20 }), GameError);
  assert.equal(s.campaignFund, 10);
});

test('santinhos: pedido fora da faixa é recusado', () => {
  const s = newCareer({ campaignFund: 100000 });
  assert.throws(() => performAction(s, 'fabricarSantinhos', { quantity: 5 }), GameError);
  assert.throws(() => performAction(s, 'fabricarSantinhos', { quantity: SANTINHO.pedidoMax + 1 }), GameError);
});

test('distribuição: não é possível entregar mais santinhos do que existem no inventário', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 20 });
  const id = s.inventory[0].id;
  assert.throws(() => performAction(s, 'distribuirSantinhos', { itemId: id, quantity: 21 }), GameError);
});

test('distribuição: inventário diminui conforme as unidades são entregues', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 20 });
  const id = s.inventory[0].id;
  s = performAction(s, 'distribuirSantinhos', { itemId: id, quantity: 5 });
  assert.equal(s.inventory.find((i) => i.id === id).quantity, 15);
  assert.equal(s.stats.santinhosDistribuidos, 5);
});

test('distribuição: limite diário de santinhos por campanha', () => {
  let s = newCareer({ campaignFund: 100000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 200 });
  const id = s.inventory[0].id;
  s = performAction(s, 'distribuirSantinhos', { itemId: id, quantity: SANTINHO.limiteDiario });
  assert.throws(() => performAction(s, 'distribuirSantinhos', { itemId: id, quantity: 1 }), GameError);
});

test('distribuição: o apoio de santinhos respeita o teto diário da região', () => {
  let s = newCareer({ campaignFund: 100000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 60 });
  const id = s.inventory[0].id;
  s = performAction(s, 'distribuirSantinhos', { itemId: id, quantity: 60 });
  const centro = REGIONS.find((r) => r.id === 'centro');
  const dailyCap = Math.floor(centro.population * DAILY_REACH_SHARE);
  assert.ok(s.support <= dailyCap, `apoio ${s.support} acima do teto diário ${dailyCap}`);
  assert.ok(Number.isInteger(s.support) && s.support >= 0);
});

test('distribuição: o alcance cai na região onde o candidato está', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 20 });
  const id = s.inventory[0].id;
  s = performAction(s, 'mudarRegiao', { regionId: 'norte' });
  s = performAction(s, 'distribuirSantinhos', { itemId: id, quantity: 2 });
  const reached = (rid) => s.regions.find((r) => r.id === rid).reached;
  assert.ok(reached('norte') > 0, 'norte deveria receber o alcance');
  assert.equal(reached('centro'), 0, 'centro não deveria receber alcance');
  assert.equal(s.stats.santinhosDistribuidos, 2);
});

// ---------------- Banners e placas ----------------
test('banners: custo = material + impressão, e o banner vai para o inventário', () => {
  let s = newCareer({ campaignFund: 5000 });
  s = performAction(s, 'fabricarBanner', { material: 'premium', size: 'grande', design: { name: 'Ana Souza', number: '71', slogan: 'Juntos' } });
  assert.equal(s.campaignFund, 5000 - BANNER.materiais.premium.fabricacao - BANNER.impressao);
  const banner = s.inventory.find((i) => i.kind === 'banner');
  assert.equal(banner.design.number, '71');
  assert.equal(banner.size, 'grande');
});

test('banners: no máximo três instalados por região', () => {
  let s = newCareer({ campaignFund: 50000 });
  for (let i = 0; i < 4; i += 1) s = performAction(s, 'fabricarBanner', { material: 'simples', size: 'medio' });
  for (let i = 0; i < BANNER.maxPorRegiao; i += 1) {
    const b = s.inventory.find((x) => x.kind === 'banner');
    s = performAction(s, 'instalarItem', { itemId: b.id });
  }
  const b = s.inventory.find((x) => x.kind === 'banner');
  assert.throws(() => performAction(s, 'instalarItem', { itemId: b.id }), GameError);
});

test('placas: placa grande custa fabricação + impressão e tem manutenção diária', () => {
  let s = newCareer({ campaignFund: 20000 });
  s = performAction(s, 'fabricarPlaca', { size: 'grande' });
  assert.equal(s.campaignFund, 20000 - PLACA.tamanhos.grande.fabricacao - PLACA.impressao);
  const placa = s.inventory.find((i) => i.kind === 'placa');
  s = performAction(s, 'instalarItem', { itemId: placa.id });
  const before = s.campaignFund;
  s = advance(s, 1);
  assert.equal(before - s.campaignFund, PLACA.tamanhos.grande.manutencaoDia);
});

test('placas: limite por região e nenhum apoio com verba zerada', () => {
  let s = newCareer({ campaignFund: 50000 });
  for (let i = 0; i < 3; i += 1) s = performAction(s, 'fabricarPlaca', { size: 'pequena' });
  for (let i = 0; i < PLACA.maxPorRegiao; i += 1) {
    const p = s.inventory.find((x) => x.kind === 'placa');
    s = performAction(s, 'instalarItem', { itemId: p.id });
  }
  const p = s.inventory.find((x) => x.kind === 'placa');
  assert.throws(() => performAction(s, 'instalarItem', { itemId: p.id }), GameError);
});

test('balanceamento: placas nunca passam do teto de audiência da região', () => {
  let s = newCareer({ campaignFund: 2000000 });
  for (let i = 0; i < 2; i += 1) {
    s = performAction(s, 'fabricarPlaca', { size: 'grande' });
    const p = s.inventory.find((x) => x.kind === 'placa');
    s = performAction(s, 'instalarItem', { itemId: p.id });
  }
  s = advance(s, 60);
  for (const r of s.regions) {
    assert.ok(r.reached <= Math.floor(r.population * REACH_SHARE), `${r.id} passou do teto total`);
  }
  assert.ok(Number.isInteger(s.support));
});

test('placa: reparo custa 10% da fabricação quando a conservação cai', () => {
  let s = newCareer({ campaignFund: 50000 });
  s = performAction(s, 'fabricarPlaca', { size: 'media' });
  const p = s.inventory.find((x) => x.kind === 'placa');
  s = performAction(s, 'instalarItem', { itemId: p.id });
  s = advance(s, 30);
  const inst = s.installs.find((i) => i.kind === 'placa');
  assert.ok(inst.condition < 100);
  const before = s.campaignFund;
  s = performAction(s, 'repararPlaca', { installId: inst.id });
  assert.equal(before - s.campaignFund, Math.round(PLACA.tamanhos.media.fabricacao * PLACA.reparoFracao));
});

// ---------------- Celulares e publicidade digital ----------------
test('celular: compra debita do dinheiro pessoal e é equipado automaticamente', () => {
  let s = newCareer({ money: 5000 });
  s = withPhone(s);
  assert.equal(s.money, 5000 - PHONES[0].price);
  assert.ok(s.equippedPhone);
  assert.equal(s.inventory.find((i) => i.kind === 'celular').name, `${PHONES[0].brand} ${PHONES[0].model}`);
});

test('celular: sem saldo pessoal, a compra é recusada', () => {
  const s = newCareer({ money: 100 });
  assert.throws(() => performAction(s, 'comprarCelular', { phoneId: PHONES[0].id }), GameError);
});

test('celular: trocar de aparelho e descartar o equipado', () => {
  let s = newCareer({ money: 20000 });
  s = withPhone(s);
  const first = s.equippedPhone;
  s = performAction(s, 'comprarCelular', { phoneId: PHONES[3].id });
  const second = s.inventory.find((i) => i.phoneId === PHONES[3].id).id;
  s = performAction(s, 'equiparCelular', { itemId: second });
  assert.equal(s.equippedPhone, second);
  s = performAction(s, 'descartarItem', { itemId: second });
  assert.equal(s.equippedPhone, null);
  assert.ok(s.inventory.some((i) => i.id === first));
});

test('publicidade digital: exige celular equipado', () => {
  const s = newCareer({ campaignFund: 10000 });
  assert.throws(() => performAction(s, 'campanhaDigital', { budget: 100, days: 7 }), GameError);
});

test('publicidade digital: orçamento diário é debitado da campanha e limitado a duas campanhas', () => {
  let s = withPhone(newCareer({ money: 5000, campaignFund: 10000 }));
  s = performAction(s, 'campanhaDigital', { budget: 100, days: 7 });
  const before = s.campaignFund;
  s = advance(s, 1);
  assert.equal(before - s.campaignFund >= 100, true);
  s = performAction(s, 'campanhaDigital', { budget: 100, days: 7 });
  assert.throws(() => performAction(s, 'campanhaDigital', { budget: 100, days: 7 }), GameError);
});

test('publicidade digital: pausa quando acaba o dinheiro de campanha (sem saldo negativo)', () => {
  let s = withPhone(newCareer({ money: 5000, campaignFund: 120 }));
  s = performAction(s, 'campanhaDigital', { budget: 100, days: 30 });
  s = advance(s, 3);
  assert.ok(s.campaignFund >= 0);
  assert.equal(s.digital[0].status, 'pausada');
});

test('publicidade digital: fama maior gera mais apoio, sem passar do teto', () => {
  const low = withPhone(newCareer({ money: 5000, campaignFund: 50000 }));
  const high = structuredClone(low);
  high.fame = 60;
  const lowRun = advance(performAction(low, 'campanhaDigital', { budget: 2000, days: 7 }), 5);
  const highRun = advance(performAction(high, 'campanhaDigital', { budget: 2000, days: 7 }), 5);
  assert.ok(highRun.support >= lowRun.support);
});

test('parar campanha digital encerra a publicidade', () => {
  let s = withPhone(newCareer({ money: 5000, campaignFund: 10000 }));
  s = performAction(s, 'campanhaDigital', { budget: 100, days: 14 });
  const id = s.digital[0].id;
  s = performAction(s, 'pararCampanhaDigital', { digitalId: id });
  assert.equal(s.digital[0].status, 'encerrada');
});

// ---------------- Conversas ----------------
test('conversa: só com cidadão da região atual', () => {
  const s = newCareer();
  const outside = s.citizens.find((c) => c.regionId !== s.currentRegion);
  assert.throws(() => performAction(s, 'conversar', { citizenId: outside.id, topic: 'cumprimentar' }), GameError);
});

test('conversa: ganho de apoio entre 25 e 30 pontos quando a reação é positiva', () => {
  let s = newCareer({ seed: 0.11 });
  for (let seed = 0; seed < 40; seed += 1) {
    const citizen = s.citizens.filter((c) => c.regionId === 'centro')[seed % CITIZENS_PER_REGION];
    if (citizen.lastTalkDay !== null) continue;
    const next = performAction(s, 'conversar', { citizenId: citizen.id, topic: 'problemas' });
    const log = next.conversations.at(-1);
    if (log.reaction === 'positiva') {
      assert.ok(next.support - s.support >= 25 && next.support - s.support <= 30, `ganho ${next.support - s.support}`);
      return;
    }
    s = next;
  }
  assert.fail('nenhuma conversa positiva em 40 tentativas (ajuste de balanceamento?)');
});

test('conversa: a mesma pessoa só pode ser abordada depois do prazo', () => {
  const s = newCareer({ seed: 0.3 });
  const citizen = cityCitizen(s);
  const once = performAction(s, 'conversar', { citizenId: citizen.id, topic: 'cumprimentar' });
  assert.throws(() => performAction(once, 'conversar', { citizenId: citizen.id, topic: 'cumprimentar' }), GameError);
});

test('conversa: apresentar o partido exige partido; proposta exige um tema', () => {
  const s = newCareer();
  const c = cityCitizen(s);
  assert.throws(() => performAction(s, 'conversar', { citizenId: c.id, topic: 'partido' }), GameError);
  assert.throws(() => performAction(s, 'conversar', { citizenId: c.id, topic: 'proposta' }), GameError);
});

test('conversa: texto da IA/local é guardado, mas nunca altera o apoio por si só', () => {
  const s = newCareer({ seed: 0.5 });
  const c = cityCitizen(s);
  const next = performAction(s, 'conversar', { citizenId: c.id, topic: 'cumprimentar', reply: 'Bom dia, candidata!' });
  assert.equal(next.conversations.at(-1).reply, 'Bom dia, candidata!');
  assert.ok(next.support - s.support === 0 || (next.support - s.support >= 25 && next.support - s.support <= 30));
});

// ---------------- Atividades, fama e região ----------------
test('fama: níveis de reconhecimento seguem os limites do briefing', () => {
  assert.equal(fameLevel(0), 'Desconhecido');
  assert.equal(fameLevel(10), 'Conhecido localmente');
  assert.equal(fameLevel(25), 'Conhecido regionalmente');
  assert.equal(fameLevel(45), 'Conhecido nacionalmente');
  assert.equal(fameLevel(65), 'Muito famoso');
  assert.equal(fameLevel(90), 'Figura pública de grande reconhecimento');
});

test('atividades: entrevista aumenta a fama e o apoio; limite de três por dia', () => {
  let s = newCareer({ campaignFund: 10000 });
  const fame = s.fame;
  s = performAction(s, 'atividade', { kind: 'entrevista' });
  assert.ok(s.fame > fame);
  assert.ok(s.support > 0);
  s = performAction(s, 'atividade', { kind: 'entrevista' });
  s = performAction(s, 'atividade', { kind: 'entrevista' });
  assert.throws(() => performAction(s, 'atividade', { kind: 'entrevista' }), GameError);
});

test('atividades: debate só existe na janela eleitoral', () => {
  const s = newCareer();
  assert.throws(() => performAction(s, 'atividade', { kind: 'debate' }), GameError);
});

test('atividades: divulgar projeto exige cargo público', () => {
  const s = newCareer();
  assert.throws(() => performAction(s, 'atividade', { kind: 'divulgarProjeto' }), GameError);
});

test('mudança de região: não é possível mudar para a região em que já está', () => {
  const s = newCareer();
  assert.throws(() => performAction(s, 'mudarRegiao', { regionId: 'centro' }), GameError);
  assert.throws(() => performAction(s, 'mudarRegiao', { regionId: 'inexistente' }), GameError);
});

test('receptividade: diminui à medida que a região é alcançada', () => {
  const s = newCareer();
  const before = receptivity(s, 'centro');
  const next = structuredClone(s);
  consumeReach(next, 'centro', 50000);
  assert.ok(receptivity(next, 'centro') < before);
});

// ---------------- Inventário, dinheiro e salvamento ----------------
test('inventário: uso e descarte parcial de santinhos', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 40 });
  const id = s.inventory[0].id;
  s = performAction(s, 'descartarItem', { itemId: id, quantity: 15 });
  assert.equal(s.inventory.find((i) => i.id === id).quantity, 25);
});

test('dinheiro: resumo separa pessoal, campanha, partido e públicos', () => {
  const s = newCareer({ money: 5000, campaignFund: 300 });
  const summary = careerSummary(s);
  assert.equal(summary.campaign.dinheiroPessoal, 5000);
  assert.equal(summary.campaign.dinheiroCampanha, 300);
  assert.equal(summary.campaign.dinheiroPartido, 0);
});

test('extrato: gastos de campanha são agrupados por categoria', () => {
  let s = newCareer({ campaignFund: 1000 });
  s = performAction(s, 'fabricarSantinhos', { quantity: 20 });
  const cats = careerSummary(s).campaign.gastosPorCategoria;
  assert.equal(cats.fabricacao, SANTINHO.fabricacao);
  assert.equal(cats.impressao, SANTINHO.impressaoPorLote);
});

test('salvamento: campos da Parte 3 sobrevivem ao salvar e carregar, com validação', () => {
  let s = withPhone(newCareer({ money: 5000, campaignFund: 20000 }));
  s = performAction(s, 'fabricarSantinhos', { quantity: 40 });
  s = advance(s, 5);
  const saved = JSON.parse(JSON.stringify(pickCareer(s)));
  assert.deepEqual(validateCareerState(saved), []);
  const a = advance(s, 20);
  const b = advance(saved, 20);
  assert.equal(a.support, b.support);
  assert.equal(a.campaignFund, b.campaignFund);
  assert.deepEqual(a.stats, b.stats);
});

test('equilíbrio: 200 dias de ações aleatórias nunca geram saldo negativo nem apoio fracionado', () => {
  let s = withPhone(newCareer({ money: 50000, campaignFund: 200000, seed: 0.77 }));
  const actions = [
    ['fabricarSantinhos', { quantity: 100 }],
    ['fabricarBanner', { material: 'simples', size: 'pequeno' }],
    ['fabricarPlaca', { size: 'pequena' }],
    ['campanhaDigital', { budget: 500, days: 7 }],
    ['atividade', { kind: 'evento' }],
  ];
  for (let i = 0; i < 200; i += 1) {
    const [name, payload] = actions[i % actions.length];
    try { s = performAction(s, name, payload); } catch { /* recusas são esperadas (sem saldo, limite) */ }
    s = advance(s, 1);
    assert.ok(s.money >= 0 && s.campaignFund >= 0, 'saldo negativo');
    assert.ok(Number.isInteger(s.support) && s.support >= 0, 'apoio inválido');
  }
});
