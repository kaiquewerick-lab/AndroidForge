// Autenticação com Firebase: o navegador faz login no Firebase e envia o ID token em
// "Authorization: Bearer". O servidor verifica o token e liga o uid a um perfil de jogador
// (nome de usuário, configurações). Não há senhas nem cookies de sessão neste servidor.
import { db, save } from './db.js';
import { verifyIdToken, FirebaseAuthError } from './firebase.js';

const USERNAME_RE = /^[A-Za-z0-9_.-]{3,24}$/;

// Verificador injetável: nos testes substituímos por um que não usa a rede.
let verifier = (token) => verifyIdToken(token);
export function setVerifier(fn) {
  verifier = fn;
}

export function validateUsername(value) {
  if (typeof value !== 'string' || !USERNAME_RE.test(value.trim())) {
    return 'Use de 3 a 24 caracteres: letras, números, ponto, traço ou underline.';
  }
  return null;
}

export const findUserByUsername = (name) =>
  db().users.find((u) => u.username.toLowerCase() === String(name).trim().toLowerCase());

export const findUserByUid = (uid) => db().users.find((u) => u.uid === uid) || null;

export function bearerToken(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7).trim() : null;
}

// Retorna { claims, user } . user é null se o perfil ainda não foi criado.
export async function identify(req) {
  const token = bearerToken(req);
  if (!token) return null;
  const claims = await verifier(token);
  return { claims, user: findUserByUid(claims.uid) };
}

export function createProfile(claims, username) {
  const user = {
    id: claims.uid,
    uid: claims.uid,
    username: username.trim(),
    email: claims.email,
    provider: claims.provider === 'google.com' ? 'google' : 'e-mail',
    createdAt: new Date().toISOString(),
    settings: null,
  };
  db().users.push(user);
  save();
  return user;
}

export function publicUser(u) {
  return { id: u.uid, username: u.username, email: u.email, provider: u.provider, createdAt: u.createdAt };
}

// Limitação simples de tentativas por chave (ex.: IP + ação).
const attempts = new Map();
export function rateLimited(key, max = 30, windowMs = 15 * 60e3) {
  const now = Date.now();
  const rec = attempts.get(key);
  if (!rec || rec.reset < now) {
    attempts.set(key, { count: 1, reset: now + windowMs });
    return false;
  }
  rec.count += 1;
  return rec.count > max;
}

export { FirebaseAuthError };
