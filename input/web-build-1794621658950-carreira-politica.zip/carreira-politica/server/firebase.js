// Verificação de ID tokens do Firebase Authentication no servidor, sem dependências externas.
// Um ID token é um JWT assinado com RS256 pelo Google. Verificamos: assinatura (certificados
// públicos do securetoken), algoritmo, emissor, audiência (projectId), expiração e o campo "sub".
import crypto from 'node:crypto';

export const FIREBASE_PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'politica-fb74a';
export const CERTS_URL =
  'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
const CLOCK_SKEW_S = 300;

export class FirebaseAuthError extends Error {}

const b64urlToBuffer = (s) => Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');

function decodePart(part) {
  try {
    return JSON.parse(b64urlToBuffer(part).toString('utf8'));
  } catch {
    throw new FirebaseAuthError('Token malformado.');
  }
}

function publicKeyFrom(pem) {
  if (pem.includes('BEGIN CERTIFICATE')) return new crypto.X509Certificate(pem).publicKey;
  return crypto.createPublicKey(pem);
}

// Verifica o token contra um conjunto de certificados {kid: pem}. Função pura: usada nos testes.
export function verifyIdTokenWith(token, certs, projectId = FIREBASE_PROJECT_ID, nowMs = Date.now()) {
  if (typeof token !== 'string') throw new FirebaseAuthError('Token ausente.');
  const parts = token.split('.');
  if (parts.length !== 3) throw new FirebaseAuthError('Token malformado.');
  const [h64, p64, s64] = parts;
  const header = decodePart(h64);
  if (header.alg !== 'RS256' || !header.kid) throw new FirebaseAuthError('Algoritmo de token não aceito.');
  const pem = certs[header.kid];
  if (!pem) throw new FirebaseAuthError('Chave de assinatura desconhecida.');

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(`${h64}.${p64}`);
  verifier.end();
  if (!verifier.verify(publicKeyFrom(pem), b64urlToBuffer(s64))) {
    throw new FirebaseAuthError('Assinatura inválida.');
  }

  const payload = decodePart(p64);
  const nowS = Math.floor(nowMs / 1000);
  if (payload.aud !== projectId) throw new FirebaseAuthError('Token de outro projeto.');
  if (payload.iss !== `https://securetoken.google.com/${projectId}`) throw new FirebaseAuthError('Emissor inválido.');
  if (typeof payload.exp !== 'number' || payload.exp <= nowS) throw new FirebaseAuthError('Sessão expirada. Entre novamente.');
  if (typeof payload.iat !== 'number' || payload.iat > nowS + CLOCK_SKEW_S) throw new FirebaseAuthError('Token com data futura.');
  if (typeof payload.sub !== 'string' || !payload.sub || payload.sub.length > 128) {
    throw new FirebaseAuthError('Usuário inválido no token.');
  }
  return {
    uid: payload.sub,
    email: typeof payload.email === 'string' ? payload.email.toLowerCase() : null,
    emailVerified: payload.email_verified === true,
    provider: payload.firebase?.sign_in_provider || 'desconhecido',
  };
}

// Cache de certificados públicos (respeita o max-age devolvido pelo Google).
let cache = { certs: null, expiresAt: 0 };

export async function fetchCerts(fetchImpl = fetch) {
  if (cache.certs && cache.expiresAt > Date.now()) return cache.certs;
  const res = await fetchImpl(CERTS_URL, { signal: AbortSignal.timeout(8000) });
  if (!res.ok) throw new FirebaseAuthError('Não foi possível obter as chaves do Firebase.');
  const certs = await res.json();
  const m = /max-age=(\d+)/.exec(res.headers?.get?.('cache-control') || '');
  cache = { certs, expiresAt: Date.now() + (m ? Number(m[1]) : 3600) * 1000 };
  return certs;
}

export async function verifyIdToken(token, projectId = FIREBASE_PROJECT_ID) {
  const certs = await fetchCerts();
  return verifyIdTokenWith(token, certs, projectId);
}
