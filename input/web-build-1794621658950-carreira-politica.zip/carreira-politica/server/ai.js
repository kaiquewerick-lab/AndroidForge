// Camada opcional de IA. A chave fica SOMENTE no servidor (variável ANTHROPIC_API_KEY).
// A IA só gera texto narrativo e uma opinião de consistência. Ela NÃO altera dinheiro,
// atributos, datas ou qualquer dado numérico: esses são calculados pelo sistema.
// Se a chave não existir, a API falhar ou a resposta for inválida, o sistema usa a contingência local.

const MODEL = process.env.ANTHROPIC_MODEL || 'claude-haiku-5-5';

export const aiConfigured = () => Boolean(process.env.ANTHROPIC_API_KEY);

function extractJson(text) {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('sem JSON');
  return JSON.parse(text.slice(start, end + 1));
}

const clean = (s) => s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim();

export async function reviewCareerStart({ character, partyName, city, uf }) {
  if (!aiConfigured()) return { used: false, reason: 'sem-chave' };
  const summary = {
    nome: `${character.firstName} ${character.lastName}`,
    idade: character.age,
    origem: `${city}, ${uf}`,
    partido: partyName || 'nenhum (independente)',
  };
  const prompt =
    'Você é o narrador de um jogo de simulação de carreira política brasileira. ' +
    'Com base nestes dados do personagem (não invente números, dinheiro ou estatísticas): ' +
    JSON.stringify(summary) +
    '. Responda APENAS com um JSON no formato {"intro": "...", "consistent": true|false}, ' +
    'onde "intro" é um parágrafo curto (até 3 frases) em português do Brasil, e "consistent" indica se os dados parecem coerentes.';
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 300, messages: [{ role: 'user', content: prompt }] }),
      signal: AbortSignal.timeout(12000),
    });
    if (!res.ok) return { used: false, reason: `http-${res.status}` };
    const data = await res.json();
    const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    const parsed = extractJson(text);
    if (typeof parsed.intro !== 'string' || parsed.intro.trim().length < 20) throw new Error('intro inválida');
    return { used: true, intro: clean(parsed.intro).slice(0, 600), consistent: parsed.consistent === true };
  } catch {
    return { used: false, reason: 'indisponivel' };
  }
}

// ---------------- Fala dos cidadãos (Parte 3) ----------------
// A reação (positiva, neutra ou negativa) já foi decidida pelo motor. A IA só escreve a fala,
// que é guardada como texto. Ela nunca altera apoio, dinheiro ou chance de conversa.
const CITIZEN_LABELS = {
  trabalhador: 'trabalhador(a)', estudante: 'estudante', comerciante: 'comerciante', professor: 'professor(a)',
  agricultor: 'agricultor(a)', aposentado: 'aposentado(a)', empresario: 'empresário(a)', morador: 'morador(a)',
};

const LOCAL_REPLIES = {
  positiva: [
    (who, city) => `Gostei da conversa. Pode contar com meu apoio: ${city} precisa de quem ouça a gente.`,
    (who) => `Você falou do que me preocupa, como ${who}. Vou comentar com a vizinhança.`,
    () => 'Obrigado por me ouvir com atenção. Acho que vale a pena acompanhar essa proposta.',
  ],
  neutra: [
    () => 'Entendi o que você disse. Preciso pensar com calma antes de decidir.',
    () => 'Pode ser. Ainda quero ver mais detalhes do que você pretende fazer.',
  ],
  negativa: [
    () => 'Não me convenceu. Já ouvi muitas promessas por aqui.',
    () => 'Com todo respeito, não vejo solução concreta no que você falou.',
  ],
};

// Contingência local: texto fixo escolhido de forma determinística (sem IA).
export function localCitizenReply({ citizen, reaction, city }) {
  const list = LOCAL_REPLIES[reaction] || LOCAL_REPLIES.neutra;
  const seed = String(citizen?.id || '').length + (citizen?.type || '').length;
  const label = CITIZEN_LABELS[citizen?.type] || 'morador(a)';
  return clean(list[seed % list.length](label, city || 'a cidade')).slice(0, 300);
}

export async function citizenReply({ citizen, topic, reaction, playerText, city }) {
  const local = localCitizenReply({ citizen, reaction, city });
  if (!aiConfigured()) return local;
  const prompt =
    'Você escreve a fala curta (uma ou duas frases, em português do Brasil) de um(a) cidadão(ã) fictício(a) ' +
    'em um jogo de política. Não cite números, dinheiro, apoio nem pontos. ' +
    `Tipo de pessoa: ${CITIZEN_LABELS[citizen?.type] || 'morador(a)'}. Cidade fictícia: ${city}. ` +
    `Tema da conversa: ${topic}. Reação decidida pelo jogo: ${reaction}. ` +
    (playerText ? `O candidato disse: "${clean(playerText).slice(0, 300)}". ` : '') +
    'Responda APENAS com um JSON no formato {"fala": "..."}.';
  try {
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({ model: MODEL, max_tokens: 160, messages: [{ role: 'user', content: prompt }] }),
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return local;
    const data = await res.json();
    const text = (data.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    const parsed = extractJson(text);
    if (typeof parsed.fala !== 'string' || parsed.fala.trim().length < 5) return local;
    return clean(parsed.fala).slice(0, 300);
  } catch {
    return local;
  }
}
