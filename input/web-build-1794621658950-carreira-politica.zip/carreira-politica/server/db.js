// Banco de dados em arquivo JSON com escrita atômica e backup.
// Se o arquivo principal estiver corrompido, o sistema restaura o backup automaticamente.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT, 'data');
const FILE = path.join(DATA_DIR, 'db.json');
const BACKUP = path.join(DATA_DIR, 'db.backup.json');

let state = null;
let loadedFromMain = false;

function emptyDb() {
  return { version: 1, users: [], sessions: [], resets: [], parties: [], careers: [] };
}

function readJson(file) {
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  const ok = data && typeof data === 'object' && Array.isArray(data.users) && Array.isArray(data.careers);
  if (!ok) throw new Error('estrutura inválida');
  return data;
}

export function db() {
  if (state) return state;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  for (const [file, isMain] of [[FILE, true], [BACKUP, false]]) {
    if (!fs.existsSync(file)) continue;
    try {
      state = readJson(file);
      loadedFromMain = isMain;
      if (!isMain) console.warn('[db] arquivo principal inválido: dados recuperados do backup.');
      return state;
    } catch (err) {
      console.error(`[db] não foi possível ler ${path.basename(file)}: ${err.message}`);
    }
  }
  state = emptyDb();
  loadedFromMain = true;
  return state;
}

export function save() {
  const current = db();
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(current, null, 2), 'utf8');
  // Só copia para o backup se o arquivo principal atual for íntegro.
  if (loadedFromMain && fs.existsSync(FILE)) fs.copyFileSync(FILE, BACKUP);
  fs.renameSync(tmp, FILE);
  loadedFromMain = true;
}

export const DATA_PATH = DATA_DIR;
