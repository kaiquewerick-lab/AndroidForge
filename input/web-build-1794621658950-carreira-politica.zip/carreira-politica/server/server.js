// Servidor HTTP da Carreira Política (sem dependências externas).
// Responsável por: perfis (login via Firebase), configurações, partidos, partidas e arquivos do jogo.
// O servidor é a autoridade: toda ação e todo avanço de tempo passam pelo motor em politics.js.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { db, save, DATA_PATH } from './db.js';
import * as auth from './auth.js';
import { FirebaseAuthError, FIREBASE_PROJECT_ID } from './firebase.js';
import { reviewCareerStart, aiConfigured, citizenReply } from './ai.js';
import {
  validateCharacter, pickCharacter, validateParty, pickParty, validateSettings, pickSettings,
  SETTINGS_DEFAULTS, validateCareerState, pickCareer,
} from '../public/js/core/validate.js';
import { VERSION } from '../public/js/core/version.js';
import { initialCareer, localIntro } from '../public/js/game/careerRules.js';
import {
  advance, performAction, careerSummary, GameError, PERSONAL_ACTIONS,
} from '../public/js/game/politics.js';
import { EXISTING_PARTIES } from '../public/js/game/offices.js';
import { CAMPAIGN_ACTION_NAMES } from '../public/js/game/campaign.js';
import { PRESIDENCY_ACTION_NAMES } from '../public/js/game/presidency.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT) || 3000;

// Ações aceitas pela API. Qualquer outra é recusada antes de chegar ao motor.
const GAME_ACTIONS = [
  ...Object.keys(PERSONAL_ACTIONS),
  'avancarDia', 'registrarCandidatura', 'retirarCandidatura', 'contribuir', 'campanha',
  'trocarPartido', 'renunciar', 'encerrarCarreira', 'votar', 'proporEmenda',
  'iniciarProjeto', 'cancelarProjeto', 'decidirEvento',
  ...CAMPAIGN_ACTION_NAMES, ...PRESIDENCY_ACTION_NAMES,
];

// Domínios do Firebase necessários para login (script, API de autenticação e pop-up).
const FIREBASE_HOSTS = {
  script: 'https://www.gstatic.com',
  connect: 'https://identitytoolkit.googleapis.com https://securetoken.googleapis.com https://www.googleapis.com',
  frame: `https://${FIREBASE_PROJECT_ID}.firebaseapp.com https://accounts.google.com`,
};

const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'same-origin',
  'X-Frame-Options': 'DENY',
  'Content-Security-Policy':
    "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; " +
    `script-src 'self' ${FIREBASE_HOSTS.script}; connect-src 'self' ${FIREBASE_HOSTS.connect}; ` +
    `frame-src ${FIREBASE_HOSTS.frame}; object-src 'none'; base-uri 'none'; frame-ancestors 'none'`,
};

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
};

class HttpError extends Error {
  constructor(status, message, extra = {}) {
    super(message);
    this.status = status;
    this.extra = extra;
  }
}

const now = () => new Date().toISOString();
const newId = () => crypto.randomUUID();
const cryptoRng = () => crypto.randomInt(0, 1e9) / 1e9;

function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...SECURITY_HEADERS, ...headers });
  res.end(body);
}

function json(res, status, obj, headers = {}) {
  send(res, status, JSON.stringify(obj), { 'Content-Type': MIME['.json'], 'Cache-Control': 'no-store', ...headers });
}

function readBody(req, limit = 2_500_000) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let aborted = false;
    req.on('data', (chunk) => {
      if (aborted) return;
      size += chunk.length;
      if (size > limit) {
        aborted = true;
        reject(new HttpError(413, 'Requisição muito grande.'));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (aborted) return;
      if (!chunks.length) return resolve({});
      const type = req.headers['content-type'] || '';
      if (!type.includes('application/json')) return reject(new HttpError(415, 'Envie os dados em JSON.'));
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(new HttpError(400, 'Dados JSON inválidos.'));
      }
    });
    req.on('error', reject);
  });
}

// Usuário autenticado com perfil completo. Sem token: 401. Token sem perfil: 403 com needsProfile.
async function requireUser(req) {
  const found = await auth.identify(req);
  if (!found) throw new HttpError(401, 'Faça login para continuar.');
  if (!found.user) throw new HttpError(403, 'Escolha seu nome de usuário para continuar.', { needsProfile: true });
  return found.user;
}

const ownParty = (user, id) => db().parties.find((p) => p.id === id && p.ownerId === user.id);
const ownCareer = (user, id) => db().careers.find((c) => c.id === id && c.userId === user.id);

function latestCareer(userId) {
  return db().careers
    .filter((c) => c.userId === userId)
    .sort((a, b) => (a.updatedAt < b.updatedAt ? 1 : -1))[0] || null;
}

function publicCareer(c) {
  const { userId, ...rest } = c;
  return { ...rest, summary: careerSummary(c) };
}

function publicParty(p) {
  const { ownerId, ...rest } = p;
  return rest;
}

// Referência de partido usada pelo motor: partido fictício existente ou partido do próprio jogador.
function partyRefFor(user, id) {
  const ext = EXISTING_PARTIES.find((p) => p.id === id);
  if (ext) return { id: ext.id, name: ext.name, acronym: ext.acronym, number: ext.number };
  const own = ownParty(user, id);
  if (own) return { id: own.id, name: own.name, acronym: own.acronym, number: own.number };
  return null;
}

// Grava o estado do motor depois de validá-lo. Nada é salvo se a validação falhar.
// Fala do cidadão: escrita depois que o motor decide a reação. A IA só produz texto.
async function attachCitizenReply(state, payload) {
  const last = state.conversations.at(-1);
  if (!last) return;
  const citizen = state.citizens.find((c) => c.id === payload.citizenId);
  last.reply = await citizenReply({
    citizen, topic: last.topic, reaction: last.reaction, city: state.location.city,
    playerText: typeof payload.text === 'string' ? payload.text.slice(0, 300) : '',
  });
}

function commitCareer(res, career, next) {
  const errors = validateCareerState(next);
  if (errors.length) throw new HttpError(500, 'A partida não pôde ser salva com segurança.');
  Object.assign(career, pickCareer(next), { updatedAt: now() });
  save();
  return json(res, 200, { career: publicCareer(career) });
}

// ---------------- Rotas da API ----------------
async function handleApi(req, res, url) {
  const p = url.pathname;
  const m = req.method;
  const ip = req.socket.remoteAddress || 'desconhecido';

  if (m === 'GET' && p === '/api/health') {
    return json(res, 200, { ok: true, version: VERSION, ai: aiConfigured(), firebaseProject: FIREBASE_PROJECT_ID });
  }

  // ----- Perfil (login feito no Firebase, no navegador) -----
  if (m === 'GET' && p === '/api/auth/me') {
    const found = await auth.identify(req);
    if (!found) return json(res, 200, { user: null });
    if (!found.user) return json(res, 200, { user: null, needsProfile: true, email: found.claims.email });
    return json(res, 200, { user: auth.publicUser(found.user), settings: pickSettings(found.user.settings) });
  }

  if (m === 'POST' && p === '/api/auth/profile') {
    if (auth.rateLimited(`profile:${ip}`, 30)) throw new HttpError(429, 'Muitas tentativas. Aguarde alguns minutos.');
    const found = await auth.identify(req);
    if (!found) throw new HttpError(401, 'Faça login para continuar.');
    if (found.user) throw new HttpError(409, 'Esta conta já tem um nome de usuário.');
    const body = await readBody(req);
    const error = auth.validateUsername(body.username);
    if (error) throw new HttpError(400, error, { fields: { username: error } });
    if (auth.findUserByUsername(body.username)) {
      const msg = 'Este nome de usuário já está em uso.';
      throw new HttpError(400, msg, { fields: { username: msg } });
    }
    const user = auth.createProfile(found.claims, body.username);
    return json(res, 201, { user: auth.publicUser(user), settings: pickSettings(user.settings) });
  }

  // ----- Configurações -----
  if (p === '/api/settings') {
    const user = await requireUser(req);
    if (m === 'GET') return json(res, 200, { settings: pickSettings(user.settings) });
    if (m === 'PUT') {
      const body = await readBody(req);
      const errors = validateSettings({ ...SETTINGS_DEFAULTS, ...body });
      if (errors.length) throw new HttpError(400, errors[0]);
      user.settings = pickSettings(body);
      save();
      return json(res, 200, { settings: user.settings });
    }
  }

  // ----- Partidos -----
  if (p === '/api/parties') {
    const user = await requireUser(req);
    if (m === 'GET') {
      return json(res, 200, { parties: db().parties.filter((x) => x.ownerId === user.id).map(publicParty) });
    }
    if (m === 'POST') {
      const body = await readBody(req);
      const errors = validateParty(body.party);
      if (errors.length) throw new HttpError(400, errors[0], { errors });
      const party = {
        id: newId(),
        ownerId: user.id,
        ...pickParty(body.party),
        members: 1,
        popularity: 0,
        createdAt: now(),
        updatedAt: now(),
      };
      db().parties.push(party);
      save();
      return json(res, 201, { party: publicParty(party) });
    }
  }

  const partyMatch = p.match(/^\/api\/parties\/([0-9a-f-]{36})$/);
  if (partyMatch && m === 'PUT') {
    const user = await requireUser(req);
    const party = ownParty(user, partyMatch[1]);
    if (!party) throw new HttpError(404, 'Partido não encontrado.');
    const body = await readBody(req);
    const errors = validateParty(body.party);
    if (errors.length) throw new HttpError(400, errors[0], { errors });
    // Apenas campos editáveis pelo jogador são alterados; os campos de jogo permanecem.
    Object.assign(party, pickParty(body.party), { updatedAt: now() });
    save();
    return json(res, 200, { party: publicParty(party) });
  }

  // ----- Partidas (carreira) -----
  if (m === 'GET' && p === '/api/career/latest') {
    const user = await requireUser(req);
    const career = latestCareer(user.id);
    return json(res, 200, { career: career ? publicCareer(career) : null });
  }

  if (m === 'POST' && p === '/api/career/prepare') {
    const user = await requireUser(req);
    const body = await readBody(req);
    const errors = validateCharacter(body.character);
    if (errors.length) throw new HttpError(400, errors[0], { errors });
    let party = null;
    if (body.partyId) {
      party = partyRefFor(user, body.partyId);
      if (!party) throw new HttpError(400, 'Partido selecionado não encontrado.');
    }
    const character = pickCharacter(body.character);
    const location = { state: character.birthState, city: character.birthCity };
    const state = initialCareer({ character, party, location }, cryptoRng);
    const stateErrors = validateCareerState(state);
    if (stateErrors.length) throw new HttpError(500, 'Não foi possível validar a partida. Tente novamente.');

    // A IA apenas gera texto; se falhar, a contingência local é usada.
    const ai = await reviewCareerStart({
      character,
      partyName: party ? party.name : null,
      city: location.city,
      uf: location.state,
    });
    const intro = ai.used ? ai.intro : localIntro(character, party, location);

    const career = {
      id: newId(),
      userId: user.id,
      ...pickCareer(state),
      narrative: { intro, source: ai.used ? 'ia' : 'local', consistent: ai.used ? ai.consistent : null },
      createdAt: now(),
      updatedAt: now(),
    };
    db().careers.push(career);
    save();
    return json(res, 201, {
      career: publicCareer(career),
      ai: { used: ai.used, reason: ai.used ? null : ai.reason },
    });
  }

  if (m === 'POST' && p === '/api/career/import') {
    // Recuperação: restaura uma partida salva localmente quando o servidor não tem nenhuma.
    const user = await requireUser(req);
    const body = await readBody(req);
    if (latestCareer(user.id)) throw new HttpError(409, 'Já existe uma partida salva nesta conta.');
    const errors = validateCareerState(body.state);
    if (errors.length) throw new HttpError(400, 'A cópia local da partida é inválida.', { errors });
    const career = {
      id: newId(),
      userId: user.id,
      ...pickCareer(body.state),
      narrative: { intro: localIntro(pickCharacter(body.state.character), null, body.state.location), source: 'local', consistent: null },
      createdAt: now(),
      updatedAt: now(),
    };
    db().careers.push(career);
    save();
    return json(res, 201, { career: publicCareer(career) });
  }

  // Ação do jogador (personagem, eleição, cargo, votação, projetos, eventos).
  const actionMatch = p.match(/^\/api\/career\/([0-9a-f-]{36})\/action$/);
  if (actionMatch && m === 'POST') {
    const user = await requireUser(req);
    const career = ownCareer(user, actionMatch[1]);
    if (!career) throw new HttpError(404, 'Partida não encontrada.');
    const body = await readBody(req);
    if (!GAME_ACTIONS.includes(body.action)) throw new HttpError(400, 'Ação inválida.');
    const payload = body.payload && typeof body.payload === 'object' && !Array.isArray(body.payload) ? { ...body.payload } : {};
    // O partido é sempre resolvido pelo servidor, nunca enviado pelo navegador.
    delete payload.party;
    if (body.action === 'trocarPartido') {
      payload.party = partyRefFor(user, payload.partyId);
      if (!payload.party) throw new HttpError(400, 'Partido não encontrado.');
    }
    const next = performAction(career, body.action, payload);
    if (body.action === 'conversar') await attachCitizenReply(next, payload);
    return commitCareer(res, career, next);
  }

  // Avanço do tempo (o navegador controla a velocidade e chama este endpoint em lotes).
  const timeMatch = p.match(/^\/api\/career\/([0-9a-f-]{36})\/time$/);
  if (timeMatch && m === 'POST') {
    const user = await requireUser(req);
    const career = ownCareer(user, timeMatch[1]);
    if (!career) throw new HttpError(404, 'Partida não encontrada.');
    const body = await readBody(req);
    if (!Number.isInteger(body.days)) throw new HttpError(400, 'Informe a quantidade de dias.');
    const next = advance(career, body.days);
    return commitCareer(res, career, next);
  }

  throw new HttpError(404, 'Rota não encontrada.');
}

// ---------------- Arquivos estáticos ----------------
function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Método não permitido.');
  let rel = decodeURIComponent(url.pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, rel));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) return send(res, 403, 'Acesso negado.');
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) return send(res, 404, 'Não encontrado.', { 'Content-Type': 'text/plain; charset=utf-8' });
    const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    const cache = file.endsWith('.html') ? 'no-cache' : 'public, max-age=3600';
    res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': type, 'Cache-Control': cache, 'Content-Length': stat.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

// ---------------- Servidor ----------------
export function createServer() {
  return http.createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      if (url.pathname.startsWith('/api/')) return await handleApi(req, res, url);
      return serveStatic(req, res, url);
    } catch (err) {
      if (err instanceof HttpError) return json(res, err.status, { error: err.message, ...err.extra });
      if (err instanceof GameError) return json(res, 400, { error: err.message });
      if (err instanceof FirebaseAuthError) return json(res, 401, { error: err.message });
      console.error('[erro]', err);
      return json(res, 500, { error: 'Erro interno do servidor.' });
    }
  });
}

// Inicia somente quando executado diretamente (permite importar nos testes).
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  db(); // carrega ou recupera o banco antes de aceitar conexões
  const BASE_URL = (process.env.PUBLIC_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
  createServer().listen(PORT, () => {
    console.log(`Carreira Política v${VERSION} em ${BASE_URL}`);
    console.log(`Dados em: ${DATA_PATH}`);
    console.log(`Firebase: projeto ${FIREBASE_PROJECT_ID} | IA: ${aiConfigured() ? 'configurada' : 'não configurada (contingência local)'}`);
  });
}
