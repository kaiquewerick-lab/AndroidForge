# Carreira Política — SaturnGames (Partes 1 a 4)

Simulação de carreira política 2D, em português. Cobre:

- **Parte 1:** abertura SaturnGames, carregamento, contas (Firebase), tela inicial, partidos, loja, configurações, criador de personagem, preparação da carreira e salvamento.
- **Parte 2:** carreira pública municipal, estadual e federal: requisitos, cargos, eleições, mandatos, salários, contas de dinheiro separadas, aprovação, votações em sessões legislativas, projetos, eventos e partidos.
- **Parte 3:** apoio popular, santinhos, banners, placas, campanhas digitais, loja de celulares, fama, dinheiro de campanha, inventário, mapa com conversas e MINHA CAMPANHA.
- **Parte 4:** candidatura à Presidência, adversários, debates, pesquisas, eleição em dois turnos, posse, governo federal (ministérios, programas, indicadores nacionais, decisões), Congresso (sanção e veto; o presidente não vota) e aprovação do governo.

## Como executar

Requer Node.js 20 ou superior. Não há dependências externas para instalar.

```bash
npm start            # http://localhost:3000
npm test             # 130 testes (API, Parte 2, Parte 3 e Parte 4)
```

### Variáveis de ambiente (todas opcionais)

| Variável | Para que serve |
| --- | --- |
| `PORT` | Porta do servidor (padrão 3000). |
| `DATA_DIR` | Pasta do banco JSON (padrão `data/`). Os testes usam uma pasta temporária. |
| `ANTHROPIC_API_KEY` | Ativa a IA apenas para textos (respostas de eleitores). Sem chave, há respostas locais. |
| `ANTHROPIC_MODEL` | Modelo usado para os textos da IA. |
| `FIREBASE_PROJECT_ID` | Projeto Firebase que emite os tokens (padrão `politica-fb74a`). |
| `PUBLIC_URL` | Endereço público usado em links gerados pelo servidor. |

## Login com Firebase

O cliente usa o SDK oficial do Firebase Authentication (versão 10.12.5, pelo CDN do Google). A configuração pública fica em `public/js/core/firebase-config.js`. Essa configuração não é segredo: ela identifica o projeto.

No console do Firebase (projeto `politica-fb74a`):

1. **Authentication → Sign-in method:** ative **E-mail/senha** e **Google**.
2. **Authentication → Settings → Authorized domains:** inclua `localhost` e o domínio onde o jogo for publicado.
3. Sem nenhuma outra configuração de segurança: o projeto é de uso pessoal, conforme combinado.

Fluxo: entrar ou criar conta no Firebase → o servidor verifica o token (RS256, emissor e audiência do projeto) → no primeiro acesso, escolha um nome de usuário → o perfil e as partidas ficam guardados no servidor. Recuperação de senha usa o e-mail do Firebase.

## Estrutura

```
public/
  index.html, css/main.css, css/politics.css
  js/
    main.js                 registro das telas
    core/                   API, Firebase, estado, relógio do jogo, validação, versão
    game/                   motor das regras (roda no servidor e no cliente para leitura)
      careerRules.js        início da carreira
      politics.js           Parte 2: cargos, eleições, mandatos, votações, projetos
      campaign.js           Parte 3: campanha, materiais, celulares, mapa, conversas
      presidency.js         Parte 4: Presidência, debates, governo, Congresso
      *Data.js, offices.js  constantes e tabelas de balanceamento
      ledger.js             contas separadas (pessoal, campanha, partido, orçamentos públicos)
    ui/
      router.js, game.js, charts.js
      screens/              uma tela por arquivo (mandato, campanha, mapa, fabrica,
                            inventario, store, presidencia, concorrer, career, auth...)
server/
  server.js                 HTTP, rotas, autenticação, validação de ações
  firebase.js               verificação dos tokens do Firebase
  ai.js                     textos da IA (com contingência local)
  db.js                     banco em arquivo JSON
tests/                      node:test
```

## Como o jogo é decidido

- **O servidor decide tudo que tem número.** Cada ação passa por `performAction` ou `advance` no servidor, é validada e só então salva. O cliente apenas mostra o estado.
- **A IA só escreve texto.** Ela responde eleitores quando há chave configurada. Ela nunca decide dinheiro, apoio, votos, resultados de debate ou eleição.
- **Adversários e avaliação de debates são lógica determinística do sistema.** Os critérios (clareza, coerência, resposta, propostas, argumentação, consistência, problemas e viabilidade) são os mesmos para todos os candidatos. Não há avaliação por IA.
- **Eventos são sorteados pelo sistema** com gerador determinístico por partida, e cada opção tem efeitos visíveis antes da escolha.
- **Dinheiro:** cinco contas separadas (pessoal, campanha, partido e um orçamento por esfera). Nenhuma conta fica negativa. Dinheiro público não pode financiar campanha pessoal.
- **Salvamento:** a partida inteira é salva no servidor a cada ação; há cópia de segurança local e exportação/importação.

### Onde ajustar o balanceamento

- `public/js/game/campaignData.js`: santinhos, banners, placas, celulares, campanhas digitais, atividades, conversas, fama.
- `public/js/game/presidencyData.js`: requisitos da Presidência, adversários, debates, pesquisas, ministérios, programas, eventos, Congresso e negociação.
- `public/js/game/offices.js`: cargos, requisitos, projetos municipais/estaduais/federais, eventos gerais.
- `public/js/game/careerRules.js`: dinheiro inicial e orçamentos públicos iniciais.

## Desvios em relação ao briefing

- Velocidade da fama de campanha: 10 apoios por ponto de fama são convertidos para **por hora de jogo** (24 horas por dia), para que o ritmo seja estável.
- Celulares são fictícios. A eficiência é independente do preço: aparelho barato pode ser eficiente e vice-versa.
- Adversários e avaliações de debate são lógica determinística (não IA). A IA é usada apenas para textos de eleitores.
- Quando o partido do jogador não tem ideologia definida no cadastro, a chance de simpatia usa um valor neutro (50/50).
- Campanha por região usa os estados como áreas na Presidência.

## Limitações conhecidas

- **Login com Firebase não foi verificado de ponta a ponta:** não houve acesso ao console do projeto nem conta real nos testes. O teste de navegação usa um Firebase simulado (stub) no navegador. Antes de publicar, faça um cadastro e um login reais.
- **Testes de navegador** cobrem renderização, erros de JavaScript, links de navegação e transbordo horizontal no celular (390 px). Não cobrem a sequência completa de ações com login real.
- **Balanceamento:** em simulações, a eleição presidencial com 20 milhões de apoio do jogador chegou ao segundo turno em todas as partidas, e o jogador não venceu. Com 400 milhões de apoio, o jogador venceu. Os números podem precisar de ajuste.
- **Parte 5:** não foi iniciada (não foi solicitada).
