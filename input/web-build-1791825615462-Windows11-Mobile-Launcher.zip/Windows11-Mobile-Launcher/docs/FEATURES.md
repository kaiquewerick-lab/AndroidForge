# Recursos

Lista do que foi implementado, com o comportamento real de cada item. Itens marcados como **parcial** têm limitações descritas em [LIMITATIONS.md](LIMITATIONS.md).

Legenda: ✅ implementado · ◐ parcial · ⛔ não implementado (ou impossível pelo Android)

---

## 1. Área de trabalho

| Recurso | Situação | Como funciona |
|---|---|---|
| Papel de parede padrão | ✅ | Gradiente azul inspirado no Windows 11 (quatro predefinidos) |
| Ícones de aplicativos e atalhos | ✅ | Atalhos internos e até 10 apps Android |
| Arrastar e reorganizar ícones | ✅ | Ao soltar, o ícone encaixa na célula livre mais próxima. Posições salvas |
| Seleção simples e abertura | ✅ | Um toque seleciona; dois toques rápidos (ou duplo clique) abrem |
| Menu de contexto | ✅ | Botão direito, toque longo ou Shift+F10 / tecla Menu |
| Organizar ícones por nome | ✅ | Pelo menu da área de trabalho ou em Configurações |
| Restaurar organização padrão | ✅ | Volta à ordem original de atalhos e fixados |
| Lixeira | ✅ | Ícone de atalho que abre a Lixeira do Explorador |
| Adaptação a tamanhos e orientações | ✅ | Ícones reposicionados ao girar o aparelho. Três tamanhos de ícone |
| Controles acessíveis ao toque | ✅ | Alvos de toque de pelo menos 36 px, toque longo como alternativa |

## 2. Aplicativos Android

| Recurso | Situação | Como funciona |
|---|---|---|
| Detectar apps que o Android permite consultar | ✅ | `queryIntentActivities` com MAIN/LAUNCHER, declarado em `<queries>` |
| Nome, ícone e pacote | ✅ | Ícones são convertidos para PNG de 96 px e guardados em cache |
| Exatamente 10 fixados por padrão | ✅ | Regra alfabética determinística (ver README). Menos apps? Mostra todos |
| Trocar um fixado | ✅ | Botão direito → **Trocar aplicativo...**. Se o escolhido já estiver fixado, os dois trocam de lugar |
| Demais apps na pesquisa e na lista | ✅ | Menu Iniciar → **Todos os aplicativos** e pesquisa |
| Não contar atalhos internos | ✅ | Atalhos internos ficam separados |
| Pesquisa por nome conforme digita | ✅ | Filtra nomes e identificadores de pacote |
| Abrir pelo intent oficial | ✅ | `getLaunchIntentForPackage` + `FLAG_ACTIVITY_NEW_TASK` |
| Mensagens úteis quando não abre | ✅ | Toast com o motivo (sem tela inicial, sem permissão, não encontrado) |
| Atualizar lista sob demanda | ✅ | Menu Iniciar → energia → **Atualizar** ou **Configurações → Aplicativos** |
| Detectar instalação e remoção | ◐ | Receptor de broadcasts de pacote. Funciona enquanto o launcher está ativo |
| Solicitar apenas permissões necessárias | ✅ | Nenhuma permissão declarada |
| Não usar `QUERY_ALL_PACKAGES` | ✅ | Visibilidade pela declaração `<queries>` |
| Incorporar o app Android dentro de uma janela | ⛔ | Impossível: apps Android são processos separados e não podem ser embutidos em janelas HTML |

## 3. Janelas internas

| Recurso | Situação | Como funciona |
|---|---|---|
| Abrir, fechar, minimizar, restaurar, maximizar | ✅ | Pelos botões da barra de título, duplo clique, barra de tarefas ou atalhos |
| Fechar encerra só a instância | ✅ | O `destroy()` da ferramenta é chamado; os dados salvos continuam no armazenamento |
| Tela cheia | ✅ | Atalho F11 (sair com F11, Esc ou pelo botão de maximizar). Cobre também a barra de tarefas |
| Modo imersivo do Android | ◐ | F11 sem janela ativa tenta esconder as barras do sistema, se permitido |
| Arrastar pela barra de título | ✅ | Mouse e toque, com captura de ponteiro |
| Redimensionar pelas bordas | ✅ | Borda direita, inferior, canto e borda esquerda |
| Foco, ordem (z-index), janela ativa | ✅ | Clique ou toque traz à frente e ativa a janela |
| Histórico de janelas recentes | ✅ | Lista MRU usada por Alt+Tab e pela visão de tarefas |
| Aparecer na barra de tarefas | ✅ | Um botão por janela, com indicador de ativa e de minimizada |
| Alternar entre janelas | ✅ | Barra de tarefas, Alt+Tab e visão de tarefas |
| Organizar lado a lado | ✅ | Win + ← / → encaixa em metade da tela |
| Animações leves | ✅ | Transições de 180 ms (desligáveis em Configurações) |
| Adaptação a telas pequenas | ✅ | Em telas com até 600 px de largura, a janela abre maximizada |

## 4. Menu Iniciar

| Recurso | Situação |
|---|---|
| Aplicativos fixados | ✅ (internos e 10 Android) |
| Lista de todos os aplicativos | ✅ (ordem alfabética, com indicação "Interno" ou "Android") |
| Pesquisa integrada | ✅ (apps, pacotes e arquivos internos) |
| Atalhos para configurações, explorador e ferramentas | ✅ |
| Botão de energia | ✅ Atualizar lista, Reiniciar interface e Sair do launcher. Não simula desligamento |
| Navegação por teclado | ✅ Setas, Enter e Esc |
| Layout adaptável | ✅ Ocupa a largura toda em telas pequenas |

## 5. Atalhos de teclado

| Atalho | Situação |
|---|---|
| Win (abrir/fechar Iniciar) | ◐ Depende de o teclado enviar a tecla Win à WebView |
| Win + E, D, R, I, S, Tab | ◐ Mesma dependência da tecla Win |
| Alt + Tab | ✅ Alterna para a janela anterior do histórico |
| Alt + F4 | ✅ Fecha a janela ativa |
| Win + ← / → / ↑ / ↓ | ◐ Mesma dependência da tecla Win |
| Ctrl + Shift + Esc | ✅ Abre o Gerenciador de tarefas |
| Ctrl + C / X / V | ✅ Nos campos de texto (nativo). No Explorador, copia, recorta e cola itens |
| Ctrl + Z / Y | ✅ No Bloco de Notas e nos campos de texto. O Paint não tem desfazer |
| F2 | ✅ Renomeia o item selecionado no Explorador |
| F11 | ✅ Tela cheia da janela ativa |
| Esc | ✅ Fecha menus, painéis e diálogos; sai da tela cheia |

Regras aplicadas: atalhos globais são ignorados em campos de texto; cada tecla é tratada uma única vez (um listener no documento, sem repasse pelo Android); Esc e Ctrl+Shift+Esc são exceções intencionais.

## 6. Mouse e toque

| Recurso | Situação |
|---|---|
| Clique esquerdo e direito | ✅ |
| Duplo clique | ✅ |
| Seleção e arrastar ícones | ✅ |
| Arrastar e redimensionar janelas | ✅ |
| Rolagem pela roda | ✅ (nas áreas de rolagem das ferramentas) |
| Menu de contexto | ✅ |
| Indicador visual de foco | ✅ (janela ativa com borda e barra de tarefas destacadas) |
| Teclado e mouse ao mesmo tempo | ✅ |

## 7. Personalização

| Recurso | Situação |
|---|---|
| Papel de parede padrão | ✅ |
| Escolher imagem da galeria | ✅ Seletor do Android. A imagem é reduzida para no máximo 1600 px e salva em JPEG |
| Modo de exibição (preencher, ajustar, esticar, centralizar, repetir) | ✅ |
| Preservar imagem após reiniciar | ✅ |
| Tema claro, escuro e automático | ✅ Automático segue o tema do sistema quando o navegador/WebView informa |
| Cor de destaque predefinida e personalizada | ✅ Oito cores e seletor livre |
| Transparência visual simulada | ✅ Opacidade de barras e menus (60% a 100%) |
| Tamanho dos ícones | ✅ Pequeno, médio ou grande |
| Posição dos ícones | ✅ Arrastar e organizar |
| Barra de tarefas centralizada ou à esquerda | ✅ |
| Mostrar ou ocultar pesquisa e visão de tarefas | ✅ |
| Densidade da interface | ✅ Compacta, normal ou confortável |
| Preferências de animação | ✅ |

Onde cada dado é salvo está em [README.md](../README.md#armazenamento-e-privacidade).

## 8. Ferramentas internas

### Explorador de arquivos
Pastas Área de Trabalho, Documentos, Imagens e Lixeira. Criar pastas e textos, renomear, copiar, recortar, colar, excluir (vai para a Lixeira), seleção múltipla com Ctrl e Shift, pesquisa na pasta, exibição em ícones ou lista, Lixeira com restauração e esvaziamento, e **Importar do aparelho** pelo seletor do Android.

### Bloco de Notas
Novo, abrir do aparelho, salvar, salvar como (em Documentos), exportar `.txt`, desfazer e refazer (histórico próprio, Ctrl+Z e Ctrl+Y). Rascunho automático: se você fechar o app com alterações não salvas, o texto volta ao reabrir.

### Calculadora
Soma, subtração, multiplicação, divisão, parênteses e decimais. Avaliador próprio, sem `eval`. Teclado completo.

### Paint simples
Desenho com mouse ou toque, 12 cores, espessura de 1 a 40 px, limpar e exportar PNG (MediaStore, em `Pictures/Win11Launcher`).

### Gerenciador de tarefas
Lista apenas as janelas internas abertas, com estado. Permite ir para uma janela, fechá-la, mostrar todas ou ir para a área de trabalho. **Não mostra CPU, memória ou processos Android**, porque o launcher não tem permissão para isso.

### Executar
Aceita somente nomes de ferramentas internas (calc, bloco, paint, explorador, configurações, lixeira etc.). Não executa comandos de terminal.

### Configurações
Oito páginas: personalização, papel de parede, temas e cores, barra de tarefas, exibição, aplicativos, sistema e dados, e sobre. Também contém atalhos para Wi-Fi, Bluetooth, som, brilho e configuração de tela inicial do Android.

## 9. Barra de tarefas, relógio e notificações

| Recurso | Situação |
|---|---|
| Menu Iniciar, pesquisa, fixados internos | ✅ |
| Indicadores das janelas abertas | ✅ |
| Relógio e data | ✅ Atualizado a cada 15 segundos |
| Calendário | ✅ Mês com navegação anterior e próximo |
| Área de notificações próprias | ✅ Eventos do próprio launcher (salvos, instalação de apps, exportações) |
| Painel de configurações rápidas | ✅ Tema, animações, alinhamento e atalhos para telas do Android |
| Indicador de foco e janela ativa | ✅ |
| Controlar Wi-Fi, Bluetooth, volume ou brilho diretamente | ⛔ Não permitido pelo Android. O painel abre as telas correspondentes |

## 10. Tela cheia e modo desktop

- A área de trabalho usa todo o espaço acima da barra de tarefas.
- Janelas em tela cheia cobrem também a barra de tarefas do launcher.
- O modo imersivo do Android (ocultar barras do sistema) é tentado somente quando o Android permite, e a saída é sempre pelo gesto de deslizar ou pelo F11.
- Nada é prometido sobre ocultação permanente das barras, que depende do aparelho.

## 11. Instalação como launcher

- Activity com `MAIN` + `HOME` + `DEFAULT`. Aparece na lista de telas iniciais do Android.
- Não é definido automaticamente. O usuário escolhe nas configurações.
- Botão Voltar: fecha menus, painéis e janelas antes de qualquer outra ação. Sem nada aberto, na tela inicial ele não sai do launcher.
- Ciclo de vida: a WebView pausa e retoma junto com a Activity, e o receptor de pacotes é registrado apenas enquanto o app está visível.

## 12. Segurança

- Sem permissões no manifesto.
- Sem credenciais, tokens, chaves de API, Firebase, Cloudflare, contas ou servidores próprios.
- Sem inteligência artificial e sem JavaScript remoto.
- A ponte nativa expõe apenas 8 métodos, todos com validação de argumentos (pacotes, nomes de arquivo, tipos MIME, lista branca de telas do Android).
- A WebView não lê arquivos do sistema de arquivos (`allowFileAccess = false`) e bloqueia navegação para fora do pacote local.
- Não há execução de comandos Android nem acesso a acessibilidade ou administrador do dispositivo.
