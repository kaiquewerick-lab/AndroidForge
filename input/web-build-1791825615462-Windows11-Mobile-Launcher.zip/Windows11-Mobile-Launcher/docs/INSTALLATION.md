# Instalação e compilação

Este guia cobre três caminhos: testar a interface no navegador, compilar o APK e instalá-lo no aparelho.

> **Estado da compilação nesta entrega:** o projeto foi reorganizado para ter o `settings.gradle.kts` na raiz da pasta `Windows11-Mobile-Launcher`, que é o formato exigido pelo AndroidForge. **O APK não foi compilado no ambiente de desenvolvimento**, porque ele não conseguiu acessar os repositórios Google Maven e o servidor de distribuição do Gradle. O log de compilação do AndroidForge (ou uma compilação local seguindo este guia) é a verificação real.

---

## 1. Testar a interface no navegador (sem compilar)

1. Descompacte o ZIP.
2. Abra `web/index.html` em um navegador (no computador ou no celular).
3. Como não há ponte Android, a lista de aplicativos é **simulada** e um aviso aparece no centro de notificações. Todo o restante funciona: janelas, menu Iniciar, Explorador, Bloco de Notas, Calculadora, Paint, personalização e atalhos de teclado.

> Dica para celular: alguns navegadores bloqueiam `localStorage` no modo anônimo. Nesse caso, as preferências valem só durante a sessão, e a aba mostra isso em **Sistema e dados**.

---

## 2. Estrutura do projeto Gradle

A pasta `Windows11-Mobile-Launcher/` é a **raiz do projeto Gradle**. Abra essa pasta (não uma subpasta) no Android Studio ou no AndroidForge.

```
Windows11-Mobile-Launcher/
├── settings.gradle.kts        ← obrigatório na raiz (é o que o AndroidForge procura)
├── build.gradle.kts           ← configuração raiz (versões dos plugins)
├── gradle.properties
├── gradlew  e  gradlew.bat    ← Gradle Wrapper (já incluído)
├── gradle/wrapper/            ← gradle-wrapper.jar e gradle-wrapper.properties (Gradle 8.0)
├── app/                       ← módulo Android
│   ├── build.gradle.kts       ← usa ../web como fonte dos assets
│   └── src/main/              ← AndroidManifest.xml, MainActivity.kt, LauncherBridge.kt, res/
└── web/                       ← interface HTML/CSS/JS, empacotada no APK
```

A pasta `web/` precisa estar **ao lado** de `app/`, na raiz. O módulo `app` a lê com `assets.srcDirs("../web")`, que é relativo à pasta `app/`.

### Versões fixadas

| Item | Versão |
|---|---|
| Gradle (wrapper) | 8.0 |
| Android Gradle Plugin | 8.1.0 |
| Kotlin (plugin Android) | 1.9.24 |
| JDK | 17 |
| compileSdk / targetSdk | 34 |
| minSdk | 29 (Android 10) |
| androidx.webkit | 1.11.0 |

---

## 3. Requisitos para compilar o APK

| Item | Versão recomendada |
|---|---|
| Android Studio | Iguana ou mais recente (ou JDK + SDK pela linha de comando) |
| JDK | 17 |
| Android SDK Platform | 34 |
| Android SDK Build-Tools | 34.0.0 ou mais recente |
| Acesso à internet | Necessário na primeira compilação, para baixar o Gradle 8.0 e as dependências do Google Maven e do Maven Central |

Dispositivo de destino: **Android 10 (API 29) ou superior**.

---

## 4. Compilar com o Android Studio (recomendado)

1. Abra o Android Studio e escolha **Open** → selecione a pasta **`Windows11-Mobile-Launcher`** (a raiz, onde está o `settings.gradle.kts`).
2. Aguarde o **Gradle Sync**. Na primeira vez ele baixa o Gradle 8.0, o plugin do Android (AGP 8.1.0) e as bibliotecas AndroidX.
3. Se o Android Studio pedir o caminho do SDK, aceite a sugestão ou aponte para o SDK instalado. Isso cria o `local.properties`, que **não** deve ser versionado nem incluído em ZIPs.
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Quando terminar, clique em **locate** na notificação. O APK de depuração fica em:
   `app/build/outputs/apk/debug/app-debug.apk`

Para um APK de **release**, crie uma chave de assinatura (**Build → Generate Signed Bundle / APK**). A chave não é incluída no projeto, por segurança.

---

## 5. Compilar pela linha de comando

Requisitos: JDK 17, Android SDK configurado (variável `ANDROID_HOME` ou `local.properties` com `sdk.dir`).

```bash
cd Windows11-Mobile-Launcher

# Dar permissão de execução ao wrapper (necessário em Linux e macOS, se o ZIP não preservou essa permissão)
chmod +x gradlew

# Compilar o APK de depuração
./gradlew assembleDebug

# (Opcional) APK de release sem assinatura
./gradlew assembleRelease
```

No Windows, use `gradlew.bat assembleDebug`.

Saída:
- `app/build/outputs/apk/debug/app-debug.apk`
- `app/build/outputs/apk/release/app-release-unsigned.apk` (se usar `assembleRelease`)

---

## 6. Compilar pelo AndroidForge

O AndroidForge procura o projeto na pasta `Windows11-Mobile-Launcher` e exige `settings.gradle` ou `settings.gradle.kts` na raiz dessa pasta. Esta entrega atende a esse requisito.

**Versão do Gradle no AndroidForge.** O projeto foi ajustado para o Gradle 8.0, que é o que o AndroidForge executa quando "Use Gradle wrapper" está desativado. Por isso o AGP foi reduzido para 8.1.0 (veja a seção 2). Não é preciso alterar o AndroidForge para este projeto. Se, no futuro, você quiser o AGP 8.5.x, o AndroidForge precisa usar o Gradle 8.7 ou superior: ative "Use Gradle wrapper" (o wrapper deste projeto é 8.0; atualize-o antes) ou configure o Gradle 8.7 no AndroidForge.

Se o AndroidForge continuar reclamando de "does not contain a Gradle build", confira:

- que o ZIP foi descompactado de modo que `settings.gradle.kts` fique **diretamente** dentro de `Windows11-Mobile-Launcher/`, e não dentro de uma subpasta extra (por exemplo `Windows11-Mobile-Launcher/Windows11-Mobile-Launcher/`);
- que a pasta `web/` está na mesma raiz, ao lado de `app/`.

---

## 7. Compilar pelo celular ou pela nuvem

Não há forma prática de compilar um APK com Android SDK diretamente no celular. Alternativas:

- Usar um serviço de compilação na nuvem que aceite projetos Gradle, enviando a pasta **inteira** `Windows11-Mobile-Launcher/` (com `web/` ao lado de `app/`). Confira se o serviço mantém essa estrutura.
- Usar um computador de terceiros ou de amigo com Android Studio.

---

## 8. Instalar o APK no aparelho

1. Copie `app-debug.apk` para o aparelho (cabo USB, nuvem pessoal ou computador).
2. Abra o arquivo pelo gerenciador de arquivos. Quando o Android pedir, permita **Instalar apps desconhecidos** para o app usado para abrir o arquivo (o nome da opção varia conforme a marca).
3. Toque em **Instalar**.
4. Abra **Windows 11 Mobile Launcher** uma vez.

Para instalar pelo computador com depuração USB ativada:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 9. Definir como tela inicial (opcional)

1. **Configurações → Apps → Aplicativo padrão de início** (ou **Início**, conforme a marca).
2. Escolha **Windows 11 Mobile Launcher**.
3. Pressione o botão Início.

Para voltar, escolha o launcher anterior na mesma tela. O launcher nunca se define sozinho como padrão.

---

## 10. Roteiro de testes recomendado (no aparelho)

Marque cada item após testar:

- [ ] O app abre e mostra o papel de parede padrão e a barra de tarefas.
- [ ] Após abrir, aparecem até **10 apps Android** na área de trabalho (ou todos, se houver menos).
- [ ] Toque no menu Iniciar e na aba **Todos os aplicativos**. Os apps aparecem em ordem alfabética.
- [ ] Pesquisar no menu Iniciar filtra os apps enquanto você digita.
- [ ] Tocar em um app Android o abre. Um app sem tela inicial mostra uma mensagem clara.
- [ ] Instalar ou desinstalar um app e voltar ao launcher atualiza a lista (ou use **Atualizar lista**).
- [ ] Abrir, minimizar, maximizar, restaurar e fechar uma janela interna.
- [ ] Arrastar uma janela pela barra de título e redimensioná-la pela borda.
- [ ] Alternar janelas com a barra de tarefas e com Alt + Tab (teclado físico).
- [ ] Trocar o papel de parede pela galeria e reiniciar o app: a imagem deve continuar.
- [ ] Alternar tema claro/escuro e cor de destaque. Fechar e reabrir: a escolha deve permanecer.
- [ ] Criar uma pasta e um arquivo de texto no Explorador, enviar um item para a Lixeira e restaurá-lo.
- [ ] Escrever no Bloco de Notas, salvar, fechar e reabrir o arquivo.
- [ ] Fazer uma conta na Calculadora (inclusive por teclado).
- [ ] Desenhar no Paint e exportar o PNG. Conferir em Imagens ou no app de galeria.
- [ ] Negar uma permissão do seletor de arquivos (ou cancelar a escolha) não deve travar o app.
- [ ] Botão Voltar: fecha menus e janelas antes de fazer qualquer outra coisa.
- [ ] Girar o aparelho: a interface se adapta sem perder as janelas abertas.

---

## 11. Solução de problemas

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| "does not contain a Gradle build" (AndroidForge) | `settings.gradle.kts` não está na raiz da pasta enviada | Confira a seção 6 deste guia |
| `Plugin [id: 'com.android.application', version: '8.1.0'] was not found` | Sem acesso ao Google Maven | Verifique a rede ou o proxy; o erro não é de configuração do projeto |
| `Could not install Gradle distribution` / falha ao baixar gradle-8.0 | Sem acesso a services.gradle.org | Verifique a rede ou o proxy |
| `Minimum supported Gradle version is 8.x. Current version is 8.0` | AGP mais novo que o Gradle em uso | Mantenha AGP 8.1.0 com Gradle 8.0, ou suba o Gradle para 8.7+ (e o AGP para 8.5.x) juntos |
| `"gradlew": Permission denied` | Permissão de execução perdida ao descompactar | Rode `chmod +x gradlew` |
| "Não foi possível abrir" ao tocar em um app | O app não tem tela inicial ou está desativado | Verifique se o app abre pelo próprio ícone do aparelho |
| Lista de apps vazia | Build sem `<queries>` ou sem permissão de visibilidade | Confira o manifesto (seção `queries`) e reinstale o APK |
| Tela branca na primeira abertura | Assets não empacotados | Confirme que a pasta `web/` existe ao lado de `app/` ao compilar |
| `SDK location not found` | Falta `local.properties` | Aponte o SDK no Android Studio ou crie `local.properties` na raiz com `sdk.dir=...` |
| Preferências somem | Armazenamento limpo pelo sistema ou modo anônimo | Use **Sistema e dados** para verificar o armazenamento disponível |
