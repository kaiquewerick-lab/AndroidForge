// Plugins de nível de projeto.
// Combinação verificada na documentação oficial:
//   - AGP 8.1.0 exige Gradle 8.0 (mínimo) e JDK 17.
//   - Kotlin Gradle plugin 1.9.20–1.9.25 aceita AGP até 8.1.0 e Gradle 6.8.3–8.1.1.
// Por isso o projeto usa Gradle 8.0 (o mesmo que o AndroidForge fornece hoje).
// AGP 8.5.x exigiria Gradle 8.7; não use esse AGP enquanto o build rodar com Gradle 8.0.
plugins {
    id("com.android.application") version "8.1.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
