plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.win11launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.win11launcher"
        // Android 10 (API 29) ou superior: MediaStore.Downloads e recursos usados exigem API 29
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Para publicar, assine o APK com sua própria chave (não incluída no projeto).
        }
        debug {
            isDebuggable = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    sourceSets {
        getByName("main") {
            // A interface web (pasta web/ na raiz do projeto) é empacotada como assets do APK.
            assets.srcDirs("../web")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.webkit:webkit:1.11.0")
}
