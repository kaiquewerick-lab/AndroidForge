package com.example.win11launcher

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

/**
 * Activity principal do launcher.
 *
 * - Hospeda a interface HTML/CSS/JS (pasta web/, copiada para os assets pelo Gradle).
 * - Carrega a página pelo endereço virtual https://appassets.androidplatform.net,
 *   que serve apenas os arquivos do próprio APK (nada é carregado da internet).
 * - Expõe ao JavaScript somente a ponte LauncherBridge (métodos fixos e validados).
 * - Escuta instalação/remoção de apps e avisa a página (window.onAppsChanged).
 * - Trata o botão Voltar (window.handleBack) sem sair da tela inicial.
 */
class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: LauncherBridge
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        // Seletor do próprio Android: somente os arquivos escolhidos são entregues à página
        filePathCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        filePathCallback = null
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // onReceive roda na thread principal: seguro para acessar a WebView
            webView.evaluateJavascript("if (window.onAppsChanged) window.onAppsChanged();", null)
        }
    }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(APP_DOMAIN)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage: preferências e arquivos internos
            databaseEnabled = false
            allowFileAccess = false           // não ler arquivos do sistema de arquivos
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = true
        }
        webView.setBackgroundColor(0xFF202020.toInt())

        bridge = LauncherBridge(this)
        webView.addJavascriptInterface(bridge, "LauncherBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                // Bloqueia qualquer navegação para fora do pacote local
                return request.url.host != APP_DOMAIN
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: WebChromeClient.FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                val accept = params.acceptTypes.firstOrNull { it.isNotBlank() } ?: "*/*"
                pickFile.launch(if (accept.contains("/")) accept else "*/*")
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("(window.handleBack && window.handleBack()) ? 'true' : 'false'") { result ->
                    val handled = result?.trim('"') == "true"
                    if (!handled) {
                        // Nada aberto na tela inicial: como launcher HOME, o Voltar não sai daqui.
                        // Se o app foi aberto pelo ícone (não como HOME), volta para a tela anterior.
                        if (!isDefaultHome()) moveTaskToBack(true)
                    }
                }
            }
        })

        webView.loadUrl("https://$APP_DOMAIN/assets/index.html")
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        // Broadcasts de pacotes são do sistema: não precisam ser exportados
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(packageReceiver) } catch (_: IllegalArgumentException) { /* já removido */ }
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        webView.resumeTimers()
        // Recarrega silenciosamente a lista de apps ao voltar ao launcher
        // (cobre instalações feitas enquanto ele estava em segundo plano)
        webView.evaluateJavascript("if (window.W11Desktop) W11Desktop.loadApps();", null)
    }

    override fun onPause() {
        webView.onPause()
        webView.pauseTimers()
        super.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    /** Verdadeiro se este app é o launcher HOME padrão do aparelho. */
    private fun isDefaultHome(): Boolean {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved?.activityInfo?.packageName == packageName
    }

    companion object {
        const val APP_DOMAIN = "appassets.androidplatform.net"
    }
}
