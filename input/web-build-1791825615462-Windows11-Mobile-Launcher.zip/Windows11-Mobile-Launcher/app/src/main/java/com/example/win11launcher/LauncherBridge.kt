package com.example.win11launcher

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Ponte nativa exposta ao JavaScript como "LauncherBridge".
 *
 * Regras de segurança:
 *  - Somente os métodos anotados com @JavascriptInterface ficam visíveis à página.
 *  - Todos os argumentos vindos da página são validados antes de uso.
 *  - Não há execução de comandos, acesso a arquivos arbitrários nem acesso à rede.
 *  - Nenhuma permissão especial é solicitada: a lista de apps usa a declaração
 *    <queries> do manifesto (MAIN/LAUNCHER), e a exportação usa o MediaStore.
 *
 * Convenção de retorno: textos que começam com "error:" indicam falha.
 */
class LauncherBridge(private val activity: Activity) {

    private val iconCache = ConcurrentHashMap<String, String>()

    @JavascriptInterface
    fun getApps(): String {
        return try {
            val pm = activity.packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val result = pm.queryIntentActivities(intent, 0)
            val seen = HashSet<String>()
            val array = JSONArray()
            for (ri in result) {
                val pkg = ri.activityInfo?.packageName ?: continue
                // Não lista o próprio launcher e evita duplicatas
                if (pkg == activity.packageName || !seen.add(pkg)) continue
                if (!isValidPackage(pkg)) continue
                val label = ri.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
                array.put(JSONObject().put("pkg", pkg).put("label", label))
            }
            array.toString()
        } catch (e: Exception) {
            Log.w(TAG, "Falha ao listar apps", e)
            "[]"
        }
    }

    @JavascriptInterface
    fun getIcon(pkg: String): String {
        if (!isValidPackage(pkg)) return ""
        iconCache[pkg]?.let { return it }
        return try {
            val drawable = activity.packageManager.getApplicationIcon(pkg)
            val bitmap: Bitmap = drawable.toBitmap(ICON_PX, ICON_PX)
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, out)
            val data = "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            iconCache[pkg] = data
            data
        } catch (e: Exception) {
            ""
        }
    }

    @JavascriptInterface
    fun launchApp(pkg: String): String {
        if (!isValidPackage(pkg)) return "error:Identificador de aplicativo inválido."
        if (pkg == activity.packageName) return "error:Este já é o Windows 11 Mobile Launcher."
        return try {
            val intent = activity.packageManager.getLaunchIntentForPackage(pkg)
                ?: return "error:Este aplicativo não tem tela inicial ou não está disponível (pode ter sido removido ou estar desativado)."
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(intent)
            "ok"
        } catch (e: ActivityNotFoundException) {
            "error:Nenhuma atividade encontrada para abrir este aplicativo."
        } catch (e: SecurityException) {
            "error:O Android não permitiu abrir este aplicativo."
        } catch (e: Exception) {
            "error:Não foi possível abrir o aplicativo (${e.javaClass.simpleName})."
        }
    }

    /** Abre uma tela de configurações do Android. kind deve estar na lista branca. */
    @JavascriptInterface
    fun openSystemSettings(kind: String): Boolean {
        val action = when (kind) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "home" -> Settings.ACTION_HOME_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "main" -> Settings.ACTION_SETTINGS
            else -> return false
        }
        return try {
            activity.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Modo imersivo: esconde barras do sistema enquanto uma janela está em tela cheia. */
    @JavascriptInterface
    fun setImmersive(enabled: Boolean): Boolean {
        activity.runOnUiThread {
            val window = activity.window
            WindowCompat.setDecorFitsSystemWindows(window, !enabled)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            if (enabled) {
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        return true
    }

    /** A lista é consultada a cada chamada de getApps(); aqui só limpamos o cache de ícones. */
    @JavascriptInterface
    fun refreshApps() {
        iconCache.clear()
    }

    /** Fecha o launcher (finish). O Android pode então mostrar outra tela inicial. */
    @JavascriptInterface
    fun exitLauncher(): Boolean {
        activity.runOnUiThread { activity.finish() }
        return true
    }

    /**
     * Salva um arquivo exportado no MediaStore (sem permissão de armazenamento):
     * imagens vão para Pictures/Win11Launcher e textos para Download/Win11Launcher.
     * Retorna o caminho relativo salvo ou "error:...".
     */
    @JavascriptInterface
    fun exportFile(name: String, mime: String, base64: String): String {
        if (!NAME_RE.matches(name)) return "error:Nome de arquivo inválido."
        if (!MIME_RE.matches(mime)) return "error:Tipo de arquivo inválido."
        val bytes = try { Base64.decode(base64, Base64.DEFAULT) } catch (e: IllegalArgumentException) {
            return "error:Dados do arquivo inválidos."
        }
        if (bytes.size > MAX_EXPORT_BYTES) return "error:Arquivo grande demais para exportar."

        val resolver = activity.contentResolver
        val isImage = mime.startsWith("image/")
        val collection = if (isImage) MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                         else MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val folder = if (isImage) "Pictures/Win11Launcher" else "Download/Win11Launcher"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return try {
            val uri = resolver.insert(collection, values) ?: return "error:Não foi possível criar o arquivo."
            val stream = resolver.openOutputStream(uri) ?: return "error:Não foi possível gravar o arquivo."
            stream.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            "$folder/$name"
        } catch (e: Exception) {
            "error:Falha ao salvar (${e.javaClass.simpleName})."
        }
    }

    private fun isValidPackage(pkg: String): Boolean = PKG_RE.matches(pkg)

    companion object {
        private const val TAG = "LauncherBridge"
        private const val ICON_PX = 96
        private const val MAX_EXPORT_BYTES = 20 * 1024 * 1024
        private val PKG_RE = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$")
        private val NAME_RE = Regex("^[A-Za-z0-9._-]{1,80}$")
        private val MIME_RE = Regex("^[a-z]+/[a-z0-9.+-]+$")
    }
}
