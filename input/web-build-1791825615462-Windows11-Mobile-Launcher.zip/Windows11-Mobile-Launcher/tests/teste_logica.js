// Testes de lógica pura (calculadora e sistema de arquivos). Execute: node tests/teste_logica.js
// Ambiente mínimo para carregar os módulos puros no Node
const fs = require("fs");
const vm = require("vm");
const path = require("path");
const base = path.join(__dirname, "..", "web", "js") + path.sep;
const store = {};
const localStorage = {
  getItem: k => (k in store ? store[k] : null),
  setItem: (k, v) => { store[k] = String(v); },
  removeItem: k => { delete store[k]; }
};
const win = { localStorage };
const ctx = vm.createContext({ window: win, localStorage, console, document: {}, navigator: {}, Date, Math, JSON, Object, Array, Promise, setTimeout, clearTimeout });
ctx.window = ctx; // window.X = ... grava no contexto
vm.runInContext(fs.readFileSync(base + "storage.js", "utf8"), ctx);
vm.runInContext(fs.readFileSync(base + "apps/calculator.js", "utf8"), ctx);
vm.runInContext(fs.readFileSync(base + "apps/fs.js", "utf8"), ctx);

const E = ctx.W11Calc.evaluate;
const cases = [
  ["2+3*4", 14], ["(2+3)*4", 20], ["10/4", 2.5], ["-3+5", 2], ["2*(3+(4-1))", 12], ["0.1+0.2", 0.3], ["7-10", -3]
];
let ok = true;
for (const [expr, want] of cases) {
  const got = E(expr);
  const pass = Math.abs(got - want) < 1e-9;
  ok = ok && pass;
  console.log(pass ? "PASS" : "FAIL", expr, "=>", got);
}
for (const bad of ["1/0", "2+", "(1+2", "1..2", "abc", "2+*3"]) {
  try { E(bad); console.log("FAIL (deveria falhar)", bad); ok = false; }
  catch (e) { console.log("PASS erro esperado:", bad, "-", e.message); }
}

// Sistema de arquivos
const F = ctx.W11FS;
const r1 = F.create("docs", "Teste.txt", "file", "olá");
console.log(r1.ok ? "PASS" : "FAIL", "criar arquivo");
const dup = F.create("docs", "teste.TXT", "file", "");
console.log(!dup.ok ? "PASS" : "FAIL", "nome duplicado recusado:", dup.error);
const bad = F.create("docs", "a/b.txt", "file", "");
console.log(!bad.ok ? "PASS" : "FAIL", "caractere inválido recusado");
F.trash([r1.id]);
console.log(F.isTrashed(r1.id) ? "PASS" : "FAIL", "envio para Lixeira");
F.restore([r1.id]);
console.log(F.get(r1.id).parent === "docs" ? "PASS" : "FAIL", "restaurado para pasta original");
const f2 = F.create("docs", "Pasta", "folder");
F.move([f2.id], "desktop");
const cp = F.copy([r1.id], "images");
console.log(F.children("images").length === 1 ? "PASS" : "FAIL", "cópia para Imagens");
console.log("Busca 'bem':", F.search("bem").map(x => x.path));
console.log(ok ? "\nCalculadora OK" : "\nHá falhas na calculadora");
