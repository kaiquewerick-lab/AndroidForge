# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright
# Gerado para o projeto: caminho relativo a este arquivo (não depende de /home/...)
import pathlib
URL = (pathlib.Path(__file__).resolve().parent.parent / "web" / "index.html").as_uri()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--no-sandbox"])
        pg = await b.new_page(viewport={"width": 1100, "height": 760})
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(400)
        # Abre duas janelas
        await pg.evaluate("W11Apps.open('explorer')")
        await pg.evaluate("W11Apps.open('notepad')")
        await pg.wait_for_timeout(250)
        w = pg.locator(".win").last
        before = await w.bounding_box()
        # Arrastar pela barra de título
        tb = w.locator(".win-titlebar")
        bb = await tb.bounding_box()
        await pg.mouse.move(bb["x"]+80, bb["y"]+10); await pg.mouse.down()
        await pg.mouse.move(bb["x"]+160, bb["y"]+60, steps=8); await pg.mouse.up()
        after = await w.bounding_box()
        print("drag moved:", round(after["x"]-before["x"]), round(after["y"]-before["y"]))
        # Redimensionar pela borda direita-inferior
        rb = await w.locator(".resize.se").bounding_box()
        await pg.mouse.move(rb["x"]+5, rb["y"]+5); await pg.mouse.down()
        await pg.mouse.move(rb["x"]+65, rb["y"]+45, steps=6); await pg.mouse.up()
        r2 = await w.bounding_box()
        print("resize delta w/h:", round(r2["width"]-after["width"]), round(r2["height"]-after["height"]))
        # Win+Left encaixa à esquerda
        await pg.keyboard.down("Meta"); await pg.keyboard.press("ArrowLeft"); await pg.keyboard.up("Meta")
        await pg.wait_for_timeout(250)
        sn = await w.bounding_box()
        print("snap left x/w:", round(sn["x"]), round(sn["width"]), "viewport w:", 1100)
        # F11 tela cheia cobre a barra
        await pg.keyboard.press("F11"); await pg.wait_for_timeout(250)
        fs = await w.bounding_box()
        print("fullscreen covers taskbar:", fs["height"] >= 759, "has-fullscreen:", await pg.evaluate("document.documentElement.classList.contains('has-fullscreen')"))
        await pg.keyboard.press("Escape"); await pg.wait_for_timeout(250)
        print("after Esc has-fullscreen:", await pg.evaluate("document.documentElement.classList.contains('has-fullscreen')"))
        # Explorador: criar pasta com diálogo
        ex = pg.locator(".win").first
        await pg.evaluate("W11Windows.focus(W11Windows.list()[0])")
        await ex.locator('[data-act="new-folder"]').click()
        await pg.wait_for_timeout(150)
        await pg.fill("#dlg-input", "Projetos")
        await pg.keyboard.press("Enter"); await pg.wait_for_timeout(200)
        names = await ex.locator(".fname").all_inner_texts()
        print("explorer items:", names)
        # Bloco de notas: escrever e salvar em Documentos
        nt = pg.locator(".win").nth(1)
        await pg.evaluate("W11Windows.focus(W11Windows.list()[1])")  # traz o Bloco de Notas à frente
        await nt.locator("textarea").fill("Olá, mundo!")
        await nt.locator('[data-act="saveas"]').click(); await pg.wait_for_timeout(150)
        await pg.fill("#dlg-input", "nota.txt"); await pg.keyboard.press("Enter"); await pg.wait_for_timeout(200)
        print("saved file in docs:", await pg.evaluate("W11FS.children('docs').map(n=>n.name)"))
        # Desfazer no bloco de notas
        await nt.locator("textarea").click()
        await nt.locator("textarea").type(" extra")
        await pg.wait_for_timeout(450)
        await pg.keyboard.press("Control+z"); await pg.wait_for_timeout(100)
        print("undo result:", repr(await nt.locator("textarea").input_value()))
        # Alt+Tab alterna para a janela anterior
        act_before = await pg.evaluate("W11Windows.active().appId")
        await pg.keyboard.down("Alt"); await pg.keyboard.press("Tab"); await pg.keyboard.up("Alt")
        act_after = await pg.evaluate("W11Windows.active().appId")
        print("alt+tab:", act_before, "->", act_after)
        # Menu de contexto na área de trabalho: organizar por nome
        await pg.evaluate("W11Windows.showDesktop()"); await pg.wait_for_timeout(200); await pg.mouse.click(60, 600, button="right"); await pg.wait_for_timeout(150)
        print("context menu visible:", await pg.is_visible("#context-menu"))
        await pg.locator("#context-menu button", has_text="Organizar ícones por nome").click()
        await pg.wait_for_timeout(200)
        print("toast/no errors so far:", errors or "none")
        # Win+D minimiza tudo
        await pg.keyboard.down("Meta"); await pg.keyboard.press("d"); await pg.keyboard.up("Meta")
        await pg.wait_for_timeout(200)
        print("after Win+D minimized:", await pg.locator(".win.minimized").count(), "of", await pg.locator(".win").count())
        # Volta a janela: visão de tarefas
        print("ERRORS:", errors or "none")
        await b.close()
asyncio.run(main())
