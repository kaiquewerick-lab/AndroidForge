# -*- coding: utf-8 -*-
import asyncio, sys
from playwright.async_api import async_playwright

# Gerado para o projeto: caminho relativo a este arquivo (não depende de /home/...)
import pathlib
URL = (pathlib.Path(__file__).resolve().parent.parent / "web" / "index.html").as_uri()

async def main():
    async with async_playwright() as p:
        try:
            browser = await p.chromium.launch(args=["--no-sandbox"])
        except Exception as e:
            print("NO_BROWSER", str(e)[:300]); return
        page = await browser.new_page(viewport={"width": 390, "height": 844})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append("console:" + m.text) if m.type == "error" else None)
        await page.goto(URL)
        await page.wait_for_timeout(500)
        icons = await page.locator(".icon").count()
        print("icons on desktop:", icons)
        # Abre Explorador via ícone (duplo toque simulado)
        await page.locator('.icon[data-id="int:explorer"]').dblclick()
        await page.wait_for_timeout(300)
        print("windows after open explorer:", await page.locator(".win").count())
        # Abre Calculadora pelo menu Iniciar
        await page.click("#btn-start")
        await page.wait_for_timeout(300)
        print("start open:", await page.is_visible("#start-menu"))
        await page.fill("#start-search", "calc")
        await page.wait_for_timeout(100)
        await page.locator("#start-results .app-row").first.click()
        await page.wait_for_timeout(300)
        print("windows after calc:", await page.locator(".win").count())
        # Calcula 2+3*4 pela calculadora
        await page.keyboard.type("2+3*4")
        await page.keyboard.press("Enter")
        await page.wait_for_timeout(100)
        print("calc result:", await page.locator(".calc-display .result").inner_text())
        # Minimiza e restaura via barra de tarefas
        await page.locator(".win").last.locator(".btn-min").click()
        await page.wait_for_timeout(250)
        print("minimized count:", await page.locator(".win.minimized").count())
        await page.locator("#taskbar-apps .tb-btn").last.click()
        await page.wait_for_timeout(250)
        print("minimized after restore:", await page.locator(".win.minimized").count())
        # Win+D minimiza tudo; Alt+F4 fecha a ativa
        await page.keyboard.press("Alt+F4")
        await page.wait_for_timeout(200)
        print("windows after Alt+F4:", await page.locator(".win").count())
        # Win (Meta) isolada alterna menu Iniciar
        await page.keyboard.down("Meta"); await page.keyboard.up("Meta")
        await page.wait_for_timeout(250)
        print("start after Meta tap:", await page.is_visible("#start-menu"))
        await page.keyboard.press("Escape")
        await page.wait_for_timeout(250)
        # Config: tema escuro persiste após reload
        await page.evaluate("localStorage.setItem('w11l:theme', JSON.stringify('dark'))")
        await page.reload(); await page.wait_for_timeout(400)
        print("theme after reload:", await page.evaluate("document.documentElement.dataset.theme"))
        # Pinned: 10 apps Android (mock)
        pinned = await page.evaluate("W11Desktop.getPinned().length")
        print("pinned android apps:", pinned)
        # Explorador: criar pasta via dialog (prompt)
        await page.evaluate("W11Apps.open('explorer')")
        await page.wait_for_timeout(200)
        print("errors:", errors if errors else "none")
        await browser.close()

asyncio.run(main())
