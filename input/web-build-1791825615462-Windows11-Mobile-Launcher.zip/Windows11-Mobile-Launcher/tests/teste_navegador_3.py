# -*- coding: utf-8 -*-
import asyncio
from playwright.async_api import async_playwright
# Gerado para o projeto: caminho relativo a este arquivo (não depende de /home/...)
import pathlib
URL = (pathlib.Path(__file__).resolve().parent.parent / "web" / "index.html").as_uri()
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--no-sandbox"])
        pg = await b.new_page(viewport={"width": 390, "height": 844})
        errors = []
        pg.on("pageerror", lambda e: errors.append(str(e)))
        await pg.goto(URL); await pg.wait_for_timeout(400)
        await pg.evaluate("W11Apps.open('settings')"); await pg.wait_for_timeout(250)
        for page_id in ["personalizacao","papel","temas","barra","exibicao","apps","sistema","sobre"]:
            await pg.locator(f'.settings-nav [data-page="{page_id}"]').click()
            await pg.wait_for_timeout(60)
            title = await pg.locator(".settings-main h2").inner_text()
            print("page", page_id, "->", title)
        # Escolhe papel de parede 'night' e modo 'fit'
        await pg.locator('.settings-nav [data-page="papel"]').click()
        await pg.locator('[data-preset="night"]').click()
        await pg.wait_for_timeout(80)
        print("wallpaper bg:", (await pg.evaluate("document.getElementById('wallpaper').style.backgroundImage"))[:60])
        await pg.locator('[data-set="mode"][data-val="fit"]').click()
        print("wallpaper class:", await pg.evaluate("document.getElementById('wallpaper').className"))
        # Tema escuro + cor de destaque
        await pg.locator('.settings-nav [data-page="temas"]').click()
        await pg.locator('[data-set="theme"][data-val="dark"]').click()
        await pg.locator('[data-accent="#8764b8"]').click()
        print("theme/accent:", await pg.evaluate("[document.documentElement.dataset.theme, getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()]"))
        # Barra à esquerda
        await pg.locator('.settings-nav [data-page="barra"]').click()
        await pg.locator('[data-set="align"][data-val="left"]').click()
        print("taskbar align:", await pg.evaluate("document.getElementById('taskbar').dataset.align"))
        # Ícones grandes
        await pg.locator('.settings-nav [data-page="exibicao"]').click()
        await pg.locator('[data-set="iconSize"][data-val="large"]').click()
        print("icons attr:", await pg.evaluate("document.documentElement.dataset.icons"))
        # Animações off
        await pg.locator('.settings-nav [data-page="personalizacao"]').click()
        await pg.locator('[data-toggle="animations"]').click()
        print("anim attr:", await pg.evaluate("document.documentElement.dataset.anim"))
        # Persistência após reload
        await pg.reload(); await pg.wait_for_timeout(400)
        print("after reload theme/align/icons:", await pg.evaluate("[document.documentElement.dataset.theme, document.getElementById('taskbar').dataset.align, document.documentElement.dataset.icons]"))
        # Ajustar uma janela para tela cheia e ver botão maximizar sair
        await pg.evaluate("W11Apps.open('calculator')"); await pg.wait_for_timeout(200)
        await pg.evaluate("W11Windows.toggleFullscreen(W11Windows.active())")
        await pg.locator(".win .btn-max").last.click(); await pg.wait_for_timeout(200)
        print("state after maximize-from-fullscreen:", await pg.evaluate("W11Windows.active().state"))
        # Lixeira via Executar
        await pg.evaluate("W11Apps.open('run')"); await pg.wait_for_timeout(150)
        await pg.fill(".win [data-role='cmd']", "lixeira"); await pg.keyboard.press("Enter")
        await pg.wait_for_timeout(200)
        print("trash opened:", await pg.evaluate("W11Windows.active().title"))
        print("ERRORS:", errors or "none")
        await b.close()
asyncio.run(main())
