/*
 * ui.js - Componentes compartilhados: menu de contexto, diálogos e avisos (toast).
 * Todos aceitam mouse, toque e teclado (setas, Enter, Esc).
 */
(function () {
  "use strict";

  var menuEl = null;
  var menuItems = [];
  var menuIndex = -1;
  var menuClose = null;

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function highlight(i) {
    var btns = menuEl.querySelectorAll("button[role=menuitem]");
    btns.forEach(function (b) { b.classList.remove("kb-focus"); });
    if (i >= 0 && btns[i]) {
      btns[i].classList.add("kb-focus");
      btns[i].scrollIntoView({ block: "nearest" });
    }
    menuIndex = i;
  }

  var UI = {
    /**
     * Mostra menu de contexto em (x, y).
     * items: [{ label, action, disabled }] ou { sep: true }
     */
    showMenu: function (x, y, items) {
      UI.hideMenu();
      menuEl = document.getElementById("context-menu");
      menuEl.innerHTML = "";
      menuItems = [];
      items.forEach(function (it) {
        if (it.sep) {
          menuEl.appendChild(document.createElement("hr"));
          return;
        }
        var b = document.createElement("button");
        b.setAttribute("role", "menuitem");
        b.textContent = it.label;
        if (it.disabled) b.disabled = true;
        b.addEventListener("click", function (e) {
          e.stopPropagation();
          UI.hideMenu();
          if (!it.disabled && it.action) it.action();
        });
        menuEl.appendChild(b);
        menuItems.push(it);
      });
      menuEl.classList.remove("hidden");
      // Mantém o menu dentro da tela
      var w = menuEl.offsetWidth, h = menuEl.offsetHeight;
      var left = Math.min(x, window.innerWidth - w - 8);
      var top = Math.min(y, window.innerHeight - h - 8);
      menuEl.style.left = Math.max(8, left) + "px";
      menuEl.style.top = Math.max(8, top) + "px";
      highlight(-1);
      menuClose = true;
    },

    hideMenu: function () {
      if (!menuEl) menuEl = document.getElementById("context-menu");
      menuEl.classList.add("hidden");
      menuEl.innerHTML = "";
      menuItems = [];
      menuIndex = -1;
      menuClose = null;
    },

    isMenuOpen: function () {
      return !!menuClose;
    },

    /** Navegação por teclado no menu aberto. Retorna true se tratou a tecla. */
    menuKey: function (key) {
      if (!menuClose) return false;
      var enabled = [];
      menuItems.forEach(function (it, i) { if (!it.disabled) enabled.push(i); });
      if (key === "ArrowDown" || key === "ArrowUp") {
        if (!enabled.length) return true;
        var cur = enabled.indexOf(menuIndex);
        var next = key === "ArrowDown" ? (cur + 1) % enabled.length : (cur <= 0 ? enabled.length - 1 : cur - 1);
        highlight(enabled[next]);
        return true;
      }
      if (key === "Enter" && menuIndex >= 0) {
        var it = menuItems[menuIndex];
        UI.hideMenu();
        if (it && !it.disabled && it.action) it.action();
        return true;
      }
      if (key === "Escape") { UI.hideMenu(); return true; }
      return false;
    },

    /**
     * Diálogo modal simples.
     * opts: { title, message, buttons: [{label, value, kind}], input: {value, placeholder} }
     * Retorna Promise com o valor do botão (ou o texto digitado, se houver input).
     */
    dialog: function (opts) {
      return new Promise(function (resolve) {
        var root = document.getElementById("dialog-root");
        var back = document.createElement("div");
        back.className = "dialog-backdrop";
        var inputHtml = opts.input
          ? '<input class="field" id="dlg-input" value="' + esc(opts.input.value || "") + '" placeholder="' + esc(opts.input.placeholder || "") + '" autocomplete="off">'
          : "";
        var buttons = (opts.buttons || [{ label: "OK", value: "ok", kind: "primary" }]);
        back.innerHTML =
          '<div class="dialog" role="dialog" aria-modal="true">' +
          '<h2>' + esc(opts.title || "") + '</h2>' +
          (opts.message ? '<p>' + esc(opts.message) + '</p>' : '') +
          inputHtml +
          '<div class="actions">' +
          buttons.map(function (b, i) {
            return '<button class="btn ' + (b.kind || "") + '" data-i="' + i + '">' + esc(b.label) + '</button>';
          }).join("") +
          '</div></div>';
        root.appendChild(back);

        var input = back.querySelector("#dlg-input");
        back.querySelectorAll("button[data-i]").forEach(function (btn) {
          btn.addEventListener("click", function () {
            var i = Number(btn.dataset.i);
            var b = buttons[i];
            var val = input ? (b.value === false ? null : input.value) : b.value;
            back.remove();
            resolve(val);
          });
        });
        back.addEventListener("keydown", function (e) {
          if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); back.remove(); resolve(null); }
          if (e.key === "Enter" && input && document.activeElement === input) {
            e.preventDefault(); e.stopPropagation();
            back.remove(); resolve(input.value);
          }
        });
        setTimeout(function () { (input || back.querySelector(".btn")).focus(); }, 30);
      });
    },

    confirm: function (title, message, okLabel) {
      return UI.dialog({
        title: title, message: message,
        buttons: [
          { label: okLabel || "Confirmar", value: true, kind: "primary" },
          { label: "Cancelar", value: false }
        ]
      }).then(function (v) { return v === true; });
    },

    prompt: function (title, value, placeholder) {
      return UI.dialog({
        title: title,
        input: { value: value || "", placeholder: placeholder || "" },
        buttons: [
          { label: "OK", value: true, kind: "primary" },
          { label: "Cancelar", value: false }
        ]
      });
    },

    /** Aviso temporário. kind: "ok" | "error" | "" */
    toast: function (message, kind, ms) {
      var root = document.getElementById("toast-root");
      var t = document.createElement("div");
      t.className = "toast " + (kind || "");
      t.textContent = message;
      root.appendChild(t);
      setTimeout(function () { t.remove(); }, ms || 3200);
    },

    escape: esc
  };

  window.W11UI = UI;
})();
