/*
 * keyboard.js - Atalhos de teclado do launcher.
 *
 * Como funciona:
 *   - Um único listener de "keydown" e "keyup" no documento (sem duplicidade:
 *     o Android NÃO repassa teclas à página por outro caminho; a ponte nativa
 *     não intercepta teclado, então cada tecla é tratada apenas aqui).
 *   - Atalhos globais são ignorados enquanto o foco está em campo de texto
 *     (input, textarea ou contenteditable), exceto os marcados como intencionais.
 *   - A tecla Windows ("Meta") é tratada assim: se for pressionada e solta sem
 *     outra tecla no meio, abre ou fecha o menu Iniciar.
 *
 * Limitações reais (ver docs/LIMITATIONS.md):
 *   - Muitos sistemas Android e teclados consomem a tecla Windows/Meta antes
 *     de chegar à WebView. Nesses casos, Win+letra não funciona; use o botão
 *     Iniciar da barra de tarefas.
 *   - Não há captura global de teclas fora do launcher.
 */
(function () {
  "use strict";

  var winDown = false;
  var winUsed = false;
  var altDown = false;

  function isTextField(el) {
    if (!el) return false;
    var tag = el.tagName;
    if (tag === "TEXTAREA") return true;
    if (tag === "INPUT") {
      var t = (el.type || "text").toLowerCase();
      return ["checkbox", "radio", "range", "button", "submit", "color", "file"].indexOf(t) === -1;
    }
    return !!el.isContentEditable;
  }

  function activeWin() {
    return W11Windows.active();
  }

  function dispatchToActive(name, detail) {
    var w = activeWin();
    if (!w || !w.body) return false;
    w.body.dispatchEvent(new CustomEvent(name, { detail: detail || {}, bubbles: false }));
    return true;
  }

  function closeTransient() {
    var handled = false;
    if (W11UI.isMenuOpen()) { W11UI.hideMenu(); handled = true; }
    if (W11Taskbar.isStartOpen()) { W11Taskbar.closeStart(); handled = true; }
    var flyouts = ["notif-panel", "quick-panel", "calendar-panel"].some(function (id) {
      return !document.getElementById(id).classList.contains("hidden");
    });
    if (flyouts) { W11Taskbar.hideFlyouts(); handled = true; }
    return handled;
  }

  function snapOrRestore(dir) {
    var w = activeWin();
    if (!w) return;
    if (dir === "left" || dir === "right") { W11Windows.snap(w, dir); return; }
    if (dir === "up") { if (w.state !== "maximized") W11Windows.toggleMaximize(w); return; }
    if (dir === "down") {
      if (w.state === "maximized" || w.state === "fullscreen") { W11Windows.restore(w); return; }
      W11Windows.minimize(w);
    }
  }

  function winCombo(e) {
    var k = e.key;
    switch (k) {
      case "e": case "E": W11Apps.open("explorer"); return true;
      case "d": case "D": W11Windows.showDesktop(); return true;
      case "r": case "R": W11Apps.open("run"); return true;
      case "i": case "I": W11Apps.open("settings"); return true;
      case "s": case "S": W11Taskbar.openStart(); return true;
      case "Tab": W11Taskbar.showTaskView(); return true;
      case "ArrowLeft": snapOrRestore("left"); return true;
      case "ArrowRight": snapOrRestore("right"); return true;
      case "ArrowUp": snapOrRestore("up"); return true;
      case "ArrowDown": snapOrRestore("down"); return true;
    }
    return false;
  }

  /** Alt+Tab: alterna para a janela anterior do histórico. */
  function altTab(e) {
    e.preventDefault();
    W11Windows.cycle();
  }

  /** Alt+F4: fecha a janela ativa (nunca o próprio launcher). */
  function altF4(e) {
    e.preventDefault();
    var a = activeWin();
    if (a) W11Windows.close(a);
    else W11UI.toast("Nenhuma janela interna aberta.", "", 1800);
  }

  /** F11: tela cheia da janela ativa ou modo imersivo do launcher. */
  function f11(e) {
    e.preventDefault();
    var fw = activeWin();
    if (fw) { W11Windows.toggleFullscreen(fw); return; }
    var on = !document.documentElement.classList.contains("immersive");
    if (W11Bridge.setImmersive(on)) document.documentElement.classList.toggle("immersive", on);
  }

  function onKeyDown(e) {
    var target = e.target;
    var inText = isTextField(target);

    // Teclas de navegação em menus abertos têm prioridade
    if (W11UI.isMenuOpen() && W11UI.menuKey(e.key)) { e.preventDefault(); return; }
    if (W11Taskbar.isStartOpen() && !inText && W11Taskbar.startKey(e.key)) { e.preventDefault(); return; }
    if (W11Taskbar.isStartOpen() && inText && (e.key === "ArrowDown" || e.key === "Enter")) {
      if (W11Taskbar.startKey(e.key)) { e.preventDefault(); return; }
    }

    if (e.key === "Meta" || e.key === "OS") {
      if (!winDown) { winDown = true; winUsed = false; }
      return;
    }

    if (e.key === "Alt") { altDown = true; return; }

    // Escape: fecha menus e painéis; em tela cheia volta ao normal
    if (e.key === "Escape") {
      if (closeTransient()) { e.preventDefault(); return; }
      var w = activeWin();
      if (w && w.state === "fullscreen") { W11Windows.toggleFullscreen(w); e.preventDefault(); return; }
      // Em campos e ferramentas, Esc é tratado pela própria ferramenta
      return;
    }

    // Ctrl+Shift+Esc: Gerenciador de tarefas interno (intencional mesmo em campos)
    if (e.ctrlKey && e.shiftKey && e.key === "Escape") {
      e.preventDefault();
      W11Apps.open("taskmanager");
      return;
    }

    // Atalhos de GERENCIAMENTO DE JANELAS são intencionais, então valem também em campos de texto.
    // Teclas de digitação (letras, números, Delete, Backspace) continuam sendo entregues ao campo.
    if (winDown) {
      winUsed = true;
      if (winCombo(e)) e.preventDefault();
      return;
    }
    if (altDown && e.key === "Tab") { altTab(e); return; }
    if (altDown && e.key === "F4") { altF4(e); return; }
    if (e.key === "F11") { f11(e); return; }

    if (inText) return;

    // Ctrl+Z / Ctrl+Y: repassados às ferramentas que os suportam (campos nativos cuidam do próprio)
    if (e.ctrlKey && (e.key === "z" || e.key === "Z")) {
      if (dispatchToActive("w11:undo")) e.preventDefault();
      return;
    }
    if (e.ctrlKey && (e.key === "y" || e.key === "Y")) {
      if (dispatchToActive("w11:redo")) e.preventDefault();
      return;
    }
    if (e.key === "F2") {
      if (dispatchToActive("w11:rename")) e.preventDefault();
      return;
    }
    if (e.key === "Delete") {
      if (dispatchToActive("w11:delete")) e.preventDefault();
    }
  }

  function onKeyUp(e) {
    if (e.key === "Meta" || e.key === "OS") {
      if (winDown && !winUsed) {
        // Tecla Windows isolada: alterna o menu Iniciar
        W11Taskbar.isStartOpen() ? W11Taskbar.closeStart() : W11Taskbar.openStart();
      }
      winDown = false;
      winUsed = false;
      return;
    }
    if (e.key === "Alt") altDown = false;
  }

  var K = {
    init: function () {
      document.addEventListener("keydown", onKeyDown, true);
      document.addEventListener("keyup", onKeyUp, true);
      // Ao perder o foco da janela (ex.: troca de app), zera as teclas modificadoras
      window.addEventListener("blur", function () { winDown = false; altDown = false; });
    },
    isTextField: isTextField
  };

  window.W11Keys = K;
})();
