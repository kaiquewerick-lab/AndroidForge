/*
 * bridge.js - Camada de acesso ao Android.
 *
 * A WebView expõe apenas o objeto "LauncherBridge" (addJavascriptInterface),
 * com um conjunto FIXO de métodos. Esta camada:
 *   - valida todos os argumentos antes de enviá-los ao Android;
 *   - oferece um modo simulado (mock) quando a página roda fora do APK,
 *     por exemplo abrindo web/index.html no navegador para testes.
 *
 * O Android chama window.onAppsChanged() quando a lista de apps muda.
 */
(function () {
  "use strict";

  var PKG_RE = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/;
  var SETTINGS_KINDS = ["wifi", "bluetooth", "display", "sound", "home", "apps", "battery", "main"];

  var native = (typeof window.LauncherBridge !== "undefined" && window.LauncherBridge) || null;
  var isNative = !!native;

  // Lista simulada usada apenas no navegador
  var MOCK_APPS = [
    { pkg: "com.example.mail", label: "E-mail" },
    { pkg: "com.example.camera", label: "Câmera" },
    { pkg: "com.example.gallery", label: "Galeria" },
    { pkg: "com.example.music", label: "Música" },
    { pkg: "com.example.clock", label: "Relógio" },
    { pkg: "com.example.maps", label: "Mapas" },
    { pkg: "com.example.calendar", label: "Agenda" },
    { pkg: "com.example.files", label: "Arquivos do aparelho" },
    { pkg: "com.example.browser", label: "Navegador" },
    { pkg: "com.example.contacts", label: "Contatos" },
    { pkg: "com.example.notes", label: "Notas do aparelho" },
    { pkg: "com.example.weather", label: "Clima" }
  ];

  function safeParse(text, fallback) {
    try { return JSON.parse(text); } catch (e) { return fallback; }
  }

  var Bridge = {
    isNative: isNative,

    /** Lista de apps: [{pkg, label}], já ordenada pelo Android. */
    getApps: function () {
      if (!isNative) return MOCK_APPS.slice();
      var list = safeParse(native.getApps() || "[]", []);
      return Array.isArray(list) ? list.filter(function (a) {
        return a && PKG_RE.test(a.pkg) && typeof a.label === "string";
      }) : [];
    },

    /** Ícone como data URL (PNG). Retorna "" se indisponível. */
    getIcon: function (pkg) {
      if (!PKG_RE.test(pkg)) return "";
      if (!isNative) return "";
      try { return native.getIcon(pkg) || ""; } catch (e) { return ""; }
    },

    /**
     * Abre um aplicativo Android pelo intent oficial de inicialização.
     * Retorna { ok: true } ou { ok: false, message }.
     */
    launchApp: function (pkg) {
      if (!PKG_RE.test(pkg)) return { ok: false, message: "Identificador de pacote inválido." };
      if (!isNative) return { ok: false, message: "Aplicativos Android só abrem dentro do APK. (Modo de visualização no navegador.)" };
      var res = String(native.launchApp(pkg) || "");
      if (res === "ok") return { ok: true };
      return { ok: false, message: res.replace(/^error:/, "") || "Não foi possível abrir este aplicativo." };
    },

    /** Abre uma tela de configurações do Android (lista branca). */
    openSystemSettings: function (kind) {
      if (SETTINGS_KINDS.indexOf(kind) === -1) return false;
      if (!isNative) return false;
      try { native.openSystemSettings(kind); return true; } catch (e) { return false; }
    },

    /** Ativa ou desativa o modo imersivo (somente quando o Android permite). */
    setImmersive: function (enabled) {
      if (!isNative) return false;
      try { return !!native.setImmersive(!!enabled); } catch (e) { return false; }
    },

    /** Pede ao Android para atualizar a lista de apps (o retorno chega em onAppsChanged). */
    refreshApps: function () {
      if (!isNative) return;
      try { native.refreshApps(); } catch (e) { /* ignorar */ }
    },

    /** Sai do launcher (finish na Activity HOME). */
    exitLauncher: function () {
      if (!isNative) return false;
      try { native.exitLauncher(); return true; } catch (e) { return false; }
    },

    /**
     * Salva um arquivo exportado (ex.: desenho do Paint) na pasta privada
     * do app, em Imagens. Retorna o caminho salvo ou lança erro.
     */
    exportFile: function (name, mime, base64) {
      var safeName = String(name || "arquivo").replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 80);
      if (!isNative) {
        // Fallback no navegador: download comum
        var a = document.createElement("a");
        a.href = "data:" + mime + ";base64," + base64;
        a.download = safeName;
        document.body.appendChild(a);
        a.click();
        a.remove();
        return "download:" + safeName;
      }
      var res = String(native.exportFile(safeName, mime, base64) || "");
      if (res.indexOf("error:") === 0) throw new Error(res.slice(6));
      return res;
    }
  };

  window.W11Bridge = Bridge;
})();
