/*
 * notepad.js - Bloco de Notas.
 * - Edita arquivos de texto do sistema interno (Documentos, etc.).
 * - Salvar grava no launcher; "Salvar como" cria um novo arquivo em Documentos.
 * - "Abrir do aparelho" usa o seletor de arquivos do Android (apenas o arquivo escolhido é lido).
 * - Desfazer / refazer com histórico próprio (Ctrl+Z / Ctrl+Y).
 */
(function () {
  "use strict";

  window.W11Impl = window.W11Impl || {};

  window.W11Impl.notepad = function (body, api, opts) {
    opts = opts || {};
    var fileId = opts.fileId || null;
    var saved = "";
    var history = [""];
    var hIndex = 0;
    var debounce = null;
    var dirty = false;

    body.innerHTML =
      '<div class="app-root">' +
        '<div class="toolbar">' +
          '<button class="btn" data-act="new">Novo</button>' +
          '<button class="btn" data-act="open">Abrir do aparelho</button>' +
          '<button class="btn primary" data-act="save">Salvar</button>' +
          '<button class="btn" data-act="saveas">Salvar como</button>' +
          '<span class="sep"></span>' +
          '<button class="btn" data-act="undo" title="Ctrl+Z">Desfazer</button>' +
          '<button class="btn" data-act="redo" title="Ctrl+Y">Refazer</button>' +
          '<span class="sep"></span>' +
          '<button class="btn" data-act="export">Exportar .txt</button>' +
        '</div>' +
        '<textarea class="editor" spellcheck="false" aria-label="Texto"></textarea>' +
        '<div class="status-bar" data-role="status"></div>' +
      '</div>';

    var ta = body.querySelector("textarea");
    var statusEl = body.querySelector('[data-role="status"]');
    var fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = ".txt,.md,.csv,.json,.html,.css,.js,text/*";
    fileInput.style.display = "none";
    body.appendChild(fileInput);

    function currentName() {
      var n = fileId ? W11FS.get(fileId) : null;
      return n ? n.name : "Sem título";
    }

    function refreshUi() {
      var name = currentName();
      api.setTitle("Bloco de Notas - " + name + (dirty ? " *" : ""));
      statusEl.textContent = (fileId ? W11FS.path(fileId) : "Não salvo") + " • " + ta.value.length + " caractere(s)" +
        (dirty ? " • alterações não salvas" : "");
      body.querySelector('[data-act="undo"]').disabled = hIndex <= 0;
      body.querySelector('[data-act="redo"]').disabled = hIndex >= history.length - 1;
    }

    function pushHistory() {
      var v = ta.value;
      if (history[hIndex] === v) return;
      history = history.slice(0, hIndex + 1);
      history.push(v);
      if (history.length > 200) history.shift();
      hIndex = history.length - 1;
    }

    // Rascunho automático: alterações não salvas são preservadas ao fechar e reabrir o app
    function saveDraft() {
      if (dirty) W11Storage.set("notepadDraft", { fileId: fileId, value: ta.value });
      else W11Storage.remove("notepadDraft");
    }

    function onInput() {
      dirty = ta.value !== saved;
      clearTimeout(debounce);
      debounce = setTimeout(function () { pushHistory(); saveDraft(); }, 350);
      refreshUi();
    }

    function undo() {
      clearTimeout(debounce); pushHistory();
      if (hIndex <= 0) return;
      hIndex--;
      ta.value = history[hIndex];
      dirty = ta.value !== saved;
      refreshUi();
    }

    function redo() {
      if (hIndex >= history.length - 1) return;
      hIndex++;
      ta.value = history[hIndex];
      dirty = ta.value !== saved;
      refreshUi();
    }

    function load(id) {
      var n = W11FS.get(id);
      if (!n || n.type !== "file") { W11UI.toast("Arquivo não encontrado.", "error"); return; }
      fileId = id;
      ta.value = n.content || "";
      saved = ta.value;
      history = [saved]; hIndex = 0;
      dirty = false;
      refreshUi();
    }

    function save() {
      if (!fileId) return saveAs();
      var r = W11FS.writeFile(fileId, ta.value);
      if (!r.ok) { W11UI.toast(r.error, "error", 4000); return false; }
      saved = ta.value; dirty = false;
      W11Storage.remove("notepadDraft");
      W11Notify.push("Bloco de Notas", "Arquivo salvo: " + currentName());
      W11UI.toast("Salvo.", "ok", 1400);
      refreshUi();
      return true;
    }

    async function saveAs() {
      var name = await W11UI.prompt("Salvar como", fileId ? currentName() : "Nota.txt", "Nome do arquivo");
      if (name === null) return false;
      if (!/\.[A-Za-z0-9]+$/.test(name)) name += ".txt";
      var r = W11FS.create("docs", name, "file", ta.value);
      if (!r.ok) { W11UI.toast(r.error, "error", 4000); return false; }
      fileId = r.id; saved = ta.value; dirty = false;
      W11Notify.push("Bloco de Notas", "Arquivo criado em Documentos: " + name);
      refreshUi();
      return true;
    }

    async function confirmDiscard() {
      if (!dirty) return true;
      return W11UI.confirm("Alterações não salvas", "Descartar as alterações atuais?", "Descartar");
    }

    async function doAction(act) {
      switch (act) {
        case "new":
          if (await confirmDiscard()) { fileId = null; ta.value = ""; saved = ""; history = [""]; hIndex = 0; dirty = false; refreshUi(); }
          break;
        case "open": fileInput.click(); break;
        case "save": save(); break;
        case "saveas": saveAs(); break;
        case "undo": undo(); break;
        case "redo": redo(); break;
        case "export": {
          var blob = new Blob([ta.value], { type: "text/plain;charset=utf-8" });
          var reader = new FileReader();
          reader.onload = function () {
            try {
              var base64 = String(reader.result).split(",")[1] || "";
              var where = W11Bridge.exportFile((currentName().replace(/\.[^.]+$/, "") || "nota") + ".txt", "text/plain", base64);
              W11UI.toast("Exportado: " + where, "ok", 4000);
            } catch (e) { W11UI.toast("Não foi possível exportar: " + e.message, "error"); }
          };
          reader.readAsDataURL(blob);
          break;
        }
      }
    }

    body.addEventListener("click", function (e) {
      var b = e.target.closest("[data-act]");
      if (b && body.contains(b) && !b.disabled) doAction(b.dataset.act);
    });

    fileInput.addEventListener("change", function () {
      var f = fileInput.files && fileInput.files[0];
      fileInput.value = "";
      if (!f) return;
      if (f.size > 1024 * 1024) { W11UI.toast("Arquivo grande demais (máximo 1 MB).", "error", 4000); return; }
      var reader = new FileReader();
      reader.onload = async function () {
        if (!(await confirmDiscard())) return;
        fileId = null;
        ta.value = String(reader.result || "");
        saved = ""; dirty = true; history = [ta.value]; hIndex = 0;
        refreshUi();
        W11UI.toast("Arquivo aberto. Use Salvar como para guardá-lo no launcher.", "ok", 3500);
      };
      reader.readAsText(f);
    });

    ta.addEventListener("input", onInput);
    ta.addEventListener("keydown", function (e) {
      var mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      var k = e.key.toLowerCase();
      if (k === "z") { e.preventDefault(); undo(); }
      else if (k === "y") { e.preventDefault(); redo(); }
      else if (k === "s") { e.preventDefault(); save(); }
    });

    body.addEventListener("w11:undo", undo);
    body.addEventListener("w11:redo", redo);

    if (fileId) {
      load(fileId);
    } else {
      var draft = W11Storage.get("notepadDraft", null);
      if (draft && typeof draft.value === "string") {
        fileId = draft.fileId && W11FS.get(draft.fileId) ? draft.fileId : null;
        ta.value = draft.value;
        saved = fileId ? (W11FS.get(fileId).content || "") : "";
        dirty = ta.value !== saved;
        history = [ta.value]; hIndex = 0;
      }
      refreshUi();
    }
    ta.focus();

    return {
      destroy: function () { /* alterações não salvas são descartadas ao fechar */ },
      isDirty: function () { return dirty; }
    };
  };
})();
