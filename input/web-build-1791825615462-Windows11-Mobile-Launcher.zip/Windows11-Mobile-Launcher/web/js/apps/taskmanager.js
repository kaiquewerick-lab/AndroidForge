/*
 * taskmanager.js - Gerenciador de tarefas INTERNO.
 * Lista apenas as janelas e ferramentas abertas dentro do launcher.
 * Não mostra CPU, memória ou processos Android: o launcher não tem
 * permissão para consultar essas métricas.
 */
(function () {
  "use strict";

  window.W11Impl = window.W11Impl || {};

  var STATE_LABEL = { normal: "Em execução", maximized: "Maximizada", fullscreen: "Tela cheia", minimized: "Minimizada" };

  window.W11Impl.taskmanager = function (body, api) {
    body.innerHTML =
      '<div class="app-root">' +
        '<div class="toolbar">' +
          '<span class="muted" data-role="count"></span>' +
          '<span style="flex:1"></span>' +
          '<button class="btn" data-act="showall">Mostrar todas</button>' +
          '<button class="btn" data-act="desktop">Mostrar área de trabalho</button>' +
        '</div>' +
        '<div class="pad" style="overflow:auto;flex:1">' +
          '<table class="tm-table"><thead><tr><th>Nome</th><th>Estado</th><th style="width:1%"></th></tr></thead><tbody data-role="rows"></tbody></table>' +
          '<p class="muted" style="margin-top:14px">Mostra apenas janelas do Launcher. Métricas de CPU e memória de outros aplicativos não estão disponíveis.</p>' +
        '</div>' +
      '</div>';

    var rows = body.querySelector('[data-role="rows"]');
    var countEl = body.querySelector('[data-role="count"]');

    function draw() {
      var list = W11Windows.list();
      countEl.textContent = list.length + " janela(s) interna(s)";
      rows.innerHTML = "";
      if (!list.length) {
        rows.innerHTML = '<tr><td colspan="3" class="muted">Nenhuma janela aberta.</td></tr>';
        return;
      }
      list.forEach(function (w) {
        var tr = document.createElement("tr");
        tr.innerHTML = '<td></td><td></td><td></td>';
        tr.children[0].textContent = (w.icon || "") + "  " + w.title;
        tr.children[1].textContent = STATE_LABEL[w.state] || w.state;

        var actions = document.createElement("div");
        actions.style.display = "flex";
        actions.style.gap = "6px";
        var sw = document.createElement("button");
        sw.className = "btn";
        sw.textContent = "Ir para";
        sw.addEventListener("click", function () { W11Windows.restore(w); });
        var cl = document.createElement("button");
        cl.className = "btn danger";
        cl.textContent = "Fechar";
        cl.addEventListener("click", function () { W11Windows.close(w); });
        actions.appendChild(sw);
        actions.appendChild(cl);
        tr.children[2].appendChild(actions);
        rows.appendChild(tr);
      });
    }

    body.addEventListener("click", function (e) {
      var b = e.target.closest("[data-act]");
      if (!b) return;
      if (b.dataset.act === "showall") W11Windows.showAll();
      if (b.dataset.act === "desktop") W11Windows.showDesktop();
    });

    var unsubscribe = W11Windows.onChange(draw);
    draw();
    api.setTitle("Gerenciador de tarefas");

    return {
      destroy: function () { unsubscribe(); }
    };
  };
})();
