/*
 * run.js - Janela Executar.
 * Aceita SOMENTE nomes de ferramentas internas (lista fechada abaixo).
 * Não executa comandos de terminal nem simula um shell do Windows.
 */
(function () {
  "use strict";

  window.W11Impl = window.W11Impl || {};

  // Lista branca: texto digitado -> ID de ferramenta interna
  var COMMANDS = {
    "calc": "calculator", "calculadora": "calculator",
    "notepad": "notepad", "bloco": "notepad", "bloco de notas": "notepad", "notas": "notepad",
    "paint": "paint", "desenho": "paint", "mspaint": "paint",
    "explorer": "explorer", "explorador": "explorer", "arquivos": "explorer",
    "lixeira": "lixeira",
    "settings": "settings", "config": "settings", "configuracoes": "settings", "configurações": "settings", "ms-settings:": "settings",
    "taskmgr": "taskmanager", "gerenciador": "taskmanager", "gerenciador de tarefas": "taskmanager",
    "personalizar": "personalizar"
  };

  window.W11Impl.run = function (body, api) {
    body.innerHTML =
      '<div class="pad">' +
        '<p class="muted">Digite o nome de uma ferramenta interna. Exemplos: <b>calc</b>, <b>bloco</b>, <b>paint</b>, <b>explorador</b>, <b>configurações</b>, <b>lixeira</b>.</p>' +
        '<div style="display:flex;gap:8px;margin-top:10px">' +
          '<input class="field" data-role="cmd" placeholder="Abrir:" autocomplete="off" autocapitalize="off" spellcheck="false" style="flex:1">' +
          '<button class="btn primary" data-act="ok">OK</button>' +
        '</div>' +
        '<p class="muted" data-role="msg" style="margin-top:12px;min-height:18px"></p>' +
        '<p class="muted" style="margin-top:14px">Por segurança, somente ferramentas do launcher podem ser abertas por aqui.</p>' +
      '</div>';

    var input = body.querySelector('[data-role="cmd"]');
    var msg = body.querySelector('[data-role="msg"]');
    api.setTitle("Executar");

    function run() {
      var key = input.value.trim().toLowerCase();
      if (!key) return;
      var target = COMMANDS[key];
      if (!target) {
        msg.textContent = "Não é possível encontrar “" + input.value.trim() + "”. Este Executar abre apenas ferramentas internas.";
        return;
      }
      msg.textContent = "";
      if (target === "lixeira") { W11Apps.open("explorer", { folderId: W11FS.TRASH }); return; }
      if (target === "personalizar") { W11Apps.open("settings", { page: "personalizacao" }); return; }
      W11Apps.open(target);
    }

    body.addEventListener("click", function (e) {
      if (e.target.closest('[data-act="ok"]')) run();
    });
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); run(); }
    });
    setTimeout(function () { input.focus(); }, 30);

    return { destroy: function () {} };
  };
})();
