/*
 * paint.js - Paint simples.
 * Desenha com mouse ou toque, escolhe cor e espessura, limpa e exporta PNG.
 * A exportação grava o arquivo na pasta privada do app (Android) ou faz
 * download no navegador. Nenhum armazenamento compartilhado é usado.
 */
(function () {
  "use strict";

  window.W11Impl = window.W11Impl || {};

  var COLORS = ["#000000", "#5f5f5f", "#c42b1c", "#e74856", "#ff8c00", "#fce100", "#107c10", "#16c60c", "#0063b1", "#0078d4", "#8764b8", "#ffffff"];

  window.W11Impl.paint = function (body, api) {
    var color = "#0063b1";
    var size = 6;
    var drawing = false;
    var last = null;

    body.innerHTML =
      '<div class="paint-wrap">' +
        '<div class="toolbar">' +
          '<div class="color-grid" data-role="colors" style="display:flex;gap:5px;flex-wrap:wrap"></div>' +
          '<span class="sep"></span>' +
          '<label class="muted" style="display:flex;align-items:center;gap:6px">Espessura ' +
            '<input type="range" min="1" max="40" value="6" data-role="size" style="width:110px"></label>' +
          '<span class="sep"></span>' +
          '<button class="btn" data-act="clear">Limpar</button>' +
          '<button class="btn primary" data-act="export">Exportar PNG</button>' +
        '</div>' +
        '<div class="paint-canvas-wrap"><canvas aria-label="Área de desenho"></canvas></div>' +
        '<div class="status-bar" data-role="status">Desenhe com o dedo, a caneta ou o mouse.</div>' +
      '</div>';

    var wrapEl = body.querySelector(".paint-canvas-wrap");
    var canvas = body.querySelector("canvas");
    var ctx = canvas.getContext("2d");
    var colorsEl = body.querySelector('[data-role="colors"]');
    var sizeEl = body.querySelector('[data-role="size"]');
    var statusEl = body.querySelector('[data-role="status"]');

    COLORS.forEach(function (c) {
      var s = document.createElement("button");
      s.className = "swatch" + (c === color ? " on" : "");
      s.style.background = c;
      s.setAttribute("aria-label", "Cor " + c);
      s.dataset.color = c;
      colorsEl.appendChild(s);
    });

    function refreshSwatches() {
      colorsEl.querySelectorAll(".swatch").forEach(function (s) {
        s.classList.toggle("on", s.dataset.color === color);
      });
    }

    // Redimensiona mantendo o desenho existente
    function resize() {
      var r = wrapEl.getBoundingClientRect();
      var w = Math.max(100, Math.floor(r.width)), h = Math.max(100, Math.floor(r.height));
      if (canvas.width === w && canvas.height === h) return;
      var snapshot = null;
      if (canvas.width && canvas.height) {
        snapshot = document.createElement("canvas");
        snapshot.width = canvas.width; snapshot.height = canvas.height;
        snapshot.getContext("2d").drawImage(canvas, 0, 0);
      }
      canvas.width = w; canvas.height = h;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, w, h);
      if (snapshot) ctx.drawImage(snapshot, 0, 0);
    }

    function pos(ev) {
      var r = canvas.getBoundingClientRect();
      return {
        x: (ev.clientX - r.left) * (canvas.width / r.width),
        y: (ev.clientY - r.top) * (canvas.height / r.height)
      };
    }

    canvas.addEventListener("pointerdown", function (ev) {
      drawing = true;
      canvas.setPointerCapture(ev.pointerId);
      last = pos(ev);
      ctx.beginPath();
      ctx.fillStyle = color;
      ctx.arc(last.x, last.y, size / 2, 0, Math.PI * 2);
      ctx.fill();
      ev.preventDefault();
    });
    canvas.addEventListener("pointermove", function (ev) {
      if (!drawing) return;
      var p = pos(ev);
      ctx.strokeStyle = color;
      ctx.lineWidth = size;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.beginPath();
      ctx.moveTo(last.x, last.y);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
      last = p;
    });
    function endStroke() { drawing = false; last = null; }
    canvas.addEventListener("pointerup", endStroke);
    canvas.addEventListener("pointercancel", endStroke);
    canvas.addEventListener("pointerleave", endStroke);

    colorsEl.addEventListener("click", function (e) {
      var s = e.target.closest(".swatch");
      if (!s) return;
      color = s.dataset.color;
      refreshSwatches();
    });
    sizeEl.addEventListener("input", function () {
      size = Number(sizeEl.value) || 6;
    });

    body.addEventListener("click", function (e) {
      var b = e.target.closest("[data-act]");
      if (!b) return;
      if (b.dataset.act === "clear") {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        statusEl.textContent = "Desenho limpo.";
      } else if (b.dataset.act === "export") {
        exportPng();
      }
    });

    function exportPng() {
      var dataUrl = canvas.toDataURL("image/png");
      var base64 = dataUrl.split(",")[1];
      try {
        var where = W11Bridge.exportFile("desenho-" + Date.now() + ".png", "image/png", base64);
        statusEl.textContent = "Exportado: " + where;
        W11Notify.push("Paint", "Imagem exportada.");
        W11UI.toast("Imagem exportada.", "ok");
      } catch (e) {
        statusEl.textContent = "Falha ao exportar: " + e.message;
        W11UI.toast("Não foi possível exportar a imagem.", "error");
      }
    }

    // Teclado: Ctrl+S exporta
    body.addEventListener("keydown", function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); exportPng(); }
    });

    body.addEventListener("w11:delete", function () {
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    });

    var ro = null;
    if (window.ResizeObserver) {
      ro = new ResizeObserver(resize);
      ro.observe(wrapEl);
    }
    resize();
    api.setTitle("Paint");

    return {
      destroy: function () { if (ro) ro.disconnect(); }
    };
  };
})();
