/*
 * fs.js - Sistema de arquivos INTERNO do launcher.
 *
 * Os arquivos ficam no armazenamento local da WebView (W11Storage, chave "fs").
 * Eles NÃO são o armazenamento real do aparelho. Para trazer um arquivo do
 * celular, use "Importar" no Explorador: o seletor de arquivos do próprio
 * Android abre e apenas o arquivo escolhido é copiado para dentro do launcher.
 *
 * Pastas fixas: Área de Trabalho, Documentos, Imagens e Lixeira.
 */
(function () {
  "use strict";

  var ROOT = "root";
  var TRASH = "trash";
  var NAME_RE = /^[^\\\/:*?"<>|\u0000-\u001f]{1,80}$/;
  var MAX_FILE_CHARS = 1000000; // ~1 MB de texto por arquivo

  function newId() {
    return "n" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  }

  function defaultFs() {
    var nodes = {};
    nodes[ROOT] = { id: ROOT, parent: null, name: "Este launcher", type: "folder", mtime: Date.now() };
    [["desktop", "Área de Trabalho"], ["docs", "Documentos"], ["images", "Imagens"]].forEach(function (p) {
      nodes[p[0]] = { id: p[0], parent: ROOT, name: p[1], type: "folder", mtime: Date.now(), fixed: true };
    });
    nodes[TRASH] = { id: TRASH, parent: ROOT, name: "Lixeira", type: "folder", mtime: Date.now(), fixed: true };
    nodes.welcome = { id: "welcome", parent: "docs", name: "Bem-vindo.txt", type: "file", mtime: Date.now(),
      content: "Este é o seu espaço interno no launcher.\n\nAqui você pode criar pastas e textos com o Explorador e o Bloco de Notas.\nOs itens são salvos neste aparelho e continuam disponíveis após fechar o launcher.\n" };
    return { nodes: nodes };
  }

  var data = null;

  function load() {
    if (data) return data;
    var stored = W11Storage.get("fs", null);
    if (!stored || !stored.nodes || !stored.nodes[ROOT]) stored = defaultFs();
    data = stored;
    return data;
  }

  function save() {
    return W11Storage.set("fs", data);
  }

  function node(id) {
    return load().nodes[id] || null;
  }

  function childrenOf(id) {
    var n = load().nodes;
    return Object.keys(n).map(function (k) { return n[k]; }).filter(function (x) { return x.parent === id; })
      .sort(function (a, b) {
        if (a.type !== b.type) return a.type === "folder" ? -1 : 1;
        return a.name.localeCompare(b.name, "pt-BR", { sensitivity: "base", numeric: true });
      });
  }

  function pathOf(id) {
    var parts = [];
    var cur = node(id);
    while (cur && cur.id !== ROOT) {
      parts.unshift(cur.name);
      cur = cur.parent ? node(cur.parent) : null;
    }
    return "/" + parts.join("/");
  }

  function isInside(id, ancestorId) {
    var cur = node(id);
    while (cur) {
      if (cur.id === ancestorId) return true;
      cur = cur.parent ? node(cur.parent) : null;
    }
    return false;
  }

  function uniqueName(parentId, name, exceptId) {
    var taken = {};
    childrenOf(parentId).forEach(function (c) { if (c.id !== exceptId) taken[c.name.toLowerCase()] = true; });
    if (!taken[name.toLowerCase()]) return name;
    var dot = name.lastIndexOf(".");
    var base = dot > 0 ? name.slice(0, dot) : name;
    var ext = dot > 0 ? name.slice(dot) : "";
    for (var i = 2; i < 1000; i++) {
      var candidate = base + " (" + i + ")" + ext;
      if (!taken[candidate.toLowerCase()]) return candidate;
    }
    return name + "-" + Date.now();
  }

  function validName(name) {
    var t = String(name || "").trim();
    if (!NAME_RE.test(t) || t === "." || t === "..") return null;
    return t;
  }

  var FS = {
    ROOT: ROOT,
    TRASH: TRASH,

    get: node,
    children: childrenOf,
    path: pathOf,
    isTrashed: function (id) { return isInside(id, TRASH); },

    /** Cria pasta ou arquivo. Retorna { ok, id?, error? }. */
    create: function (parentId, name, type, content) {
      var p = node(parentId);
      if (!p || p.type !== "folder" || parentId === TRASH) return { ok: false, error: "Pasta de destino inválida." };
      var clean = validName(name);
      if (!clean) return { ok: false, error: "Nome inválido. Evite \\ / : * ? \" < > |." };
      if (childrenOf(parentId).some(function (c) { return c.name.toLowerCase() === clean.toLowerCase(); })) {
        return { ok: false, error: "Já existe um item com este nome nesta pasta." };
      }
      var id = newId();
      load().nodes[id] = { id: id, parent: parentId, name: clean, type: type, mtime: Date.now(),
        content: type === "file" ? (content || "") : undefined };
      save();
      return { ok: true, id: id };
    },

    rename: function (id, name) {
      var n = node(id);
      if (!n || n.fixed) return { ok: false, error: "Este item não pode ser renomeado." };
      var clean = validName(name);
      if (!clean) return { ok: false, error: "Nome inválido." };
      if (childrenOf(n.parent).some(function (c) { return c.id !== id && c.name.toLowerCase() === clean.toLowerCase(); })) {
        return { ok: false, error: "Já existe um item com este nome." };
      }
      n.name = clean; n.mtime = Date.now(); save();
      return { ok: true };
    },

    writeFile: function (id, content) {
      var n = node(id);
      if (!n || n.type !== "file") return { ok: false, error: "Arquivo não encontrado." };
      if (String(content).length > MAX_FILE_CHARS) return { ok: false, error: "Arquivo grande demais (limite de 1 MB de texto)." };
      n.content = String(content); n.mtime = Date.now();
      return save() ? { ok: true } : { ok: false, error: "Sem espaço de armazenamento local disponível." };
    },

    /** Move itens para a pasta de destino (sem duplicar nomes). */
    move: function (ids, destId) {
      var dest = node(destId);
      if (!dest || dest.type !== "folder" || destId === TRASH) return { ok: false, error: "Destino inválido." };
      var errors = [];
      ids.forEach(function (id) {
        var n = node(id);
        if (!n || n.fixed) { errors.push("item fixo"); return; }
        if (n.type === "folder" && isInside(destId, id)) { errors.push("pasta dentro dela mesma"); return; }
        n.name = uniqueName(destId, n.name, id);
        n.parent = destId; n.mtime = Date.now();
      });
      save();
      return errors.length ? { ok: false, error: "Alguns itens não foram movidos (" + errors[0] + ")." } : { ok: true };
    },

    copy: function (ids, destId) {
      var dest = node(destId);
      if (!dest || dest.type !== "folder" || destId === TRASH) return { ok: false, error: "Destino inválido." };
      var store = load().nodes;
      function clone(id, parentId) {
        var src = node(id);
        var cid = newId();
        var copy = { id: cid, parent: parentId, name: src.name, type: src.type, mtime: Date.now() };
        if (src.type === "file") copy.content = src.content;
        store[cid] = copy;
        if (src.type === "folder") childrenOf(id).forEach(function (c) { clone(c.id, cid); });
        return cid;
      }
      ids.forEach(function (id) {
        var n = node(id);
        if (!n || n.fixed) return;
        if (n.type === "folder" && isInside(destId, id)) return;
        var cid = clone(id, destId);
        store[cid].name = uniqueName(destId, n.name, null);
      });
      save();
      return { ok: true };
    },

    /** Envia itens para a Lixeira, guardando a pasta de origem. */
    trash: function (ids) {
      ids.forEach(function (id) {
        var n = node(id);
        if (!n || n.fixed || n.parent === TRASH) return;
        n.origParent = n.parent;
        n.origName = n.name;
        n.parent = TRASH;
        n.name = uniqueName(TRASH, n.name, id);
        n.mtime = Date.now();
      });
      save();
      return { ok: true };
    },

    /** Restaura da Lixeira para a pasta original (ou Documentos, se ela não existir mais). */
    restore: function (ids) {
      ids.forEach(function (id) {
        var n = node(id);
        if (!n || n.parent !== TRASH) return;
        var target = node(n.origParent) && node(n.origParent).type === "folder" && n.origParent !== TRASH ? n.origParent : "docs";
        n.parent = target;
        n.name = uniqueName(target, n.origName || n.name, id);
        delete n.origParent; delete n.origName;
      });
      save();
      return { ok: true };
    },

    /** Exclui definitivamente (somente itens que já estão na Lixeira). */
    deleteForever: function (ids) {
      var store = load().nodes;
      ids.forEach(function (id) {
        var n = node(id);
        if (!n || n.fixed || n.parent !== TRASH) return;
        (function rm(x) {
          childrenOf(x).forEach(function (c) { rm(c.id); });
          delete store[x];
        })(id);
      });
      save();
      return { ok: true };
    },

    emptyTrash: function () {
      return FS.deleteForever(childrenOf(TRASH).map(function (c) { return c.id; }));
    },

    /** Pesquisa por nome, fora da Lixeira. Retorna [{id, name, type, path}]. */
    search: function (q) {
      var needle = String(q || "").toLowerCase();
      if (!needle) return [];
      var out = [];
      Object.keys(load().nodes).forEach(function (k) {
        var n = load().nodes[k];
        if (n.id === ROOT || n.id === TRASH || isInside(n.id, TRASH)) return;
        if (n.name.toLowerCase().indexOf(needle) !== -1) {
          out.push({ id: n.id, name: n.name, type: n.type, path: pathOf(n.id) });
        }
      });
      return out;
    },

    /** Importa um arquivo de texto escolhido pelo seletor do Android. */
    importText: function (folderId, name, text) {
      return FS.create(folderId, name, "file", String(text).slice(0, MAX_FILE_CHARS));
    },

    /** Reinicia o sistema de arquivos (ação explícita do usuário). */
    reset: function () {
      data = defaultFs();
      return save();
    }
  };

  window.W11FS = FS;
})();
