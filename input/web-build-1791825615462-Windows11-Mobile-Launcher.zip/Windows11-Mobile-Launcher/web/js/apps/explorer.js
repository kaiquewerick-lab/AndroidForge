/*
 * explorer.js - Explorador de arquivos INTERNO.
 * Navega apenas pelas pastas do launcher (ver fs.js).
 * Atalhos: Enter abre, Backspace sobe, F2 renomeia, Delete envia à Lixeira,
 * Ctrl+C / Ctrl+X / Ctrl+V copiam, recortam e colam, Ctrl+A seleciona tudo.
 */
(function () {
  "use strict";

  var clipboard = null; // { mode: "copy"|"cut", ids: [] }
  var VIEW_KEY = "explorerView";

  var QUICK = [
    { id: "desktop", label: "Área de Trabalho", icon: "\u{1F5A5}" },
    { id: "docs", label: "Documentos", icon: "\u{1F4C4}" },
    { id: "images", label: "Imagens", icon: "\u{1F5BC}" },
    { id: "trash", label: "Lixeira", icon: "\u{1F5D1}" }
  ];

  function esc(s) { return W11UI.escape(s); }

  function iconFor(n) {
    if (n.id === "trash") return "\u{1F5D1}";
    if (n.type === "folder") return "\u{1F4C1}";
    if (/\.(png|jpe?g|gif|webp)$/i.test(n.name)) return "\u{1F5BC}";
    return "\u{1F4C4}";
  }

  function formatSize(n) {
    var c = (n.content || "").length;
    return c < 1024 ? c + " caractere(s)" : Math.round(c / 1024) + " KB";
  }

  window.W11Impl = window.W11Impl || {};

  window.W11Impl.explorer = function (body, api, opts) {
    opts = opts || {};
    var state = {
      folder: opts.folderId || W11FS.ROOT,
      selected: [],
      anchor: null,
      query: "",
      view: W11Storage.get(VIEW_KEY, "icons")
    };
    var fileInput = null;

    body.innerHTML =
      '<div class="app-root">' +
        '<div class="toolbar">' +
          '<button class="btn" data-act="up" title="Subir (Backspace)">&#x2191; Subir</button>' +
          '<button class="btn" data-act="new-folder">Nova pasta</button>' +
          '<button class="btn" data-act="new-file">Novo texto</button>' +
          '<span class="sep"></span>' +
          '<button class="btn" data-act="copy" title="Ctrl+C">Copiar</button>' +
          '<button class="btn" data-act="cut" title="Ctrl+X">Recortar</button>' +
          '<button class="btn" data-act="paste" title="Ctrl+V">Colar</button>' +
          '<button class="btn" data-act="rename" title="F2">Renomear</button>' +
          '<button class="btn" data-act="delete" title="Delete">Excluir</button>' +
          '<span class="sep"></span>' +
          '<button class="btn" data-act="import">Importar do aparelho</button>' +
          '<button class="btn" data-act="view">Exibição</button>' +
          '<input class="field" data-role="search" placeholder="Pesquisar nesta pasta" style="max-width:180px;height:32px">' +
        '</div>' +
        '<div class="split">' +
          '<nav class="sidebar"></nav>' +
          '<div class="main">' +
            '<div class="toolbar" style="border-bottom:none;padding-bottom:0"><div class="crumbs" data-role="crumbs"></div></div>' +
            '<div class="file-list" data-role="list" tabindex="0" aria-label="Itens"></div>' +
            '<div class="status-bar" data-role="status"></div>' +
          '</div>' +
        '</div>' +
      '</div>';

    var listEl = body.querySelector('[data-role="list"]');
    var crumbsEl = body.querySelector('[data-role="crumbs"]');
    var statusEl = body.querySelector('[data-role="status"]');
    var sidebarEl = body.querySelector(".sidebar");
    var searchEl = body.querySelector('[data-role="search"]');

    fileInput = document.createElement("input");
    fileInput.type = "file";
    fileInput.accept = ".txt,.md,.csv,.json,.html,.css,.js,text/*";
    fileInput.style.display = "none";
    body.appendChild(fileInput);

    function currentItems() {
      var items = W11FS.children(state.folder);
      if (state.query) {
        var q = state.query.toLowerCase();
        items = items.filter(function (i) { return i.name.toLowerCase().indexOf(q) !== -1; });
      }
      return items;
    }

    function render() {
      if (!W11FS.get(state.folder)) { state.folder = W11FS.ROOT; }
      state.selected = state.selected.filter(function (id) { return !!W11FS.get(id); });
      var items = currentItems();
      listEl.className = "file-list" + (state.view === "list" ? " list" : "");
      listEl.innerHTML = "";
      items.forEach(function (n) {
        var el = document.createElement("div");
        el.className = "fitem" + (state.selected.indexOf(n.id) !== -1 ? " sel" : "");
        el.dataset.id = n.id;
        el.setAttribute("role", "option");
        el.setAttribute("tabindex", "-1");
        var meta = n.type === "folder" ? "Pasta" : formatSize(n);
        el.innerHTML = '<span class="ficon">' + iconFor(n) + '</span><span class="fname"></span>' +
          (state.view === "list" ? '<span class="muted fmeta" style="margin-left:auto">' + esc(meta) + '</span>' : "");
        el.querySelector(".fname").textContent = n.name;
        listEl.appendChild(el);
      });
      if (!items.length) {
        listEl.innerHTML = '<p class="muted pad">' + (state.query ? "Nenhum item encontrado." : "Esta pasta está vazia.") + '</p>';
      }

      // Migalhas de pão
      var parts = [];
      var cur = W11FS.get(state.folder);
      while (cur && cur.id !== W11FS.ROOT) { parts.unshift(cur.name); cur = W11FS.get(cur.parent); }
      crumbsEl.textContent = "Este launcher › " + (parts.length ? parts.join(" › ") : "");
      statusEl.textContent = items.length + " item(ns)" + (state.selected.length ? " • " + state.selected.length + " selecionado(s)" : "") +
        (clipboard ? " • Área de transferência: " + clipboard.ids.length + " (" + (clipboard.mode === "cut" ? "recortado" : "copiado") + ")" : "");

      renderSidebar();
      updateButtons();
    }

    function renderSidebar() {
      sidebarEl.innerHTML = "";
      QUICK.forEach(function (q) {
        var b = document.createElement("button");
        b.className = (state.folder === q.id || (q.id === "trash" && W11FS.isTrashed(state.folder)) ? "active" : "");
        b.innerHTML = "<span></span><span></span>";
        b.firstChild.textContent = q.icon;
        b.lastChild.textContent = q.label;
        b.addEventListener("click", function () { go(q.id); });
        sidebarEl.appendChild(b);
      });
    }

    function updateButtons() {
      var inTrash = state.folder === W11FS.TRASH;
      body.querySelectorAll("[data-act]").forEach(function (b) {
        var act = b.dataset.act;
        var hide = false;
        if (inTrash && ["new-folder", "new-file", "import", "paste"].indexOf(act) !== -1) hide = true;
        if (!inTrash && (act === "restore" || act === "empty")) hide = true;
        b.classList.toggle("hidden", hide);
      });
      // Botões específicos da Lixeira
      var t = body.querySelector('[data-act="restore"]');
      if (!t && inTrash) {
        var tb = body.querySelector(".toolbar");
        tb.insertAdjacentHTML("beforeend",
          '<button class="btn" data-act="restore">Restaurar</button>' +
          '<button class="btn danger" data-act="empty">Esvaziar Lixeira</button>');
      }
    }

    function go(folderId) {
      state.folder = folderId;
      state.selected = [];
      state.anchor = null;
      state.query = "";
      searchEl.value = "";
      render();
      api.setTitle(folderTitle());
    }

    function folderTitle() {
      var n = W11FS.get(state.folder);
      return "Explorador - " + (n ? n.name : "");
    }

    function up() {
      var n = W11FS.get(state.folder);
      if (n && n.parent) go(n.parent);
    }

    function selectItem(id, ev) {
      var items = currentItems().map(function (i) { return i.id; });
      if (ev && ev.shiftKey && state.anchor) {
        var a = items.indexOf(state.anchor), b = items.indexOf(id);
        var lo = Math.min(a, b), hi = Math.max(a, b);
        state.selected = items.slice(lo, hi + 1);
      } else if (ev && (ev.ctrlKey || ev.metaKey)) {
        var idx = state.selected.indexOf(id);
        if (idx === -1) state.selected.push(id); else state.selected.splice(idx, 1);
        state.anchor = id;
      } else {
        state.selected = [id];
        state.anchor = id;
      }
      render();
    }

    function openItem(id) {
      var n = W11FS.get(id);
      if (!n) return;
      if (n.type === "folder") { go(id); return; }
      if (n.parent === W11FS.TRASH || W11FS.isTrashed(id)) {
        W11UI.toast("Restaure o arquivo antes de abrir.", "", 2500);
        return;
      }
      W11Apps.open("notepad", { fileId: id });
    }

    function selectedIds() {
      return state.selected.slice();
    }

    async function doAction(act) {
      var ids = selectedIds();
      switch (act) {
        case "up": up(); break;
        case "new-folder": {
          var name = await W11UI.prompt("Nova pasta", "Nova pasta", "Nome da pasta");
          if (name === null) break;
          var r = W11FS.create(state.folder, name, "folder");
          if (!r.ok) W11UI.toast(r.error, "error"); else { render(); }
          break;
        }
        case "new-file": {
          var fname = await W11UI.prompt("Novo arquivo de texto", "Novo texto.txt", "Nome do arquivo");
          if (fname === null) break;
          if (!/\.[A-Za-z0-9]+$/.test(fname)) fname += ".txt";
          var rf = W11FS.create(state.folder, fname, "file", "");
          if (!rf.ok) W11UI.toast(rf.error, "error"); else { render(); }
          break;
        }
        case "copy": clipboard = { mode: "copy", ids: ids }; render(); break;
        case "cut": clipboard = { mode: "cut", ids: ids }; render(); break;
        case "paste":
          if (!clipboard) { W11UI.toast("Nada na área de transferência.", "", 1800); break; }
          var res = clipboard.mode === "cut" ? W11FS.move(clipboard.ids, state.folder) : W11FS.copy(clipboard.ids, state.folder);
          if (!res.ok) W11UI.toast(res.error, "error");
          if (clipboard.mode === "cut") clipboard = null;
          render();
          break;
        case "rename": {
          if (ids.length !== 1) { W11UI.toast("Selecione um item para renomear.", "", 1800); break; }
          var cur = W11FS.get(ids[0]);
          var nn = await W11UI.prompt("Renomear", cur.name, "Novo nome");
          if (nn === null || nn === cur.name) break;
          var rr = W11FS.rename(ids[0], nn);
          if (!rr.ok) W11UI.toast(rr.error, "error"); render();
          break;
        }
        case "delete":
          if (!ids.length) { W11UI.toast("Selecione um item.", "", 1800); break; }
          if (state.folder === W11FS.TRASH) {
            var ok = await W11UI.confirm("Excluir definitivamente", "Os itens selecionados serão apagados e não poderão ser recuperados.", "Excluir");
            if (ok) W11FS.deleteForever(ids);
          } else {
            W11FS.trash(ids);
            W11Notify.push("Lixeira", ids.length + " item(ns) enviado(s) para a Lixeira.");
          }
          state.selected = []; render();
          break;
        case "restore":
          W11FS.restore(ids); state.selected = []; render();
          W11UI.toast("Itens restaurados.", "ok", 1800);
          break;
        case "empty": {
          var ok2 = await W11UI.confirm("Esvaziar Lixeira", "Todos os itens da Lixeira serão excluídos definitivamente.", "Esvaziar");
          if (ok2) { W11FS.emptyTrash(); state.selected = []; render(); }
          break;
        }
        case "import": fileInput.click(); break;
        case "view":
          state.view = state.view === "icons" ? "list" : "icons";
          W11Storage.set(VIEW_KEY, state.view);
          render();
          break;
      }
    }

    body.addEventListener("click", function (e) {
      var b = e.target.closest("[data-act]");
      if (b && body.contains(b)) { doAction(b.dataset.act); }
    });

    listEl.addEventListener("click", function (e) {
      var el = e.target.closest(".fitem");
      if (!el) { state.selected = []; render(); return; }
      selectItem(el.dataset.id, e);
    });
    listEl.addEventListener("dblclick", function (e) {
      var el = e.target.closest(".fitem");
      if (el) openItem(el.dataset.id);
    });
    // Toque: segundo toque rápido abre
    var lastTap = { id: null, t: 0 };
    listEl.addEventListener("touchend", function (e) {
      var el = e.target.closest(".fitem");
      if (!el) return;
      var now = Date.now();
      if (lastTap.id === el.dataset.id && now - lastTap.t < 420) {
        lastTap = { id: null, t: 0 };
        openItem(el.dataset.id);
      } else {
        lastTap = { id: el.dataset.id, t: now };
      }
    }, { passive: true });

    searchEl.addEventListener("input", function () {
      state.query = searchEl.value.trim();
      render();
    });

    fileInput.addEventListener("change", function () {
      var f = fileInput.files && fileInput.files[0];
      fileInput.value = "";
      if (!f) return;
      if (f.size > 1024 * 1024) { W11UI.toast("Arquivo grande demais para importar (máximo 1 MB).", "error", 4000); return; }
      var reader = new FileReader();
      reader.onload = function () {
        var res = W11FS.importText(state.folder, f.name, String(reader.result || ""));
        if (!res.ok) W11UI.toast(res.error, "error"); else { W11UI.toast("Arquivo importado para o launcher.", "ok"); render(); }
      };
      reader.onerror = function () { W11UI.toast("Não foi possível ler o arquivo escolhido.", "error"); };
      reader.readAsText(f);
    });

    // Teclado dentro do explorador
    body.addEventListener("keydown", function (e) {
      if (W11Keys.isTextField(e.target)) return;
      if (e.key === "Backspace") { e.preventDefault(); up(); return; }
      if (e.key === "Enter" && state.selected.length === 1) { e.preventDefault(); openItem(state.selected[0]); return; }
      if (e.key === "Delete") { e.preventDefault(); doAction("delete"); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "a") {
        e.preventDefault(); state.selected = currentItems().map(function (i) { return i.id; }); render(); return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "c") { e.preventDefault(); doAction("copy"); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "x") { e.preventDefault(); doAction("cut"); return; }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "v") { e.preventDefault(); doAction("paste"); return; }
    });

    // Eventos vindos do gerenciador global de atalhos (F2, Delete etc.)
    body.addEventListener("w11:rename", function () { doAction("rename"); });
    body.addEventListener("w11:delete", function () { doAction("delete"); });

    api.onResize(function () {});
    render();
    api.setTitle(folderTitle());

    return {
      destroy: function () { /* nada persistente: os dados já estão salvos */ },
      openFolder: go
    };
  };
})();
